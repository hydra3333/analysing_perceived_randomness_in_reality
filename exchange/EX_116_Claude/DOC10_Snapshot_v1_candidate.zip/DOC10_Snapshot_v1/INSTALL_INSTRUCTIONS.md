# DOC10_Snapshot_v1 - DOC-10 snapshot package (register v0.23, Architecture v0.9, handovers and related documents; document-only) (only after the owner's ratification)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\DOC10_Snapshot_v1` folder, then extract it there (`tar -xf "E:\TEMP\DOC10_Snapshot_v1_candidate.zip" -C E:\TEMP`). This package adds 26 new files and replaces 5 (`.gitattributes`, `README.md`, `CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md` and two template files). No file under `src/` or `tests/` changes, so the test suite is not needed: Claude ran it once on Linux with these documents in place (471 tests PASS).

## 0. First, check the line endings of the committed record files

The new `.gitattributes` rule (`results/** -text`) stops Git converting record files. Once it is in place, any record file whose working copy Git had already converted shows as modified, and the POST check would stop. So check first:

```bat
git status --short
git ls-files --eol results
```

Expected: `git status --short` prints nothing, and every line of the second command shows `w/lf` (one empty log file may show `w/none`). **If any line shows `w/crlf`, stop here and send Claude the output:** Claude will give you the exact commands to put those files' committed bytes back, as for the Powerball batch records on 1 November 2026.

## 1. Update, check, copy, check

```bat
git pull --ff-only
python "E:\TEMP\DOC10_Snapshot_v1\VERIFY_DOC10_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\DOC10_Snapshot_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\DOC10_Snapshot_v1\VERIFY_DOC10_INSTALL.py" --repo . --phase post
git ls-files --eol results
```

Expected: the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `31 File(s) copied`; `POST PASS`; and every results line still `w/lf` (or `w/none`). If anything prints `STOP`, do not commit: send Claude the output.

## 2. Stage, commit, check, and only then push

```bat
git add .gitattributes README.md CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md doc review
git status --short
git commit -m "DOC-10: the snapshot - register v0.23, Architecture v0.9, H-1 v1r7 and H-2 v1r8 with blurbs, holdout exposure record v0.3, template draft 4, README, Claude Code rulebook v0.3, .gitattributes results rule (document-only install)"
python "E:\TEMP\DOC10_Snapshot_v1\VERIFY_DOC10_INSTALL.py" --repo . --phase committed
git status --short
```

Expected: the first `git status --short` lists 26 lines starting with `A` and 5 starting with `M`, and nothing else; then `COMMITTED PASS`; then the last `git status --short` prints nothing (the new `.gitattributes` rule changes no stored file). Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub.

## 3. Your own edit: one line in `.claude\settings.json`

The rulebook v0.3 now names the ranking report tool in rule 7. To make Claude Code's settings refuse it too, add this one entry to the `"deny"` list in `.claude\settings.json` (it is your file; Claude does not edit it), for example after the line `"Bash(*.bat*)",`:

```
      "Bash(*Method_Rankings_Report*--game*)",
```

This exact pattern refuses any command that runs the report tool (it needs `--game`) and refuses none of the existing task commands T001 to T015 (checked). Then commit it on its own:

```bat
git add .claude/settings.json
git commit -m "settings: deny running the ranking report tool from Claude Code (rulebook v0.3 rule 7)"
git push
```
