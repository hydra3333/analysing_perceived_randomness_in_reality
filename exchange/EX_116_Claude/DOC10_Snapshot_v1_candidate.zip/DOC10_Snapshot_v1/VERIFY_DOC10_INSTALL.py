#!/usr/bin/env python3
"""Read-only installation verifier for the DOC-10 snapshot package (register v0.23, Architecture v0.9, handovers and related documents; document-only).

Claude, 31 October 2026 (from the wave 2 package verifier; adds deleted paths). Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 26 new paths are absent; the 5 modified files and the 0 files
             to be deleted still have their base bytes; guarded files unchanged in Git.
  post       after copying the overlay (and the git rm step, if any): exactly the 26 new paths
             appear, exactly the 5 modified files change and exactly the 0 deleted files are gone
             (staged deletions), all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths, modified exactly the modified files and deleted exactly the deleted files,
             all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_DOC10_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = '608025c5fa3d3e3fc9a8518c5e8dbbd23bac3eec'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r8.md': '4239f566eb4e7e4a938552a01709f169448c26514b7dc57837c7eb8238f4bcb2',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r8_introductory_blurb.md': '17633e4ec5413d12ed3c2909819b9f899a156af22631a31ee3e1b6f145ea0d2a',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r7.md': 'e209555f315ed5ee0614320c2913bbe62735f2e95468b2909549b5f30d1cd447',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r7_introductory_blurb.md': 'a5ac4774d15d927477b3d3221c59fd53dc45170eb229a197661d9f7f828c448d',
    'doc/HOLDOUT_EXPOSURE_RECORD_v0_3.md': '9f47ff3976767e6aa14ae009ac1723dd2493f0a83ab2851cd0ec5ed33547bcd5',
    'doc/METHOD_TEMPLATE/CHANGES.md': 'eda583e42f93c5734523e49e0f2c4fc849d16ce94a1f0b405b3d192287068ed8',
    'doc/Predictive_Randomness_Software_Architecture_Discussion_v0_9.md': '3a88e6d166bf09385760a4c191006d2072e01b0f323cd242abf88604012de104',
    'doc/RATIFICATION_REGISTER_v0_23.md': '312145b4d5808e941c53247a116cc2922834d59c4212c5c2a87d0b17a1a11566',
    'review/DOC10_Snapshot_v1/H1_blurb_v1r6_to_v1r7.diff': 'a677e0fea6d0ede30fd7687b35da9dfbaa0319f99a7a12749b667e4b86d26e89',
    'review/DOC10_Snapshot_v1/H1_v1r6_to_v1r7.diff': 'a4c155c92635f6c36428c504c1c23a29afafe032643dc5e5d797f3ad52c12f4c',
    'review/DOC10_Snapshot_v1/H2_blurb_v1r7_to_v1r8.diff': '4bb308e912d99f171e5ac6abff1534cfc520cb879fba07ed10007d9d11e1012f',
    'review/DOC10_Snapshot_v1/H2_v1r7_to_v1r8.diff': '09b8f753cef198caf2d8c38a32d41dce7b7886883df93dd659d2d0cba6109c22',
    'review/DOC10_Snapshot_v1/INSTALL_MANIFEST_SHA256.txt': '4ba5200b1e39709bdeba8a02921892b05e0dab0a856f2947e97b05edc5cfeb59',
    'review/DOC10_Snapshot_v1/arch_v0_8_to_v0_9.diff': 'b3151e6889d4426f1fb8dcd67330aa50d22d1d46210a05e7e9c93a3aa94c283e',
    'review/DOC10_Snapshot_v1/build_doc10.py': '83d5624357074b4a951f3338ded4d9c0901f59dccbd3d5785b27a3c38cb38412',
    'review/DOC10_Snapshot_v1/h1_section12.md': 'b8ce3654070ae95aafa5a96b93183ca46762c1aedc8cdbee08402b1e03c57549',
    'review/DOC10_Snapshot_v1/make_arch_v09.py': '236c99999f68b0193b25dabda0cd524cd07fec35e067b18c3ec3656a4107561d',
    'review/DOC10_Snapshot_v1/make_blurbs_v1r7_v1r8.py': 'd78b34b2a51fd660bfadefacff46c436d67522b937128ade50d48e0881e6e2d5',
    'review/DOC10_Snapshot_v1/make_h1_v1r7.py': 'ee11dbf911ec74fb6324132c1460a30517d53b3d4205dae6d987943f29ab4c54',
    'review/DOC10_Snapshot_v1/make_h2_v1r8.py': '5c3a49c544f1c499f584db6a14f1dfdd3784b1ac0f76317ad51c916e75cea85c',
    'review/DOC10_Snapshot_v1/make_register_v23.py': 'a828dc3544986079c30cd801531d799b7557a224043974f8af46291040317f74',
    'review/DOC10_Snapshot_v1/register_v0_22_to_v0_23.diff': '0764c34a39702ed6cedc8bc0163cd670892dc67639b61809240bd5c93e5bbc61',
    'review/Independent_ChatGPT_PERF1_Code_Review_EX115.md': '2c8f270617ea12651360bf504e4b0ff1909b11b8cf060b36e50679768beee5f5',
    'review/Independent_ChatGPT_WF1B_Code_Focused_RECHECK_EX111.md': 'bf0f76f7bbcfc02a73c791a3b90af91c1b5294108c60b7cea86e0729fd7841a3',
    'review/Independent_ChatGPT_WF1B_Code_R2_Review_EX109.md': 'd00b0aaacca89aa86baf85cb64fa20268e4a37797bb237ff6f896bcb29c3f019',
    'review/Independent_ChatGPT_WF1B_v3_Focused_Review_EX113.md': '724b307e1f701d7c4b4e3172df5ec84f38bdffdb29429e80cb40ca9114908f9a',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF
    '.gitattributes': ('6938db8d010884bcc70eedaf832f43de24d7e83b8f3c1a4738769938b892e350', 'e73570de0a035b1dc00f6687c3b445a4d19f0db5340c79e2d3bf434499f6caee'),
    'CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md': ('12b50a5cadda0d5cef73106b75ec31051fd1c6b4cbe80ddafa387bd49936f562', '509e381ed612e7572940014d33f2724172a12a0da8a8a1e76020571ede63b56b'),
    'README.md': ('0fa7baabcf99f58a9f7c22df36a28fe6df043c2b44ab0358cc78bd51891d8949', '329f571c93f631ef3f5cce752d933c5bcc576a24e99e3f3162d9a81aac429dff'),
    'doc/METHOD_TEMPLATE/METHOD_SPECIFICATION_TEMPLATE.md': ('1ef9df2dfb31fb14d1c5439311c919500ffa26a6eaa4ce70b857e60b55598cfa', '82705363c26994cea253edd49416a4bc5a6f3cfcfe615ef2261cc2e61e0b9da5'),
    'doc/METHOD_TEMPLATE/README.md': ('daac8da1f404e21bd1869609e4621f47bc25a84b3524c1688703c69ca2064214', '9e993efafe1528e9a26470d6f557f4ba32d6042b5595b802727c462a7df4d41a'),
}
DELETED = {  # path: base Git-content SHA-256 (LF)

}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'src/evaluation/numerics.py': '8f3aaa3e698e941077407cc0e1401ced2a82a9af95244190de8f10b10e163a40',
    'src/evaluation/report.py': 'b1ce781436268332daa0bf5f6037564f7774a70ab5d68de71b16811de29da82b',
    'src/evaluation/Method_Rankings_Report.py': '42b081a5303f63e243772c08de508bf8bd04c575da8b70564a24fcc31e2aed19',
    'src/evaluation/n1.py': 'f5008a72b93eb0c69f951e60e90759d2c45bbe7a721b6bed1f70672e1b9a1330',
    'src/evaluation/n1_generator.py': '004583a8d02f4282fbfefd1ec46bc3983f50bc78e0a186a836ec7b521f88e36f',
    'src/evaluation/measures.py': '2081d324e12fab909411d14346b19a24cec28316e2c13e263d194e464e9867bf',
    'src/evaluation/divisions.py': 'bd6201c310e3b9eea085062d5b84627f9d8b30fc593c06a0d82e2743a288deb2',
    'src/evaluation/collect.py': 'ea9214ebc7320a2a197e7164b97474085e116ef46cdc735c82f821a3f9486c02',
    'src/evaluation/outcome_reader.py': '8852361b271c45998867b4c18441b7287651744e73d897d03e6e18e1d8b0a8d7',
    'src/evaluation/report_writer.py': '914c8e4f883c8d4c975da6be0075afb6f4c700367d03d57be1a7e98c3e678db4',
    'src/evaluation/seed_policies.py': '83723109d13f98d91226c1b1c711bfeca5aacd6080a5fbb36b5ffaf2f708e094',
    'src/evaluation/registry/MEASURE_REGISTRY_V1.json': '133d5608c3772c3fb95a8cda586bc1ff822d5f8e003c11a386a84ae117ef9bcf',
    'src/evaluation/registry/FAMILY_REGISTRY_V1.json': '97299f32475e3e7311adc421f3dedf09f9a9c88aca2f8906adf4944904b341ac',
    'src/evaluation/seed_policies/N1_ROOT_NIST_C2_20261031T1030Z_V1.json': '4c429266b6471c0939e2d0b2d3d4bd12f62300af7085e3e9283f0e14705a154a',
    'src/evaluation/seed_policies/N1_ROOT_NIST_C2_20261106T0000Z_V1.json': '117008099e17db296cf9c6b0d2ca39b4a858e5c16a2380b8519c7b58834c17b2',
    'src/methods/_common/walk_forward.py': 'c11cf709e8a5bf6fb87b7467c94b56a82e16355e0a1bb7265efb4b4ac45922a7',
    'src/methods/Method_Walk_Forward.py': '1a1edd445566a2e9537a1636ede00ddcef6fca18cbaa021785cd35264faa7856',
    'src/methods/_common/contract_runner.py': 'c023fdc90d2ae0552558371489c39d3b583ef5c707d96394a77c2403b8dc4683',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'Run_Method_Rankings.bat': '087813da95aa163d2f308b47284710bc4f3bf1fc88014faa80dc0df9a1eb2973',
    'Run_Experiment.bat': 'dfd324d645cbbe5d528883f7a0309d5f5f3cbea47c4a49ddffaf6b0bdc7f0c5d',
    'Run_Coordinator.bat': '6ccb23302c897747432d84d1a1f4ed6fd7b2cf99faa8298ec4f3b5d82841bc70',
    'Run_Results_Updater.bat': 'c01ac19ed4a04ad133f28f4873dfe8c161bac811237b2176e70717f63bb80230',
    'doc/RATIFICATION_REGISTER_v0_22.md': 'ca955cf23b5681a534e784b4a4852acd2e8d0ccd0484e34150a05c824c0fe56b',
    'doc/Predictive_Randomness_WF1B_Supplement_Design_v0_1r1.md': 'a2f470797f31e387f44b5492ed406f1376b3eb92f2181dc76f6ac4c80168185a',
    'doc/Predictive_Randomness_Releases_and_WF1_Design_v0_1r1.md': '03f95fbe5c3f0e3771a07550b8b57d3c87fe5f7e06a8cc5d02974982ff7a12ee',
    'doc/Predictive_Randomness_CODE3_and_E1_Revision2_Design_v0_1r2.md': 'fb3b26daba2a14c6e2b5ad82e102ed9920faba14115046a820fbd0ee63b7209a',
    'doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md': '53e30a3e649b48b8a88923d08bf578caf04a4ce93d6ea6468891ca97e93a57b6',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r6.md': 'a5f74126dfead7f5ea40a5999b3944e44fe7f0764d9bdef463df1075953f9509',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r7.md': 'a59ab8504d0d63d852d66efcc9491a05d3329656eb5164eef682df57da60ec38',
    'doc/HOLDOUT_EXPOSURE_RECORD_v0_2.md': 'aec833fe031b6d1d73e6acbb81757b50b193425a6899c84d438431d9df4433e2',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        for p, old in DELETED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be deleted is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be deleted differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} files to replace and {len(DELETED)} to delete '
              'at their base version. Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        dele = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('D  ')}
        need(len(new) + len(mod) + len(dele) == len(lines),
             'changes other than new files, modified files and staged deletions:\n' + status[:600])
        need(dele == set(DELETED), 'unexpected staged deletions: ' + ', '.join(sorted(dele ^ set(DELETED))))
        for p in DELETED:
            need(not (repo / p).exists(), f'deleted path still on disk: {p}')
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths, {len(MODIFIED)} modified files and '
              f'{len(DELETED)} staged deletions, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    for p, old in DELETED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the deleted file: {p}')
        need(run(repo, 'cat-file', '-e', f'HEAD:{p}').returncode != 0, f'deleted file still in HEAD: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}, **{p: 'D' for p in DELETED}}
    need(got == want, 'the last commit did not change exactly the expected paths; differences (path, status): ' +
         repr(sorted(set(got.items()) ^ set(want.items()))))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files, modified '
          f'{len(MODIFIED)} and deleted {len(DELETED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
