# WF1A_Install_v2 - WF-1A package (the walk-forward driver; the real-development switch turned on) (only after the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\WF1A_Install_*` folders, then extract it there (`tar -xf "E:\TEMP\WF1A_Install_v2.zip" -C E:\TEMP`). This package adds 10 new files, replaces 5 existing files (`.gitignore`, `src/methods/Method_Contract_Runner.py`, `src/methods/_common/contract_runner.py`, `tests/test_e2r_dispatch.py`, `tests/test_e2r_runner.py`); nothing else changes.

## 1. Update, check, copy, check, and the tests (one block; do not skip the last command)

```bat
git status --short
git pull --ff-only
python "E:\TEMP\WF1A_Install_v2\VERIFY_WF1A_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\WF1A_Install_v2\repo_overlay\*" . /E /Y
python "E:\TEMP\WF1A_Install_v2\VERIFY_WF1A_INSTALL.py" --repo . --phase post
.venv\Scripts\python.exe "E:\TEMP\WF1A_Install_v2\RUN_WF1A_SUITE.py" --repo .
```

Expected: `git status --short` prints nothing (if it prints anything, stop and send Claude the output); the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `15 File(s) copied`; `POST PASS`; then `SUITE PASS` (326 tests; the only allowed skips are symlink tests: on Windows without symlink rights, up to 3). E2R-T12 starts up to six ordinary Python worker processes and lets them finish normally. The tests change nothing in the repository. If anything prints `STOP` or `FAILED`, do not commit: send Claude the output.

## 2. Stage, commit, check, and only then push

```bat
git add .gitignore review src tests
git status --short
git commit -m "WF-1A: the walk-forward driver; ENABLE_CONTRACT_REAL_DEVELOPMENT turned on (owner decision WF1-3); real-development runs under results/real/development/"
python "E:\TEMP\WF1A_Install_v2\VERIFY_WF1A_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 10 lines starting with `A`, 5 starting with `M`, and nothing else; then `COMMITTED PASS`. Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub. Claude pushes nothing to the repository while you install.
