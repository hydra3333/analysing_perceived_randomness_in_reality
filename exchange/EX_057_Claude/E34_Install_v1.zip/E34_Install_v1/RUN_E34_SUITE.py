#!/usr/bin/env python3
"""E_3/E_4 package: run all 242 current tests, module by module, and compare with the expected counts.

Claude, 30 October 2026 (from the E_6 package runner; adds tests/test_polynomial_fits.py, 19 tests, and tests/test_e3_e4_polynomial.py, 13 tests). Owner-run on Windows, after the overlay is copied and before committing.
Offline: the 84 earlier accepted tests (E_1's goldens, the protected-coordinator AST tests, the E1-ALIGN
guards), the 54 E2R-CODE-1 contract tests (T12 starts up to six local Python worker processes through
concurrent.futures and lets them finish normally), the 52 E2R-CODE-2 tests (tests/test_e2r_dispatch.py,
tests/test_e2r_runner.py; temporary registries, method folders, invented masters and run folders only),
the 20 E_6 tests (tests/test_e6_beta_bernoulli.py), the 19 tests of the shared polynomial helper
(tests/test_polynomial_fits.py; invented series only) and the 13 E_3/E_4 tests (tests/test_e3_e4_polynomial.py;
invented masters and temporary copies only).
They read no holdout, start no Windows process, and make no network access; this script only runs them.
Each module runs in its own `python -B -m unittest -v` process (no bytecode written).
A skip is allowed only where a test skips because Windows cannot create a symlink (the reader-contracts
symlink subtest, the exit-receipt symlink test and CODE-2's dangling-symlink publication test). Anything
else stops.
Usage (repository root):  .venv\\Scripts\\python.exe RUN_E34_SUITE.py --repo .
"""
import argparse, os, platform, re, subprocess, sys
from pathlib import Path

EXPECTED = [  # module, tests; first the 65-test standard suite, then the other 19
    ('tests.test_multigame_reader_contracts', 10), ('tests.test_multigame_static_and_timing', 6),
    ('tests.test_multigame_launch_and_manifest', 11), ('tests.test_multigame_exit_receipt', 18),
    ('tests.test_multigame_science_allowlist', 6), ('tests.test_multigame_console_and_synthetic_scorer', 7),
    ('tests.test_t05_hardening', 2), ('tests.test_e1_align', 5), ('tests.test_e1_standalone', 13),
    ('tests.test_multigame_windows_lifecycle_review', 6),
    ('tests.test_e2r_contract', 53), ('tests.test_e2r_prefix', 1),
    ('tests.test_e2r_dispatch', 18), ('tests.test_e2r_runner', 34),
    ('tests.test_e6_beta_bernoulli', 20), ('tests.test_polynomial_fits', 19),
    ('tests.test_e3_e4_polynomial', 13),
]
SYMLINK_SKIP_OK = {'tests.test_multigame_reader_contracts', 'tests.test_multigame_exit_receipt',
                   'tests.test_e2r_runner'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    repo = ap.parse_args().repo.resolve()
    env = {k: v for k, v in os.environ.items() if k != 'PYTHONPATH'}
    env['PYTHONPATH'] = os.pathsep.join(str(repo / p) for p in ('src', os.path.join('src', 'methods'), 'tests'))
    print('environment:', platform.system(), platform.release(), 'Python', platform.python_version(), sys.executable)
    bad, total, skipped = [], 0, 0
    for mod, want in EXPECTED:
        r = subprocess.run([sys.executable, '-B', '-m', 'unittest', '-v', mod], cwd=repo, env=env,
                           capture_output=True, text=True)
        err = r.stderr
        m = re.search(r'^Ran (\d+) tests?', err, re.M)
        ran = int(m.group(1)) if m else -1
        last = err.strip().splitlines()[-1] if err.strip() else '(no output)'
        skips = [ln.strip() for ln in err.splitlines() if re.search(r"\.\.\. skipped|\) \.\.\. skipped|skipped '", ln)]
        total += max(ran, 0); skipped += len(skips)
        print(f'{mod:<52} ran {ran:3d} (expected {want:2d})  skipped {len(skips)}  {last}')
        for s in skips:
            print('    skip:', s[:200])
        if r.returncode != 0 or ran != want or not last.startswith('OK'):
            bad.append(f'{mod}: exit {r.returncode}, ran {ran} expected {want}, "{last}"')
        for s in skips:
            if mod not in SYMLINK_SKIP_OK or 'symlink' not in s.lower():
                bad.append(f'{mod}: unexpected skip: {s[:120]}')
    print(f'total ran {total} (expected 242); skips {skipped}')
    if bad:
        print('SUITE STOP:'); [print('  ' + b) for b in bad]; sys.exit(1)
    print('SUITE PASS: all 242 tests ran and passed; only the allowed symlink skips, if any.')


if __name__ == '__main__':
    main()
