# E_3/E_4 package v1 - E_3 and E_4 revision 1 and their shared helper, installed non-runnable, and register v0.16 (only after the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Install the E_6 package first; this package checks that it is there.** **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\E34_Install_*` folders, then extract it there (`tar -xf "E:\TEMP\E34_Install_v1.zip" -C E:\TEMP`). This package adds 69 new files and replaces 1 existing file (`src/methods/Method_Contract_Runner.py`); nothing else changes. E_3 and E_4 are installed **non-runnable**: every E_3 or E_4 request is refused until a separate release package.

## 1. Update, check, copy, check

```bat
git status --short
git pull --ff-only
python "E:\TEMP\E34_Install_v1\VERIFY_E34_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\E34_Install_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\E34_Install_v1\VERIFY_E34_INSTALL.py" --repo . --phase post
```

Expected: `git status --short` prints nothing (if it prints anything, stop and send Claude the output); the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `70 File(s) copied`; `POST PASS`.

## 2. Tests, before committing (offline; nothing in the repository is changed)

```bat
.venv\Scripts\python.exe "E:\TEMP\E34_Install_v1\RUN_E34_SUITE.py" --repo .
```

Expected: `SUITE PASS` (242 tests; the only allowed skips are symlink tests: on Windows without symlink rights, up to 3). E2R-T12 starts up to six ordinary Python worker processes and lets them finish normally. **Do not skip this step.** If anything in steps 1 or 2 prints `STOP` or `FAILED`, do not commit: send Claude the output.

## 3. Stage, commit, check, and only then push

```bat
git add doc review src tests
git status --short
git commit -m "E_3 and E_4 revision 1 with the shared polynomial helper (installed non-runnable) and register v0.16"
python "E:\TEMP\E34_Install_v1\VERIFY_E34_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 69 lines starting with `A` and 1 starting with `M`, and nothing else; then `COMMITTED PASS`. Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub. Claude pushes nothing to the repository while you install.
