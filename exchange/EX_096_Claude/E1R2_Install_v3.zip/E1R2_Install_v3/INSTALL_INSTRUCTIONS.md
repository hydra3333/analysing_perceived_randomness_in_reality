# E1R2_Install_v3 - CODE-3 and E_1 revision 2 package (retirement tooling; E_1 revision 1 archived; E_1 revision 2 installed and released) (only after the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\E1R2_Install_*` folders, then extract it there (`tar -xf "E:\TEMP\E1R2_Install_v3.zip" -C E:\TEMP`).

This package adds 31 new files and 2 release entries, and replaces 7 existing files (`src/methods/E_001/multigame_e1.py`, `src/methods/E_001_Historical_Appearance_Frequency.py`, `src/methods/_common/walk_forward.py`, `src/methods/contract_adapters/e_001.py`, `tests/test_e2r_dispatch.py`, `tests/test_rel1_release.py`, `tests/test_wf1a_walk_forward.py`). Nothing else changes. It installs **behind a temporary barrier**: E_1's own `src/methods/E_001/IN_DEVELOPMENT.txt`, copied first and deleted last, and never committed. While the barrier is there, E_1 cannot run by any route.

**Before you start, and until after the push: run or resume no batch, of either game, and no E_1 run.**

## 1. Update, then the five steps behind the barrier, then the tests (one block)

Each line runs its action only if the check before it printed PASS (`&&`), so a STOP stops everything after it.

```bat
git status --short
git pull --ff-only
python "E:\TEMP\E1R2_Install_v3\VERIFY_E1R2_INSTALL.py" --repo . --phase pre && xcopy "E:\TEMP\E1R2_Install_v3\barrier_overlay\*" . /E /Y
python "E:\TEMP\E1R2_Install_v3\VERIFY_E1R2_INSTALL.py" --repo . --phase barrier && xcopy "E:\TEMP\E1R2_Install_v3\repo_overlay\*" . /E /Y
python "E:\TEMP\E1R2_Install_v3\VERIFY_E1R2_INSTALL.py" --repo . --phase code && xcopy "E:\TEMP\E1R2_Install_v3\release_overlay\*" . /E /Y
python "E:\TEMP\E1R2_Install_v3\VERIFY_E1R2_INSTALL.py" --repo . --phase release && del src\methods\E_001\IN_DEVELOPMENT.txt
python "E:\TEMP\E1R2_Install_v3\VERIFY_E1R2_INSTALL.py" --repo . --phase post && .venv\Scripts\python.exe "E:\TEMP\E1R2_Install_v3\RUN_E1R2_SUITE.py" --repo .
```

Expected, in order: `git status --short` prints nothing (if it prints anything, stop and send Claude the output); the pull says `Fast-forward` or `Already up to date`; `PRE PASS` then `1 File(s) copied`; `BARRIER PASS` then `38 File(s) copied`; `CODE PASS` then `2 File(s) copied`; `RELEASE PASS` (the `del` prints nothing); `POST PASS`; then `SUITE PASS` (350 tests; the only allowed skips are symlink tests: on Windows without symlink rights, up to 3). E2R-T12 starts up to six ordinary Python worker processes and lets them finish normally. The tests change nothing in the repository.

**If anything prints `STOP` or `FAILED`:** do not commit and do not push; run nothing; send Claude the whole output.
- **Before `POST PASS`:** the barrier is still in place. Leave it there.
- **After `POST PASS`** (the tests, or a later step): nothing is undone automatically. If you want E_1 closed again while Claude looks, copy the barrier back (`xcopy "E:\TEMP\E1R2_Install_v3\barrier_overlay\*" . /E /Y`); then `python "E:\TEMP\E1R2_Install_v3\VERIFY_E1R2_INSTALL.py" --repo . --phase release` must print `RELEASE PASS`.

## 2. Stage, commit, check, and only then push

```bat
git add archive doc review src tests
git status --short
git commit -m "CODE-3 and E_1 revision 2: E_1 revision 1 archived (archive/methods/E_001/r1/); revision 2 admits real development runs (owner decision WF1-13); design v0.1r2"
python "E:\TEMP\E1R2_Install_v3\VERIFY_E1R2_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 33 lines starting with `A` and 7 starting with `M`, and nothing else (no `IN_DEVELOPMENT.txt`); then `COMMITTED PASS`. Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub. Claude pushes nothing to the repository while you install. Only after Claude's check: the first 40-variant batch, when you decide.
