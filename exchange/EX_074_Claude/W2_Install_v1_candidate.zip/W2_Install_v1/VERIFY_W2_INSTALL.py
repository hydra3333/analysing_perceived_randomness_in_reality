#!/usr/bin/env python3
"""Read-only installation verifier for the wave 2 package (E_2, E_17, E_18 and E_19 revision 1 with their shared helper, installed non-runnable; the template's draft 3).

Claude, 30 October 2026 (from the E_3/E_4 package verifier). Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 87 new paths are absent; the 3 modified files still have their
             base bytes; guarded files unchanged in Git.
  post       after copying the overlay: exactly the 87 new paths appear and exactly the 3
             modified files change, all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths and modified exactly the modified files, all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_W2_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = '8f44d50066ecf6fe971ea2d97d49a4ea9b8b4b1d'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/Predictive_Randomness_Wave2_E2_E17_E18_E19_Design_v0_1r2.md': '2ab342911701edf1e93ad590e4765a3efac54a76d732b7fd2c5875c7d363fe74',
    'doc/RATIFICATION_REGISTER_v0_19.md': 'd6822419bf76a9232e59b37cd805efe9dd402b91d786dd2be7726d0d91a16197',
    'review/Independent_ChatGPT_Wave1_R2_and_Register_v18_Review_v0_1.md': 'baf0914044f88ef5162ed6d71d7f5f0dc5d93f6f7e33f1dfa8af5541c38ffa90',
    'review/Independent_ChatGPT_Wave2_R3_Review_v0_1.md': '75ec652caf27c1db5594625bbc0ad4b0f587ffc233e59c68bc25695841913c51',
    'review/Independent_ChatGPT_Wave2_v0_1r1_R3_RECHECK_v0_1.md': '64a48a8cb91633fad3027860fd6ff2ca770d35a88040f936404294dbc2ade56a',
    'review/Independent_ChatGPT_Wave2_v0_1r2_Focused_RECHECK_v0_1.md': 'e5b5116be5448601d82eba27fb4efcd86fa3c6400a762a9ea275ece474ef2305',
    'review/W2_Install_v1/INSTALL_MANIFEST_SHA256.txt': 'bc80eb17abadf9cd1009ca5975c6407738ee9b06eca534d50a56d6fa212cc968',
    'review/W2_Install_v1/design_probes_v0_1r2.txt': '46cca12a77b4bfe529aee152d27717135dbb30fa394338bc725bb9417547bba5',
    'review/W2_Install_v1/mutations_py313.txt': '779d456e3f04ef793c1a203420e2b5c282d1d51645dc42705047e3053e83d37d',
    'review/W2_Install_v1/replaced_files_base_to_v1.diff': '81c1633daff8e5de126a059cffc7be70ae1adbb9742a48c533c9c653e8174676',
    'review/W2_Install_v1/suite_py313.txt': '048317cb982745b4823e9c160e89b838b8bb76f79b4e32ac1274e7178ba9e2ee',
    'review/W2_Install_v1/suite_py315.txt': '61749e54c9810d0ecc51f9e6e386097a1c4526abb5ffdb2bdc0eb2e648c91a15',
    'review/W2_Install_v1/template_trial_v3.txt': 'f8afbce28cdc49ae82ca8387528f231f91cd2c2fd91a70a79c3f84c3d8a7bf2e',
    'review/W2_Install_v1/tools/edit_runner.py': '0b14965fbefc8bc2f7844da1a6148f62f935a1e07f46264f7ab99fb2cbd5ee4e',
    'review/W2_Install_v1/tools/make_template_draft3.py': '7898d505977977387847125cac42ef7a202a63570e4748d4e439edb3a31192c5',
    'review/W2_Install_v1/tools/make_wave2_contract_data.py': '0341d4134b75a0ed3508c5b6786fddd1c8726d3f83e18401c13dba533b8a2e07',
    'review/W2_Install_v1/tools/reference_wave2.py': '078006f5394b67a73f0815b73cdf5abd42b8151b551845efee2ba67b5fda07ed',
    'review/W2_Install_v1/tools/template_trial_v3.py': '7f10b1d1dd4832cec102c6bf972921c6ab40d17c241dc2576c094abec3878d19',
    'review/W2_Install_v1/tools/w2_mutations.py': '042834959ab259cd627c22386f9e181dfbf2ac5b59f7101b35d9587e65293f58',
    'review/W2_Install_v1/tools/write_wave2_methods.py': 'c0b72ed070a9a3575dd6c3180e50960b2c5f99a3d466cc7452d4737d3f91c09f',
    'src/methods/E_002/IN_DEVELOPMENT.txt': '2b40a5620d83a7746bbe8b0e62faf02809e29bf57193aa9c52c5a85a9a98913e',
    'src/methods/E_002/__init__.py': 'd1650f4375a47c932da0d3e4c03e6ce84c8b8fc7e2d3b5362d6da753b2f2a133',
    'src/methods/E_002/contract.py': 'b6f253131ea8d390a847f177665fefffbe57dab977596f1abb1877d73c159b4d',
    'src/methods/E_002/variants.py': 'ffb0b88774a8f0b4ef8a37d175dd5368d517286e7b70f756e874f52d1522f236',
    'src/methods/E_017/IN_DEVELOPMENT.txt': '901c5df586c654e8949205151a7c00cbd6a894cef633ec0784d108f7fcc022da',
    'src/methods/E_017/__init__.py': '818d3bf627580aa5d029e77003857c8e31d2964df375fa7dc4354f9d1d733f54',
    'src/methods/E_017/contract.py': 'd2a70ff1b732d7716a122a7e5a4c4e955bc4c27ab0f8ee6e819faaf96baea6dd',
    'src/methods/E_017/variants.py': 'd7198ed6fc4ba1d1909c8d2bbb0187945573f2ab25fda6e1707c915b15b798b6',
    'src/methods/E_018/IN_DEVELOPMENT.txt': 'd3d59d6fbeeab40dcda8bede03f64009f6c09acecb6c04ee0783b0e07df9c5ef',
    'src/methods/E_018/__init__.py': '74a177f7a6b6d8b367bdc73abb804b83f7852ea267a0a8bc66eaa65f6aede314',
    'src/methods/E_018/contract.py': '7eb180820cc1af4322f2d24ac35e907c6bf2eb5f248bfd4ed0a3cae3d1ebfc6e',
    'src/methods/E_018/variants.py': '46f9e36602ead8e932ce8b3193370ed86fc22f1cd10a1f9d5033e234839a891c',
    'src/methods/E_019/IN_DEVELOPMENT.txt': '22428c736b470b05400093a498836aac97808fbce8be4ed6372a1fec9cddcacb',
    'src/methods/E_019/__init__.py': '580fd2c6263d849acc523617b5ef22516dbf480520c50cf51f932559ad177cfc',
    'src/methods/E_019/contract.py': 'f3945ed8d8a3fe1363ec2a6c2351bc666c64b01cd679c9e4723ec311d381f56e',
    'src/methods/E_019/variants.py': 'a25cece3909d40f9c33aa2eb2490cc64a82fefdf424f600671aa12daf0be7e51',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_17/HAZARD_BINS_C100_V1/r1.json': 'f2f96c44d04940bf7947af7bc949d0147f0d45b7c2b336565dd97f5c6c8fccfa',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_17/HAZARD_BINS_W208_C100_V1/r1.json': '2a03bd5e45f01f10e7c608eb14f60539b596c9d96193dc8bc3c1ab60533047ac',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_17/HAZARD_LOGAGE_SIGN_V1/r1.json': '9a8342a577f0cc64037a16cd67c76eff96efca896b9ac3df165f64a3db4eb60d',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_18/MIX4_ALL_C10_V1/r1.json': 'bc92579b77e85062032f28e6626a1ba4f5ac1a1522b3ca95f4e2f8b9738921e9',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_18/MIX4_W104_C10_V1/r1.json': '49f90ebd3851c00a95bc58c717010470ff932b0014ea6205b55a941baa0480ac',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_18/MIX4_W208_C10_V1/r1.json': 'e7606ecbfd5f8903c50f1a29e944d296dabd8e41ed1c2430863fe9d57d56e79a',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_19/PERIODIC_T2_V1/r1.json': '62789082573aaf60f52a54c74cbd948a733d093c83d5eccccd382e716c682d25',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_19/PERIODIC_T3_V1/r1.json': '16a5d9dead75345e744cd077d9ef25ee5ba7135d3d0b09ece6dbb5cb2ccf472e',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_19/PERIODIC_T4_V1/r1.json': 'd83fc14269fae241f7801812bf63132337ed00827e7b40430595bac24fcbfeae',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_2/RECUR_MEAN_ALL_V1/r1.json': 'bbba4bee9ce74bfce3ed09ed03fb4586acca2eeda76bef29975f974e2467de0a',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_2/RECUR_MEAN_LAST8_V1/r1.json': 'e99f22cd4f44043544e84a30eb82d2b7dd1b615418f2a36b1c35d974ff7b41cb',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_2/RECUR_MEDIAN_ALL_V1/r1.json': '7dce794f89ebc9f88614c14ba1b5051173bdd5d4bd76457871ca90a9c4cbddc4',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_17/HAZARD_BINS_C100_V1/r1.json': '5c569355f959fd7afdac5ac794eb5264ff5ffa5d95858e6fccad98db6c499a30',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_17/HAZARD_BINS_W208_C100_V1/r1.json': '35f52c8c45b31a52e7a8cee24e1702de3005c28681745a17df9c0966a6cdbea4',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_17/HAZARD_LOGAGE_SIGN_V1/r1.json': '8f700fd880b500bce7573bf03d261024207961737a12aa187e03f379eb922f27',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_18/MIX4_ALL_C10_V1/r1.json': '061dc54bc75ba81b9adbee2e25b858c2e3f032fd77967e5cfaf8b9d46e791ad3',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_18/MIX4_W104_C10_V1/r1.json': '9faaf91cde0637a6591b5d9194472555e450f5aa929d44add8a055509df4a697',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_18/MIX4_W208_C10_V1/r1.json': 'a4af701c39f5d38d8af61688bed3fecdf281f1015c045f0cab28de841b88a5f3',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_19/PERIODIC_T2_V1/r1.json': '9c958db77cdcac4e5fb17fe1f95989228461735e1bc14f8d9e6afb2589c09b54',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_19/PERIODIC_T3_V1/r1.json': '52ae723d79abc6e12203549fc178aa60ce7256f1d43eec73463346f697870119',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_19/PERIODIC_T4_V1/r1.json': '427d26ceb48ae6644e3fdc2eb1d1c228862fe6ccb4e7ef25bbd25b26e08da992',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_2/RECUR_MEAN_ALL_V1/r1.json': '7810f447e22806396f3c0351385d6821c218fd77e8b6725fbd6eb9717d8ad903',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_2/RECUR_MEAN_LAST8_V1/r1.json': '72c59217e7dc7de7abc421c1642b19061889987c9d0f921818fa37c2f6c884fb',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_2/RECUR_MEDIAN_ALL_V1/r1.json': '55fbc3ab5df7c6d366377986dd9ecd69ace7c62a47a7820f258110253103facf',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_17/HAZARD_BINS_C100_V1/entry_0001.json': 'b9221d0744d1535b755f777aebb0d69c06a529fd723b40e2d26537a468bb4a02',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_17/HAZARD_BINS_W208_C100_V1/entry_0001.json': 'a8789a90939448d2326cde0786f2d071641fc18b790cbfb4e3296694519f1bde',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_17/HAZARD_LOGAGE_SIGN_V1/entry_0001.json': '052c0213d2949112c3ff255f4da10fd29328f44127d6636a534180cbd58f7091',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_18/MIX4_ALL_C10_V1/entry_0001.json': 'b4dc68a72e35a1bb74b4d928aa6219dd5a55b1e6ee6b05a875ea955a90865e09',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_18/MIX4_W104_C10_V1/entry_0001.json': 'dd71e5ade9720b600a678bb44b78f3688eb84df242b98fdc5e832ce176454462',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_18/MIX4_W208_C10_V1/entry_0001.json': '9103a83548ada86f6783b9c597a5cbdc3eb10c85dc78d8bc1a91961e8098949b',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_19/PERIODIC_T2_V1/entry_0001.json': 'adb702494a02ec0d8c6cb8e1d116166dc0ac48653ff910fa9939e6efba4eef08',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_19/PERIODIC_T3_V1/entry_0001.json': 'eda8793793c4a689316db877a7a795cf1c52b3a60ee9958c8a29b3bc222ad304',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_19/PERIODIC_T4_V1/entry_0001.json': '1f8369115df83f202c6f827dcc626ee500909634d5a8e7b58029f2b2a36536ad',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_2/RECUR_MEAN_ALL_V1/entry_0001.json': '611895ec0e813343ffae65cc8b2357443f8787e44eb1f16e7533ae1f217912c2',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_2/RECUR_MEAN_LAST8_V1/entry_0001.json': '0321994bec3b8405f3d298ee9aac2faf5db86dc81cd13f5740e84c561fc90953',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_2/RECUR_MEDIAN_ALL_V1/entry_0001.json': '8bd7374f96f919897ca7163576f0dfe3fb8179f76ed2bd030df991e686860d96',
    'src/methods/_common/contract_data/registry/POWERBALL/E_17/HAZARD_BINS_C100_V1/entry_0001.json': '380ec894a69571604dc8ac6244ffce205686509e1dea705366a7df48decb45dc',
    'src/methods/_common/contract_data/registry/POWERBALL/E_17/HAZARD_BINS_W208_C100_V1/entry_0001.json': '9331336945adf884b51acccc275041fee252fd858519749a2d401db7c09a5c5b',
    'src/methods/_common/contract_data/registry/POWERBALL/E_17/HAZARD_LOGAGE_SIGN_V1/entry_0001.json': 'c244fa78e545822ac278b11db9656e44c7eeabf6cff5c7e716133a08228949c8',
    'src/methods/_common/contract_data/registry/POWERBALL/E_18/MIX4_ALL_C10_V1/entry_0001.json': '25847301725ac6ad4aed7ccc815624857a7b469babb3505b185457f134641998',
    'src/methods/_common/contract_data/registry/POWERBALL/E_18/MIX4_W104_C10_V1/entry_0001.json': '8fc9c30450484933bc4e20604c18a2f01d40c2561b31e0b5da10f6a45482099d',
    'src/methods/_common/contract_data/registry/POWERBALL/E_18/MIX4_W208_C10_V1/entry_0001.json': '88ec1113452ff82915032c2f7d2c28692f0dabceb68251522f040aa80278cf80',
    'src/methods/_common/contract_data/registry/POWERBALL/E_19/PERIODIC_T2_V1/entry_0001.json': '83407a0e531a8170a7c5fd134f33092cec90cc4957044f7bcabd051be8580853',
    'src/methods/_common/contract_data/registry/POWERBALL/E_19/PERIODIC_T3_V1/entry_0001.json': 'a19ec47f8c77c3028289b34eb95c0ea2cc147a9f0326ed66e7520012d1e2d52c',
    'src/methods/_common/contract_data/registry/POWERBALL/E_19/PERIODIC_T4_V1/entry_0001.json': 'e8a8708021d1d1b4fea7e8f67bfe0da39adabd3cd31ffc5116ea8c93cef46204',
    'src/methods/_common/contract_data/registry/POWERBALL/E_2/RECUR_MEAN_ALL_V1/entry_0001.json': 'c70bee767387c6388b6adb2c2968a3c3e53c40d97807071d8712bfb87716b300',
    'src/methods/_common/contract_data/registry/POWERBALL/E_2/RECUR_MEAN_LAST8_V1/entry_0001.json': '17df4ae692b29a9262f883e2f24919a0f47557d817ebb5d68be6860b0a7dc687',
    'src/methods/_common/contract_data/registry/POWERBALL/E_2/RECUR_MEDIAN_ALL_V1/entry_0001.json': '74805c81ae443fa6468e17544022953e37745663af43ef6d44cd5a20e53627c5',
    'src/methods/_common/recurrence_gaps.py': '37b1be1d33bd7da5291fe36cf40272b1f12673f36a9fda8e20d7d6a26fdd1f25',
    'tests/test_recurrence_gaps.py': 'e2e89cf3a61d5ff09861fd65b6fe4911acd968a8ac743a5dca80d295e8e7f5ad',
    'tests/test_wave2_recurrence.py': '7db0f7c67b559a7d346d607f92c4f4b60e10b1524be391aad9f23c3f0b48ff67',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF
    'doc/METHOD_TEMPLATE/METHOD_SPECIFICATION_TEMPLATE.md': ('759ad3a0151e7292a45abfc0ea8b8b1f9ba70210511b19ebf38e5be7425a31c3', '1ef9df2dfb31fb14d1c5439311c919500ffa26a6eaa4ce70b857e60b55598cfa'),
    'doc/METHOD_TEMPLATE/README.md': ('91eca77e9b3e0ec46d8ef2ae4186c7035f97f0caddbdde816b42e44470764b68', 'daac8da1f404e21bd1869609e4621f47bc25a84b3524c1688703c69ca2064214'),
    'src/methods/Method_Contract_Runner.py': ('aca387afa81472cc6b9e3eff7c9e89f52a2c627e6dae70221fa2f82fb67c93c8', 'e6b2d511afc02133d2887c1a9f56f22b1eb63e71196cf37d8d5c61a5671addc4'),
}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'doc/RATIFICATION_REGISTER_v0_18.md': '85125c4900dabee53d2674d0ca3a18abbed64d5179b7f0b178300f928de93c97',
    'doc/RATIFICATION_REGISTER_v0_17.md': '268e72b2a435628550079682040ae2eab69b5a08baa3241e4ee9e47e54499d17',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r5.md': '1214bd971058ddd6cc680526fd80375bdbbd6db17397e41ba4c14ae5467101e1',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r6.md': 'db40f40ef22995fc65a949243001858f1d7d1285713c9954531ae6b601fc5616',
    'doc/Predictive_Randomness_E3_E4_Polynomial_Fit_Design_v0_1.md': 'b9d60b4c753bb90c6a7ca302fb4802c353b0ae23fbe82c2b417ae7b089fad072',
    'src/methods/_common/polynomial_fits.py': '1d1c8d1078638607c0c0f584184834a95285f6d3e00b544a2a8a103e5d831615',
    'src/methods/E_003/contract.py': '8509ea3641d48ed8b3771237beaa3205d31a09a491049b1687bc09177059e87f',
    'src/methods/E_004/contract.py': '68f967e1b86d9076235d8a94c15d3098f226ad7b97b24afbfed60406ccc74043',
    'tests/test_e3_e4_polynomial.py': 'ee038a2dd045698b81ace4bdfa2c9571290838ad97714bb273178ec55dddd562',
    'doc/METHOD_TEMPLATE/method_folder/model.py.txt': '2baf07c9a2c980012777c6cd370262aea8647d62e5d94a97bc025c4af1c9d72f',
    'doc/METHOD_TEMPLATE/test_template.py.txt': 'dcdb3c061d24f3029f5aafdb8aa0b64db35ca713f55c65462505d60f19d6fff4',
    'doc/METHOD_TEMPLATE/method_folder/contract.py.txt': 'fe2c4242fdeb3910d043541fb1c88ca9dc8c2ddce6eecb037118cdea4f0596b9',
    'doc/Predictive_Randomness_Wave1_E7_E8_E9_E10_Design_v0_1r1.md': '06b491225812e14962aef99e299cbd6c003be68bb5a73425e566f1b1fe685060',
    'src/methods/_common/occurrence_counts.py': '76e39bf0aeb3273d0f5a9a41391d0ceac1cfd6a7b06955cbb80518e05f5cbde9',
    'src/methods/E_007/contract.py': '756e526776eb6a0a8e991d41bafcdd17ddd68259e5dba631dac9a4458f51487d',
    'src/methods/E_008/contract.py': 'd5073c29e3ce6de75d53884af31133c2e77b83f1d3a40fbb234d509e885f5000',
    'src/methods/E_009/contract.py': '09538733263b95167dfdd1bde3e87252659df84648a3fbd7ea3205118b642dcd',
    'src/methods/E_010/contract.py': '99324f3310899499633c61fe50001be8ea96938567ea0eb35610c58004e39f7a',
    'src/methods/E_010/IN_DEVELOPMENT.txt': 'c4ed10bb77c2bfd39cdb2cc8f72b174528c75f97d3cb4f5328785c08f0b36c71',
    'tests/test_occurrence_counts.py': '473c33ef15c13e9d44d6c53119ff8ccf49baeb4eab33406cc257f3273a84bbdb',
    'tests/test_wave1_frequency.py': 'd82d98173658f0d6edc766cbd21e51cdb3c7f3834db0a82846061c236aa78313',
    'doc/Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md': '0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954',
    'doc/Predictive_Randomness_E6_Specification_and_Method_Template_Design_v0_1.md': 'cef16b44fb7088ec018e0a8d6f233231c04e3fe6d5431cf0a2e604ad8f6fc82e',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/canonical_encoding.py': '2096d8adb40737373169aea6c5d94147daa2b16ae6c961bbfcc6063e333efcac',
    'src/methods/E_001/multigame_e1.py': '3c4a2305873aed7dc0457efcb898519f6e888ed72557670da1e8b0f9687ca462',
    'src/methods/E_001/e1_standalone_contract.py': 'd9ef642c2949b1b2a10232d614ba1306365abaefe65338b5c0aa9e3d9f285e50',
    'src/methods/_common/contract_vocab.py': '6e30b5be8d024fa647a2406e38b44cdf3b3c0c84f0468d84e168e9fde40d4ec8',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/methods/_common/contract_task.py': 'e58c0ab288b3292d3eeaf49e7cf9170b0341ff53d23cbde839b8cdbd716a31b3',
    'src/methods/_common/contract_forecast.py': 'be88a1d640098a6990f14090108524e1d7437a425e1b6254672164b6fc7f8121',
    'src/methods/_common/contract_receipts.py': 'e6d159e65dcf8269ea5576a7338d3ebcbf2d5dc0c06b06f1517189cc215908fd',
    'src/methods/_common/contract_registry.py': '00082aad1754edbf2380c2caa144b0c79a12e2b6f26eb806d85903f177f11064',
    'src/methods/_common/contract_dispatch.py': '7f026bc8ff6a0a13120031371acee455734d12a79cbe923f988ba12c6a92a322',
    'src/methods/_common/contract_publication.py': '665ed261bb1504854b0c3be7c60a84ad6ecab6559d74d949c19f85eaa7ae809b',
    'src/methods/_common/contract_runner.py': 'a45c2612fdef0130b7b2a755b4d1db6aaafbdbc337d1bdcf9c83154782b1ed40',
    'src/methods/contract_adapters/e_001.py': 'b7b86cc19a522655d0f1be34e7a869572cd905eb038bb61d312f8201b129abaa',
    'src/coordinator_private/contract_coordinated_gate.py': '22e9686c1fc4589c981a73e5aacfc3fab2333fcd449388e9c6a50f56db560094',
    'src/coordinator_private/multigame_launch_spec.py': '2f4717f4e6be2d2084a01205c24a9ab048b55239da334b4b79181616ce675507',
    'src/methods/_common/multigame_method_registry.py': '496df7ae50df36fcbf5bb9818be434b706ebec31f58751b3dd7329d0cc77f67b',
    'src/methods/E_006/beta_bernoulli.py': '2c94d463f4020e7eb4f29949d12cb0cc8d0456f54dd5e1a89504c8f2d7fd976c',
    'src/methods/E_006/contract.py': '1752ecc51046ffcc49ce1d8b95986872f7422c8a50feafc221c057f3ab800b4b',
    'src/methods/E_006/IN_DEVELOPMENT.txt': '853862022b400247cce6e2fac4421d90be71f52475db8f6681f35bfe5fa63a5e',
    'tests/e2r_fixtures.py': '6755c9fe44ba2d222d2522cd81090c11044f59c2e2344e4bd27b9f02ecab643d',
    'tests/e2r_code2_fixtures.py': '20c92643998634b5eb6acac45bfcf8bf6253b8ca01ce6e524fdb795b622110f4',
    'tests/test_e2r_runner.py': 'a2d2384c0f7369f554db0235886aeed6b90443d90e012645c2b46e046ffbee9d',
    'tests/test_e2r_contract.py': 'e09139279401b202c70fd3de230607a9a1755dde42f533a2a164c639c460dd47',
    'tests/test_e2r_dispatch.py': '7c37981283ec0f640eb1c59121fec5ebe5aa1d2bd3ccfdc4d6d79c64fffd3ab9',
    'tests/test_e6_beta_bernoulli.py': '8750b1e3bf134d2994bf3569f4970ca5aa54846bdbb64e17cac582261d48e8b4',
    'src/methods/_common/contract_data/registry/POWERBALL/E_2/NOT_YET_SPECIFIED/entry_0001.json': '73f57ea86f48b865b515c5857725bec32d9ee784e7c6faf966e3e24d3c97c8d2',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_19/NOT_YET_SPECIFIED/entry_0001.json': '817637a3af9d41009cd0be83a7918ab1ca6bf3dd8ebf55336ea0b0dff0dc20de',
    'src/methods/_common/contract_data/registry/POWERBALL/E_7/BETA_SHRINK_W52_C52_V1/entry_0001.json': '4a6bb0506c65511f394885715e5ecc6878cd09e0ca901bd802856915fdb76775',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} files at their base version. '
              'Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        need(len(new) + len(mod) == len(lines), 'changes other than new files and modified files:\n' + status[:600])
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths and {len(MODIFIED)} modified files, '
              'all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}}
    need(got == want, 'the last commit did not change exactly the expected paths: ' + repr(sorted(got.items())))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files and modified '
          f'{len(MODIFIED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
