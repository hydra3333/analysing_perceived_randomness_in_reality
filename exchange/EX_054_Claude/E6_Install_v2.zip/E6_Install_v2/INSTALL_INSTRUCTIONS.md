# E_6 package v2 - E_6 revision 1 installed non-runnable, the new-method template and register v0.15 (only after the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\E6_Install_*` folders, then extract it there (`tar -xf "E:\TEMP\E6_Install_v2.zip" -C E:\TEMP`). This package adds 40 new files and replaces 3 existing files (`src/methods/Method_Contract_Runner.py`, `tests/test_e2r_contract.py`, `tests/test_e2r_dispatch.py`); nothing else changes. E_6 is installed **non-runnable**: every E_6 request is refused until a separate release package.

## 1. Update, check, copy, check

```bat
git status --short
git pull --ff-only
python "E:\TEMP\E6_Install_v2\VERIFY_E6_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\E6_Install_v2\repo_overlay\*" . /E /Y
python "E:\TEMP\E6_Install_v2\VERIFY_E6_INSTALL.py" --repo . --phase post
```

Expected: `git status --short` prints nothing (if it prints anything, stop and send Claude the output); the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `43 File(s) copied`; `POST PASS`.

## 2. Tests, before committing (offline; nothing in the repository is changed)

```bat
.venv\Scripts\python.exe "E:\TEMP\E6_Install_v2\RUN_E6_SUITE.py" --repo .
```

Expected: `SUITE PASS` (210 tests; the only allowed skips are symlink tests: on Windows without symlink rights, up to 3). E2R-T12 starts up to six ordinary Python worker processes and lets them finish normally. **Do not skip this step.** If anything in steps 1 or 2 prints `STOP` or `FAILED`, do not commit: send Claude the output.

## 3. Stage, commit, check, and only then push

```bat
git add doc review src tests
git status --short
git commit -m "E_6 revision 1 (installed non-runnable), the new-method template draft 1 and register v0.15"
python "E:\TEMP\E6_Install_v2\VERIFY_E6_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 40 lines starting with `A` and 3 starting with `M`, and nothing else; then `COMMITTED PASS`. Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub. Claude pushes nothing to the repository while you install.
