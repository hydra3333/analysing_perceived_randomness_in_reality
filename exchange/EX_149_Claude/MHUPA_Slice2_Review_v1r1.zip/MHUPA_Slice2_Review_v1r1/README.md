# MHUPA_Slice2_Review_v1r1 - MHUP-A review slice 2, candidate v1r1 after EX_148 (Claude, 5 November 2026)

A REVIEW package, not an install candidate: nothing here is to be installed. See EX_149 (EX_147 was candidate v1; EX_148 its review).

- `overlay/` - every file of the development tree that differs from or is absent in the base tree (`main` at 2061055):
  70 files, at their repository paths (slice 1's reviewed files included, unchanged except the two test lines
  EX_147 section 1 names). `REMOVED_FILES.txt` lists the one file the tree removes.
- `tools/` - the scripts that build the development tree from the base by counted edits (slice 1 then slice 2), the
  updater v0.2 maker, the suite runner (expected counts) and both slices' mutation tools.
- `evidence/` - the Linux suite runs (Python 3.13 and 3.15.0b4, E2R-T12 included) and the slice 2 mutation output.
- `MHUP_A_work_item_card_v6.md` - the work-item card.
- `MHUP1_design_amendment_A1_draft.md` - the B01 design amendment for review (also a member of EX_149).

No file under source_data/, results/ or transitory_data/ is in this package or was read to make it.
