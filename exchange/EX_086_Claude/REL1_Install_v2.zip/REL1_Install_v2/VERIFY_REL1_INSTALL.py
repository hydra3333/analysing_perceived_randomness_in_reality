#!/usr/bin/env python3
"""Read-only installation verifier for the REL-1 package (release of the 39 variants of the 11 installed methods, both games).

Claude, 31 October 2026 (from the wave 2 package verifier; adds deleted paths). Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 92 new paths are absent; the 5 modified files and the 11 files
             to be deleted still have their base bytes; guarded files unchanged in Git.
  post       after copying the overlay (and the git rm step, if any): exactly the 92 new paths
             appear, exactly the 5 modified files change and exactly the 11 deleted files are gone
             (staged deletions), all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths, modified exactly the modified files and deleted exactly the deleted files,
             all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_REL1_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = 'd15183eccdc9e5d6b7d6322ef2bf57a6bf118b18'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/Predictive_Randomness_Releases_and_WF1_Design_v0_1r1.md': '03f95fbe5c3f0e3771a07550b8b57d3c87fe5f7e06a8cc5d02974982ff7a12ee',
    'doc/RATIFICATION_REGISTER_v0_21.md': '65524f92b99db2f9556c300536700af43bb1e449c55a998c8c87f427e1b78405',
    'review/Independent_ChatGPT_WF1_Design_Focused_RECHECK_EX080.md': '4c05c27b9907e18971f64cb3ae7568bb2ce7e7122452f6cc1ab418e342b51795',
    'review/Independent_ChatGPT_WF1_Design_R3_Review_EX078.md': '8e117858a7b1e3bd92b5537efd0a5e0d99c95e600b98f2b66c46503e0a97be72',
    'review/REL1_Install_v2/INSTALL_MANIFEST_SHA256.txt': '84781794be27ae39958d66a931272011f3e9b068c0929420027fbfa37228e3e3',
    'review/REL1_Install_v2/mutations_rel1_py313.txt': '9b71465e7c55faf2fafc6f09d5db1a888922e6b570e1eae24f779c657b6e12a7',
    'review/REL1_Install_v2/replaced_files_base_to_v1.diff': 'a94a75559dcd2662e834b447729148fb97cee049da7d4097693f9d09cf58ae5a',
    'review/REL1_Install_v2/suite_rel1_py313.txt': '495aca9585d4243eecc158393365b53b4dfca79c93b1f79c148c965c766b6f43',
    'review/REL1_Install_v2/suite_rel1_py315.txt': 'b78a51d72ebf766dc0b64fefa9a81e0c8451577b1d239ddead20fb497bc0299a',
    'review/REL1_Install_v2/tools/edit_tests_rel1.py': '0bc7f88d40060ba8e4538869f9eaee163ed7470f78c29c69eff93ea480152485',
    'review/REL1_Install_v2/tools/make_register_v21.py': 'f8271a5cd3fce04e7ce3261681b4fedcc853b4eb09f6e8fbee9cb0188bfeb700',
    'review/REL1_Install_v2/tools/make_rel1_release.py': '6293d0848f180d82914ad94a080af8aff5339544640535b9a972e9c0fd09bffa',
    'review/REL1_Install_v2/tools/wf1_mutations.py': '56a06f6d45dd54d5a14761275c776a3c6a1857276e22042e673baf77f58ffcf4',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_10/CONTRAST_S13_L104_V1/entry_0002.json': '406d90af7cb17cb0e1aa2c10c8def9e65626d8e00153b4b66a49c43c6475db0a',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_10/CONTRAST_S26_L208_V1/entry_0002.json': 'c0b954e549cb1a5ec3e132231e4c38ea7c6b3880bbfd8edbc76cf4317b5483e2',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_10/CONTRAST_S52_FULL_V1/entry_0002.json': 'caf50fbbe03efa62875b644a62b4e851a5ec88c2b384a9e0337f9ff1b809fdc9',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_17/HAZARD_BINS_C100_V1/entry_0002.json': 'c7bcfaa61013470a1ecdd1cf46b5265ea14d5b39074e2d08f048c2c5a305f314',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_17/HAZARD_BINS_W208_C100_V1/entry_0002.json': '2a66d1ad06233838870a17b8b89e67a40a24fe06f66e59a5fbbb6ed24cbf1d7e',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_17/HAZARD_LOGAGE_SIGN_V1/entry_0002.json': '485e511bb5f9e245151e4cc1ce55f01270990413aef719c4bd5422df40d7000b',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_18/MIX4_ALL_C10_V1/entry_0002.json': 'cadf464141f8d3129b6cb56a3d744f25c79502c84ad0e04e11875db2e3b8e657',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_18/MIX4_W104_C10_V1/entry_0002.json': '23a2f9c378b058737bba0671c8e3bf347a9c6f87a2db31f5bb2004882cb3ca8d',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_18/MIX4_W208_C10_V1/entry_0002.json': '27e479bfd07067da2c2bcf58021f4b57d6cfc43c5d07f3bd0c9f8fd026e677d2',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_19/PERIODIC_T2_V1/entry_0002.json': '6c0e1d02c44d6a9f864b1130521a9ce72649e363e239d12dd5eff9154f75afc7',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_19/PERIODIC_T3_V1/entry_0002.json': '2d89cfbeec41634162af23d341c50b0c0a917f4e02d411d89aa452965ea6b55e',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_19/PERIODIC_T4_V1/entry_0002.json': 'f6ed5f7c24799f9be1955c4bd08fb22b2489b4e0641cf90297496adefc37169a',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_2/RECUR_MEAN_ALL_V1/entry_0002.json': '81931d2496d3b3d2a375558090d562bf6c3cbed4e350f2a2143316acdd4cba7f',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_2/RECUR_MEAN_LAST8_V1/entry_0002.json': '221f2d84edf39863fc1926f202c57ece54d883b0d08ef35d78dda5e368c930eb',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_2/RECUR_MEDIAN_ALL_V1/entry_0002.json': 'b8991e32f1600a81ddc21d06a2c1f66d2dd2f994fe7ebf6d5bee2ee66624cdec',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_INTERP_W52_D4_H4_V1/entry_0002.json': '97968b7713294861725730c8e29a003bfb44fa8ff36862702bdfd141756fa35d',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_LS_W104_D3_V1/entry_0002.json': '5d42db8c5c8738f67336d59cc3e4e870e5b39b2f8d96593427be34b30fad1654',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_LS_W52_D2_V1/entry_0002.json': '4ddab1511e3cf8d5b33a91d1ef86b662a3a2bd42cc706f75e8a11096f2caf9c3',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_LS_W52_D3_V1/entry_0002.json': '13ac4778bd92c592f36a8ff183c24201a2556e1aec3b0604236f81b6b567cf12',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_MINIMAX_W52_D2_H4_V1/entry_0002.json': 'ae205e826a824a357d96e57a5abae3a0e2d89df278918e2c95251a97dbb5ac52',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_MINIMAX_W52_D3_H4_V1/entry_0002.json': 'aa37cb63eba22909c811a7323c508cda61f201934b553ff0f0b7df028d9b2221',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_INTERP_W52_D4_H4_V1/entry_0002.json': '6e973e995b6dcc40c32104989bd78c9b0e9dff8394f3ee9e97d16f6ea6b7bed1',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_LS_W104_D3_V1/entry_0002.json': '6dd0d79deb49206dd73ee9d44be9dd4bea449aca32f51174a4959cc7c0385bf1',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_LS_W52_D2_V1/entry_0002.json': '7dae16fe5fb75be176a631b1d00280672f3da3aef4f863b7f7ecc3be269ff863',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_LS_W52_D3_V1/entry_0002.json': '57c000acd0b8e6893d73c6b118ac5c92ebac78e116ff77a87dc8e2c76d423314',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_MINIMAX_W52_D2_H4_V1/entry_0002.json': '07ae93a30b18dfb53372ddae89fa99399916c77a8dd6fc322dd112401b137e54',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_MINIMAX_W52_D3_H4_V1/entry_0002.json': '089c6b27f757963ad23df6c2a296511c549cbc16dd578b7cdb3110b840ca1411',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_6/BETA_BERNOULLI_DECAY_149_150_V1/entry_0002.json': '5293dd0f278dce2775f846ad7f103370acbf6e33e795b619a2896025875b9a0f',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_6/BETA_BERNOULLI_DECAY_74_75_V1/entry_0002.json': 'eb844a2fadbcead1538b39c0a4df2089db86d9f14538aeb215a04e54728ed4c8',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_6/BETA_BERNOULLI_FULL_MEMORY_V1/entry_0002.json': 'a220b073baee5732b23a1ad54dbaa82b8f8acf10fb74ab6d5330392f539c67ea',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_7/BETA_SHRINK_FULL_C52_V1/entry_0002.json': '46714513788139d38781e07cd868d227cdcf91ecd7e961ab4e26d5ba38df6411',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_7/BETA_SHRINK_W104_C52_V1/entry_0002.json': '52d82ef34e2af70710d7ac8b52ba230c4a0359cef4353d4b12f11b782767f020',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_7/BETA_SHRINK_W52_C52_V1/entry_0002.json': 'e709bb044222d3a136868c9641b86f8719a8f2dec69dbb0c42d0ae83ade73df4',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_8/HIER_PERIODS_P13_V1/entry_0002.json': '705522295c484c6318f40841b324fc17a305186abfe9a8d91107734341545775',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_8/HIER_PERIODS_P26_V1/entry_0002.json': '0f478ef8c4bae01f166f4a31ec54618f9247ac58328bdfcde380940e638058da',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_8/HIER_PERIODS_P52_V1/entry_0002.json': '871f5f0583b689f716f989ad5a0142ad2781288b029dc257f601a2d09e771cd3',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_9/EXP_DECAY_18_19_V1/entry_0002.json': 'd1eb3ed99824cf885fe22528f804f21cbc7cc03c8bb463707b653a63039d4dfb',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_9/EXP_DECAY_37_38_V1/entry_0002.json': '4a9f3a829fbf8137b163a8d0aead73251b8cf3079579fb8322a00b4604824a23',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_9/EXP_DECAY_5_6_V1/entry_0002.json': '695ec5a79e596ce6c4f9878a3e152fa17691b72590bccd908a725aede22e0406',
    'src/methods/_common/contract_data/registry/POWERBALL/E_10/CONTRAST_S13_L104_V1/entry_0002.json': '1e3d55942c7ad05833eab7f2efb7cb4137ba7a7c3b3dc4dd13cfa0cc1a886c1f',
    'src/methods/_common/contract_data/registry/POWERBALL/E_10/CONTRAST_S26_L208_V1/entry_0002.json': '82b40c2d545f78ac9c5e4d2f5b693bed413a369cd2b860e7005caa6516123604',
    'src/methods/_common/contract_data/registry/POWERBALL/E_10/CONTRAST_S52_FULL_V1/entry_0002.json': 'baa7bd63d8eab878da057cb1ae7be10f099e2d3c52379906ce382264dd2d5d27',
    'src/methods/_common/contract_data/registry/POWERBALL/E_17/HAZARD_BINS_C100_V1/entry_0002.json': 'be1cff9efef697a66912c60c84f5bd9a3c95f0acd8515ac08cd48231ddba8f36',
    'src/methods/_common/contract_data/registry/POWERBALL/E_17/HAZARD_BINS_W208_C100_V1/entry_0002.json': '65764c7ba4df7a287b681ebfff26d99115efeae2206a6b0891e7e875049d20c0',
    'src/methods/_common/contract_data/registry/POWERBALL/E_17/HAZARD_LOGAGE_SIGN_V1/entry_0002.json': 'cf06ba007d5081593042fe944fa7b1eb9776b3de2507578683e039b86d6c776d',
    'src/methods/_common/contract_data/registry/POWERBALL/E_18/MIX4_ALL_C10_V1/entry_0002.json': '31e86e9cc644869d14726a03f32eb6b5b0aacbf32d40dc1d1c1a205e2d4e3d65',
    'src/methods/_common/contract_data/registry/POWERBALL/E_18/MIX4_W104_C10_V1/entry_0002.json': 'af38c410cd71c42c6da8b65539b2c87ef8ab38da7063d203a8a20315570695ec',
    'src/methods/_common/contract_data/registry/POWERBALL/E_18/MIX4_W208_C10_V1/entry_0002.json': 'b4e1e45f982e81019dd5a20588c9d4411fa77044fe28ce32a797d4d95eb6b2fd',
    'src/methods/_common/contract_data/registry/POWERBALL/E_19/PERIODIC_T2_V1/entry_0002.json': 'e2513cf7efff71cab22fe6dc5bedfcf07d6773f23bae25e34397f3e63ac68e6b',
    'src/methods/_common/contract_data/registry/POWERBALL/E_19/PERIODIC_T3_V1/entry_0002.json': 'a0caf2f418475f763b8d7bacef6349cd559605ae562efdb9cf286168127ad164',
    'src/methods/_common/contract_data/registry/POWERBALL/E_19/PERIODIC_T4_V1/entry_0002.json': 'd17d6839a34aa5670a1f5d9e0fa28517cda7032c5755bbe74fa1a6fc97540021',
    'src/methods/_common/contract_data/registry/POWERBALL/E_2/RECUR_MEAN_ALL_V1/entry_0002.json': '08700c3317bb704276fa1b8b862d4bac2c3da440ad441ef6713cf96b8c754a27',
    'src/methods/_common/contract_data/registry/POWERBALL/E_2/RECUR_MEAN_LAST8_V1/entry_0002.json': '5558d5f736b91ce0b086c74f763a6cca4cb1bc6df8411bc378ca866b1abca9a3',
    'src/methods/_common/contract_data/registry/POWERBALL/E_2/RECUR_MEDIAN_ALL_V1/entry_0002.json': 'ee6854db255c5c84e48f6145dcf2bdb900117050a1e564b54a2962fce9b52800',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_INTERP_W52_D4_H4_V1/entry_0002.json': '023c84d38f6d5261973d3dbedc8ebb30c8351d8b6ee56dc3bd41f8979300cb4b',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_LS_W104_D3_V1/entry_0002.json': 'dd89dee2e565d6256a595deb32a1f7761216798366229fdd08e6c47329ab358b',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_LS_W52_D2_V1/entry_0002.json': '1bb6cf353b6492b29cbd77c2c0aa0a01bfb26eb62a8784b68e9b78ebce968479',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_LS_W52_D3_V1/entry_0002.json': '9cf4d070e4a3fc70b762cd0e075fd27c20eef17b71d64dee306ae1ce83a15311',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_MINIMAX_W52_D2_H4_V1/entry_0002.json': '97e243cefb1ab20cad8c0e729337b9daf82239b622b85f2bd43e3edd4d774f01',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_MINIMAX_W52_D3_H4_V1/entry_0002.json': '18a572b4267c694f3cf2f20bfc5dc6fb506fc7bc00a7f71a8035e4599a463b43',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_INTERP_W52_D4_H4_V1/entry_0002.json': '261b0687770f3d6f70e58f29ccc3bc193ea0e452bfe79f3b457152e829f2fc67',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_LS_W104_D3_V1/entry_0002.json': 'a4860b2f5f29f98ae89ea214f3e9d04fa77d56069760122b19b364c0942eb0e4',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_LS_W52_D2_V1/entry_0002.json': '89f36850efeb4705eddc5b08a1f61b6af1ff1b1f00bf1d7ac8fb2eb9e6d50ef3',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_LS_W52_D3_V1/entry_0002.json': '994bc8a65e65b355776cf35dec6f4971af2aeaee08b3121409f4ca753348aa6d',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_MINIMAX_W52_D2_H4_V1/entry_0002.json': '8ed301f7fecc104169822e2a8be51b2f63bcc0b7934932af37be38b41ae9edb9',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_MINIMAX_W52_D3_H4_V1/entry_0002.json': '20abdc8ec7dd4492cf7557f412601f3c0f7fe09668cb7fcc57ec648e7e0e79d6',
    'src/methods/_common/contract_data/registry/POWERBALL/E_6/BETA_BERNOULLI_DECAY_149_150_V1/entry_0002.json': '1c9c7c13afa9803c51457e3fc2dfe420ae75065dd03e48c118225dfd80d0019d',
    'src/methods/_common/contract_data/registry/POWERBALL/E_6/BETA_BERNOULLI_DECAY_74_75_V1/entry_0002.json': 'd4a21d90222ea8c5d196c6a236b7e4166476d6e67f83aeccc67dd8ccbdea63c3',
    'src/methods/_common/contract_data/registry/POWERBALL/E_6/BETA_BERNOULLI_FULL_MEMORY_V1/entry_0002.json': 'f41e65b39b13fd321a4ddf748355b41bafaac070a68868507fd829cc66d59e0d',
    'src/methods/_common/contract_data/registry/POWERBALL/E_7/BETA_SHRINK_FULL_C52_V1/entry_0002.json': 'f2d258704cbb1a72ed11d98c4762882473eb0a2f4a878f60dcdeb2d9f5720c8f',
    'src/methods/_common/contract_data/registry/POWERBALL/E_7/BETA_SHRINK_W104_C52_V1/entry_0002.json': '5ac2d89182a580e08d17663cd538540a423ad9e8e907a7f63fa8408120080c11',
    'src/methods/_common/contract_data/registry/POWERBALL/E_7/BETA_SHRINK_W52_C52_V1/entry_0002.json': '024d3d4e8033d85664b32064c7af1abca2015ba5eed861e1a71a8b76efbca2c7',
    'src/methods/_common/contract_data/registry/POWERBALL/E_8/HIER_PERIODS_P13_V1/entry_0002.json': 'f4eec464aca97452477babd8cfdfaa740914d14dd37d3a2e546c61a46e3a493a',
    'src/methods/_common/contract_data/registry/POWERBALL/E_8/HIER_PERIODS_P26_V1/entry_0002.json': 'bb012d370014d43892d48b2efbd43f4d0da1b82c1fb9922841360f18a6f37f92',
    'src/methods/_common/contract_data/registry/POWERBALL/E_8/HIER_PERIODS_P52_V1/entry_0002.json': 'd857182fbe67b1bbc47bd07ed9505860ea90822ddaa78371626f9f8397c9f330',
    'src/methods/_common/contract_data/registry/POWERBALL/E_9/EXP_DECAY_18_19_V1/entry_0002.json': 'eb8267f77ec9cb273c80043b230f05d60c0546cb83ee997197b040ce65fdad2e',
    'src/methods/_common/contract_data/registry/POWERBALL/E_9/EXP_DECAY_37_38_V1/entry_0002.json': 'aaa175168b19207e34f25cdc70b7d59844949bfaab9bdc3d1e86d6d675bb29b7',
    'src/methods/_common/contract_data/registry/POWERBALL/E_9/EXP_DECAY_5_6_V1/entry_0002.json': 'd161385514ad5825048426504f45c754e24535dc35bc733ab7ab1e177be99b79',
    'tests/test_rel1_release.py': 'ea6b32d604a5203f8c53d91ee9e61ac9f0a4e8935feee7311c52bcc73af1d618',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF
    'tests/test_e2r_dispatch.py': ('7c37981283ec0f640eb1c59121fec5ebe5aa1d2bd3ccfdc4d6d79c64fffd3ab9', '7b7dcaf488e1b59d0af7533b2e8a5da24f6db37392bce3246150ae19b7625187'),
    'tests/test_e3_e4_polynomial.py': ('ee038a2dd045698b81ace4bdfa2c9571290838ad97714bb273178ec55dddd562', '31b65547a5836677a1b2a4a70f07bef3297be13169f1deafbbbb537f2ce7722e'),
    'tests/test_e6_beta_bernoulli.py': ('8750b1e3bf134d2994bf3569f4970ca5aa54846bdbb64e17cac582261d48e8b4', '122a11bd000a6467c713cf9277bd158856aff7e0ad14d03a83339e374f15a21c'),
    'tests/test_wave1_frequency.py': ('d82d98173658f0d6edc766cbd21e51cdb3c7f3834db0a82846061c236aa78313', '7a330dc423341d0bb3e7769754d7d7899ade59a806796c1df7d4a2da28f2900e'),
    'tests/test_wave2_recurrence.py': ('7db0f7c67b559a7d346d607f92c4f4b60e10b1524be391aad9f23c3f0b48ff67', '50d312c212a285d3485cabe6904e48c1720c52d5aac9064599094ab9094f521f'),
}
DELETED = {  # path: base Git-content SHA-256 (LF)
    'src/methods/E_002/IN_DEVELOPMENT.txt': '2b40a5620d83a7746bbe8b0e62faf02809e29bf57193aa9c52c5a85a9a98913e',
    'src/methods/E_003/IN_DEVELOPMENT.txt': '068ce17c1855b5e666b046e6397fdf96a36f970d35f407a3f7f61cce386da72e',
    'src/methods/E_004/IN_DEVELOPMENT.txt': 'aca1b3f57e18307be94114cd22702cb9059ecd607f43f3ad9688fdcee05d4c9d',
    'src/methods/E_006/IN_DEVELOPMENT.txt': '853862022b400247cce6e2fac4421d90be71f52475db8f6681f35bfe5fa63a5e',
    'src/methods/E_007/IN_DEVELOPMENT.txt': '1f1b5bc827e4c6b8f0545b3fc4931909f3cd1055140f486387c275d96bc16a06',
    'src/methods/E_008/IN_DEVELOPMENT.txt': 'ff16a0768ce49fcee9e300a8cddb2b4a40ebc140086607ddb8ecc3c34ec0ba7a',
    'src/methods/E_009/IN_DEVELOPMENT.txt': '60171715ba11c97ccf4ca2d2d912546d0abaf60d06c62a806eb34220ed328e75',
    'src/methods/E_010/IN_DEVELOPMENT.txt': 'c4ed10bb77c2bfd39cdb2cc8f72b174528c75f97d3cb4f5328785c08f0b36c71',
    'src/methods/E_017/IN_DEVELOPMENT.txt': '901c5df586c654e8949205151a7c00cbd6a894cef633ec0784d108f7fcc022da',
    'src/methods/E_018/IN_DEVELOPMENT.txt': 'd3d59d6fbeeab40dcda8bede03f64009f6c09acecb6c04ee0783b0e07df9c5ef',
    'src/methods/E_019/IN_DEVELOPMENT.txt': '22428c736b470b05400093a498836aac97808fbce8be4ed6372a1fec9cddcacb',
}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'src/methods/E_001/multigame_e1.py': '3c4a2305873aed7dc0457efcb898519f6e888ed72557670da1e8b0f9687ca462',
    'src/methods/E_001/e1_historical_appearance_frequency.py': '2c727d3b20584cd9a30c89863b6b51c72a1e0c373b48751e3da27d55f514f250',
    'src/methods/E_001_Historical_Appearance_Frequency.py': 'f060944e7db40ac950f20d9bfe245e2cf5f64e2f7ef716766069d9973e5e767c',
    'src/methods/contract_adapters/e_001.py': 'b7b86cc19a522655d0f1be34e7a869572cd905eb038bb61d312f8201b129abaa',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/contract_dispatch.py': '7f026bc8ff6a0a13120031371acee455734d12a79cbe923f988ba12c6a92a322',
    'src/methods/_common/contract_registry.py': '00082aad1754edbf2380c2caa144b0c79a12e2b6f26eb806d85903f177f11064',
    'src/methods/_common/contract_publication.py': '665ed261bb1504854b0c3be7c60a84ad6ecab6559d74d949c19f85eaa7ae809b',
    'src/methods/_common/contract_receipts.py': 'e6d159e65dcf8269ea5576a7338d3ebcbf2d5dc0c06b06f1517189cc215908fd',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/methods/_common/contract_forecast.py': 'be88a1d640098a6990f14090108524e1d7437a425e1b6254672164b6fc7f8121',
    'src/methods/_common/contract_task.py': 'e58c0ab288b3292d3eeaf49e7cf9170b0341ff53d23cbde839b8cdbd716a31b3',
    'src/methods/_common/contract_vocab.py': '6e30b5be8d024fa647a2406e38b44cdf3b3c0c84f0468d84e168e9fde40d4ec8',
    'src/coordinator_private/contract_coordinated_gate.py': '22e9686c1fc4589c981a73e5aacfc3fab2333fcd449388e9c6a50f56db560094',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'Run_Experiment.bat': 'dfd324d645cbbe5d528883f7a0309d5f5f3cbea47c4a49ddffaf6b0bdc7f0c5d',
    'Run_Coordinator.bat': '6ccb23302c897747432d84d1a1f4ed6fd7b2cf99faa8298ec4f3b5d82841bc70',
    'src/methods/_common/contract_data/registry/POWERBALL/E_1/FULL_HISTORY_RAW_COUNTS_V1/entry_0001.json': '544891641041f27ba5ac66ef7b8910945eb0a1c95261c27115372e365eba86bc',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_2/NOT_YET_SPECIFIED/entry_0001.json': 'f52e82c332269334a76f5868d19774b642cfd40775fcf8a09d99b141f7bd18df',
    'src/methods/_common/contract_data/registry/POWERBALL/E_6/BETA_BERNOULLI_FULL_MEMORY_V1/entry_0001.json': 'f835ba33b5ed9749aceaecc3f6b5fc69138ba45153912daf3028a5e3ff82ea47',
    'doc/RATIFICATION_REGISTER_v0_20.md': 'd273f7a16532935368d137ee404717873e66d8ea189b35336104c396d2c517d4',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r6.md': 'a5f74126dfead7f5ea40a5999b3944e44fe7f0764d9bdef463df1075953f9509',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r7.md': 'a59ab8504d0d63d852d66efcc9491a05d3329656eb5164eef682df57da60ec38',
    'doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md': '53e30a3e649b48b8a88923d08bf578caf04a4ce93d6ea6468891ca97e93a57b6',
    'src/methods/_common/contract_runner.py': 'a45c2612fdef0130b7b2a755b4d1db6aaafbdbc337d1bdcf9c83154782b1ed40',
    'src/methods/Method_Contract_Runner.py': 'e6b2d511afc02133d2887c1a9f56f22b1eb63e71196cf37d8d5c61a5671addc4',
    '.gitignore': '4a9a408c9233ea46df94495cbbc7d2d5a49bfe91a16c6d731febefc8d05efec1',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        for p, old in DELETED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be deleted is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be deleted differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} files to replace and {len(DELETED)} to delete '
              'at their base version. Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        dele = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('D  ')}
        need(len(new) + len(mod) + len(dele) == len(lines),
             'changes other than new files, modified files and staged deletions:\n' + status[:600])
        need(dele == set(DELETED), 'unexpected staged deletions: ' + ', '.join(sorted(dele ^ set(DELETED))))
        for p in DELETED:
            need(not (repo / p).exists(), f'deleted path still on disk: {p}')
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths, {len(MODIFIED)} modified files and '
              f'{len(DELETED)} staged deletions, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    for p, old in DELETED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the deleted file: {p}')
        need(run(repo, 'cat-file', '-e', f'HEAD:{p}').returncode != 0, f'deleted file still in HEAD: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}, **{p: 'D' for p in DELETED}}
    need(got == want, 'the last commit did not change exactly the expected paths; differences (path, status): ' +
         repr(sorted(set(got.items()) ^ set(want.items()))))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files, modified '
          f'{len(MODIFIED)} and deleted {len(DELETED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
