"""Draft register v0.21 from the installed register v0.20 by counted in-place edits (Claude, 31 Oct 2026).

Records: the new reviewer chat's takeover (30 October 2026) and its follow-up answers; the releases and WF-1 design
review (EX_077 to EX_081) and the owner's ratification of design v0.1r1 with decisions WF1-1 to WF1-13; the R3 findings
it carries; the REL-1 and WF-1A packages (REL-1 installed with this register; WF-1A after it, in its own commit).
Every old string must occur exactly once; inserted text is ASCII. Input: the Git blob of
doc/RATIFICATION_REGISTER_v0_20.md (d273f7a1...17d4). Files named here are hashed by the caller and passed in.
Placeholder, finalised after the owner's ratification: "RATIFICATION CANDIDATE" (version line).
Usage: python3 -I make_register_v21.py REGISTER_v0_20 DESIGN EX078_COPY EX080_COPY OUT_v0_21
"""
import hashlib, sys

src, design, r78, r80, out = sys.argv[1:6]
raw = open(src, 'rb').read()
assert hashlib.sha256(raw).hexdigest() == 'd273f7a16532935368d137ee404717873e66d8ea189b35336104c396d2c517d4'
t = raw.decode('utf-8')
assert '\r' not in t
H = {k: hashlib.sha256(open(p, 'rb').read()).hexdigest() for k, p in (('design', design), ('r78', r78), ('r80', r80))}
assert H['design'] == '03f95fbe5c3f0e3771a07550b8b57d3c87fe5f7e06a8cc5d02974982ff7a12ee'

NEW_SECTION = f"""## The new reviewer, releases and WF-1 (register v0.21)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.21.

**The DOC-8 installation.** H-1 v1r6, H-2 v1r7, their introductory blurbs and register v0.20 were installed at `03f7da470d0231354592c98b1b32f28e6a86d473` (30 October 2026; parent `9583f97`). Claude verified it from GitHub: 14 files added, all blobs as packaged. The owner's roadmap was updated at `1d836c6`.

**The new reviewer chat (30 October 2026).** The owner started a new ChatGPT reviewer chat from H-2 v1r7 and its introductory blurb, with the repository snapshot at `1d836c6`.
- **Its takeover reply** accepted the role, with the same rights (R-1 to R-11) and independence. It verified H-2's protected rights region (7,676 bytes, `70e50dc3...72db`) and H-2 v1r7's canonical hash, and found 0 BLOCKER, 0 CORRECTION, 1 OPTIONAL and 0 RECONSIDER.
- **H2-TAKEOVER-O01 (OPTIONAL):** H-2's historical wording still calls R-8 to R-11 proposed. They have been OWNER-RATIFIED since 27 October 2026 (H-2 v1r2). At the next H-2 revision, a clarification is to be added **outside** the protected region; the region stays byte-identical.
- **Its answers to five follow-up questions** (test reproduction under R-2 and R-9; E_17's scores are not probabilities, and mark-never-suppress; the pattern origins PO-1 to PO-4; a holdout exposure in an attachment; its first EX message) were checked by Claude against the record: all consistent. Its two terminology points on the method overview were adopted: "E_1 is the only `SUPPORTED` method"; E_17's variants publish ranking scores, not probabilities.

**The releases and WF-1 design review (EX_077 to EX_081).**
- **EX_077** (`4bdb060`): the design note v0.1 for REL-1, WF-1A, SEED-1 and WF-1B, with reference and timing probes on invented data. Section 8.1 announced N1's provisional seed policy `N1_ROOT_NIST_C2_20261106T0000Z_V1`: NIST Randomness Beacon 2.0, chain 2, the pulse at `2026-11-06T00:00:00.000Z`, field `outputValue`, `statusCode` 0, no fallback.
- **EX_078** (`b4b83c1`): R-3 RECHECK, with 1 BLOCKER (WF1-R3-B01: the driver would have continued after a data-admission failure), 4 CORRECTION (C01 NIST's certificate notice and the meaning of verification; C02 the search-log row written too late; C03 the downgrade rules for missing opportunities; C04 "exact everywhere" overstated) and 2 OPTIONAL. The copy installed with this register is `review/Independent_ChatGPT_WF1_Design_R3_Review_EX078.md` (LF, `{H['r78']}`).
- **EX_079** (`be002c9`): design v0.1r1, resolving all seven.
- **EX_080** (`6df9585`): focused RECHECK PASS. B01 and C01 to C04 are resolved, O01 and O02 adopted. It adds C05 (CORRECTION, FIX AND PROCEED, REVIEWER-DECIDED: one phrase of WF1-7's summary) and O03 (OPTIONAL: probe_tails.py's second chain-link check is tautological; to be qualified at the next documentary update). The copy installed with this register is `review/Independent_ChatGPT_WF1_Design_Focused_RECHECK_EX080.md` (LF, `{H['r80']}`).
- **EX_081** (`4c68f3f`): Claude applied C05 exactly as permitted (a one-line change, recorded with its diff), giving the ratification candidate.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** WF1-R3-C05.

**The code review (EX_082 to EX_084).**
- **EX_082** (`4ba804e`): the REL-1 and WF-1A code candidates and this register's first candidate, with owner decision WF1-13 disclosed.
- **EX_083** (`faafe13`): R-2, RECHECK. REL-1: no finding; all 78 transitions, the 11 deletions and the unchanged E_1 checked independently. WF-1A: WF1A-R2-B01 (BLOCKER): resume counted a pair done from any terminal record with the same registry entry and revision, which binds neither the master pin nor the batch, and does not validate the records. WF1A-R2-O01 (OPTIONAL): per-module test times. WF1-13's interim exclusion of E_1 and M = 78: no objection. This register's content: consistent, with the package status to be reconciled.
- **EX_084:** WF-1A v2 resolves B01. Before each run, the driver appends a `WF_BATCH_ATTEMPT_V1` line (the batch ID, the pair, the fresh run ID and the digest of the exact request) to the batch's `attempts.jsonl`. A pair is done only through an attempt of the same batch whose run folder holds a valid canonical terminal record matching that request, in a CONTINUE class. For a SUCCESS it also needs a consumable forecast whose receipt and record carry the plan's master pin, run mode, view, declaration and registry entry. Runs of other batches are never reused. The RECHECK result and the owner's acceptance of WF-1A are recorded in the next register.

**The owner's decisions (30 and 31 October 2026).**
- **The design ratified:** `Predictive_Randomness_Releases_and_WF1_Design_v0_1r1.md` (`{H['design']}`), with C05 applied, OWNER-RATIFIED 31 October 2026 and installed with this register. Its decisions WF1-1 to WF1-5, WF1-7, WF1-8, WF1-10 and WF1-11 are OWNER-RATIFIED as recommended.
- **WF1-6 (OWNER-DECIDED 30 October 2026):** each track is scored on its own fixed grid, with a labelled common-set descriptive table, departing from R3 17.3.7's default intersection set; under the downgrade rules of the design's section 6.2A.
- **WF1-9:** the announced pulse is kept.
- **WF1-12 (OWNER-DECIDED 30 October 2026, after EX_078 C01):** N1's seed is trusted through NIST's official HTTPS service. The pulse's signature and certificate are not validated (`NOT_PERFORMED`), and NIST's certificate notice of 23 October 2026 does not block approval. D-9's two-person check stays: the owner fetches the pulse by hand, and Claude independently reads it from NIST's archive and compares five fields. The owner accepts the residual authenticity risk. D-9 to D-11 are unchanged.
- **D-10, as ratified (confirmed by the owner, 30 October 2026):** "no seed shopping" means no replacement except a new pre-announced policy, with every root kept and counted.
- **WF1-13 (OWNER-DECIDED 31 October 2026, during WF-1A's coding):**
  - **The finding:** E_1 revision 1's multi-game function refuses real data. It was kept byte-unchanged on purpose when E_1 was wired into the contract (E2RC-C04 option (a)). So E_1 cannot run in the walk-forward batches as the design assumed.
  - **The owner's choice (option C):** a new E_1 revision 2 that accepts real development runs, with E_1's legacy runner moved to revision 2 as well. CODE-3 (retirement tooling, D-5) comes first.
  - **In the meantime:** WF-1A names E_1 in every batch plan as not in the cohort, with the reason, and never runs it. The cohort is 39 variants, and the design's MR7 families have M = 78 until E_1 r2 joins with its own batch.
  - **The options not chosen:** leaving E_1 out for good (A); a one-line scoped exception keeping revision 1 (B); E_1 through its legacy D3 runner and record format (D).
  - **Recorded in** `exchange/OWNER_REMINDERS.md` R-005.

**Findings for R3, recorded here** (R3 v0.5's text is not edited; this register prevails for WF-1):
- **R3-1:** R3 17.3.7's default intersection set gives Oz Lotto 12 draws with this cohort; superseded for WF-1 by WF1-6.
- **R3-2:** Oz Lotto's default window starts at 1474, the era's first draw, which has no history; it is in no track's grid.
- **R3-3:** 17.13's stage-2 test list "21..23" is read as MRT-22 and MRT-23 in stage 2, and MRT-21 (MR15) in stage 3.
- **R3-4:** 17.11's production route (`lgamma`) and test oracle (`Fraction`) swap roles (WF1-7).

**The packages, reviewed in one round (R-2) and installed one after the other:**
- **REL-1** (`review/REL1_Install_v2/`), **installed with this register:** it releases the 39 variants of E_2, E_3, E_4, E_6, E_7, E_8, E_9, E_10, E_17, E_18 and E_19 in both games. It appends 78 `entry_0002.json` records (`SUPPORTED`), deletes the 11 `IN_DEVELOPMENT.txt` flags, adds tests/test_rel1_release.py, edits five existing tests' status expectations, and installs this register, the design and the two review copies. Contract runs stay synthetic until WF-1A.
- **WF-1A** (`review/WF1A_Install_v2/`), **installed after REL-1, in its own commit,** identified after installation:
  - it adds the walk-forward driver (`src/methods/Method_Walk_Forward.py` and `src/methods/_common/walk_forward.py`) and its tests;
  - it turns `ENABLE_CONTRACT_REAL_DEVELOPMENT` on (WF1-3);
  - it moves the runner's real run root to `results/real/development/contract_runs/` and git-ignores it, with each batch's `attempts.jsonl`.
  Its installation is the owner's decision to turn that switch on. Each real batch is a further owner authorisation, recorded in the next register.

**Out-of-date statements (register v0.21).** This register prevails, and the files are not edited:
- **D6-3's release order** (E_6's full-memory variant first): superseded by WF1-2.
- **D2-2 and E2R-1** ("`ENABLE_CONTRACT_REAL_DEVELOPMENT` stays False"; "contract runs are synthetic only"): superseded by WF1-3 once WF-1A is installed.
- **H-1 v1r6 and H-2 v1r7, "the four switches stay False":** three stay False; the fourth is on once WF-1A is installed. Their other status lines are superseded by this register.
- **Architecture 13.1 and R3 11.7:** real-development contract runs are published under `results/real/development/contract_runs/`, not `transitory_data/contract_runs/`, once WF-1A is installed.
- **The design's sections 8.2 and 9.5, on NIST's chain links:** their second chain-link line is illustrative only (EX_080 O03); qualified at the next documentary update.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_Releases_and_WF1_Design_v0_1r1.md` | Claude; reviewed by the ChatGPT reviewer chat (EX_078, EX_080; C05 applied) | OWNER-RATIFIED 31 Oct 2026; installed with this register; `{H['design']}` |
| `RATIFICATION_REGISTER_v0_20.md` | Claude; on the owner's instruction, no other-model review before ratification (register v0.20) | OWNER-RATIFIED 30 Oct 2026; installed at `03f7da4`; superseded by this register; `d273f7a16532935368d137ee404717873e66d8ea189b35336104c396d2c517d4` |

"""

EDITS = [
    ('**Register version:** v0.20 OWNER-RATIFIED 30 October 2026, recording',
     '**Register version:** v0.21 RATIFICATION CANDIDATE (drafted 31 October 2026), recording the new reviewer chat\'s takeover, the releases and WF-1 design review and ratification with the owner\'s decisions WF1-1 to WF1-13, and the REL-1 and WF-1A packages; v0.20 OWNER-RATIFIED 30 October 2026, recording'),
    ("For v0.20, the wave 2 installation commit `b61b1a2` was verified by Claude from GitHub. This register, H-1 v1r6, H-2 v1r7 and their introductory blurbs are installed together by the document-only procedure, in one commit identified after installation.",
     "For v0.20, the wave 2 installation commit `b61b1a2` was verified by Claude from GitHub. This register, H-1 v1r6, H-2 v1r7 and their introductory blurbs are installed together by the document-only procedure, in one commit identified after installation. For v0.21, the DOC-8 commit `03f7da4` and the exchange records from `4bdb060` onward were verified by Claude from GitHub. The REL-1 package and this register are installed together, in one commit identified after installation; WF-1A follows in its own commit. The owner's Windows results for both are recorded after installation."),
    ('\n## Interpretation and verification\n',
     '\n' + NEW_SECTION + '## Interpretation and verification\n'),
]
for old, new in EDITS:
    n = t.count(old)
    assert n == 1, (n, old[:80])
    assert all(ord(c) < 128 for c in new), old[:60]
    t = t.replace(old, new)
open(out, 'wb').write(t.encode('utf-8'))
print(out, hashlib.sha256(t.encode()).hexdigest(), len(t.splitlines()), 'lines')
