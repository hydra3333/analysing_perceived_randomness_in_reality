#!/usr/bin/env python3
"""Read-only installation verifier for E2R-CODE-2 (wiring the contract library in).

Claude, 29 October 2026. Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 17 new paths are absent; the 3 modified file still has its base
             bytes; guarded files unchanged in Git.
  post       after copying the overlay: exactly the 17 new paths appear and exactly the 3
             modified file changes, all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths and modified exactly the modified file, all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_E2R_CODE2_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = 'b846519bce7463cc7a7a57095d438b9223dd8bb9'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/Predictive_Randomness_E2R_CODE2_Design_v0_1r1.md': 'f0c36fd3dabb83dcc5f21d8b92bd9b5c3eaf9647da069a4e5bff63514a26f2dd',
    'review/E2R_CODE2_Install_v2/INSTALL_MANIFEST_SHA256.txt': 'bf5242877841a26ae191e55cf5167a54f6f9e9ef9e8aad31f5e886c450bbd82c',
    'review/E2R_CODE2_Install_v2/e2r_code2_mutation_checks_linux.txt': 'a96fece66f32b2656e8e65a31a87a7e81ad3877751db7678cfb74c655045cd2b',
    'review/E2R_CODE2_Install_v2/suite_e2r_code2_linux_py313.txt': 'a1ec543b8c00bf8f3fab407431c5a21f0d9cee52b7ae07c3820eae935e4ef63d',
    'review/E2R_CODE2_Install_v2/suite_e2r_code2_linux_py315b4.txt': 'c18b29d4a8f7dba8559483d0b51b84ef5c3c89a2a395256fd42b00638d747d26',
    'review/E2R_CODE2_Install_v2/tools/e2r_code2_mutations.py': '85d17b8d869c635cdac8bf4d9d5fc855c0126e66ff3b2f9cdb5bd44720525d92',
    'review/Independent_ChatGPT_E2R_CODE2_R3_Design_and_Register_v12_Review_v0_1.md': 'eedd59e4eb0dcde7e0876fa2ae47b01ec0b45d75927a602b7d967e1a1f02f18a',
    'src/coordinator_private/contract_coordinated_gate.py': 'a5340060d3c3376b2f315f0f68836e71175b4dc6ca5dfa9322b406d5286d5b3e',
    'src/methods/Method_Contract_Runner.py': 'b890ace2c1d694d426afc33dfa78a00dc9209db3fe6f47f6128dac72c3906bb3',
    'src/methods/_common/contract_dispatch.py': '5703fee40a13a4d29b0103de88d38f1f44f21741226846ab9b1b565e77bcd439',
    'src/methods/_common/contract_publication.py': '03f8827b42463fa580991b783bc062cd3caabadba226fb160b3c7d7e8b849178',
    'src/methods/_common/contract_runner.py': '8751faa73559bbcefa8baac10371ba242fec60d257b670844898775bacb0a63f',
    'src/methods/contract_adapters/__init__.py': '37eec72f21cd52244498674f93579a200b8021e5028163acc0ad68c8410eb3a7',
    'src/methods/contract_adapters/e_001.py': 'b7b86cc19a522655d0f1be34e7a869572cd905eb038bb61d312f8201b129abaa',
    'tests/e2r_code2_fixtures.py': '18ba63d83b77b565a36c4ced51832f9e7076040962329474657c9bd98fa0555c',
    'tests/test_e2r_dispatch.py': '9477f0cf33a89bd8e4f8c62a372cd0085cfd85d6b8ed663bac45b9d5a76453a2',
    'tests/test_e2r_runner.py': 'f2c74667296227381b5382ae88d451865044c2a39ca2f2f8212183917daea931',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF
    'src/methods/E_001_Historical_Appearance_Frequency.py': ('3ee292f226be2a93a8222f6d7646fe7cc4dc140dbb345c535dd6a2e5b0f43b39', 'f060944e7db40ac950f20d9bfe245e2cf5f64e2f7ef716766069d9973e5e767c'),
    'src/methods/_common/multigame_method_registry.py': ('78693c06d109f584b3ce987baaf633028fb8d6eb036f4068006173754b46aacd', '496df7ae50df36fcbf5bb9818be434b706ebec31f58751b3dd7329d0cc77f67b'),
    'src/methods/_common/multigame_standalone_contract.py': ('d27fc6b15948e0701ff4c9e7020274e29d2c9423a903f5dc1c8e75139ce20b95', '36538a23d85d2107d00161e36be1300e3aa2aa9d4561e9cd0eb9e98548f40510'),
}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'doc/RATIFICATION_REGISTER_v0_12.md': '6f6f4556522b54ae4416da07357b50bed82ec799e7761f758cac99b6324ac4eb',
    'doc/Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md': '0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/canonical_encoding.py': '2096d8adb40737373169aea6c5d94147daa2b16ae6c961bbfcc6063e333efcac',
    'src/methods/E_001/multigame_e1.py': '3c4a2305873aed7dc0457efcb898519f6e888ed72557670da1e8b0f9687ca462',
    'src/methods/E_001/e1_historical_appearance_frequency.py': '2c727d3b20584cd9a30c89863b6b51c72a1e0c373b48751e3da27d55f514f250',
    'src/methods/E_001/e1_training_view.py': 'e75e13729ffcdb5f14c4d7f762d8b31e590adbb1498142f9731eaf452394cad8',
    'src/methods/E_001/e1_standalone_contract.py': 'd9ef642c2949b1b2a10232d614ba1306365abaefe65338b5c0aa9e3d9f285e50',
    'src/methods/_common/contract_vocab.py': '6e30b5be8d024fa647a2406e38b44cdf3b3c0c84f0468d84e168e9fde40d4ec8',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/methods/_common/contract_task.py': 'e58c0ab288b3292d3eeaf49e7cf9170b0341ff53d23cbde839b8cdbd716a31b3',
    'src/methods/_common/contract_forecast.py': 'be88a1d640098a6990f14090108524e1d7437a425e1b6254672164b6fc7f8121',
    'src/methods/_common/contract_receipts.py': 'e6d159e65dcf8269ea5576a7338d3ebcbf2d5dc0c06b06f1517189cc215908fd',
    'src/methods/_common/contract_registry.py': '00082aad1754edbf2380c2caa144b0c79a12e2b6f26eb806d85903f177f11064',
    'src/methods/_common/multigame_result_registry.py': '768e719f17e61a1b246668fcd9050a6e218be43ad89b73bcc1d9d779100eb34b',
    'src/coordinator_private/multigame_launch_spec.py': '2f4717f4e6be2d2084a01205c24a9ab048b55239da334b4b79181616ce675507',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} file at its base version. '
              'Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        need(len(new) + len(mod) == len(lines), 'changes other than new files and modified files:\n' + status[:600])
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths and {len(MODIFIED)} modified file, '
              'all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}}
    need(got == want, 'the last commit did not change exactly the expected paths: ' + repr(sorted(got.items())))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files and modified '
          f'{len(MODIFIED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
