"""Non-launching Package 2 v0.11 timing, AST, and safety proof checks.

No subprocesses, Windows lifecycle operations, gate changes, master updates,
scientific score evaluation or holdout reads. The protected-function AST check uses the
packaged v0.6 fixture under tests/fixtures/coordinator_v0_6_baseline/ (P2-R1-O3); V06_BASELINE
may point at another copy.
"""
from __future__ import annotations
import ast
import hashlib
import os
from pathlib import Path
import queue
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path[:0] = [str(ROOT/'src'),str(ROOT/'src'/'methods')]
from _common.multigame_ancestry_release import RELEASE_POLL_SECONDS,RELEASE_WAIT_SECONDS
from _common.multigame_result_registry import _COORDINATED_SCIENCE_ALLOWLIST
from coordinator_private.multigame_windows_lifecycle import PIPE_READER_JOIN_TIMEOUT_SECONDS as LIFE_JOIN
import Powerball_Experiment_Coordinator as coord

PROTECTED=(
    'accept_ancestry_candidate','check_exited_worker_for_orphan',
    'departed_members_check','read_status','record_unresolved_orphan',
    'register_root','require_no_unresolved_orphan','save_new',
    'status_and_result','status_orphan_evidence','terminate_owned_tree',
)


class StaticSafetyTests(unittest.TestCase):
    def test_switches_closed_and_empty_scientific_allowlist(self):
        self.assertIs(coord.ENABLE_PROCESS_TERMINATION,False)
        self.assertIs(coord.ENABLE_SCIENTIFIC_COORDINATION,False)
        self.assertIs(coord.ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE,False)
        self.assertEqual(len(_COORDINATED_SCIENCE_ALLOWLIST),0)

    def test_human_speed_timeout_constants(self):
        self.assertEqual((coord.POLL_SECONDS_DEFAULT,coord.POLL_SECONDS_MIN,
                          coord.POLL_SECONDS_MAX),(1.0,.5,5.0))
        self.assertEqual(coord.PIPE_EOF_WAIT_SECONDS,5.0)
        self.assertEqual(RELEASE_POLL_SECONDS,coord.POLL_SECONDS_MIN)
        self.assertEqual(RELEASE_WAIT_SECONDS,15.0)
        self.assertEqual(coord.LINE_QUEUE_PUT_TIMEOUT_SECONDS,.12)
        self.assertEqual(coord.PIPE_READER_JOIN_TIMEOUT_SECONDS,.05)
        self.assertEqual(LIFE_JOIN,coord.PIPE_READER_JOIN_TIMEOUT_SECONDS)
        self.assertEqual(list(coord.receive_messages(queue.Queue(),poll_seconds=1.0)),[])
        for bad in (.01,.49,5.01):
            with self.assertRaises(ValueError):
                list(coord.receive_messages(queue.Queue(),poll_seconds=bad))
        q=queue.Queue();q.put((1,'invented synthetic log'))
        self.assertEqual(list(coord.receive_messages(q,poll_seconds=1.0)),
                         [(1,'invented synthetic log')])

    def test_protected_v06_ast_mechanically_equal(self):
        # P2-R1-O3: never skips. The committed v0.6 coordinator (commit d09d669) is packaged as a
        # hash-pinned, non-importable fixture; V06_BASELINE may still point at another copy.
        baseline=(Path(os.environ['V06_BASELINE']) if 'V06_BASELINE' in os.environ
                  else ROOT/'tests'/'fixtures'/'coordinator_v0_6_baseline'/
                       'Powerball_Experiment_Coordinator_v0_6.py.txt')
        self.assertTrue(baseline.is_file(), f'v0.6 baseline coordinator missing: {baseline}')
        # Git stores LF; a Windows checkout may hold CRLF, so hash the LF form.
        before=baseline.read_bytes().replace(b'\r\n',b'\n')
        self.assertEqual(hashlib.sha256(before).hexdigest(),
            '2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b')
        after=(ROOT/'src'/'Powerball_Experiment_Coordinator.py').read_bytes()
        def functions(raw):
            return {x.name:ast.dump(x,include_attributes=False)
                    for x in ast.parse(raw).body if isinstance(x,ast.FunctionDef)}
        b,c=functions(before),functions(after)
        for name in PROTECTED:
            with self.subTest(name=name):
                self.assertEqual(b[name],c[name])

    def test_legacy_waits_untouched_and_new_literals_named(self):
        source=(ROOT/'src'/'Powerball_Experiment_Coordinator.py').read_text()
        life=(ROOT/'src'/'coordinator_private'/'multigame_windows_lifecycle.py').read_text()
        self.assertNotIn('messages.put((number, line.rstrip("\\r\\n")), timeout=0.12)',source)
        self.assertNotIn('w.reader.join(timeout=0.05)',source)
        self.assertNotIn('worker.reader.join(timeout=0.05)',life)
        self.assertIn('timeout=LINE_QUEUE_PUT_TIMEOUT_SECONDS',source)
        self.assertIn('timeout=PIPE_READER_JOIN_TIMEOUT_SECONDS',source)
        self.assertIn('timeout=PIPE_READER_JOIN_TIMEOUT_SECONDS',life)
        self.assertIn('timeout=3.0',source)  # protected termination path
        self.assertIn('wait(timeout=3)',source)

    def test_method_loader_import_firewall_except_accepted_legacy_e1(self):
        accepted_legacy='E_001_Historical_Appearance_Frequency.py'
        # E1-ALIGN: method folders are scanned too. Every reference to the shared
        # reader is identified by module AND imported name (so 'from _common import
        # game_draws_reader' is caught), and every textual mention of the reader or of
        # source_data is counted. E_1's accepted legacy references inside its folder
        # are allowed exactly: file, form, module, name, alias and count. Anything
        # else fails, including a new file in E_001/, and every allowance must be used.
        # This is a static regression guard, not a defence against obfuscated dynamic
        # imports; the exact-diff review of each package remains mandatory.
        allowed_imports={('E_001/e1_common_reader_bridge.py','from','_common.game_draws_reader',
                          'DrawView',None):1}
        allowed_text={('E_001/e1_common_reader_bridge.py','game_draws_reader'):1,
                      ('E_001/e1_training_view.py','source_data'):1}
        used_imports={}
        used_text={}
        methods=ROOT/'src'/'methods'
        files=sorted([*methods.glob('*.py'),*methods.glob('E_[0-9][0-9][0-9]/**/*.py')])
        for method in files:
            rel=method.relative_to(methods).as_posix()
            if rel==accepted_legacy:
                # Its own previously accepted standalone historical reader is
                # grandfathered; do not modify a frozen E1 golden source file.
                continue
            contents=method.read_text('utf-8')
            tree=ast.parse(contents)
            for node in ast.walk(tree):
                if isinstance(node,ast.ImportFrom):
                    module=('.'*node.level)+(node.module or '')
                    for alias in node.names:
                        if 'game_draws_reader' in module or 'game_draws_reader' in alias.name:
                            key=(rel,'from',module,alias.name,alias.asname)
                            self.assertIn(key,allowed_imports,f'unauthorised reader import in {rel}: {key}')
                            used_imports[key]=used_imports.get(key,0)+1
                elif isinstance(node,ast.Import):
                    for alias in node.names:
                        if 'game_draws_reader' in alias.name:
                            key=(rel,'import',alias.name,None,alias.asname)
                            self.assertIn(key,allowed_imports,f'unauthorised reader import in {rel}: {key}')
                            used_imports[key]=used_imports.get(key,0)+1
            for word in ('game_draws_reader','source_data'):
                n=contents.count(word)
                if n:
                    key=(rel,word)
                    self.assertIn(key,allowed_text,f'unauthorised {word} reference in {rel}')
                    used_text[key]=used_text.get(key,0)+n
        self.assertEqual(used_imports,allowed_imports)
        self.assertEqual(used_text,allowed_text)

    def test_no_retired_acquisition_overlay_importable(self):
        from importlib.util import find_spec
        for module in ('_common.lotterywest_api_client_v1',
                       '_common.multigame_results_build_v1',
                       '_common.multigame_offline_source_pipeline_v1',
                       'multigame_results_tool_v1','multigame_scraper_entry_v0_1'):
            with self.subTest(module=module):
                self.assertIsNone(find_spec(module))

if __name__=='__main__': unittest.main()
