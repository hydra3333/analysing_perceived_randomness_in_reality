#!/usr/bin/env python3
"""Read-only installation verifier for the E_6 package (E_6 revision 1, installed non-runnable, and the template).

Claude, 30 October 2026 (from the E2R-CODE-2 verifier). Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 40 new paths are absent; the 3 modified files still have their
             base bytes; guarded files unchanged in Git.
  post       after copying the overlay: exactly the 40 new paths appear and exactly the 3
             modified files change, all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths and modified exactly the modified files, all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_E6_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = 'f9de54ad4b877bf45a5e4d8bcca2e4b4b5e3f752'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/METHOD_TEMPLATE/METHOD_SPECIFICATION_TEMPLATE.md': '3812f671977382fc94e89477de5c417133800e71d0002397c40843b051fbadf6',
    'doc/METHOD_TEMPLATE/README.md': 'f17e2d6eb489797415252689038078047011b7aa7ba2e24f987c265078df3e26',
    'doc/METHOD_TEMPLATE/declaration_example.json': 'f4f4ca0c0978c7f6df6fcdea18dd062d8e5333fe72f51ba695d4c58698c102fb',
    'doc/METHOD_TEMPLATE/make_contract_data.py.txt': '3058fb0b1bb77bf5f381772552d83745e872319038150e9ea9a9e63749f8006f',
    'doc/METHOD_TEMPLATE/method_folder/IN_DEVELOPMENT.txt': '353b475f2c0e1e9c0690c69fa288645c40bd6a8ef0d0f7b7e93d5bbb02c03d3b',
    'doc/METHOD_TEMPLATE/method_folder/__init__.py.txt': 'b1a55326fd4557ba5ae9960c9b9445c6c7221c7d86da5e80c5c04db8346c82d7',
    'doc/METHOD_TEMPLATE/method_folder/contract.py.txt': '8aefa8b17e70be4b63aa3add66722b4ac099bc4507623fb5a38ae225849294fa',
    'doc/METHOD_TEMPLATE/method_folder/model.py.txt': '2baf07c9a2c980012777c6cd370262aea8647d62e5d94a97bc025c4af1c9d72f',
    'doc/METHOD_TEMPLATE/registry_entry_example.json': 'e38c1d99e7b1cb5ef7231821862cdf0f55514000f346520cb2cb9ebddff00095',
    'doc/METHOD_TEMPLATE/test_template.py.txt': 'dcdb3c061d24f3029f5aafdb8aa0b64db35ca713f55c65462505d60f19d6fff4',
    'doc/Predictive_Randomness_E6_Specification_and_Method_Template_Design_v0_1.md': 'cef16b44fb7088ec018e0a8d6f233231c04e3fe6d5431cf0a2e604ad8f6fc82e',
    'doc/RATIFICATION_REGISTER_v0_15.md': '97f134bddbf6153f91e57c5aec3326a6c5d9a2ba7f623d1bb0d4309a486d557e',
    'review/E6_Install_v2/INSTALL_MANIFEST_SHA256.txt': 'dcb0c7ccceafc4022ab37caa220460d65f16113df7266a159019a0162ba6d599',
    'review/E6_Install_v2/candidate_v1_to_v2.diff': '477011f6979d0171c2ad309af75c04f2525022dfcd9e23a56cae46898118eaa7',
    'review/E6_Install_v2/e6_mutation_checks_linux.txt': '1455d9b46c41ec45acf189d71cc23997836a8ded548ee404dc479d7204b26125',
    'review/E6_Install_v2/replaced_files_base_to_v2.diff': 'c4421e7d30e54f0706f51b0a908cb809916d6c1d32006440962383efe0ff1001',
    'review/E6_Install_v2/suite_e6_linux_py313.txt': 'bc96a0f82442e47ca43ac1f5a69ddcc0b69273f17bb2a783434113eee694355d',
    'review/E6_Install_v2/suite_e6_linux_py315b4.txt': '48a12bf42ca7f56607ffe3fb1705a544d72a37d54b251241b279fd4b7bc4fe58',
    'review/E6_Install_v2/template_trial_linux.txt': '32bf720133d7b12dd7ae815a006c57f1d30e6b93ca96cb7f445917ca84d542b2',
    'review/E6_Install_v2/tools/e6_mutations.py': '0327e6b8fbb842c729fe5ae08aba71e8e6ef5da41d67e0deaa7b8133e3f6dc3a',
    'review/E6_Install_v2/tools/make_e6_contract_data.py': '261aa06702145405b26be9da33882a6f41d4578f043b156c72fe67cd014f2b78',
    'review/E6_Install_v2/tools/template_trial.py': '81c9ff63fc8bf712fa67214e6f0c96093cf80157f173b568af62ceb0ff7f934d',
    'review/Independent_ChatGPT_E6_R3_R2_Review_v0_1.md': 'ee0613f618738b219cd2ba33b03fd16148abfc471bef66140e1c583822e6b4cb',
    'src/methods/E_006/IN_DEVELOPMENT.txt': '853862022b400247cce6e2fac4421d90be71f52475db8f6681f35bfe5fa63a5e',
    'src/methods/E_006/__init__.py': '81766cd46cc6c2d7d6821f37b4651281beb3d3b8f652437be94c6e40db74c199',
    'src/methods/E_006/beta_bernoulli.py': '2c94d463f4020e7eb4f29949d12cb0cc8d0456f54dd5e1a89504c8f2d7fd976c',
    'src/methods/E_006/contract.py': '1752ecc51046ffcc49ce1d8b95986872f7422c8a50feafc221c057f3ab800b4b',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_6/BETA_BERNOULLI_DECAY_149_150_V1/r1.json': 'c49328aa5922c9edc57b57feeb85c2f4440d58ade4a1f0c9d74547b6cae66e8a',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_6/BETA_BERNOULLI_DECAY_74_75_V1/r1.json': '3e694bf784193ea438aaa70ef435644611b15ce87d4109860153a697b9b58e67',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_6/BETA_BERNOULLI_FULL_MEMORY_V1/r1.json': '7dc4f396c13ec4d1bc3ff307878cf00bea4de33f9c5e9ebcae2dcb3c17dc3124',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_6/BETA_BERNOULLI_DECAY_149_150_V1/r1.json': 'e20a2ae32022c1dc7332bdba4ddeaa3c67888741480cddf69cfba3868708306d',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_6/BETA_BERNOULLI_DECAY_74_75_V1/r1.json': 'b6f320ace4facdd4aa099c3726564d9c73fd095a77fffd88a13c8b6c1f66bd68',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_6/BETA_BERNOULLI_FULL_MEMORY_V1/r1.json': '5d2067df3788f42e47d363bb13edf0e13b273b04d30e0c13b8faf8e7b3e4d087',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_6/BETA_BERNOULLI_DECAY_149_150_V1/entry_0001.json': 'e549367d2331b1419ee2e8e02a1a676086b39128576e9b0b2293ed772b56eac2',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_6/BETA_BERNOULLI_DECAY_74_75_V1/entry_0001.json': 'aba2dba8cc1168b82e3062b820f10d93164a667d6a6e92dfeb4db4ce68efe8b9',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_6/BETA_BERNOULLI_FULL_MEMORY_V1/entry_0001.json': '72af0e3dd66dc9ce0fe0bdd25e8fd220e67f0cde7ee28456213abfa5041d5600',
    'src/methods/_common/contract_data/registry/POWERBALL/E_6/BETA_BERNOULLI_DECAY_149_150_V1/entry_0001.json': 'f6cf3c538efdedb8a24a8fd6a450a2a3bbf2f7f86840f536f8e9bddfa1c554ee',
    'src/methods/_common/contract_data/registry/POWERBALL/E_6/BETA_BERNOULLI_DECAY_74_75_V1/entry_0001.json': '15bb2ef503039feac1d2e5ae8f0e93e0a84e5b05ef73411352bf080a03ea252f',
    'src/methods/_common/contract_data/registry/POWERBALL/E_6/BETA_BERNOULLI_FULL_MEMORY_V1/entry_0001.json': 'f835ba33b5ed9749aceaecc3f6b5fc69138ba45153912daf3028a5e3ff82ea47',
    'tests/test_e6_beta_bernoulli.py': '8750b1e3bf134d2994bf3569f4970ca5aa54846bdbb64e17cac582261d48e8b4',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF
    'src/methods/Method_Contract_Runner.py': ('b890ace2c1d694d426afc33dfa78a00dc9209db3fe6f47f6128dac72c3906bb3', '2fbb2e5080e7f2f97e19691e1d64fb25e88e304480f414a32344563b9b4f7c2a'),
    'tests/test_e2r_contract.py': ('eda52fa4046831cb78cec075c05c810cce09d16824553da6c70ad2207d82a3dd', 'e09139279401b202c70fd3de230607a9a1755dde42f533a2a164c639c460dd47'),
    'tests/test_e2r_dispatch.py': ('4cdb65f7605c54b5111ca95c3efc1d274455e7c72896bbdbc7f294f606f3b7bb', '7c37981283ec0f640eb1c59121fec5ebe5aa1d2bd3ccfdc4d6d79c64fffd3ab9'),
}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'doc/RATIFICATION_REGISTER_v0_14.md': '74d2ae89a16d2c7a971db1b62e89c3e9aa7f6a2803a9102516507fa705e2bfa4',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r4.md': '2050e9363d841634ecf2a9c308d3efb1ed51b359fbdaf2aa3531a60eb1f1c16a',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r5.md': '67a1b3eaa3e1f51415eceba513fd7e1a39de91619296f0efba97ba108570a094',
    'doc/Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md': '0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954',
    'doc/Predictive_Randomness_E2R_CODE2_Design_v0_1r1.md': 'f0c36fd3dabb83dcc5f21d8b92bd9b5c3eaf9647da069a4e5bff63514a26f2dd',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/canonical_encoding.py': '2096d8adb40737373169aea6c5d94147daa2b16ae6c961bbfcc6063e333efcac',
    'src/methods/E_001/multigame_e1.py': '3c4a2305873aed7dc0457efcb898519f6e888ed72557670da1e8b0f9687ca462',
    'src/methods/E_001/e1_historical_appearance_frequency.py': '2c727d3b20584cd9a30c89863b6b51c72a1e0c373b48751e3da27d55f514f250',
    'src/methods/E_001/e1_training_view.py': 'e75e13729ffcdb5f14c4d7f762d8b31e590adbb1498142f9731eaf452394cad8',
    'src/methods/E_001/e1_standalone_contract.py': 'd9ef642c2949b1b2a10232d614ba1306365abaefe65338b5c0aa9e3d9f285e50',
    'src/methods/E_001_Historical_Appearance_Frequency.py': 'f060944e7db40ac950f20d9bfe245e2cf5f64e2f7ef716766069d9973e5e767c',
    'src/methods/_common/contract_vocab.py': '6e30b5be8d024fa647a2406e38b44cdf3b3c0c84f0468d84e168e9fde40d4ec8',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/methods/_common/contract_task.py': 'e58c0ab288b3292d3eeaf49e7cf9170b0341ff53d23cbde839b8cdbd716a31b3',
    'src/methods/_common/contract_forecast.py': 'be88a1d640098a6990f14090108524e1d7437a425e1b6254672164b6fc7f8121',
    'src/methods/_common/contract_receipts.py': 'e6d159e65dcf8269ea5576a7338d3ebcbf2d5dc0c06b06f1517189cc215908fd',
    'src/methods/_common/contract_registry.py': '00082aad1754edbf2380c2caa144b0c79a12e2b6f26eb806d85903f177f11064',
    'src/methods/_common/contract_dispatch.py': '7f026bc8ff6a0a13120031371acee455734d12a79cbe923f988ba12c6a92a322',
    'src/methods/_common/contract_publication.py': '665ed261bb1504854b0c3be7c60a84ad6ecab6559d74d949c19f85eaa7ae809b',
    'src/methods/_common/contract_runner.py': 'a45c2612fdef0130b7b2a755b4d1db6aaafbdbc337d1bdcf9c83154782b1ed40',
    'src/methods/contract_adapters/e_001.py': 'b7b86cc19a522655d0f1be34e7a869572cd905eb038bb61d312f8201b129abaa',
    'src/coordinator_private/contract_coordinated_gate.py': '22e9686c1fc4589c981a73e5aacfc3fab2333fcd449388e9c6a50f56db560094',
    'src/coordinator_private/multigame_launch_spec.py': '2f4717f4e6be2d2084a01205c24a9ab048b55239da334b4b79181616ce675507',
    'src/methods/_common/multigame_method_registry.py': '496df7ae50df36fcbf5bb9818be434b706ebec31f58751b3dd7329d0cc77f67b',
    'src/methods/_common/multigame_result_registry.py': '768e719f17e61a1b246668fcd9050a6e218be43ad89b73bcc1d9d779100eb34b',
    'src/methods/_common/multigame_standalone_contract.py': '36538a23d85d2107d00161e36be1300e3aa2aa9d4561e9cd0eb9e98548f40510',
    'tests/e2r_fixtures.py': '6755c9fe44ba2d222d2522cd81090c11044f59c2e2344e4bd27b9f02ecab643d',
    'tests/e2r_code2_fixtures.py': '20c92643998634b5eb6acac45bfcf8bf6253b8ca01ce6e524fdb795b622110f4',
    'tests/test_e2r_runner.py': 'a2d2384c0f7369f554db0235886aeed6b90443d90e012645c2b46e046ffbee9d',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} files at their base version. '
              'Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        need(len(new) + len(mod) == len(lines), 'changes other than new files and modified files:\n' + status[:600])
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths and {len(MODIFIED)} modified files, '
              'all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}}
    need(got == want, 'the last commit did not change exactly the expected paths: ' + repr(sorted(got.items())))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files and modified '
          f'{len(MODIFIED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
