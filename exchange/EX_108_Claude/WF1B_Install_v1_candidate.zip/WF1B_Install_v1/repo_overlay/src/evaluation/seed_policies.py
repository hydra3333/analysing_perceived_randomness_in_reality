"""N1's seed policy records (releases and WF-1 design v0.1r1 sections 7.6 and 8; decision WF1-12).

Records live in src/evaluation/seed_policies/, are reviewed and immutable, and are all kept (provisional, refused,
replaced and approved), so that every root tried is counted (D-10; design 8.4). The report tool uses N1 only with
exactly one APPROVED record; there is no default, test or fallback root in production code (7.6)."""
from __future__ import annotations

import json
import re
from pathlib import Path

FOLDER = Path(__file__).resolve().parent / 'seed_policies'
SCHEMA = 'SEED_POLICY_V1'
STATUSES = ('PROVISIONAL', 'APPROVED', 'REFUSED', 'REPLACED_BEFORE_PULSE')
ROOT = re.compile(r'[0-9A-F]{128}\Z', re.ASCII)
_APPROVED_FIELDS = ('output_value', 'uri', 'pulse_index', 'time_stamp', 'status_code', 'certificate_id', 'chain_index',
                    'version', 'sources', 'owner_file_sha256', 'fetched_by', 'fetched_utc', 'verified_by',
                    'verified_utc', 'signature_verification', 'trust_basis', 'nist_notice')


def _records() -> list[dict]:
    out = []
    if not FOLDER.is_dir():
        return out
    for p in sorted(FOLDER.glob('*.json')):
        rec = json.loads(p.read_bytes().decode('ascii'))
        validate(rec)
        out.append(rec)
    return out


def validate(rec) -> dict:
    if type(rec) is not dict or rec.get('schema') != SCHEMA or rec.get('status') not in STATUSES:
        raise ValueError('not a SEED_POLICY_V1 record with a known status')
    if type(rec.get('policy_id')) is not str or not rec['policy_id'].startswith('N1_ROOT_'):
        raise ValueError('invalid policy_id')
    if rec['status'] == 'APPROVED':
        missing = [k for k in _APPROVED_FIELDS if k not in rec]
        if missing:
            raise ValueError(f"APPROVED record {rec['policy_id']} lacks {missing}")
        if type(rec['output_value']) is not str or not ROOT.fullmatch(rec['output_value']):
            raise ValueError('outputValue must be 128 upper-case hexadecimal characters')
        if rec['signature_verification'] != 'NOT_PERFORMED' or rec['status_code'] != 0 or rec['chain_index'] != 2 \
                or rec['version'] != '2.0' or len(rec['sources']) != 2:
            raise ValueError('APPROVED record fails the WF1-12 acceptance fields')
        if type(rec['owner_file_sha256']) is not str or not re.fullmatch(r'[0-9a-f]{64}', rec['owner_file_sha256']):
            raise ValueError('owner_file_sha256 must be a SHA-256')
    return rec


def count_policies() -> int:
    return len(_records())


def approved_policy() -> dict | None:
    """The one APPROVED policy, or None. More than one APPROVED record is refused (a replacement must be explicit)."""
    approved = [r for r in _records() if r['status'] == 'APPROVED']
    if len(approved) > 1:
        raise ValueError('more than one APPROVED N1 seed policy')
    return approved[0] if approved else None
