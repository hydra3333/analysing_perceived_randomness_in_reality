# WF1B_Install_v1 - WF-1B package (the R3 stage-2 scorer and ranking report, N1 and its seed policy) (only after the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\WF1B_Install_*` folders, then extract it there (`tar -xf "E:\TEMP\WF1B_Install_v1.zip" -C E:\TEMP`). This package adds 37 new files and replaces 1 existing file (`.gitignore`); nothing else changes. It runs no report: running one is your separate decision afterwards.

## 1. Update, check, copy, check, and the tests (one block; do not skip the last command)

```bat
git status --short
git pull --ff-only
python "E:\TEMP\WF1B_Install_v1\VERIFY_WF1B_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\WF1B_Install_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\WF1B_Install_v1\VERIFY_WF1B_INSTALL.py" --repo . --phase post
.venv\Scripts\python.exe "E:\TEMP\WF1B_Install_v1\RUN_WF1B_SUITE.py" --repo .
```

Expected: `git status --short` prints nothing (if it prints anything, stop and send Claude the output); the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `38 File(s) copied`; `POST PASS`; then `SUITE PASS` (447 tests; the only allowed skips are symlink tests: on Windows without symlink rights, up to 3). E2R-T12 starts up to six ordinary Python worker processes and lets them finish normally. The WF-1B tests run on invented data in temporary folders, with an invented N1 root. If anything prints `STOP` or `FAILED`, do not commit: send Claude the output.

## 2. Stage, commit, check, and only then push

```bat
git add .gitignore Run_Method_Rankings.bat doc review src tests
git status --short
git commit -m "WF-1B: the R3 stage-2 scorer and ranking report (src/evaluation, Run_Method_Rankings.bat), N1 and its seed policy records; WF-1B supplement design v0.1r1"
python "E:\TEMP\WF1B_Install_v1\VERIFY_WF1B_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 37 lines starting with `A` and 1 starting with `M`, and nothing else; then `COMMITTED PASS`. Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub.
