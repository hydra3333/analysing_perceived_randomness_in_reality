# Predictive Randomness — Ratification Register

**Register version:** v0.30, 15 November 2026, OWNER-RATIFIED 15 November 2026, about 09:10 (RAT-32, with H-1 v3; written by Claude from the records; reviewed in EX_190 to EX_192), recording the documentation install of RAT-31 (`5a8527b`), the owner's dependency change (`cc0ab73`) and TASK_T024, EX_176 to EX_190, the replacement reviewer chat, the owner's decisions of 14 November 2026 (C02, D1-D7, the working approach P0-P6, OUTLANDISH_01's methods, B01 as a scoped W-23 acceptance) and the POC rerun and updater self-test (both PASS); v0.29, 14 November 2026, OWNER-RATIFIED 14 November 2026, about 14:36 (RAT-31, with H-1 v2 and H-2 v2 r1; written by Claude from the records), recording the owner's decisions of 13 November 2026 (Mode H first, then MHUP-B; the fixed cohort; CATCH_UP; the freeze; Q7 decided; R-015 (b) and (c)), the Mode H readiness reviews (EX_167, EX_168 PASS; nothing authorised), the reviewer's full handover H-2 v2 (EX_169 to EX_172) and the full Claude handover H-1 v2 (EX_171, EX_172); v0.28, 13 November 2026, OWNER-APPROVED 13 November 2026 (written by Claude; a correction, not a new decision): register v0.27's "RAT-28" for the ratification of 11 November 2026 is read as RAT-30, and the ratifications RAT-28 (H-1 v1r10r2, 8 November 2026) and RAT-29 (H-1 v1r10r3, 10 November 2026) are recorded; v0.27, 13 November 2026, OWNER-APPROVED 13 November 2026 as DOC-14 (written by Claude from the records; documentation of decisions already ratified, not a new ratification), recording the integrated MHUP-A package from its start to its install and closure on 13 November 2026, rulebook v0.5 and the Appendix J amendments (RAT-28), design v0.1r7, the post-install test fix and the owner's decisions of 13 November 2026; v0.26 OWNER-RATIFIED 8 November 2026 (written by Claude; checked by the ChatGPT reviewer chat, EX_160 and EX_161, whose three corrections were applied; ratified by the owner with DOC-13, RAT-27), recording DOC-12's installation, T022 and T021, the owner's decisions DEP-1 and GAIS-1, the Git history clean-up and its commit-ID crosswalk, the owner's later own commits, the integrated MHUP-A package's start, the Claude handover H-1 v1r10r1 (EX_157 to EX_159; RAT-26), and the DOC-13 documents (H-2 v1r10 delta, design v0.1r6, the new-method template draft 5, the repository README, and the move of superseded editions); v0.25 OWNER-RATIFIED 6 November 2026 (written by Claude; the ChatGPT reviewer chat ended on 6 November 2026; the new reviewer chat checked candidate 1 in its takeover, EX_153; candidate 2 applied TAKEOVER-C01 to C05, EX_154; the reviewer's EX_155 passed C01 on RECHECK; candidate 3 applied its C06 and O02, EX_156; the owner accepted the new reviewer and ratified H-2 v1r9 and this register, RAT-25), recording DOC-11's installation, the completion of the staged Claude handover (HO-2) with the owner's decisions HO2-A and Q9-E1 to Q9-E4, the direction document v0.3r1, the MHUP-A code reviews in two slices (EX_141 to EX_152) with the owner's decisions C01-EFF, A1-B and IIIB-1 and the ratification of design amendment A1 (A1-R), the owner's Windows runs T018 to T020, the Claude Code rulebook v0.4 and its clone tool v0.4, the owner's own commits of 5 and 6 November 2026, and the end of the reviewer chat with the emergency handovers; v0.24 OWNER-RATIFIED 4 November 2026 (the Claude handover package reviewed in the ChatGPT reviewer chat's Step 1.1 review, EX_133 to EX_136), recording the DOC-10 installation, the chat switch, the stock-take of 2 November 2026 with the owner's decisions ST-1 to ST-5 and its correction, the direction document (DIR-1), the owner's process decisions MC-1 and KISS-1, the MHUP-1 design reviews EX_123 to EX_132 with the owner's decisions MHUP-Q10, MHUP-Q1, MHUP-B02, MHUP-C03, MHUP-B04, MHUP-Q11 and MHUP-D1 to MHUP-D3, the ratification of the MHUP-1 design v0.1r5 (MHUP-R) and the rules it amends, the staged AI handover (HO-2) with its Step 1.1 review, the owner's naming decision LW-1, and H-1 v1r8 with its introductory blurb; v0.23 OWNER-RATIFIED 1 November 2026 (content reviewed in EX_117, EX_119 and EX_121), recording register v0.22's installation, the seed brought forward and approved, the WF-1B supplement design and code reviews, the WF-1B and PERF-1 installations, the first real report runs, the owner's decisions GOAL-1, SD-1, SD-2, WB-0 to WB-2, WF1B-A1, WF1B-A2, PF-1, PF-2, HX-1, HX-2, ORD-1, HO-1, TSC-1, MH-1, OFF-1, EFF-1 and FB-1, the cold-read probes, the cold-read test of H-1 and the snapshot package's documents; v0.22 OWNER-RATIFIED 31 October 2026, recording the REL-1, WF-1A and E_1 revision 2 installations, the CODE-3 and E_1 revision 2 design and code reviews with the owner's decisions, the first walk-forward batches and the owner's performance proposal; v0.21 OWNER-RATIFIED 31 October 2026, recording the new reviewer chat's takeover, the releases and WF-1 design review and ratification with the owner's decisions WF1-1 to WF1-13, and the REL-1 and WF-1A packages; v0.20 OWNER-RATIFIED 30 October 2026, recording the wave 2 installation, the end of the previous reviewer chat, and the handovers H-1 v1r6 and H-2 v1r7 with their introductory blurbs; v0.19 OWNER-RATIFIED 30 October 2026, recording the wave 1 installation, the wave 2 design review, the owner's decisions and ratification, and the wave 2 package; v0.18 OWNER-RATIFIED 30 October 2026, recording the handover installation, the owner's revised order of work, the wave 1 review and owner decisions, and the wave 1 package; v0.17 OWNER-RATIFIED 30 October 2026, recording the E_3/E_4 installation, the owner's order of work and the handover round (H-1 v1r5, H-2 v1r6); v0.16 OWNER-RATIFIED 30 October 2026, recording the E_6 installation, the three-part review and owner decisions, and the E_3/E_4 package; v0.15 OWNER-RATIFIED 30 October 2026, recording the document-round installation, the E_6 review and owner decisions, and the E_6 package; v0.14 OWNER-RATIFIED 29 October 2026, recording the E2R-CODE-2 installation and acceptance, the owner decisions after register v0.13, and H-1 v1r4 and H-2 v1r5; v0.13 OWNER-RATIFIED 29 October 2026, recording the E2R-CODE-2 reviews, the owner decisions D2-1 to D2-4 and the E2R-CODE-2 installation; v0.12 OWNER-RATIFIED 29 October 2026, recording the E2R-CODE-1 installation and acceptance and the Claude Code local runner; v0.11 OWNER-RATIFIED 29 October 2026, recording the E1-ALIGN acceptance, the owner-approved E_2-readiness code scope and the E2R-CODE-1 contract library; v0.10 OWNER-RATIFIED 28 October 2026, recording the E1-ALIGN code installation, H-2 v1r4, exchange README v0.4 and the owner's rule for document-only installs; v0.9 OWNER-RATIFIED 28 October 2026, recording the NAMES-1 installation, the move to Python 3.15 and H-1 v1r3; v0.8 OWNER-RATIFIED 28 October 2026, recording the DOC-2 and NAMES-1 installations, the NAMES-1 ratification and the owner decisions made after register v0.7; v0.7 OWNER-RATIFIED 28 October 2026, recording the E2R-1 specification ratification and the owner decisions of 28 October 2026; v0.6 OWNER-RATIFIED 28 October 2026, recording the records after the effective commit (its identity, the delivery method, the review-disposition procedure and TH-1); v0.5 OWNER-RATIFIED 27 October 2026, recording the AI roles transition, the Package 2 v0.11-r1 acceptance and the integration installation; v0.4 OWNER-RATIFIED 27 October 2026 (drafted 26 October 2026), adding the method-ranking integration; v0.3 OWNER-RATIFIED 26 October 2026; v0.2 OWNER-RATIFIED 24 October 2026. Historical ratifications are preserved and remain valid.
**Basis:** the historical owner decisions and approved handovers, with current committed files cross-checked by Claude at GitHub HEAD `1c7cfced` (24 October 2026). Ten other content hashes matched that HEAD; the Architecture hash below is explicitly corrected to the **actually committed** v0.5 content (unfixed §5C heading). The separately proposed one-line heading change and register v0.1 were **not committed**. The pre-integration consolidated editions below were owner-ratified 26 October 2026; only explicit OPEN/PROVISIONAL/RECOMMENDED subitems remain undecided. The v0.4 entries were cross-checked by Claude against GitHub HEAD `618fe48` (26 October 2026), the v0.5 entries against GitHub HEAD `ae76c29` (27 October 2026), the v0.6 entries against GitHub HEAD `b14116b` (27 October 2026), and the already-committed v0.7 references against GitHub commit `38fc60e` (28 October 2026). The E2R-1 v0.3r3 specification is not present at that commit; it is verified by its content hash below, and its installation is a separate owner decision. The v0.8 entries were cross-checked by Claude against GitHub commit `908db9ea9d4a37b17833f5d43919804c78ef7e14` (28 October 2026); the NAMES-1 specification and code, and the E1-ALIGN specification, are installed with register v0.8, in one commit, and are identified by content hash. For v0.9, historical predecessor references through commit `83d1515` (28 October 2026) were checked by Claude. The new Python 3.15.2 environment and the Windows results are owner-reported. H-1 v1r3 and register v0.9 were OWNER-RATIFIED 28 October 2026 and are installed together in the DOC-3 commit, identified by content hash; the actual install commit and final blobs are verified separately after installation. For v0.10, the DOC-3 commit `ee62eb6` and the DOC-4 commit `040f80e` were verified by Claude from GitHub; the Windows results are owner-reported. The E1-ALIGN code and this register are installed together, in one commit identified after installation; the owner's Windows results for it are recorded after installation. For v0.11, the E1-ALIGN commit `295118d` and the follow-up commits `c1159c7` and `1b23fd9` were verified by Claude from GitHub; the Windows results are owner-reported. The CODE-1 contract library and this register are installed together, in one commit identified after installation. For v0.12, the CODE-1 commit `205ae73` and the Claude Code commits named in its section were verified by Claude from GitHub; the Windows results are owner-reported. This register is installed by the document-only procedure. For v0.13, the register v0.12 commit `b846519` and the exchange records `5957569` to `8d1f080` were verified by Claude from GitHub. The E2R-CODE-2 code and this register are installed together, in one commit identified after installation; the owner's Windows results for it are recorded after installation. For v0.14, the CODE-2 commit `ced9b6c` and the Claude Code commits named in its section were verified by Claude from GitHub; the Windows results are owner-reported. This register, H-1 v1r4 and H-2 v1r5 are installed together by the document-only procedure. For v0.15, the DOC-6 commit `337b5b2` and the clean-up commit `f9de54a` were verified by Claude from GitHub. The E_6 package and this register are installed together, in one commit identified after installation; the owner's Windows results for it are recorded after installation. For v0.16, the E_6 installation commit `7c93320` was verified by Claude from GitHub. The E_3/E_4 package and this register are installed together, in one commit identified after installation; the owner's Windows results for it are recorded after installation. For v0.17, the E_3/E_4 installation commit `5b9edb4` was verified by Claude from GitHub. This register, H-1 v1r5 and H-2 v1r6 are installed together by the document-only procedure. For v0.18, the handover installation commit `8defe9d` was verified by Claude from GitHub. The wave 1 package and this register are installed together, in one commit identified after installation; the owner's Windows results for it are recorded after installation. For v0.19, the wave 1 installation commit `947c370` was verified by Claude from GitHub. The wave 2 package and this register are installed together, in one commit identified after installation; the owner's Windows results for it are recorded after installation. For v0.20, the wave 2 installation commit `b61b1a2` was verified by Claude from GitHub. This register, H-1 v1r6, H-2 v1r7 and their introductory blurbs are installed together by the document-only procedure, in one commit identified after installation. For v0.21, the DOC-8 commit `03f7da4` and the exchange records from `4bdb060` onward were verified by Claude from GitHub. The REL-1 package and this register are installed together, in one commit identified after installation; WF-1A follows in its own commit. The owner's Windows results for both are recorded after installation. For v0.22, the installation commits `6a1bed9` (REL-1), `0d98706` (WF-1A) and `86d12ea` (CODE-3 and E_1 revision 2), the batch commits `86a1a01` and `8430a15`, and the exchange records from `ef51305` onward were verified by Claude from GitHub; the Windows results are owner-reported. This register is installed by the document-only procedure, in one commit identified after installation. For v0.23, the installation commits `2b1e7e3` (register v0.22) and `24d192f` (WF-1B), the Claude Code reports `bf47668`, `40958d6` and `2cc6933`, and the exchange records from `0b067f1` onward were verified by Claude from GitHub; the Windows results are owner-reported. Register v0.23 is installed with the snapshot package, by the document-only procedure, in one commit identified after installation. For v0.24, the DOC-10 installation commit `7bb0bfd`, the owner's commits `905ecee` and `f47ce14` to `6de0d99`, and the exchange records from `446bf38` onward were verified by Claude from GitHub; the Windows results are owner-reported. Register v0.24 is installed with DOC-11, the Claude handover package (document-only, with a verifier), in one commit identified after installation, after the reviewer's Step 1.1 review of that package (HO-2).  
**Authority:** This register records approvals; it does **not** independently ratify any document, authorise an experiment, or supersede an operative specification. If a historic document still says “draft”, “review candidate” or “not ratified”, its status at the time of drafting is historical. The later owner approval recorded here determines its current status.

## Current and historical ratification identities

SHA-256 below is computed from **UTF-8 Git-stored file content with LF line endings** (the canonical content represented by the source GitHub ZIP and ratified install artifacts), *not* from a Windows working copy whose checkout may have CRLF endings. The Architecture v0.5 hash below represents **actual Git-committed v0.5 content**, including the historical §5C heading. The corrected-heading version (`2d57f59afbd152ae80720e117dab5b9749ab3a611bf32ab1b14d3ed1be478acd`) was only proposed, never committed; Architecture v0.6 would replace it after ratification, without changing the v0.5 historical bytes. Hashes are immutable document-content identities, not Git commit IDs.

| Document (under `doc/`) | Authority and status | Owner approval date | Superseded by / qualifier | Git-content SHA-256 |
|---|---|---|---|---|
| `Predictive_Randomness_Research_Project_Proposal_v0_3.md` | Historical — OWNER-RATIFIED | 21 Oct 2026 | Proposal v0.4 | `04e061d13b69e49c0dc227b7093570e96598d4c416952ac6092af4d3d14d4b64` |
| `Predictive_Randomness_Experimental_Methods_Research_R1_v0_4.md` | Current — OWNER-RATIFIED | 21 Oct 2026 | — | `19809ae8a1aca716c6c6a4de71a37b705129304894a2b382036d51b76575b99f` |
| `Predictive_Randomness_Experimental_Method_Specifications_R2_v0_3.md` | Historical — OWNER-RATIFIED | 22 Oct 2026 | — (R2 approved erratum v0.2 also applies) | `7ec4bad9ab00a619a42cedc4abbe4bec393589563d3bc3061ab4737525259d71` |
| `Predictive_Randomness_R2_v0_3_Approved_Erratum_v0_2.md` | Historical — OWNER-APPROVED narrow erratum | 22 Oct 2026 | — (ERR-R2-02 remains provisional pending P2) | `a08b4e7620be8cb32142b23146c5f82c415a50e56cba0b2ea3bed6e1a4b80d5e` |
| `Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_2.md` | Historical — OWNER-RATIFIED | 22 Oct 2026 (ratified handback v0.2) | R3 v0.3 | `dd0b5243ad8f93a0de7c502e2e6ce54a99c5e427063ce7b3e49313fb18975800` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_4.md` | Historical — previously OWNER-RATIFIED | 23 Oct 2026 | Architecture v0.5 | `7526e381be93caa68ce8f8a6b90f135748925f1c0b080e171e1ef18cd771f257` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_5.md` | Historical — OWNER-RATIFIED | 23 Oct 2026 | Architecture v0.6 | `9889617f39be766a167856fdd171896c1ffb712aae8db4e78d6f3d861a345502` |
| `Predictive_Randomness_Windows_POC_Implementation_Task_Specification_v0_1.md` | Historical — OWNER-RATIFIED for P0–P2 | By 23 Oct 2026; precise date not independently established | Windows POC Task Spec v0.2 | `deeae27f846061d51555c3d89a77c8199941b74456520a98aa6501c504b85e5e` |
| `Predictive_Randomness_Windows_POC_Implementation_Task_Specification_v0_2.md` | Current — OWNER-RATIFIED | 23 Oct 2026 | — | `ca5e89dde7e9927974e759f1df115eefca03144de45e073c240aa9e13f24ebf1` |
| `HANDOVER/Predictive_Randomness_ChatGPT_Continuation_Handback_v0_2.md` | Historical — OWNER-RATIFIED | By 23 Oct 2026; precise date not independently established | Handback v0.4 | `53b33b6ddec5b874725b195d4c45e3295351915a6e8331e2d2eb56d4b8a28140` |
| `HANDOVER/Predictive_Randomness_ChatGPT_Continuation_Handback_v0_4.md` | Historical continuity — OWNER-RATIFIED | 23 Oct 2026 | — | `5093e446fb14bc281fecea1e722ee2bea366614dac9fb5192e36b96b63e603db` |

## Multi-game documents ratified 24 October 2026

| Ratified document | Authority and supersession | Git-content SHA-256 (UTF-8/LF) |
|---|---|---|
| `Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_3.md` | OWNER-RATIFIED; supersedes R3 v0.2 for multi-game evaluation extensions | `69d61d162d8d46094c02c1aca36ba53b47e6aec56fe5552f3ef39687f07d0826` |
| `Predictive_Randomness_R2_v0_3_Erratum_Record_v0_3.md` | OWNER-APPROVED ERR-R2-05; preserves earlier errata, ERR-R2-02 still provisional | `f3be1b28bb156ec68207ad6cd614972bedcd2409519c9e8dd6a8751c41a5768e` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_6.md` | OWNER-RATIFIED; supersedes Architecture v0.5; existing safety conditions preserved | `99b8222b0d905fc45eda7723997aa9cfcbe7ba09a5b0b8d322b9eea3e766cea7` |
| `Predictive_Randomness_Research_Project_Proposal_v0_4.md` | OWNER-RATIFIED; supersedes Proposal v0.3 for multi-game scope | `1749889d4f02825b15a8f317e9620b2ab8b26908c41eda8611157c1675f089b5` |
| `Predictive_Randomness_MultiGame_Infrastructure_P3_Task_Specification_v0_1.md` | OWNER-RATIFIED new task specification; POC task v0.2 retained separately | `86c4d062cafab07595953e5447ec5ae5b287e0d98e2fa4ec35c1015e0fa052f4` |
| `contracts/TIE_SHA256_V1_Ratified_Encoding_v0_2.md` | OWNER-RATIFIED multi-game applicability; encoding unchanged | `045b784d16a4611ac4ba5e8af063733e957b0b9359882d52b7143b912a65a0b6` |

**Register identity:** this register cannot include its own SHA-256 without a self-reference. Its final file hash is provided in the enclosing installation manifest; update the register only in a later version after a corresponding owner decision.


## Method ranking measures and integration editions (26 October 2026)

In this section, "this register" means register v0.4, the edition that recorded the integration. Two documents were owner-ratified on 26 October 2026 at commit `ac01678`. Their authoring-time headers ("RATIFICATION CANDIDATE" / "CANDIDATE ... awaits owner ratification") are historical; the ratification recorded here determines their status, and the files are never edited to change those headers.

| Document (path under `doc/`) | Authority and status | Git-content SHA-256 (UTF-8/LF) |
|---|---|---|
| `Predictive_Randomness_Method_Ranking_Measures_Proposal_v0_5.md` | OWNER-RATIFIED 26 Oct 2026. Its content is integrated into the four editions below, owner-ratified 27 Oct 2026; the file is integrated history, kept unchanged. Versions v0.2-v0.4 are historical drafts. | `c6ca2cb2174ee2963a6fe33347820c80b92e6dd1eda518a1f0c8e3254d67ab19` |
| `HOLDOUT_EXPOSURE_RECORD_v0_2.md` | OWNER-RATIFIED 26 Oct 2026; factual, value-free record (6 items); supersedes v0.1 | `aec833fe031b6d1d73e6acbb81757b50b193425a6899c84d438431d9df4433e2` |
| `RATIFICATION_REGISTER_v0_3.md` | OWNER-RATIFIED 26 Oct 2026; superseded by register v0.4 (OWNER-RATIFIED 27 Oct 2026) | `99e75fbe1bc5cea34a7d2b1c456633815b88e340c4a05aab5fb671d624c7ec37` |

**Integration editions (OWNER-RATIFIED 27 October 2026).** Each is its ratified predecessor edited in place; every ratified ID and rule is kept, and the protected blocks are byte-identical.

| Integration edition (path under `doc/`) | Ratified predecessor | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md` | R3 v0.4 | OWNER-RATIFIED 27 Oct 2026; adds R3 section 17 (method ranking measures); `53e30a3e649b48b8a88923d08bf578caf04a4ce93d6ea6468891ca97e93a57b6` |
| `Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md` | R2 v0.4 | OWNER-RATIFIED 27 Oct 2026; adds R2 sections 2.5 (supplementary rule), 3.6 (numbering), 5.6 (stage-1 contract fields) and 8.4 (in-sample mode); `2c67db8fcba50e469b0490cd85caf2fe964b3b79fc17fe7da4ebf033b91d9a3e` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_8.md` | Architecture v0.7 | OWNER-RATIFIED 27 Oct 2026; adds Architecture sections 5A.4 (ranking tool launcher) and 12.5 (report tool, in-sample runs, N1); protected 5C unchanged; `32cf157d9ce8850e790274e962236f2be3b50a8bdee7ec94a28ba00d7fd452ec` |
| `Predictive_Randomness_Research_Project_Proposal_v0_6.md` | Proposal v0.5 | OWNER-RATIFIED 27 Oct 2026; adds Proposal section 2.7 (charter); supplementary sentence in Proposal sections 0 and 3.1; `6a281e05127e7db976a16557ba69006327a8d615c2b0ec90bb6b34ee1c648a73` |

**On owner ratification (given 27 October 2026):** the installation step changes the **five edition/status headers, including this register**, and all affected candidate-status and present-authority rows to OWNER-RATIFIED; it marks the pre-integration inventory explicitly historical, updates the R3 section 17.13 stage-0 integration status, recomputes the **four governed-document Git-content hashes** in this register and places this register's own SHA-256 in the external installation manifest. Claude verifies the resulting installed files against the committed Git HEAD. Historical hashes and decisions remain preserved. Neither ratification nor documentation authorises runs, Mode H/FINAL, holdout access, process termination or Package 2 scientific use. Unchanged by this integration: R1 v0.4, TIE_SHA256_V1 v0.2, P3 v0.2, the Windows POC Task Specification v0.2, the numerical reference v0.1, the E_1 legacy schema and goldens, the masters, the owner tools, the coordinator and Package 2 v0.11.

**Continuity documents:** from the effective commit, the current continuity documents are H-1, H-2 and H-3 (next section). Before it (commit `618fe48`, verified by Claude), the current handovers were `HANDOVER/Claude_Reviewer_Handover_Predictive_Randomness_v10.md` and `HANDOVER/Predictive_Randomness_ChatGPT_Coder_Handover_v1_1r1.md`. Reviewer handovers v2-v9, coder handovers v1.0r1 and v1.1, and the ChatGPT handbacks are in `HANDOVER/superseded/`; the interim note is in `HANDOVER/`. They are continuity records, not normative, and are superseded for future roles by H-1, H-2 and H-3.

## AI roles transition, Package 2 acceptance and integration installation (27 October 2026)

Paths in this section are under `doc/`, except those beginning `review/`, which are from the repository root.

**Roles.** `HANDOVER/HANDOVER_CHANGED_AI_Roles_Agreed_v0_1r1_RATIFIED.md` (`7d572400b941ad423978a7542d6c32fb73c934f0057240dbc5138898112bd53b`) is OWNER-RATIFIED (committed at `4a45b70`). **Effective commit (owner decision, 27 October 2026):** the commit that installed register v0.5 together with H-1, H-2 and H-3, which is `d36735da777b7d8403718af9e1d9d65c1cad47cc` (identified in register v0.6); it is not the Package 2 acceptance commit. From the effective commit, Claude is primary designer and coder, the ChatGPT reviewer chat is the independent reviewer, and the project owner remains sole ratifier, run authoriser and committer; the agreed position's sections 1-8 apply. **Owner decision, 27 October 2026:** from the effective commit, the ChatGPT reviewer chat holds the latitude Claude held as reviewer from 23 October, to be used carefully: it settles routine review matters itself, labelled REVIEWER-DECIDED; consequential items still go to the owner. Claude as author keeps only routine choices that affect no scope, acceptance or review gate. **Owner instruction, 27 October 2026:** for the first three reviews under the new roles, Claude checks every REVIEWER-DECIDED item against the ratified compliance, safety and process rules and flags any departure to the owner; reporting only (H-1 section 1.5). The transition documents below carry their authoring-time "DRAFT" headers; this register records their ratification. The ChatGPT coding chat retired on 27 October 2026 and the earlier Claude reviewer chat on 26 October 2026. As of drafting, the owner reports no intervening code package since the ChatGPT coding chat retired; any work before the effective commit is reconciled at installation against the existing roles and gates.

| Transition document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `HANDOVER/Claude_Primary_Handover_H1_v1r1.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 27 Oct 2026; superseded by H-1 v1r2 (register v0.6); `3223c41732888ea56c5458b365488660d157c93902b3745ed71d7d300fc2751e` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r2.md` | ChatGPT reviewer chat; facts checked by Claude; rights section checked by the owner alone | OWNER-RATIFIED 27 Oct 2026, including R-8..R-11 and section 3.1; superseded by H-2 v1r3 (register v0.6); `53f3af3f0845ea8534e25e896ffc8790fe685a7df9ecad8f7d7e48cd53f234a2`. Erratum: its closing line reads "End of H-2 v1r1 DRAFT"; the file is v1r2 and is installed unchanged. |
| `HANDOVER/AI_Roles_Transition_Record_H3_v1r1.md` | Claude; facts checked by the ChatGPT reviewer chat | OWNER-RATIFIED 27 Oct 2026; `8b01c57fd8804029906e1e9c87e8ecef18edb914a269e43a45dac90880703ce5` |

**Superseded for future roles** (kept in place as evidence, not normative): `HANDOVER/Claude_Reviewer_Handover_Predictive_Randomness_v10.md` (`61a5127816d30e2ffc342a011e3d029d7a3a6a80bc55c368751cc9d09ed9b191`); `HANDOVER/Predictive_Randomness_ChatGPT_Coder_Handover_v1_1r1.md` (`ab0afb64cec845cbbde29265e53309225991cd4a469306c609b905aff9048a01`); `HANDOVER/Interim_Handover_Note_for_both_claude_and_chatgpt_v1.md` (`a46866cad2c8d16869685f3a37b898dc453bf651572e60d27579024a2015a1e5`); `HANDOVER/Claude_Checkpoint_v2.md` (`33ddaf9c1d0d35726088d832893f72c7c97e532967c24b63cc36e6822f2693cf`). **Inputs, never authority:** D-1 `HANDOVER/Claude_Delta_Handover_D1_since_v10_v1.md` (`ac6dda4f6f965637118dbf2811cb4006497006e10f7be72476e5acd64c37a50c`) and ADD-2 `review/ChatGPT_Coder_ADD_2_Package2_v0_11r1_v0_1.md` (`ebaff99f4fc34ce38099ac5581abada7a1d0ffd1d8a7b7bfe3a0ce5fbb41f35b`).

**Package 2 v0.11-r1: ACCEPTED by the owner on 27 October 2026 and installed at commit `c5424839d8fc9d620bae132873e8594b5651d2ce`** (27 files: 2 modified, 25 added; Claude verified every blob against the reviewed bytes). Claude's review: `review/Claude_Review_Package2_v0_11r1_v1.zip` (`5c2e84655dcfd1d3a24129c0d38a5996e2f14195e807def382ba2bdb7d545a29`; PASS, 0 BLOCKER, 0 CORRECTION, 3 OPTIONAL). Factual record: `HANDOVER/Package2_v0_11r1_Acceptance_Deferred_Work_v0_1.md` (`42a75e0d75d33b4d8538070ba557b7e1a8ecc7117205baf131041473227a3ad3`). **Erratum:** that record names the installation hash file `EXPECTED_SOURCE_SHA256.json`; the actual file is `evidence/CLAUDE_EXPECTED_26_FILE_SHA256.txt` inside `review/Predictive_Randomness_MultiGame_Package2_v0_11r1_OWNER_INSTALL_OVERLAY_v0_1.zip`. Deferred test items P2-R1-O1 and P2-R1-O3 were scheduled as the first package under the new roles (owner decision, 27 October 2026) and are now done (TH-1, register v0.6); the other open optionals stay open. Acceptance grants no Windows, lifecycle, destructive, scientific, holdout, Mode H, FINAL, switch or allowlist authority.

**Integration installation:** installed at commit `ae76c29783856dbb9bf0076fabe0c3612340314e` (10 files added; Claude verified every blob). Package `MR_Integration_Install_v1r1.zip` (`154f54d8afb8870c7e4cc613fc9f69d656f8d8bbfbe343cc924f1566c67cd162`); its manifest `review/MR_Integration_Install_v1/INSTALL_MANIFEST_SHA256.txt` gives register v0.4's own SHA-256, `cdb8c24eeb1a855a042cfebed30a801e9e36a654ccc655b5a2b8cc4eba4585d7`. ChatGPT reviews: `review/Independent_ChatGPT_Focused_Review_MR_Integration_Candidates_v3.md` (PASS) and `review/Independent_ChatGPT_Focused_Review_MR_Integration_Install_v1.md` (editions PASS; C-INSTALL-01, verifier only, applied in v1r1).

| Document (path under `doc/`) | Authority and status | Git-content SHA-256 (UTF-8/LF) |
|---|---|---|
| `RATIFICATION_REGISTER_v0_4.md` | OWNER-RATIFIED 27 Oct 2026; superseded by register v0.5 (OWNER-RATIFIED 27 Oct 2026) | `cdb8c24eeb1a855a042cfebed30a801e9e36a654ccc655b5a2b8cc4eba4585d7` |

**Out-of-date statements in ratified editions.** These describe events that have since happened; this register prevails, and the files are not edited. Fold them into the next editions when those are revised for another reason.
- R3 v0.5 section 0.1, the Package 2 v0.11 row ("PENDING code/review"): Package 2 v0.11-r1 is accepted and installed (above).
- Architecture v0.8 section 0, "Current runtime task" (Package 2 v0.11 to correct C1-C6 under Claude's review): done; the reader and coordinator are installed at `c542483`.
- Proposal v0.6 section 0, "Current execution boundary" (ChatGPT implements and Claude reviews), and A-29: from the effective commit, the agreed roles position governs who drafts and who reviews. The rest of that paragraph (no scientific use approved; switches False; orphan interlock; empty allowlist) still holds.
- Proposal v0.6 section 0, "Document classification" (Package 2 outstanding), and A-18 (Package 2 v0.11 and its reviews outstanding): done.

## Records after the effective commit (register v0.6; 27 October 2026)

Paths in this section are under `doc/`, except those beginning `review/`, which are from the repository root. In this section, "this register" means register v0.6.

**Effective commit identity.** The effective commit is `d36735da777b7d8403718af9e1d9d65c1cad47cc` (parent `6460ae3`), verified by Claude in `review/Claude_Verification_Transition_Commit_d36735d_v1.md` (`c76b3bb305fca61bec0b791e6d792bc5b33f46529df0222498cbc5669a9343a0`, committed at `744afea`). The owner's commit `6460ae3` had already added four history files listed in the installation manifest, byte-identical to it; installation package v1r1's verifier accepted them. History commit `997ed46` added the final mechanical review and the installation ZIPs.

**Delivery method (owner decision, 27 October 2026; settles the Git transport question in the agreed roles position, section 11).** Changes are delivered as whole-file replacements: a `repo_overlay/` folder the owner copies onto the repository root, a read-only verifier with `pre`, `post` and `committed` phases (tolerant of CRLF working copies; every Git call uses `--no-optional-locks`), and a staging script naming the exact files. The exact unified diff of every changed file always travels with the package as evidence. No hand edits to project files; any deletion is explicit, listed and verified.

**Review dispositions (owner-accepted 27 October 2026).** `review/REVIEWER_FIX-and-PROCEED_RECHECK_PROCEDURE_v1.md` (`5067aa520990b8ccc8521a04f3581424100cdd94994f5b9e3cb9e37863685339`, committed at `b14116b`) adds two reviewer-controlled dispositions to the four finding classes, which are unchanged. FIX AND PROCEED: Claude makes exactly the correction the reviewer authorised and continues without a separate recheck of it, keeping the evidence the procedure lists. RECHECK: the corrected material returns to the reviewer before acceptance. RECHECK is the default. Only the reviewer assigns a disposition, under its REVIEWER-DECIDED latitude; the owner may override. **Owner decision, 27 October 2026: FIX AND PROCEED never applies to code concerning any of the eight standing always-review subjects, however small the change.** The procedure changes no risk tier, always-review subject, reviewer right (R-1 to R-11), firewall, holdout safeguard or owner gate.

**Package sizing (owner-confirmed 27 October 2026).** Small packages for complex or HIGH work; a lead item that proves the pattern before a batch of similar items (for example, one lead method per family); heavy methods one at a time; ensembles last.

**TH-1 offline test hardening: ACCEPTED by the owner and installed at commit `744afea085c9fabc62c18ee5c18ee400d0853a9d`** (5 paths: 3 added, 2 modified; Claude verified every blob; the coordinator and the reader are unchanged; every file mode 100644). It closes the deferred Package 2 items P2-R1-O1 and P2-R1-O3. Installed package `review/TH1_Test_Hardening_v1r2.zip` (`47d6e5a67eb60b045c9b3c1b0930f0ced2ad082cee47dbdd93caaa74196c3015`); ChatGPT reviews `review/Independent_ChatGPT_Review_TH1_Test_Hardening_v1r1.md` and `review/Independent_ChatGPT_Focused_Recheck_TH1_Test_Hardening_v1r2.md` (PASS). The standard offline suite adds `tests.test_p2_r1_t05_hardening_v1` (60 tests). Owner-reported Windows evidence (Windows 11, Python 3.14.8): 60 OK with 2 skips, both because the owner's account cannot create symlinks; the reader's refusal of a hard-linked master passed on NTFS. Acceptance grants no Windows lifecycle, destructive, scientific, holdout, Mode H, FINAL, switch or allowlist authority.

**Oversight instruction status (as at register v0.6; superseded by register v0.7).** Two of the first three reviews under the new roles are done (the TH-1 review and its recheck). Claude listed the REVIEWER-DECIDED items (TH1-RD-01 to TH1-RD-04) and found no departure from the ratified rules. The third is the review of the package that carries this register edition.

**Continuity documents (register v0.6).** H-1 v1r2 replaces H-1 v1r1 for future roles; H-2 v1r3 replaces H-2 v1r2; H-3 v1r1 is unchanged. Earlier editions stay in place as history.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `HANDOVER/Claude_Primary_Handover_H1_v1r2.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; `55543ba522a4085fc4f2476d421a4940171bcd4c183a1fab5a691d291605eac0` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r3.md` | ChatGPT reviewer chat; facts checked by Claude; rights section checked by the owner alone | OWNER-RATIFIED 28 Oct 2026; `a2fb5c641a6fa8010aa59ff811aeba23145703bd5c0d4e2dbd70ac2fb419edb1` |
| `RATIFICATION_REGISTER_v0_5.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 27 Oct 2026; superseded by register v0.6; `551c1b42e99b58ad313dabe7d533e5650db83edce58e04f954b2f616c77afb3f` |

## E2R-1 specification and owner decisions of 28 October 2026 (register v0.7)

Paths in this section are under `doc/`, except those beginning `review/`, which are from the repository root. In this section, "this register" means register v0.7.

**DOC-1 installation.** Register v0.6, H-1 v1r2 and H-2 v1r3 were installed at commit `be185485693f29cf9ab28292dc6eebad00bbc32c` (parent `b14116b`; 9 files added; Claude verified every blob against `review/DOC1_Install_v1/INSTALL_MANIFEST_SHA256.txt`, whose SHA-256 is `6d992efa1fc78e286702f351c4180ef13720d93eca5c1cfbafade8fafc3c9476`, and which gives register v0.6's own hash, `5e677dce3f2ae01cd7a3f6cc1ff408c8e32e268150fe0c956e42bf703a9b074c`). The DOC-1 review is `review/Independent_ChatGPT_Review_DOC1_Records_Refresh_v1.md` (PASS). That review was the third of the first three reviews under the owner's oversight instruction; no departure was found.

**E2R-1, the E_2-readiness method-generic contract specification.** `Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md` (`0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954`) is OWNER-RATIFIED 28 October 2026. It is the stage-1 contract-field schema and acceptance list required by R2 v0.5 section 5.6, R3 v0.5 section 17.13 (stage 1) and Architecture v0.8 section 20A. Its authoring-time "DRAFT" header is historical; this register records its ratification.
- **Review history**, all by the ChatGPT reviewer chat:
  - the R-3 review of v0.2, `review/E2R_R3_Review_Commit_Independent.md` (`17087f5715bc3cfe49a2120fd25d1cdb626c6d9c480d53b5f3bb73559e93b2b2`; 3 BLOCKER, 10 CORRECTION, 2 OPTIONAL, 1 RECONSIDER);
  - its unforwarded predecessor, `review/Independent_ChatGPT_R3_Design_Review_E2R_v0_2_FINAL_OWNER_Addendum_v0_2.md` (history only; superseded);
  - focused rechecks of v0.3r1 (`review/Independent_ChatGPT_E2R_v0_3r1_Focused_Recheck_v0_1.md`, `866974a7ca38a156c76d46034fd0f31c2970b814dc627685f33c9c585f8ae392`) and v0.3r2 (`review/Independent_ChatGPT_E2R_v0_3r2_Focused_Recheck_v0_1.md`, `865edd97b97b06a5975b3ddc037dc5d3053e1f563cd1f295857a7a9d7623def2`);
  - the **PASS** recheck of v0.3r3, `review/Independent_ChatGPT_E2R_v0_3r3_Focused_Recheck_v0_1.md` (`3b69f540c637f400c503092daef9072c0069a857b9450cc91355e48e7c7d6646`; 0 findings).

  The review packages are `review/E2R_Spec_Review_v0_2.zip` and `review/E2R_Spec_Recheck_v0_3r1.zip` .. `_v0_3r3.zip` (commit `319fd11`).
- **What ratification does:** it fixes the design that the E_2-readiness code package implements. It authorises no code, no NAMES-1 work, no source move, no run, no registry change and no release. Each of those needs its own owner decision. It changes no ratified text of R2, R3 or Architecture; where it extends them, the next editions fold it in (out-of-date statements below).

**Owner decisions of 28 October 2026 recorded in the specification (its section 14).** Each is OWNER-DECIDED:
- **D-1:** `track_id` excludes the method revision. Each report uses one declared revision per track, and nothing is silently mixed or replaced (E2R-R40, R40A).
- **D-2:** synthetic and benchmark records carry the evidence tier `NOT_EVIDENCE`.
- **D-3:** method texts for E_1 and E_2 are written in the E_2-readiness code package; later methods' texts are written with their own specifications.
- **D-4:** `src/` holds current code only, with stable names and a folder per method (`src/methods/E_<nnn>/`, a locator only).
- **D-5:** superseded revisions move to revision-labelled archives (`archive/methods/E_<nnn>/r<k>/`, `archive/common/<name>/r<k>/`) with a README. There are no commit IDs, no stored file hashes and no run-time code-identity recording. Exact historical replay is not promised.
- **D-6:** a method runs only if its active registry entry is `SUPPORTED` for its current revision **and** no `IN_DEVELOPMENT.txt` flag is present. Release is the owner's two deliberate actions.
- **D-7:** NAMES-1, a one-off rename of existing versioned file names, comes before the E_2-readiness code.
- **D-8:** prospective results are shown both "as published" and "current methods".
- **D-9:** a seed policy's root is a pre-announced NIST Randomness Beacon pulse, fetched once by hand and independently verified. Runs never fetch.
- **D-10:** roots may be switched as a new revision or variant. Every root tried is logged and counted.
- **D-11:** a root published after historical targets may be used for retrospective development runs, labelled as experiment randomisation. A real forecast needs an already-approved root.

**Process decisions of 28 October 2026 (OWNER-DECIDED).**
- **Oversight instruction:** extended from three to six reviews under the new roles. The reviewer counts the E2R-1 rechecks as continuations of review 4 (its E2R-RD-13, -17 and -21). This newer owner instruction of 28 October 2026 supersedes the earlier requirement to send the owner every REVIEWER-DECIDED item: the reviewer still lists every item, and Claude still checks every one, but reports one to the owner only if Claude disagrees with it, or judges that it would interest the owner. It changes reporting only; reviewer rights are unchanged, and the authority is not delegated.
- **Handover documents get one review** each.
- **Git history:** the owner may clean or rewrite it once the code base is stable and in production, and does not plan to before then. Before any clean-up, Claude records which commit IDs this register and the handovers rely on. The E2R-1 design does not depend on Git history.

**Snapshot commits.** `319fd11` added `HANDOVER/Claude_Checkpoint_v4.md` (`d7634683d3d40edaa27c91576531cb198f1358613ca84c2e67e42096a1a6456e`; a non-authoritative running checkpoint) and the E2R-1 review history above. `38fc60e` added the superseded interim review and a duplicate copy of the checkpoint at `review/Claude_Checkpoint_v4.md`, byte-identical; history only.

**Out-of-date statements (register v0.7).** This register prevails, and the files are not edited:
- Architecture v0.8's standalone `.py` wording is extended by owner decision D-4. NAMES-1 proposes stable filename renaming only, without implementing per-method folders; its exact entry-file/folder layout is subject to the owner's separate OPEN-N1 decision. The next Architecture edition will incorporate the settled layout.
- R2 v0.5 section 5.6 and R3 v0.5 section 17.13 say the owner ratifies the stage-1 field schema first: done (above).
- H-1 v1r2:
  - section 1.5 describes the oversight instruction as three reviews with full reporting (now six, by exception);
  - section 9 lists the E_2-readiness specification as next (done; NAMES-1 is next, then the E_2-readiness code);
  - it does not mention the E2R-1 specification or decisions D-1..D-11.

  The next H-1 revision folds these in.
- Register v0.6, "Oversight instruction status" (two of three reviews done): superseded by the paragraph above.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; `0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954` |
| `RATIFICATION_REGISTER_v0_6.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; superseded by register v0.7; `5e677dce3f2ae01cd7a3f6cc1ff408c8e32e268150fe0c956e42bf703a9b074c` |

## NAMES-1 and owner decisions after register v0.7 (register v0.8)

Paths in this section are under `doc/`, except those beginning `review/` or `exchange/`, which are from the repository root. In this section, "this register" means register v0.8.

**DOC-2 installation.** The E2R-1 specification v0.3r3 and register v0.7 were installed at commit `908db9ea9d4a37b17833f5d43919804c78ef7e14` (28 October 2026).
- **It arrived in two commits.** The owner had already committed four of the package's eight files, byte-identical to the package, in commit `2c766644215a315edd8b92130e691224b60cd3de` (merged as `f300f2dfcd5c6a5efccb4c8b1040368728e2ad69`). They were the two DOC-2 review packages and the two DOC-2 reviews. `908db9ea9d4a37b17833f5d43919804c78ef7e14` added the other four.
- **The installer stopped on its one-commit rule only.** Its final check requires a single commit to add all eight files, and that is the rule that failed. Its blob check, which runs first, had passed for all eight files. The owner pushed after Claude confirmed that.
- **The owner accepted the two-commit delivery as a one-off exception (28 October 2026; OWNER-DECIDED).** It is not a precedent: a STOP remains a STOP. The installer STOP results are not recast as PASS. The reviewer accepted the installed DOC-2 content on this evidence (DOC2-RD-04, in `review/Independent_ChatGPT_EX_011_DOC2_Register_v0_8_NAMES1_Final_Recheck.md`, LF copy, `8c632dbc29916cded75efedecf6e3eea8918f07157e198e9fed2a72e34af6d0e`).
- **Claude verified the result from GitHub.** At `908db9ea9d4a37b17833f5d43919804c78ef7e14` all eight files match the package: the seven listed in `review/DOC2_Install_v1/INSTALL_MANIFEST_SHA256.txt`, and the manifest itself (`c3b373a3222d716963a1894ccc9d84f5737fa4af673d74b1fca18fdf1c39f8a0`). No file under `src/` or `tests/`, and no `.bat` file, has changed since `38fc60e`.
- **Commit `2c76664` also carried six NAMES-1 and E1-ALIGN history files**, byte-identical to those that NAMES-1 cites: the two NAMES-1 review packages and reviews, the owner-decisions record, and the E1-ALIGN early comments. Register v0.7's final bytes are `f9be980c2482c22cb2da6f7af34020f8cfd8e32302694c975c955ec407fcc015`. Its reviewed candidate r2 was `8b751a878e0626165b6c01bbc49d7d3014b3bd83a171200b4247eb5ec761796d`, and the mechanical finalisation diff is `review/DOC2_Register_v0_7_candidate_to_final.diff`.
- The DOC-2 reviews were:
  - `review/Independent_ChatGPT_Review_DOC2_Register_v0_7_v1.md` (2 CORRECTION, 1 OPTIONAL);
  - the PASS recheck `review/Independent_ChatGPT_Focused_Recheck_DOC2_Register_v0_7_r2.md` (`fc35b3ff7ad6892a066c7aca081f00c90cbc0847901ccebe3a2c202b376af13a`).

**NAMES-1, the one-off rename to stable file names.** `Predictive_Randomness_NAMES1_Rename_Specification_v0_2.md` (`07bda3e4a8a99bfc611a76cec672f8642532186567737e1a23de5e5701489e5a`) is OWNER-RATIFIED 28 October 2026. Its `OPEN` labels show its drafting state; the owner's decisions are below.
- **Review history**, all by the ChatGPT reviewer chat:
  - the R-3 review of v0.1, `review/Independent_ChatGPT_R3_Design_Review_NAMES1_v0_1.md` (`30d24ed02ff4ba3b0c84c760f306c8bfd02ddd2717db61013e60f855e3ace85a`; 0 BLOCKER, 4 CORRECTION, 1 OPTIONAL, 1 RECONSIDER);
  - the **PASS** recheck of v0.2, `review/Independent_ChatGPT_Focused_Recheck_NAMES1_Spec_v0_2.md` (`020fe9f73ba15f5260812d06701713d7b439880afb4197ace3488c4d63849f45`).

  The review packages are `review/NAMES1_Spec_Review_v0_1.zip` (`6aab40a1407c4b438ce05b7132ee2d3e183a6feb711d6f5877d9becc3246325f`) and `review/NAMES1_Spec_Recheck_v0_2.zip` (`fddf24f147406038653673e49350a7737b97c518849e46fc8c7b178d06b442a6`).
- **Owner decisions on NAMES-1, 28 October 2026** (OWNER-DECIDED; recorded in `review/Owner_Decisions_and_E1_ALIGN_Proposal_28Oct2026.md`):
  - **OPEN-N1 = A.** Each method's entry file stays directly in `src/methods/` (`E_<nnn>_<Name>.py`), as the Option F wrapper requires. Its folder `src/methods/E_<nnn>/` holds its method-specific modules and its `IN_DEVELOPMENT.txt` flag, and is created when that method's code first arrives. This settles the layout that E2R-1 section 12A.1 and decision D-4 left to NAMES-1.
  - **OPEN-N2 = deferred.** The owner's data tools and the legacy one-off test scripts stay out of NAMES-1. Any later tidy-up is a separate, owner-scoped package.
  - **OPEN-N3 = accepted.** The stable test names are those of the specification's section 3.
- **Installation.** The NAMES-1 code is installed in the same commit as this register. It makes 27 renames, with the 94 allowlisted substitutions in 27 files. Its manifest is `review/NAMES1_Code_Install_v1/INSTALL_MANIFEST_SHA256.txt`, and its exact allowlist and proof evidence are filed under `review/NAMES1_Code_Install_v1/`. The reviewer's code RECHECK is filed in `review/` in the same commit. The owner's Windows run of all 79 current tests, made before committing, is the acceptance.
- **E_1 stays revision 1**, under the structural exception scoped to NAMES-1 (N1-R03; E2R-R14A).
- **A visible record effect (N1-R01B).** A coordinator exit receipt issued before NAMES-1 no longer verifies afterwards, and is refused. No scientific receipt can exist yet, and none is converted or bypassed.
- **Test commands after NAMES-1.** The 60-test standard offline suite is `tests.test_multigame_reader_contracts tests.test_multigame_static_and_timing tests.test_multigame_launch_and_manifest tests.test_multigame_exit_receipt tests.test_multigame_science_allowlist tests.test_multigame_console_and_synthetic_scorer tests.test_t05_hardening`. The other 19 current tests are `tests.test_e1_standalone tests.test_multigame_windows_lifecycle_review`. Both use `PYTHONPATH` = `src`, `src/methods`, `tests`.

**Owner decisions made after register v0.7 (28 October 2026; OWNER-DECIDED).**
- **Oversight instruction: extended indefinitely**, superseding register v0.7's "six reviews". The reporting rule is unchanged: the reviewer lists every REVIEWER-DECIDED item, and Claude checks every one but reports one to the owner only if Claude disagrees or judges it of owner interest. Reviewer rights are unchanged, and the authority is not delegated.
- **Python 3.14.10 and the dependency update** (approved by the owner). The project venv was upgraded from Python 3.14.8 to 3.14.10 with `venv --upgrade`. The owner's dependency updater then changed no package versions: numpy 2.5.4, scipy 1.18.1, psutil 7.2.2, threadpoolctl 3.7.0, requests 2.34.2, beautifulsoup4 4.15.0 and selenium 4.51.0. Before NAMES-1, the owner re-ran the current suite on Windows: 60 tests OK with 2 skips, and the other 19 OK. Moving to Python 3.15 is a separate, later owner decision.
- **Phone exchange protocol:** `exchange/README.md` v0.3 (commit `262a2c4`).
  - When the owner relays from a phone, each message between the two AI chats is one upload: `EX_NNN_<Sender>.md`, or a flat `.zip` whose EX message lists its contents.
  - Claude records every EX file from both sides in `exchange/`, unchanged, and commits **only** inside `exchange/`.
  - Nothing in `exchange/` is ratified. Only the owner moves material into the main tree.
- **E1-ALIGN design ratified.** `Predictive_Randomness_E1_ALIGN_Specification_v0_2r1.md` (`d9ffd900c74d8a0cc5002bb78c83121f818514cd88ca9150bada8d6d1fa6653a`) is OWNER-RATIFIED 28 October 2026, as a design only, and is installed with this register. E1-ALIGN brings E_1 into the per-method layout and removes the shared reader's dependence on E_1's module.
  - **Review history**, all by the ChatGPT reviewer chat. Reviews that arrived through `exchange/` are stored under `review/` with LF line endings; the hashes below are of those LF copies, and the CRLF originals stay in `exchange/` (EX_004, EX_007 and EX_009):
    - early comments `review/Independent_ChatGPT_E1_ALIGN_Early_Design_Comments_28Oct2026.md` (`0cf83504ecd35440cc35723d74dcafab5c58b4dbd33c7feb3daaca3b475021af`);
    - the R-3 review of v0.1, `review/Independent_ChatGPT_R3_Review_E1_ALIGN_v0_1.md` (`ba64d1ef5a05718ac87f80802a74f08bde88b224c75a6cf58e6e9b7fb946df13`; 1 BLOCKER, 1 CORRECTION, 1 OPTIONAL);
    - the recheck of v0.2, `review/Independent_ChatGPT_E1_ALIGN_v0_2_Focused_Recheck_v0_1.md` (`7a887a780875da5b0f3f315b84d695c363017f8078aa6f6530939a9e5e9683c9`; 1 CORRECTION);
    - the **PASS** recheck of v0.2r1, `review/Independent_ChatGPT_EX_009_E1_ALIGN_v0_2r1_and_NAMES1_Order_Recheck.md` (`fbe0584ab69d7c59403bfc1f2e65aa3d868573d4fa17c38e6770d0ede7810248`; the reviewer's message EX_009, unchanged).
  - **Owner decisions, 28 October 2026** (OWNER-DECIDED):
    - **E1A-D1:** E_1 stays revision 1 under a structural-migration exception scoped to E1-ALIGN (its E1A-R02 conditions). This is a second scoped exception under E2R-R14A, not a precedent.
    - **E1A-D2:** the order is NAMES-1, then E1-ALIGN, then the E_2-readiness code. This amends E2R-R59.
    - **E1A-D3:** E_001's entry file keeps its whole-file firewall exemption for this migration, and the folder `E_001/` gets only the exact, counted allowances of the specification's section 5.
  - **Nothing about E1-ALIGN's code is authorised.** Its implementation is a separate HIGH-tier package after NAMES-1 is installed. It needs the owner's authorisation, an independent code RECHECK, and the owner's Windows run of all 84 tests.

**A known gap, found in review (28 October 2026).**
- The committed static import-firewall test (`test_method_loader_import_firewall_except_accepted_legacy_e1`) reads only the module part of `from X import Y`. So a method file using `from _common import game_draws_reader` would pass it.
- No current method uses that form, and NAMES-1 changes only the test's literal, not its logic.
- E1-ALIGN closes the gap with a symbol-aware check. Until then, Claude's review of every code package checks for that import form by hand.

**Out-of-date statements (register v0.8).** This register prevails, and the files are not edited:
- Register v0.7:
  - its oversight paragraph ("extended from three to six reviews"): now indefinite (above);
  - its line on Architecture's standalone `.py` wording ("subject to the owner's separate OPEN-N1 decision"): decided, A (above);
  - its basis line ("not present at that commit ... a separate owner decision"): the E2R-1 specification was installed at `908db9ea9d4a37b17833f5d43919804c78ef7e14`.
- E2R-1 section 12A.1 ("the exact entry-file and module layout inside each folder is fixed by NAMES-1"): fixed by OPEN-N1 = A.
- E2R-1 E2R-R59 (the order: specification, NAMES-1, E_2-readiness code): E1-ALIGN is inserted after NAMES-1 (E1A-D2).
- E2R-1 E2R-R14A ("the one scoped exception is NAMES-1's"): E1-ALIGN has its own scoped exception (E1A-D1).
- File names that NAMES-1 changed, in H-1 v1r2 (its section 7.1 module map and its suite command), in R2, R3 and Architecture, and in the TH-1 records: the old names are historical. The NAMES-1 specification's section 3 maps old to new. The next editions fold them in.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_NAMES1_Rename_Specification_v0_2.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; `07bda3e4a8a99bfc611a76cec672f8642532186567737e1a23de5e5701489e5a` |
| `Predictive_Randomness_E1_ALIGN_Specification_v0_2r1.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026 (design only); `d9ffd900c74d8a0cc5002bb78c83121f818514cd88ca9150bada8d6d1fa6653a` |
| `RATIFICATION_REGISTER_v0_7.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; superseded by register v0.8; `f9be980c2482c22cb2da6f7af34020f8cfd8e32302694c975c955ec407fcc015` |

## NAMES-1 installed, Python 3.15 and H-1 v1r3 (register v0.9)

Paths in this section are under `doc/`, except those beginning `review/` or `exchange/`, which are from the repository root. In this section, "this register" means register v0.9.

**NAMES-1 installation verified.** NAMES-1 was installed at commit `52ebeaa385fd05b18c4f3805c3cd2000948e343d` (28 October 2026; parent `7f6b4e8`), in one commit with register v0.8, the NAMES-1 v0.2 and E1-ALIGN v0.2r1 specifications and the review history, as register v0.8 records.
- **The owner's Windows run** (Python 3.14.10; owner-reported) followed the reviewed instructions:
  - PRE PASS; 27 renames; 42 files copied; POST PASS;
  - all 79 current tests passed, with 2 skips, the reader-contracts symlink subtest and the exit-receipt symlink test;
  - 63 import-origin and firewall checks passed;
  - COMMITTED PASS before the push.
- **One earlier attempt stopped at PRE** on three downloaded files saved under `review/`. It was undone with `git reset --hard` and `git clean -fd -- doc review`, and restarted from PRE. Nothing from it was committed.
- **Claude verified the commit from GitHub:**
  - the committed-phase verifier passes;
  - without rename detection, the commit has 42 additions, 27 deletions and 3 modifications;
  - `review/NAMES1_Code_Install_v1/INSTALL_MANIFEST_SHA256.txt` is `9d8664f38c33ee374ace06d29d98a4d84477af9199359e22bfcef84e1897f6a7`;
  - no `.bat` file and no test fixture changed;
  - the 79 tests pass on Linux.
- **The immediate recovery check (N1-T10) passed.** In a disposable clone, `git revert` restored a tree identical to `7f6b4e8`, and the pre-NAMES-1 suite passed under the old names. The clone was deleted. This is not a later rollback guarantee.
- **The reviewer's checks of the package:** the NAMES-1 code review (`review/Independent_ChatGPT_NAMES1_Code_Review_v0_1.md`), its rechecks (EX_009, EX_011) and the mechanical check of the final ZIP (`exchange/EX_013_ChatGPT.md`, PASS). Claude's report is `exchange/EX_014_Claude.md`.

**Python 3.15.2 (OWNER-DECIDED, 28 October 2026).**
- **The new venv:** the project venv is now Python 3.15.2, built afresh with `py -3.15 -m venv .venv`. The owner's dependency updater installed every package from a ready-built wheel: numpy 2.5.4, scipy 1.18.1, psutil 7.2.2, threadpoolctl 3.7.0, requests 2.34.2, beautifulsoup4 4.15.0 and selenium 4.51.0. Against the 3.14.10 venv, only certifi (2026.10.19 to 2026.10.23) and soupsieve (3.0.3 to 3.0.4) changed.
- **Tests (owner-reported):** on Python 3.15.2 at `52ebeaa`, all 79 current tests passed on Windows, with the same 2 symlink skips, and the 63 import checks passed.
- **The fallback:** the previous 3.14.10 venv is kept as `venv.bak` (ignored by Git), with Python 3.14 installed. The free-threaded 3.14t build was removed.
- **Not yet run under 3.15:** the owner's data tools. Their first run is a first run.
- **What changed in the language:** Python 3.15 makes UTF-8 the default text encoding (PEP 686). The tests show no effect on the project.
- **Ratified text this decision supersedes, on the interpreter version only:**
  - Proposal v0.6 A-17 ("Python 3.14 is the intended implementation platform") and its platform line;
  - R2 v0.5 section 9.1 ("Standard CPython 3.14 on Windows 11, not a free-threaded or experimental interpreter"). The rest of that line stands: the interpreter is standard CPython, not free-threaded;
  - R2 v0.5 section 12.3 ("Preserve the user's working standard Python 3.14.8 project `.venv`" and "its Python 3.14/Windows support checked"). Read these as the current project interpreter, now 3.15.2; any new package's support for that interpreter is still checked and announced first;
  - R3 v0.5's environment line, and Architecture v0.8 section 20.1, which cites the 3.14 documentation (an informational reference).

  The files are not edited; the next editions fold this in.
- **What this is not:** no scientific run, mode or gate changes with it. Moving to a new Python is not a W-23 waiver; the always-review rule on dependency upgrades stands.
- **Limits of the evidence:** the 79-test Windows run and 63 import checks are the evidence reported for this interpreter change; they do not by themselves establish the full W-23 and related dependency-upgrade acceptance gates. This record claims no completed gate not evidenced here. The owner's interpreter choice does not authorise a scientific or data run, or relax future upgrade preflight, numerical, N-1, golden or independent-review duties.

**H-1 v1r3.** `HANDOVER/Claude_Primary_Handover_H1_v1r3.md` (`ddf4de23b726b2abf55ffcab613f926b62775469076476f939288a278e6422fc`) was OWNER-RATIFIED 28 October 2026 and is installed with this register; its installation is verified after the install.
- It is a records refresh of H-1 v1r2. Its Appendix C lists every change.
- It replaces H-1 v1r2 for future roles; v1r2 is kept as history.
- It authorises nothing.

**The phone exchange records.** `exchange/EX_001` to `EX_014` record the messages between the two AI chats from 28 October 2026. They are committed by Claude inside `exchange/` only, up to commit `83d1515`. They are evidence, not authority. Where they matter, the review files are stored under `review/` as LF copies, as register v0.8 records.

**Out-of-date statements (register v0.9).** This register prevails, and the files are not edited:
- Register v0.8, its future-tense description of NAMES-1 being installed with it: now historical fact (above).
- H-1 v1r2, generally: superseded by H-1 v1r3.
- Python 3.14 as the project interpreter, in the ratified documents listed above and in H-1 v1r2 and H-2 v1r3: the venv is now 3.15.2 (above).
- H-2 v1r3: it does not cover the events of 28 October 2026. The reviewer chat may refresh it as its own handover; it gets one review.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `HANDOVER/Claude_Primary_Handover_H1_v1r3.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; `ddf4de23b726b2abf55ffcab613f926b62775469076476f939288a278e6422fc` |
| `HANDOVER/Claude_Primary_Handover_H1_v1r2.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; superseded by H-1 v1r3; `55543ba522a4085fc4f2476d421a4940171bcd4c183a1fab5a691d291605eac0` |
| `RATIFICATION_REGISTER_v0_8.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; superseded by this register; `3f217c6875d443a0cc1bba2f6c329b1fda455fb4a97bf7fe06090394736fffcf` |

## E1-ALIGN installed, H-2 v1r4 and document installs (register v0.10)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/` or `tests/`, which are from the repository root. In this section, "this register" means register v0.10.

**DOC-3 installation verified.** H-1 v1r3 and register v0.9 were installed at commit `ee62eb6d1c9c968f04ee1c6b26d7c9536dac0f3f` (28 October 2026; parent `ac9d120`), in one commit with the DOC-3 review records.
- **The owner's Windows run (owner-reported):** PRE PASS, 6 files copied, POST PASS, COMMITTED PASS before the push. An earlier attempt stopped before PRE on seven downloads saved under `review/`; they were moved out, and nothing was committed from that attempt.
- **Claude verified the commit from a fresh GitHub clone:** the committed-phase verifier passes, the commit adds exactly 6 files, and every blob equals `review/DOC3_Install_v1/INSTALL_MANIFEST_SHA256.txt`.

**H-2 v1r4 (OWNER-RATIFIED 28 October 2026; installed).** `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r4.md` (`73b90ea348aea5fc337097a14ec4a8669258bc6cba55ce5a2485de26575f3f3a`, UTF-8) was installed at commit `040f80e6e5ab90637da83ef971796ea59783e921` (DOC-4), with its review history.
- **Its one factual review** was Claude's (`review/Claude_Fact_Check_H2_v1r4_v1.md`): three documentary corrections, H2F-01..03, which the reviewer adopted (H2-RD-01..03).
- **Its reviewer-rights region** (R-1..R-11, T-05 and section 3.1; 7,676 bytes) is byte-identical to H-2 v1r3. Both chats checked this mechanically.
- **Its status lines are historical** ("PENDING PROJECT-OWNER RATIFICATION/INSTALLATION"); this register determines its status.
- **Supersession:** it replaces H-2 v1r3 for future reviewer roles; v1r3 is kept as history.
- **Verification:** Claude checked DOC-4 from GitHub: 8 added files, every blob equal to `review/DOC4_Install_v1/INSTALL_MANIFEST_SHA256.txt`. The owner's decisions record installed with it, `review/Owner_Decisions_H2_v1r4_and_Exchange_v0_4_28Oct2026.md`, is superseded by this register as the formal record.

**exchange/README.md v0.4 (OWNER-DECIDED 28 October 2026).** EX message files stay US-ASCII with CRLF. An enclosed document that is, or derives from, a UTF-8 project file keeps its characters, in LF or CRLF, and its identity is the SHA-256 of its canonical LF bytes. Committed by Claude inside `exchange/` only, at `63c19e7515e02acc10af1a9c7a290acc73371b7e`.

**Document-only installs (OWNER-DECIDED 28 October 2026).** The owner judged the install machinery for documents to be excessive overhead for little value, and directs effort to design safety, coding and testing.
- **Scope:** files only under `doc/` and `review/`: handovers, registers, specifications and review records. Not `src/`, `tests/`, a launch or owner `.bat` wrapper, data or `transitory_data/`.
- **Delivery:** one zip whose folders mirror the repository, and one short command block: extract; `git pull --ff-only`; copy; `git add doc review`; `git status --short`, which must list only the expected new files; commit; push.
- **The check:** after the push, Claude checks once from GitHub that the files and blobs are as expected. A mistake is fixed with a follow-up commit. There is no verifier script, no PRE/POST/COMMITTED, and no reviewer check of the install zip.
- **What is unchanged:** content review (one factual review of each handover; review of each register edition and specification) and the reviewer's rights.
- **Code packages keep the full discipline:** anything touching `src/`, `tests/`, wrappers or an always-review topic gets an exact allowlist, a read-only verifier, PRE, POST and COMMITTED before the push, an independent RECHECK and the owner's Windows tests. DOC-4 was the first install made this way.

**E1-ALIGN code (owner-authorised 28 October 2026; installed with this register).** The owner authorised the E1-ALIGN code package on 28 October 2026. The code is installed in the same commit as this register, under the ratified design `Predictive_Randomness_E1_ALIGN_Specification_v0_2r1.md` (`d9ffd900c74d8a0cc5002bb78c83121f818514cd88ca9150bada8d6d1fa6653a`) and its decisions E1A-D1..D3 (register v0.8).
- **What it changes:**
  - five E_1-only modules move from `src/methods/_common/` to `src/methods/E_001/`;
  - `canonical_bytes` and the tuple helper (now `length32_tuple`) move, bodies byte-for-byte unchanged, into `src/methods/_common/canonical_encoding.py`;
  - the shared reader imports its encoder from there, so it no longer depends on E_1;
  - the static import firewall is widened to method folders and made symbol-aware, with E_1's three exact, counted allowances (this closes the gap recorded in register v0.8);
  - `tests/test_e1_align.py` adds five guards.
- **The exact change set:** 5 moves, 10 edited files with 22 edit blocks, 1 file moved unchanged and 3 added files. Every edited file equals its predecessor plus the reviewed frozen allowlist, `review/E1ALIGN_Code_Install_v1/e1align_allowlist.json` (`aaf7f46e529ff42036cf7f943c4efc6232edbd2c3ff463e9e1be02f10a975164`), which the install verifier checks.
- **What it does not change:** no schema, record identity, golden, scientific constant or output byte; no E_1 behaviour. The protected coordinator, `coordinator_private`, the launch wrappers and the owner tools are not edited. The three switches stay False and the allowlist stays empty. E_1's real-mode gate and the orphan-marker checks are unchanged, and no gate is activated.
- **E1A-D1, E_1 revision 1:** E_1 stays revision 1 under its scoped structural exception only if the E1A-R02 conditions hold at installation. Those conditions are: the exact change set above; the moved definitions byte-identical; every E_1-facing symbol resolving to the same object; and the full proof, including the owner's Windows run. That run is the 84 tests by module (`RUN_E1ALIGN_SUITE.py`) and the location, origin and mutation checks (`CHECK_E1ALIGN_IMPORTS.py`), on the project interpreter, now Python 3.15.2 (register v0.9; this supersedes E1A-T12's "Python 3.14" on the version only). Its results are recorded after the install; this register does not predeclare them.
- **Evidence before installation (Claude, Linux; not Windows acceptance):** on Python 3.13.17, and on a 3.15.0b4 interpreter with numpy 2.5.4, scipy 1.18.1 and psutil 7.2.2, all 84 tests pass (79 before E1-ALIGN), with no skips. The exact allowlist check, the moved bodies, and the controls and mutations of the design pass. The allowlist regenerated from the installed NAMES-1 tree is byte-identical to the reviewed one.
- **Review:** the code package gets the reviewer's independent RECHECK (HIGH tier) before installation.

**The phone exchange records.** `exchange/EX_015` onward record the DOC-3, H-2 v1r4, DOC-4 and E1-ALIGN exchanges, from 28 October 2026. They are committed by Claude inside `exchange/` only, and are evidence, not authority.

**Out-of-date statements (register v0.10).** This register prevails, and the files are not edited:
- H-1 v1r3 section 1 and H-2 v1r4 section 8.2 ("Delivery practice"): document-only installs are now as above.
- H-1 v1r3's module map (section 7.1), Architecture v0.8's "one standalone `.py` per method", and the file paths of E_1's modules in R2, R3 and the TH-1 records: E_1's modules are now in `src/methods/E_001/`, its entry file is unchanged, and the encodings are in `_common/canonical_encoding.py`.
- H-1 v1r3, H-2 v1r4 and register v0.8, on the firewall's known `from _common import game_draws_reader` gap: closed by E1-ALIGN.
- Register v0.9, its exchange-records range ("`EX_001` to `EX_014`"): extended above.
- H-2 v1r3, generally: superseded by H-2 v1r4.

The next editions fold these in.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r4.md` | the ChatGPT reviewer chat; factual review by Claude | OWNER-RATIFIED 28 Oct 2026; installed at `040f80e`; `73b90ea348aea5fc337097a14ec4a8669258bc6cba55ce5a2485de26575f3f3a` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r3.md` | the ChatGPT reviewer chat; factual review by Claude | OWNER-RATIFIED; superseded by H-2 v1r4; `a2fb5c641a6fa8010aa59ff811aeba23145703bd5c0d4e2dbd70ac2fb419edb1` |
| `Predictive_Randomness_E1_ALIGN_Specification_v0_2r1.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; code installed with this register; `d9ffd900c74d8a0cc5002bb78c83121f818514cd88ca9150bada8d6d1fa6653a` |
| `RATIFICATION_REGISTER_v0_9.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; installed at `ee62eb6`; superseded by this register; `e84a7a208d99775bbbbf15af8a177d956c5a8e4819cf5b35537f6b70f5dfc6c8` |

## E1-ALIGN accepted and the E_2-readiness contract library (register v0.11)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/` or `tests/`, which are from the repository root. In this section, "this register" means register v0.11.

**E1-ALIGN installation verified and accepted.** The E1-ALIGN code and register v0.10 were installed at commit `295118d3aedb40d1113d234fced6bac77bf55f3a` (28 October 2026; parent `72ef196`).
- **The owner's Windows run** (Windows 11, Python 3.15.2; owner-reported):
  - PRE PASS; the 5 moves; 21 files copied; POST PASS (the 10 edited files equal predecessor plus the reviewed allowlist);
  - all 84 tests passed, with only the 2 allowed symlink skips;
  - all 37 location, origin and mutation checks passed;
  - COMMITTED PASS before the push. A first commit command was mistyped, so the committed check ran before any commit and stopped; nothing had been committed or pushed, and the owner then committed and re-ran it.
- **Claude verified the commit from GitHub:** exactly 5 deletions, 5 moved-path additions, 11 other additions and 6 modifications, every blob equal to the committed manifest, and the 84 tests pass on Linux. **E1A-T13:** in a disposable clone, since deleted, `git revert` gave `src/` and `tests/` identical to `72ef196`, and the 79 pre-E1-ALIGN tests passed. This is not a later rollback guarantee.
- **E1A-D1 holds:** with that evidence the E1A-R02 conditions are met, and **E_1 remains revision 1** under its scoped structural exception.
- **The reviewer's reviews** are installed with this register as LF copies: `review/Independent_ChatGPT_E1ALIGN_Code_RECHECK_v0_1.md` and `review/Independent_ChatGPT_Register_v0_10_Review_v0_1.md` (EX_028).

**Departure, recorded and fixed.** The owner installed the reviewed candidate ZIP (`c613cc1a...b00c`), not the final ZIP (`87a8fdcb...2283`). Their code, tests, allowlist and evidence are byte-identical; they differ only in register v0.10's version line, its manifest line and the verifier constants. So `295118d` carried the candidate register ("RATIFICATION CANDIDATE") and its manifest. The owner fixed both by the document-only procedure: `c1159c7` (the register, `8ee8307e...75a4`) and `1b23fd9` (the manifest, `66109201...dddd`). The second commit was needed because the packaging used fixed ZIP member times: the two manifests have the same size, so Git did not see the replacement until it was re-added. Claude's packaging now uses real times. The tree at `1b23fd9` holds all 21 files byte-identical to the final package.

**E1A-CODE-RD-02 waived (OWNER-DECIDED 28 October 2026).** The reviewer required a mechanical check of the final ZIP before installation. The owner waived it on Claude's advice: the install's POST phase rebuilds every edited code file from its base blob using only the reviewed allowlist, whose hash the verifier pins, so a wrong code byte would have stopped the install. The reviewer received the narrow diff afterwards (EX_029).

**E_2-readiness code scope (OWNER-APPROVED 28 October 2026).** `Predictive_Randomness_E2R_Code_Scope_v0_1.md` (`2d0b0c6acf2f77a518276e24c1c69f6ab3c065ddda26b1cf153cbce0f50c08a1`) is the owner scoping that E2R-1 section 13A requires, installed with this register. The owner approved:
- **S-1:** three packages. CODE-1 is the contract library, new files only and wired into nothing. CODE-2 wires it into the launchers and coordinator, with its own design note first, and any change to a protected coordinator function is an owner decision first. CODE-3 is retirement tooling (E2R-T15).
- **S-2:** E_1's synthetic `METHOD_FORECAST_V1` adapter for E2R-T09 lives in the tests, not in `src/methods/E_001/`.
- **S-3:** the reviewer was asked to start an independent R-4 T-05 oracle in parallel (EX_031).
- **The reviewer's design-stage view** (EX_032; `review/Independent_ChatGPT_E2R_Code_Scope_Review_v0_1.md`, LF copy): it supports S-1..S-3, with 0 BLOCKER, 4 CORRECTION and 1 OPTIONAL. E2RC-C01..C03 and O01 are implemented in CODE-1; C04 (E_1 revision discipline when it is wired in) binds CODE-2's design note.
- **The R-4 oracle** (`review/Independent_E2R_T05_Oracle_v0_1.py` and its plan, LF copies) agreed with CODE-1 on all 192 synthetic cases when Claude ran it on Linux. That is evidence, not authorisation.

**E2R-CODE-1, the contract library (installed with this register).**
- **What it adds** (new files only):
  - six shared modules under `src/methods/_common/`: `contract_vocab.py`, `contract_records.py`, `contract_task.py`, `contract_forecast.py`, `contract_receipts.py` and `contract_registry.py`;
  - the installed contract data under `src/methods/_common/contract_data/`: E_1's `METHOD_DECLARATION_V1` for both games, its `SUPPORTED` registry entries, and `FORMULA_OPEN` entries (variant `NOT_YET_SPECIFIED`) for E_2..E_62 in both games, with the texts for E_1 and E_2 written in plain English (owner decision D-3);
  - the tests `tests/test_e2r_contract.py`, `tests/test_e2r_prefix.py` and their fixtures `tests/e2r_fixtures.py`: E2R-T01 to T13, T16 at record level, T17 and T18.
- **What it does not change:** every existing file, including the reader, the coordinator and its 11 protected functions, `coordinator_private`, both launchers, the wrappers, E_1's code, Package 2's modules and `multigame_method_registry.py`. The three switches stay False and the allowlist stays empty. No gate is activated. E_1 keeps revision 1 with no exception needed, because no E_1 code changes.
- **Nothing is wired in:** no launcher dispatches through the contract yet. The dispatch gate (E2R-T14), run-level receipts and terminal records, `mg-` run IDs and E_1 producing `METHOD_FORECAST_V1` at run time are CODE-2's.
- **Implementation choices made within E2R-1** are listed in `review/E2R_CODE1_Implementation_Notes_v0_1.md` (`0946f5dc9bc2846bcd2be2ffe9a266cdbff3c740f18707693bdcbb39ebcc3698`), for the reviewer's RECHECK.
- **Review:** CODE-1 gets the reviewer's independent HIGH-tier RECHECK, with R-2 reproduction and the R-4 T-05 oracle, and the owner's Windows run before the commit. Its results are recorded after installation; this register does not predeclare them.

**Out-of-date statements (register v0.11).** This register prevails, and the files are not edited:
- Register v0.10, its forward wording "installed with this register" for E1-ALIGN: done, at `295118d`, as above.
- E2R-1 section 13's test list: T14 joins with CODE-2 and T15 with CODE-3, as its own note says; T16 is tested at record level now and at run level in CODE-2.
- Package 2's `multigame_method_registry.py` stays the live dispatch roster until CODE-2 replaces its use; the installed registry entries are the contract's record of status from now on.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_E2R_Code_Scope_v0_1.md` | Claude; design-stage view by the ChatGPT reviewer chat | OWNER-APPROVED 28 Oct 2026; `2d0b0c6acf2f77a518276e24c1c69f6ab3c065ddda26b1cf153cbce0f50c08a1` |
| `RATIFICATION_REGISTER_v0_10.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; installed at `295118d`, finalised at `c1159c7`; superseded by this register; `8ee8307e3c98eabbf24743391c7ebb821e6700f8efa8a093996f97d3d43475a4` |

## E2R-CODE-1 accepted and the Claude Code local runner (register v0.12)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.12.

**E2R-CODE-1 v2 installation verified and accepted.** The contract library and register v0.11 were installed at commit `205ae73dba203d8a8bcaf9be66578b7fde9687aa` (29 October 2026; parent `8b359c6`, an owner document commit). The package was `E2R_CODE1_Install_v2.zip` (final, `5a2b978c96d82e3159cc50e8c24a2f29a944a39d29b7452452f8b484b9a23a11`), taken from `exchange/EX_037_Claude/`.
- **The owner's Windows run** (Windows 11, Python 3.15.2; owner-reported):
  - the ZIP hash checked with `certutil`; PRE PASS; 156 files copied; POST PASS; COMMITTED PASS before the push.
- **Departure, recorded.** The owner's log has no test run between POST and the commit. The owner ran the suite straight after the push, unchanged in the repository: `SUITE PASS`, all 138 tests including E2R-T12, with only the 2 allowed symlink skips. The same package bytes had already passed all 138 tests on the owner's machine in the Claude Code rehearsal TASK_T003 (below). No further action is needed.
- **Claude verified the commit from a fresh GitHub clone:** exactly 156 added files and nothing else; COMMITTED PASS; all 155 manifest entries match their blobs (manifest `cb60b3c8e272d76d7dd1221a2f49de518b6d8977895942b332e10b1aa915452b`); register v0.11 is `704dbd63...96ea`; the 138 tests pass on Linux.
- **What it does not change:** every existing file, as register v0.11 states. The three switches stay False and the allowlist stays empty. Nothing calls the library yet; E_1 keeps revision 1.

**Review history (EX_033 to EX_037).**
- **v1** (EX_033, `acb9f0ea...76fb`) was never installed. The reviewer's HIGH-tier RECHECK (EX_034; `review/Independent_ChatGPT_E2R_CODE1_HIGH_RECHECK_v0_1.md`, LF copy, installed with CODE-1) found 1 BLOCKER and 2 CORRECTION:
  - E2RC1-B01: the registry's immutability was shallow;
  - E2RC1-C01: `frozen_at_utc` accepted offsets and date-only values;
  - E2RC1-C02: the instructions' test count.
- **v2** (EX_035) fixed all three in exactly three code files, with 5 new tests. The reviewer's focused RECHECK (EX_036; `review/Independent_ChatGPT_E2R_CODE1_v2_Focused_RECHECK_v0_1.md`, LF copy, `a99c8539f6d717358333991265a18b21656f12b8b74c7037f9b6cb4c628de2a3`, installed with this register) passed with 0 findings. Its independent R-2 run passed 127 of 127 selected offline tests; the 10 tests that need the real masters and T12 were not run there.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:**
  - E2RC1-RD-01: keep the HIGH tier and require a focused RECHECK of B01 and C01;
  - RD-02: C02 is FIX AND PROCEED;
  - RD-03: register v0.11's content accepted conditionally (no ratification inferred);
  - RD-04: R-2 recorded as PARTIAL;
  - RD-05 and RD-06: B01 and C01 closed, PASS;
  - RD-07: C02 closed, with v2's 138-test count;
  - RD-08: CODE-1 v2 passed and recommended to the owner, with the Windows and installation gates kept.
- **CODE-2 watchpoint** (EX_036, not a finding): the dispatch gate must fetch the installed registry entry again, never trust a copy a caller holds.

**Owner decisions (29 October 2026).**
- **OWNER-RATIFIED:** register v0.11. Only its version line changed from the reviewed candidate (`16a29efc...19ae` to `704dbd63...96ea`).
- **OWNER-APPROVED:** E2R-T12, which starts up to six ordinary Python worker processes that finish normally, for the rehearsal and the install run.
- **OWNER-DECIDED:** no reviewer check of the final ZIP before installation, as for E1-ALIGN. Claude sent the reviewer the narrow diff afterwards (EX_037: the register line, its manifest line and two verifier constants).

**The Claude Code local runner (OWNER-DECIDED 28 and 29 October 2026).**
- **What it is:** Claude Code, in VS Code on the owner's Windows machine, carries out task files written by Claude and reports what happened. It makes no design or code decisions. It works in disposable task clones taken from GitHub, whose link to GitHub is removed and which refuse every push, and it commits only its own report file. The owner pushes.
- **Authorisation:** the owner authorised Claude and Claude Code to read, write and commit in and under `CLAUDE_CODE_WORKING_FOLDER_TREE/`. Claude's exchange/ rule is unchanged.
- **The files:**
  - the rulebook `CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md` (v0.2 at `423bd19`), which repeats every hard prohibition;
  - the helper tools under `CLAUDE_CODE_WORKING_FOLDER_TREE/tools/` and the task and report formats;
  - the root `CLAUDE.md` pointer and `.claude/settings.json` (which turns off web access and bypass mode and denies Git writes, data-folder reads and edits outside that folder), committed by the owner at `ee76fc0`.
- **The first tasks:**
  - T001 (report `e33ccbf`): STOP at its module-origin step, because Claude's helper still used the v1 registry attributes. Nothing was changed. The tool was fixed at `ae7102b`.
  - T002 (report `a6a92d7`): PASS. The v2 candidate rehearsed in a task clone; 137 tests (T12 left out).
  - T003 (report `9351e1a`): PASS. The final package rehearsed in a task clone; all 138 tests, including T12.
- **What its reports are:** owner-machine evidence produced by a runner, read by Claude from GitHub. They are not reviewer evidence and not acceptance by themselves. One known fidelity slip: the T002 report retyped one output line with a wrong character. Claude will add a helper that records each step's output itself.

**Out-of-date statements (register v0.12).** This register prevails, and the files are not edited:
- Register v0.11, "installed with this register" for CODE-1: done, at `205ae73`, as above. Its review results, "recorded after installation", are recorded here.
- E2R-CODE-1's install instructions (v1) gave 132 tests; v2 gives the correct 138.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `RATIFICATION_REGISTER_v0_11.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 29 Oct 2026; installed at `205ae73`; superseded by this register; `704dbd6383fcef5a4501b8dbc867eedcdabd8df82d1945e80dcddb5a2e0996ea` |

## E2R-CODE-2: the dispatch gate and the standalone contract runner (register v0.13)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/` or `tests/`, which are from the repository root. In this section, "this register" means register v0.13.

**Register v0.12 installed.** The owner installed it by the document-only procedure at commit `b846519bce7463cc7a7a57095d438b9223dd8bb9` (29 October 2026), with the EX_036 review copy. Claude verified from GitHub that the commit adds exactly those 2 files: the register is `6f6f4556...4eb` and the review copy is `a99c8539...e2a3`. Only the register's version line changed from the reviewed candidate (`e1ac8b55...567c`).

**The design note.** `Predictive_Randomness_E2R_CODE2_Design_v0_1r1.md` (`f0c36fd3dabb83dcc5f21d8b92bd9b5c3eaf9647da069a4e5bff63514a26f2dd`) is installed with this register. It meets E2R-CODE-1 scope S-1's requirement of a design note before CODE-2.
- **v0.1** (EX_038, `d15a42af...b161`) was REVISIONS REQUIRED. The reviewer's review (EX_039; `review/Independent_ChatGPT_E2R_CODE2_R3_Design_and_Register_v12_Review_v0_1.md`, LF copy, `eedd59e4eb0dcde7e0876fa2ae47b01ec0b45d75927a602b7d967e1a1f02f18a`) found 2 BLOCKER, 3 CORRECTION and 1 OPTIONAL:
  - E2RC2-B01: E_1's legacy runner was outside the release rule;
  - E2RC2-B02: consumption trusted a caller-supplied "gates passed" flag;
  - C01: publication relied on a rename, not a proven create-only step;
  - C02: a legitimate no-ticket, no-diagnostic result had to be told apart from invalid output;
  - C03: the per-method roster is not a variant admission authority;
  - O01: the command line cannot request a diagnostic-only run, which is to be labelled a launcher limit.
- **v0.1r1** (EX_040) resolved all six. The reviewer passed it unchanged (EX_041, E2RC2-RD-06).

**The code.**
- **v1** (EX_038, `a5e8ac89...4a49`) was never run by the reviewer, because the design did not pass unchanged (RD-03).
- **v2** (EX_040, `cea050a0...7e00`) was REVISIONS REQUIRED. The reviewer's HIGH-tier review (EX_041; `review/Independent_ChatGPT_E2R_CODE2_v2_HIGH_RECHECK_v0_1.md`, LF copy, `110564fbeed2b01807649be96c55bcb95a8a36c3b4d3232f9c1068b4b3126d26`) found 2 BLOCKER, both RECHECK:
  - E2RC2-CODE-B01: the public run, dispatch, consumption and coordinator-gate functions accepted a caller-chosen orphan marker, registry folder and method folder;
  - E2RC2-CODE-B02: the standalone runner could publish a SUCCESS record labelled COORDINATED.
- **v3** (EX_042, `0f4b6600d3a239a0de124ce8365c382450eb6df24a07750457a58505f3ebd69f`) removed every such parameter and fixed the run's data source. `review/E2R_CODE2_EX041_Corrections_v0_1.md` (`55eb9a4e1b4ec108f4b203e60bf93c53fcc909423b598457a2d141426f8441ef`) records the changes. The reviewer's focused RECHECK (EX_043; `review/Independent_ChatGPT_E2R_CODE2_v3_Focused_RECHECK_v0_1.md`, LF copy, `da67250611475fdf3e1941a5a2f8d26546a6cd169690a84636243e352328ee01`) passed with 0 findings.
- **Independent reproduction:** the reviewer's R-2 run passed 179 of 179 selected offline tests, with no skips. The 10 tests that need the real masters and E2R-T12 were not run there; they are reserved for the owner's run (RD-14).
- **Claude's evidence** (author evidence): 190 tests on Linux, Python 3.13.17 and 3.15.0b4; 22 of 22 planted defects caught; install run-throughs in disposable clones.

**REVIEWER-DECIDED, checked by Claude, no exception to report:**
- E2RC2-RD-01: register v0.12's content passed;
- RD-02: the HIGH tier is kept, with a RECHECK of the five required design corrections;
- RD-03: no code review until the design passes unchanged;
- RD-04: D2-1, D2-2 and D2-4 supported, D2-4 with the variant-exact safeguard; D2-3 for the owner;
- RD-05: the E_1 wrapper plan is kept, with no undocumented registry or legacy-gate exception;
- RD-06: design v0.1r1 passed unchanged;
- RD-07: E_1 stays revision 1 for the new legacy gate, because the only change to E_1's files is the gate insertion, and E_1's calculation and goldens are unchanged;
- RD-08: the condition for the code review was met;
- RD-09 and RD-10: CODE-B01 and CODE-B02 assigned, BLOCKER and RECHECK;
- RD-11: v2 not recommended for installation;
- RD-12 and RD-13: CODE-B01 and CODE-B02 closed, PASS;
- RD-14: the bounded 179-test reproduction is accepted, and is not a 190-test acceptance;
- RD-15: v3 recommended for the owner's acceptance, with every owner gate kept.

**Owner decisions (29 October 2026).**
- **D2-3, OWNER-DECIDED** (before v0.1r1): E_1's legacy standalone runner gets the release check, not an exception.
- **D2-1, OWNER-RATIFIED:** CODE-2 covers the standalone path. The coordinator side gets only an entry point that runs the release check and then refuses every contract request. Coordinated contract runs need a later package.
- **D2-2, OWNER-RATIFIED:** a fourth switch, `ENABLE_CONTRACT_REAL_DEVELOPMENT`, stays `False`. Turning it on needs a separate owner approval.
- **D2-4, OWNER-RATIFIED:** Package 2's roster is read from the installed registry, as a roll-up only. Admission is the dispatch gate's alone.
- **OWNER-APPROVED:** E2R-T12 (up to six ordinary Python worker processes that finish normally) for CODE-2's rehearsal and install run.
- **OWNER-DECIDED:**
  - Claude Code rehearses the final package in a disposable task clone before the install;
  - no reviewer check of the final ZIP before installation, as for CODE-1. Claude sends the reviewer the narrow diff afterwards.
- **OWNER-DECIDED (process):** the reviewer's ZIPs are given to Claude, which records them in `exchange/`. The owner does not save them into the repository working tree.

**E2R-CODE-2 (installed with this register).**
- **What it adds** (new files):
  - `src/methods/_common/contract_dispatch.py`: the one dispatch gate (E2R-R57, T14). It admits a request only if:
    - the installed registry's active entry for the exact game, method and variant is SUPPORTED;
    - the request pins exactly that entry and its declaration;
    - the revision matches;
    - there is no `IN_DEVELOPMENT.txt`.

    It loads the installed registry afresh on every call. A refusal reads no data and creates nothing;
  - `contract_publication.py`: create-only publication (no file is ever overwritten), the run-level receipts and terminal record, and `read_run`. `read_run` decides whether a run may be consumed from the fixed orphan marker and the installed registry only, and for standalone runs only;
  - `contract_runner.py`: the standalone contract runner, with `mg-` run IDs and the switch `ENABLE_CONTRACT_REAL_DEVELOPMENT = False`;
  - `src/methods/Method_Contract_Runner.py`: its command line, launched by the existing `Run_Experiment.bat`;
  - `src/methods/contract_adapters/`: E_1's wrapper (E2RC-C04 option (a)), outside E_1's folder, which must match E_1's own result exactly;
  - `src/coordinator_private/contract_coordinated_gate.py`: the refusing coordinator-side entry point (D2-1);
  - the tests `tests/test_e2r_dispatch.py`, `tests/test_e2r_runner.py` and their fixtures `tests/e2r_code2_fixtures.py`: E2R-T14, and T16 at run level.
- **What it replaces** (3 files):
  - `multigame_method_registry.py`: the roster as a roll-up (D2-4);
  - `multigame_standalone_contract.py`: a synthetic run needs a released variant;
  - `E_001_Historical_Appearance_Frequency.py`: the legacy gate (D2-3), eight lines after its orphan-marker check.
- **What it does not change:**
  - the coordinator file, its 11 protected functions and `coordinator_main`;
  - the reader;
  - the launchers;
  - E_1's code under `src/methods/E_001/`;
  - CODE-1's modules and contract data.

  The three existing switches stay False, and the allowlist stays empty. E_1 keeps revision 1 (RD-07). There are no coordinated contract runs, no real-data contract runs and no FINAL, IS, scoring or retirement.
- **Review and acceptance:** the owner's Windows run, with all 190 tests including T12, comes before the commit. Claude verifies the commit from GitHub. The results are recorded after installation; this register does not predeclare them.

**Out-of-date statements (register v0.13).** This register prevails, and the files are not edited:
- Register v0.11, S-1, "CODE-2 wires it into the launchers and coordinator": by D2-1, CODE-2 wires the standalone path and E_1's legacy runner. The coordinator side gets only the refusing entry point.
- Register v0.11, "Package 2's `multigame_method_registry.py` stays the live dispatch roster until CODE-2 replaces its use": with CODE-2 the roster is a roll-up of the installed registry (D2-4).
- Register v0.11, T14 "joins with CODE-2" and T16 "at run level in CODE-2": both are in CODE-2's tests.
- Register v0.12, "Nothing calls the library yet": the standalone contract runner, E_1's legacy runner and the coordinator-side entry point call it once CODE-2 is installed. The EX_036 watchpoint is met: the gate loads the installed registry afresh.
- Design note v0.1r1, section 8: it gives 185 tests (47 for CODE-2, 29 in `test_e2r_runner.py`) and 18 planted defects. v3 has 190 tests (52 for CODE-2, 34 in `test_e2r_runner.py`) and 22 defects. The corrections note lists the additions.
- Design note v0.1r1, section 10, "awaiting the owner" for D2-1, D2-2 and D2-4: decided, as above.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_E2R_CODE2_Design_v0_1r1.md` | Claude; reviewed by the ChatGPT reviewer chat | Design PASS (E2RC2-RD-06); owner decisions D2-1 to D2-4 as above; installed with this register; `f0c36fd3dabb83dcc5f21d8b92bd9b5c3eaf9647da069a4e5bff63514a26f2dd` |
| `RATIFICATION_REGISTER_v0_12.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 29 Oct 2026; installed at `b846519`; superseded by this register; `6f6f4556522b54ae4416da07357b50bed82ec799e7761f758cac99b6324ac4eb` |

## E2R-CODE-2 accepted, and the handovers refreshed (register v0.14)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.14.

**E2R-CODE-2 installation verified and accepted.** CODE-2 and register v0.13 were installed at commit `ced9b6cbd43b98e9584b8020724388109eb28d68` (29 October 2026; parent `bce33b1`). The package was `E2R_CODE2_Install_v3.zip` (final, `ec643ceab097ca69630594e42551a2c7c4fc5ef5b4d8e6e593a7489a694c6969`), taken from `exchange/EX_046_Claude/`.
- **The owner's Windows run** (Windows 11, Python 3.15.2; owner-reported), in the reviewed order:
  - a clean tree and `git pull --ff-only`;
  - the ZIP hash checked with `certutil`;
  - PRE PASS; 25 files copied; POST PASS;
  - **before the commit**, `SUITE PASS`: all 190 tests including E2R-T12, with only the 3 allowed symlink skips;
  - 22 added and 3 modified files staged; COMMITTED PASS before the push.
- **Claude verified the commit from a fresh GitHub clone:**
  - exactly 22 added and 3 modified files;
  - COMMITTED PASS;
  - all 24 manifest entries match their blobs (manifest `75a0c1f4759a7b652e2c4dd35ff37ec8622bd939ca5dac883b6cf231e524b510`);
  - register v0.13 is `6ff86e72...391e`;
  - the 190 tests pass on Linux.
- **What it does not change:** as register v0.13 states. The four switches stay False, the allowlist stays empty, and E_1 keeps revision 1. Contract runs are standalone and synthetic only.
- **The final ZIP and the reviewed candidate.** After the owner ratified v0.13, the final ZIP differed from the candidate the reviewer checked (EX_045) in:
  - the register's version line, its manifest line and two verifier constants;
  - one sentence of the install instructions, corrected before use. It had said the only allowed skips were "the two symlink tests"; the unchanged suite runner also allows CODE-2's dangling-symlink skip, so it now says "up to 3".

  No code or test changed. Under the owner's decision (register v0.13), the reviewer did not check the final ZIP before the install. Claude sent the narrow diff for information (EX_046).

**The rehearsal (TASK_T004; OWNER-DECIDED in register v0.13).** Before the install, Claude Code ran the final package in a disposable task clone on the owner's machine: PASS in all 15 steps, including all 190 tests with T12, in 39 seconds, with the 3 symlink skips. The main repository was unchanged.
- The task and two tool updates are at `5b1481a`, and the report is at `bce33b1`. The tool updates:
  - `cc_clone.py overlay --replace`, which may replace only named, tracked files;
  - the module-origin check also covers CODE-2's modules.
- The report is owner-machine evidence produced by the runner; it is not reviewer evidence.

**The reviewer's review of register v0.13 (EX_045).** `review/Independent_ChatGPT_Register_v0_13_Content_Review_v0_1.md` (LF copy, `5ee5bba48ce5f9a43b330e7bfbdde6e6f33bd3f793dabc8d3e5a070b3343d56c`, installed with this register) passed v0.13's content and the package's identity, with 0 findings.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:**
  - E2RC2-RD-16: register v0.13's content PASS; finalisation changes only the status line and its dependent identities;
  - RD-17: the package candidate's identity PASS: the reviewed v3 code and tests are unchanged.

**Owner decisions (29 October 2026, after register v0.13).**
- **OWNER-RATIFIED:** register v0.13. Only its version line changed from the reviewed candidate (`b1c21a2c...f22c` to `6ff86e72...391e`).
- **OWNER-DECIDED:**
  - E2R-CODE-3 (retirement tooling, E2R-T15) is kept in the plan; the owner expects the need soon;
  - **review rounds are combined:** register text goes to the reviewer only together with a code package or the handovers, never in a round of its own;
  - **the handovers are refreshed at milestones:** after CODE-2, now, and later when a method is released, a process changes, or a register's out-of-date list grows long. H-1 is shortened and points to the register for history.
- **Proportion (owner's remark, recorded):** the owner asked how much plumbing the project really needs. The answer adopted: keep the safety-critical machinery, and keep everything else lean. This changes no rule.

**H-1 v1r4 and H-2 v1r5 (installed with this register).**
- `HANDOVER/Claude_Primary_Handover_H1_v1r4.md` (`2050e9363d841634ecf2a9c308d3efb1ed51b359fbdaf2aa3531a60eb1f1c16a`): Claude's handover, refreshed to `ced9b6c` and shortened. Its Appendix B lists what changed and where any material it no longer repeats now lives. It adds the process for adding a new method (its section 9). It changes no rule. It is reviewed by the ChatGPT reviewer chat.
- `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r5.md` (`67a1b3eaa3e1f51415eceba513fd7e1a39de91619296f0efba97ba108570a094`): the reviewer's handover, refreshed to `ced9b6c` and shortened by the reviewer chat. Its reviewer-rights region (R-1..R-11, T-05 and section 3.1; 7,676 bytes) is byte-identical to H-2 v1r4, which Claude checked mechanically. Its one factual review is Claude's, `review/Claude_Fact_Check_H2_v1r5_v1.md` (`58224dfc7b3dcdf5fba8289c4598ce479072dd6663b0786318973ff2d8394203`, installed with this register): no BLOCKER; findings H2F5-01..03 CORRECTION and H2F5-04..07 OPTIONAL, for the reviewer to adopt.
- Each replaces its predecessor for future roles; the predecessors are kept as history. Neither authorises anything.

**One EX number used twice.** `EX_047` was used by both chats in the same minute (29 October 2026): `EX_047_Claude` (H-1 v1r4 and this register's first candidate; `1c8668e`) and `EX_047_ChatGPT` (H-2 v1r5's draft; `6ba6284`). Neither could have seen the other. Both are recorded under their own names, nothing was overwritten, and numbering continues at `EX_048`.

**Out-of-date statements (register v0.14).** This register prevails, and the files are not edited:
- Register v0.13, "installed with this register" for CODE-2: done, at `ced9b6c`, as above. Its review and Windows results, "recorded after installation", are recorded here.
- Register v0.13, "Claude sends the reviewer the narrow diff afterwards": done (EX_046).
- H-1 v1r3 and H-2 v1r4, generally: superseded by H-1 v1r4 and H-2 v1r5. The out-of-date statements of registers v0.10 to v0.13 that concern H-1 v1r3 are folded into H-1 v1r4.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `HANDOVER/Claude_Primary_Handover_H1_v1r4.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 29 Oct 2026; installed with this register; `2050e9363d841634ecf2a9c308d3efb1ed51b359fbdaf2aa3531a60eb1f1c16a` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r5.md` | the ChatGPT reviewer chat; factual review by Claude | OWNER-RATIFIED 29 Oct 2026; installed with this register; `67a1b3eaa3e1f51415eceba513fd7e1a39de91619296f0efba97ba108570a094` |
| `HANDOVER/Claude_Primary_Handover_H1_v1r3.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; superseded by H-1 v1r4; `ddf4de23b726b2abf55ffcab613f926b62775469076476f939288a278e6422fc` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r4.md` | the ChatGPT reviewer chat; factual review by Claude | OWNER-RATIFIED 28 Oct 2026; superseded by H-2 v1r5; `73b90ea348aea5fc337097a14ec4a8669258bc6cba55ce5a2485de26575f3f3a` |
| `RATIFICATION_REGISTER_v0_13.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 29 Oct 2026; installed at `ced9b6c`; superseded by this register; `6ff86e728142ce47adb76cb975e9f1ad75f01de48b6ab71c005fdb6c2331391e` |

## E_6, the first new method, and the new-method template (register v0.15)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.15.

**The document round installed (DOC-6).** H-1 v1r4, H-2 v1r5 and register v0.14 were installed by the document-only procedure at commit `337b5b20f7eb8c642f42e24227fe4884a7a880fc` (29 October 2026; parent `dceab36`). Claude verified from GitHub that the six intended files are exactly the ratified bytes:
- H-1 v1r4 `2050e936...c16a`;
- H-2 v1r5 `67a1b3ea...a094`;
- register v0.14 `74d2ae89...bfa4`;
- the three review copies.

**Departure, recorded and fixed.** The owner's first `git status --short` was not empty: four EX zips downloaded into `review/` (`EX_047_ChatGPT`, `EX_047_Claude`, `EX_048_Claude`, `EX_049_ChatGPT`) were staged and committed too.
- Claude checked that each is byte-identical to its copy in `exchange/`.
- The owner removed them at `f9de54ad4b877bf45a5e4d8bcca2e4b4b5e3f752`, which makes 4 deletions and nothing else; Claude verified this from GitHub.

The rule stands: if the first status line shows anything, stop and ask.

**Older duplicates, left in place.** `review/` also holds 10 earlier copies of EX messages from the owner's snapshot commits: `EX_026_Claude.md` twice, one with a "(1)" suffix, and `EX_027` to `EX_034`. Each matches its `exchange/` copy, apart from line endings in the `.md` files. The owner may remove them later.

**The project's purpose, restated (owner-reported, 30 October 2026).** The owner put the purpose to the reviewer chat: to detect, predict and measure unusual fluctuations or patterns in apparent randomness by mathematically valid means. That includes deliberately unusual ones, for example from quantum physics, or relaxed assumptions. The reviewer chat agreed, with six working principles:
1. be exploratory;
2. do not reject an idea because conventional theory predicts it should fail;
3. distinguish mathematical validity from statistical orthodoxy;
4. measure what actually happens: a method can fail as a predictor yet succeed as an exploratory instrument;
5. protect the integrity of evaluation (N-1, frozen forecasts, TOP/WORST, null-world diagnostics, the sealed holdout);
6. investigate surprises rather than explain them away, without reading an analogy as a mechanism.

This restates the owner's foundational points (H-1 v1r4 section 2A) and changes no rule. The exchange took place in the owner's chats, not in an EX file.

**The owner's plan (OWNER-DECIDED, 29-30 October 2026).**
1. E_6 first, as the lead method and the first real use of the new plumbing, with a draft template for later methods.
2. Then E_3 and E_4 together, sharing one Chebyshev fitting helper with three fit types (least squares, interpolation and minimax), in one review round.
3. Then the E_7-E_16 frequency family as a batch made from the template.

Each step keeps its own design review, code review and owner go-ahead.
- **The template** keeps only what changes from method to method; safety logic stays in the shared library.
- **Variant settings are fixed in a method's specification before its code.** By E2R-R14A, any later change to a released method's code is a new revision.
- **Claude Code** rehearses each install. Whether it may try building a method from the template is asked when the batch is reached; that needs a rulebook change.

**The E_6 review (EX_050 and EX_051).**
- **What was reviewed:** the design note `Predictive_Randomness_E6_Specification_and_Method_Template_Design_v0_1.md` (`cef16b44fb7088ec018e0a8d6f233231c04e3fe6d5431cf0a2e604ad8f6fc82e`), installed with this register, and Claude's speculative candidate (`E6_Install_v1_candidate.zip`, `098214c1...6b66`).
- **The verdict** (`review/Independent_ChatGPT_E6_R3_R2_Review_v0_1.md`, LF copy, `ee0613f618738b219cd2ba33b03fd16148abfc471bef66140e1c583822e6b4cb`, installed with this register):
  - R-3 design PASS unchanged;
  - R-2 HIGH-tier candidate PASS, with 0 BLOCKER, CORRECTION or RECONSIDER;
  - 199 of 199 selected offline tests independently reproduced, run module by module. This is not a whole-suite run: the 10 real-master tests and T12 are reserved for the owner's run.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:**
  - E6-RD-01: design PASS unchanged;
  - RD-02: D6-1..D6-5 supported, for the owner's decision;
  - RD-03: the candidate PASS;
  - RD-04: the owner's Windows acceptance and the install checks are not replaced by the review.
- **The reviewer's non-blocking terminology note, adopted:** for lambda < 1, E_6's estimate is a discounted (power-likelihood) Beta update, not the plain Bayesian posterior; only lambda = 1 is the posterior mean. The package now labels the two decay variants accordingly:
  - fit version `BETA_BERNOULLI_DISCOUNTED_UPDATE_V1`;
  - their own calibration note;
  - a sentence in their registry texts and the code comments.

  `BETA_BERNOULLI_FULL_MEMORY_V1`'s declarations and entries are byte-identical to the reviewed candidate. Nothing else changed in the code or the tests, apart from one test that checks the fit version per variant. The reviewer receives the narrow diff with this register.

**Owner decisions D6-1..D6-5 (OWNER-DECIDED 30 October 2026).** The owner decided all five after seeing the reviewer's interim view, before its formal reply. EX_051 then supported all five unchanged.
- **D6-1:** a contract method needs no per-method entry file. The shared standalone runner is its entry, and its code lives in its own folder, `src/methods/E_<nnn>/`. This narrows NAMES-1 OPEN-N1 "A" for contract methods only; E_1's legacy entry file is unchanged.
- **D6-2:** E_6 revision 1 is approved at method level (R2 7.1):
  - an independent Beta-Bernoulli model for each number;
  - a prior centred on the fair-draw rate and worth one draw;
  - forgetting weight lambda^age;
  - exact rational arithmetic;
  - three fixed variants: lambda 1, 74/75 and 149/150, in both games.
- **D6-3:** the release plan: installed non-runnable; release 1 makes `BETA_BERNOULLI_FULL_MEMORY_V1` `SUPPORTED` and removes the flag; release 2 adds the two decay variants, registry only. Real-data contract runs stay off.
- **D6-4 (planning only):** real-data contract runs, a walk-forward driver and the R3 scorer, as a later reviewed package, WF-1. Nothing is authorised.
- **D6-5:** the new-method template, `doc/METHOD_TEMPLATE/`, as draft 1.

**The E_6 package (installed with this register).**
- **What it adds:**
  - `src/methods/E_006/`: the mathematics, the runner connection and `IN_DEVELOPMENT.txt`;
  - 6 declarations and 6 `FORMULA_OPEN` registry entries;
  - `tests/test_e6_beta_bernoulli.py` (20 tests);
  - the design note;
  - the template, 10 files under `doc/METHOD_TEMPLATE/`;
  - review evidence.
- **What it replaces:**
  - `src/methods/Method_Contract_Runner.py`: one import and one `ADAPTERS` entry;
  - `tests/test_e2r_contract.py`: the literal count of 124 registry chains becomes the count of installed chain folders;
  - `tests/test_e2r_dispatch.py`: "no `IN_DEVELOPMENT.txt` anywhere" becomes "flags only in unreleased method folders, never E_001".
- **What it does not change:** the contract libraries (CODE-1 and CODE-2), the reader, the coordinator and its 11 protected functions, E_1, the launchers and wrappers, the owner tools, and E_6's `NOT_YET_SPECIFIED` placeholder. The four switches stay False, and the allowlist stays empty.
- **E_6 cannot run** once this is installed: every request is refused with `NOT_SUPPORTED` before any data is read, and the flag is present.
- **Review and acceptance:**
  - the owner's Windows run of all 210 tests comes before the commit;
  - E2R-T12 for this package's rehearsal and install run: OWNER-APPROVED 30 October 2026 (up to six ordinary Python worker processes that finish normally);
  - Claude verifies the commit from GitHub.

  The results are recorded after installation; this register does not predeclare them.

**Out-of-date statements (register v0.15).** This register prevails, and the files are not edited:
- Register v0.14, "installed with this register" for H-1 v1r4 and H-2 v1r5: done, at `337b5b2`, as above.
- H-1 v1r4 section 9, step 3, "the entry file ... its contract adapter": by D6-1, a contract method has no entry file of its own. Its connection to the runner is `contract.py` in its own folder, as `doc/METHOD_TEMPLATE/README.md` describes.
- H-1 v1r4 section 7.4, "190 offline tests in 14 modules": 210 in 15 once the E_6 package is installed.
- The E_6 design note v0.1, sections 1 and 2.2, "the posterior mean" for every variant: exactly so only for lambda = 1. For lambda < 1 it is a discounted (power-likelihood) Beta update, as above.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_E6_Specification_and_Method_Template_Design_v0_1.md` | Claude; reviewed by the ChatGPT reviewer chat | Design PASS unchanged (E6-RD-01); owner decisions D6-1..D6-5 as above; installed with this register; `cef16b44fb7088ec018e0a8d6f233231c04e3fe6d5431cf0a2e604ad8f6fc82e` |
| `RATIFICATION_REGISTER_v0_14.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 29 Oct 2026; installed at `337b5b2`; superseded by this register; `74d2ae89a16d2c7a971db1b62e89c3e9aa7f6a2803a9102516507fa705e2bfa4` |

## E_6 installed, and E_3 and E_4, the polynomial-fit pair (register v0.16)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.16.

**The E_6 rehearsal (TASK_T005).** Before the install, Claude Code ran the final E_6 package (`exchange/EX_054_Claude/E6_Install_v2.zip`, `eea8e444...3e29`) in a disposable task clone on the owner's machine. The report (`CLAUDE_CODE_WORKING_FOLDER_TREE/outbox/REPORT_T005.md`, commit `6e85b78`) gives:
- PASS in all 15 steps;
- all 210 tests, including E2R-T12, in 52 seconds, with the 3 allowed symlink skips;
- the main repository unchanged, and `scratch\` empty again.

**Deviation, recorded.** At step 11, Claude Code redirected the status output to a temporary file outside the repository so that it could count the lines, and the file's deletion was declined. The file holds only that status output, and nothing in the repository was touched. Later task files will have the tool do any counting itself, so no redirection is needed.

**The E_6 package installed** at commit `7c93320c2cce853b94e23203bb47e3f66aaa7994` (30 October 2026; parent `6e85b78`, the T005 report).
- **The owner's log**, in order:
  - the ZIP's SHA-256 checked;
  - `git status --short` empty, and `Already up to date`;
  - `PRE PASS`;
  - 43 files copied;
  - `POST PASS`;
  - **before the commit**, `SUITE PASS`: all 210 tests, including E2R-T12, with only the 3 allowed symlink skips;
  - 40 `A` and 3 `M`;
  - `COMMITTED PASS`, then the push.
- **Claude's check, from a fresh GitHub clone:**
  - the parent and the 40 `A` + 3 `M` change set;
  - `COMMITTED PASS` repeated;
  - all 42 manifest entries match their Git blobs;
  - register v0.15 is the ratified `405cc2f9...ea2e`;
  - 210 tests pass on Linux.

E_6 is installed non-runnable, as D6-3 intends.

**The three-part review (EX_052 and EX_053).** The verdict is `review/Independent_ChatGPT_EX052_Three_Part_Review_v0_1.md`, LF copy, `8cb7519e72c01751d8a88e211517e65daf8ea63d88fef3fbafd35fc21a1b6491`, installed with this register. It found 0 BLOCKER, 0 CORRECTION and 0 RECONSIDER.
- **E_6 v2 against v1:** a narrow content and identity PASS. The candidate diff reproduced every changed file byte for byte, and no arithmetic changed.
- **Register v0.15:** CONTENT PASS. The exact predecessor was reconstructed, and the three counted edits reproduced the candidate byte for byte.
- **The E_3/E_4 design note v0.1:** R-3 design PASS unchanged, with 2 OPTIONAL items, both adopted as tests:
  - E34-O01: the exchange method in detail (ties for the largest error, a reference with zero levelled error, the sign pattern of the final reference, the cap);
  - E34-O02: for least squares and interpolation, the per-number polynomials of a barrel add up to the constant K, so their values at the target add up to K and their slopes to 0. This is not imposed on minimax, which is not linear.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:**
  - E6-052-RD-01: accept the v2 terminology and identity change without reopening E_6's design;
  - REG15-052-RD-02: v0.15 content acceptable for ratification;
  - E34-052-RD-03: the E_3/E_4 code may be prepared to the frozen design; it still needs its own R-2 review.
- **EX_054** (Claude) recorded the owner's decisions below and the final E_6 package, for the record only.

**Owner decisions (30 October 2026).**
- **Register v0.15 OWNER-RATIFIED,** as reviewed.
- **E2R-T12 OWNER-APPROVED** for the E_6 package's rehearsal and install run.
- **D34-1..D34-5 OWNER-DECIDED** as designed:
  - D34-1: one shared helper, `_common/polynomial_fits.py`, versioned with both methods;
  - D34-2: six fixed variants per method, including the interpolation node positions 50, 40, 26, 11, 1;
  - D34-3: least squares on the raw 0/1 series; interpolation and minimax on the series smoothed by a centred mean of half-width 4, clipped to the window. The smoother is part of the hypothesis tested, not a claim about cause;
  - D34-4: scores only, with no probability vector;
  - D34-5: precise naming. The least-squares fit is ordinary polynomial least squares; "Chebyshev" names the interpolation nodes and the minimax criterion.

**The owner-reminders file.** `exchange/OWNER_REMINDERS.md` (added by Claude at `43c95c5`, 30 October 2026) lists things the owner asked to be reminded of, with the date asked and whether each is open or done. It is a working list, not reviewed and not part of the rules. Its items stay on file when completed or dropped.

**The E_3/E_4 package (installed with this register).**
- **What it adds:**
  - the shared helper `src/methods/_common/polynomial_fits.py`, revision 1: exact rational least squares, interpolation and minimax, each with a second, differently written algorithm or certificate for verify();
  - `src/methods/E_003/` and `src/methods/E_004/`, each with `variants.py`, `contract.py` and `IN_DEVELOPMENT.txt`;
  - 24 declarations and 24 `FORMULA_OPEN` registry entries;
  - `tests/test_polynomial_fits.py` (19 tests) and `tests/test_e3_e4_polynomial.py` (13 tests);
  - the design note;
  - review evidence.
- **What it replaces:** `src/methods/Method_Contract_Runner.py`, with two imports and two `ADAPTERS` entries.
- **What it does not change:** the contract libraries, the reader, the coordinator and its 11 protected functions, E_1, E_6, the template, the launchers and wrappers, the owner tools, and E_3's and E_4's `NOT_YET_SPECIFIED` placeholders. The four switches stay False, and the allowlist stays empty.
- **E_3 and E_4 cannot run** once this is installed: every request is refused with `NOT_SUPPORTED` before any data is read, and both flags are present.
- **Review and acceptance:**
  - the owner's Windows run of all 242 tests comes before the commit;
  - E2R-T12 for this package's rehearsal and install run: OWNER-APPROVED 30 October 2026 (up to six ordinary Python worker processes that finish normally);
  - Claude verifies the commit from GitHub.

  The results are recorded after installation; this register does not predeclare them.

**Out-of-date statements (register v0.16).** This register prevails, and the files are not edited:
- Register v0.15, "installed with this register" for the E_6 package: done, at `7c93320`, as above.
- Register v0.15, the owner's plan, "one Chebyshev fitting helper": by D34-5, a polynomial-fit helper; "Chebyshev" applies to the interpolation nodes and the minimax criterion only.
- H-1 v1r4 section 7.4, "190 offline tests in 14 modules": 242 in 17 once the E_3/E_4 package is installed.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_E3_E4_Polynomial_Fit_Design_v0_1.md` | Claude; reviewed by the ChatGPT reviewer chat | Design PASS unchanged (E34-052-RD-03); owner decisions D34-1..D34-5 as above; installed with this register; `b9d60b4c753bb90c6a7ca302fb4802c353b0ae23fbe82c2b417ae7b089fad072` |
| `RATIFICATION_REGISTER_v0_15.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 30 Oct 2026; installed at `7c93320`; superseded by this register; `405cc2f964db5a86cdf6a94bfc1382d01911ef9f41162b047c43c7f1af04ea2e` |

## E_3 and E_4 installed, the owner's order of work, and the handovers refreshed (register v0.17)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.17.

**The E_3/E_4 review (EX_055 to EX_057).** The verdict is `review/Independent_ChatGPT_E34_HIGH_R2_and_Register_v16_Review_v0_1.md`, LF copy, `f58821b8a09aede3df4481ae9fa6ad6c47438aaac9cac172c1d11a2f67c6accb`, installed with this register. It found 0 BLOCKER, 0 CORRECTION, 0 OPTIONAL and 0 RECONSIDER.
- **The code candidate:** HIGH-tier R-2 PASS.
  - The overlay was verified against the base snapshot of `7c93320`, and the one replaced file rebuilt exactly.
  - 231 selected offline tests were independently reproduced, with no skips. The 10 real-master tests and T12 were left for the owner's run, so this is not the full 242-test acceptance.
  - 1,968 extra exact minimax checks passed.
  - Claude's 27 of 27 mutation result is author evidence only: the reviewer's attempt to rerun it timed out.
- **Register v0.16:** CONTENT PASS; the exact predecessor was reconstructed and the three counted edits reproduced the candidate byte for byte.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:**
  - E34-056-RD-01: the code PASS, provided the installed overlay stays byte-identical to the reviewed code;
  - REG16-056-RD-02: v0.16 content PASS; only the owner's finalisation and its dependent identities may change;
  - E34-056-RD-03: both EX_053 optional test expectations are satisfied.
- **EX_057** (Claude) recorded the owner's decisions below and the final E_3/E_4 package, for the record only.

**Owner decisions after EX_056 (30 October 2026).**
- **Register v0.16 OWNER-RATIFIED,** as reviewed.
- **E2R-T12 OWNER-APPROVED** for the E_3/E_4 package's rehearsal and install run.

**The E_3/E_4 rehearsal (TASK_T006).** Claude Code ran the final package (`exchange/EX_057_Claude/E34_Install_v1.zip`, `9d9949d5...15fc`) in a disposable task clone on the owner's machine. The report (`CLAUDE_CODE_WORKING_FOLDER_TREE/outbox/REPORT_T006.md`, commit `6dc54f9`) gives:
- PASS in all 15 steps;
- all 242 tests, including E2R-T12, in 94 seconds, with the 3 allowed symlink skips;
- the main repository unchanged.

Step 11 now asked for the whole status output, copied as printed, and Claude counted it from the report: 70 lines, 69 `A` and 1 `M`. The runner needed no temporary file this time.

**The E_3/E_4 package installed** at commit `5b9edb44d4f4bf01e2d4e8cd7ec9561b32b3110e` (30 October 2026; parent `6dc54f9`, the T006 report).
- **The owner's log**, in order:
  - the ZIP's SHA-256 checked;
  - `git status --short` empty, and `Already up to date`;
  - `PRE PASS`;
  - 70 files copied;
  - `POST PASS`;
  - 69 `A` and 1 `M`;
  - `COMMITTED PASS`, then the push.
- **Departure, recorded.** The log has no test run between `POST PASS` and the commit. The owner ran the suite straight after the push, unchanged in the repository: `SUITE PASS`, all 242 tests including E2R-T12, with only the 3 allowed symlink skips, and `git status --short` empty afterwards. The same package bytes had already passed all 242 tests on the owner's machine in the T006 rehearsal. No further action is needed.

  This is the second such departure (the first was at the CODE-1 install, register v0.12). Claude's install steps will put the suite command in the same block as POST.
- **Claude's check, from a fresh GitHub clone:**
  - the parent and the 69 `A` + 1 `M` change set;
  - `COMMITTED PASS` repeated;
  - all 69 manifest entries match their Git blobs;
  - register v0.16 is the ratified `d84fc3dd...c220`;
  - 242 tests pass on Linux.

E_3 and E_4 are installed non-runnable, as designed.

**The owner's order of work (OWNER-DECIDED, 30 October 2026).**
1. This handover round.
2. The template, draft 2.
3. The E_7-E_16 batch, made from the template.
4. Method A, as E_17.
5. Method B, as E_45.
6. The discussion of the non-local means idea.

Each step keeps its own design review, code review and owner go-ahead.

**The owner's two further methods, identified.**
- **What they are:** the owner confirmed them as Methods A and B of `GASI_thought_experiments/Proposal_Methods_A_and_B_FROM_GAIS_v0.1.md`:
  - A, a recurrence-gap spectrum: whether a number that has just been drawn repels or clusters;
  - B, delay-embedding analogues: what followed the past draws that looked most like the recent ones, with forbidden ordinal patterns as a diagnostic.
- **The source:** that proposal supersedes the pre-exploratory `GASI_thought_experiments/GASI_thought_experiments_possibly_unexplored_areas.md`.
- **Their place in the catalogue:** R2 already lists close relatives. A is near E_17 (Discrete Recurrence Hazard Curves; also E_19); B is near E_45 (Delay-Embedded Nearest-Analogue Forecast; also E_27 and E_32). They become those methods' specifications, not new E-numbers.

**Keeping the template current (OWNER-DECIDED, 30 October 2026).** The new-method template is reviewed and kept up to date whenever new findings, in Claude's assessment or the reviewer's, suggest an update is warranted.
- Claude proposes each update in the next package, and it is reviewed like any other document.
- Each method's handback says whether it found anything for the template.

**The owner's working lists.** Claude keeps two lists in `exchange/` for the owner. They are working lists, not reviewed and not part of the rules; this register stays the record.
- `exchange/OWNER_REMINDERS.md` (from `43c95c5`; updated at `95ad6bf` and `eadb3e3`): things the owner asked to be reminded of, each with the date asked and its status. As of this register:
  - R-001: the two methods above;
  - R-002: the non-local means idea, postponed by the owner until after Methods A and B;
  - R-003: the optional tidy-up of old EX copies in `review/`;
  - R-004: the NIST Randomness Beacon root (D-9..D-11), due at the first method that uses random numbers.
- `exchange/OWNER_ROADMAP.md` (from `eadb3e3`): the steps in plain English and where the project is up to. Claude updates it at each milestone and shows it to the owner then, and whenever asked.

**H-1 v1r5 and H-2 v1r6 (installed with this register).** The owner asked for the handovers to be refreshed at this milestone, the first three new methods installed, as register v0.14 foresaw.
- `HANDOVER/Claude_Primary_Handover_H1_v1r5.md` (`1214bd971058ddd6cc680526fd80375bdbbd6db17397e41ba4c14ae5467101e1`): Claude's handover, refreshed in place to `5b9edb4` with 37 counted edits from v1r4. It keeps v1r4's structure; section 2A is byte-identical. Its Appendix B lists what changed. It folds in the out-of-date statements of registers v0.15 and v0.16 that concern H-1 v1r4.
- `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r6.md` (`db40f40ef22995fc65a949243001858f1d7d1285713c9954531ae6b601fc5616`): the reviewer's handover, refreshed by the reviewer chat. Claude's factual check: factual PASS subject to three corrections (H2F6-01..03), all adopted in the reviewer's r1 together with the three optionals (H2F6-04..06); the reviewer-rights region (7,676 bytes) is byte-identical to H-2 v1r5. The check is `review/Claude_Fact_Check_H2_v1r6_v1.md` (LF, `25e9644d162c51bd70018faa4453b11a40577c1e60e267442de0c464e80bebd1`), installed with this register.

**Out-of-date statements (register v0.17).** This register prevails, and the files are not edited:
- Register v0.16, "installed with this register" for the E_3/E_4 package: done, at `5b9edb4`, as above.
- H-1 v1r4 and H-2 v1r5, generally: superseded by H-1 v1r5 and H-2 v1r6.
- The E_6 design note v0.1 and the E_3/E_4 design note v0.1, where they describe the next steps: superseded by the owner's order of work above.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `HANDOVER/Claude_Primary_Handover_H1_v1r5.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 30 Oct 2026; installed with this register; `1214bd971058ddd6cc680526fd80375bdbbd6db17397e41ba4c14ae5467101e1` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r6.md` | the ChatGPT reviewer chat; factual review by Claude | OWNER-RATIFIED 30 Oct 2026; installed with this register; `db40f40ef22995fc65a949243001858f1d7d1285713c9954531ae6b601fc5616` |
| `HANDOVER/Claude_Primary_Handover_H1_v1r4.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 29 Oct 2026; superseded by H-1 v1r5; `2050e9363d841634ecf2a9c308d3efb1ed51b359fbdaf2aa3531a60eb1f1c16a` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r5.md` | the ChatGPT reviewer chat; factual review by Claude | OWNER-RATIFIED 29 Oct 2026; superseded by H-2 v1r6; `67a1b3eaa3e1f51415eceba513fd7e1a39de91619296f0efba97ba108570a094` |
| `RATIFICATION_REGISTER_v0_16.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 30 Oct 2026; installed at `5b9edb4`; superseded by this register; `d84fc3ddd5978f0a5529bad20f9db9d1f95142c7e06e3dd78599cc0d4fa1c220` |

## The handovers installed, the owner's revised order, and wave 1 (register v0.18)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.18.

**The handover round's review (EX_058 to EX_060).** The verdict on H-1 v1r5 and register v0.17 is `review/Independent_ChatGPT_H1_v1r5_Register_v17_Review_v0_1.md` (LF copy, `1a20c96264c54957152c0d3cf27562f0abe5fc0470af82a1bf263cdaa2fb2fa6`), installed at `8defe9d`.
- **H1F5-C01 (CORRECTION, FIX AND PROCEED) was Claude's error.** A note pointing to the owner's purpose restatement had been placed inside H-1's section 2A, and Claude's builder had checked only the section's heading and seven points, so the claim "section 2A is unchanged" was not true of the whole section.
  - Claude moved the note unchanged to just before the section, as the reviewer specified.
  - The result is `1214bd97...01e1`, the reviewer's own reconstruction.
  - The whole section is byte-identical (1,359 bytes), and the builder now asserts the whole section.
  - Register v0.17 changed only in its two H-1 references.
- **The other two dispositions:** register v0.17 CONTENT PASS, and H-2 v1r6 r1 adopting all six of Claude's H2F6 items with the rights region unchanged.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** HROUND-060-RD-01..03.

**The handovers installed (DOC-7)** at commit `8defe9d7fbc0a1f46ddda14cac4355970e348761` (30 October 2026; parent `eed7485`), by the document-only procedure.
- The owner's log is clean.
- Claude checked all 6 files from GitHub against the ratified bytes: H-1 v1r5, H-2 v1r6 (r1, `db40f40e...5616`), register v0.17 (`268e72b2...9d17`), and the review copies of EX_056 and EX_060 with Claude's fact check.
- H-1 v1r5 and H-2 v1r6 are now the operative handovers.

**The owner's revised order of work (OWNER-DECIDED, 30 October 2026; it replaces register v0.17's order of the same day).** The owner asked whether other catalogue methods should come first. Claude proposed the order below, with a plain description of every method, and the owner agreed:
1. **Wave 1,** light counting methods, with the template's draft 2: E_7, E_9, E_10, E_8.
2. **Wave 2,** gaps between appearances, sharing one helper: E_2 (one of the owner's original six), E_17 as Method A, E_19, E_18.
3. **Releases and WF-1:** switch the methods on, then the first real measured results over past draws, walk-forward, with the scorer.
4. **Wave 3,** look-alike past draws: E_27, E_45 as Method B, E_26, E_28.
5. **The non-local means discussion** (the owner chose to keep it here, rather than after wave 11).
6. **Waves 4 to 11** (`exchange/OWNER_ROADMAP.md` lists every method):
   - 4: E_5 and the rest of E_11 to E_16, with E_12, E_13 and E_16 each in its own package;
   - 5: curves and cycles;
   - 6: numbers acting together;
   - 7: drawn order;
   - 8: information and nonlinear methods;
   - 9: machine learning, which needs a dependency change and the seed policy;
   - 10: the pilot-wave-inspired family;
   - 11: outside data.
7. **The ensembles,** E_55 and E_56, last.

**Reasons given to the owner for the change:**
- E_2 and E_5 are owner originals still unbuilt.
- The heavy members of E_7 to E_16 deserve their own packages.
- Methods A and B pair with their simplest relatives.
- After about ten methods, measuring them on real past draws is worth more than adding more.

**The wave 1 design review (EX_061 to EX_064).** The design note is `Predictive_Randomness_Wave1_E7_E8_E9_E10_Design_v0_1r1.md`, installed with this register.
- **EX_062** found it scientifically sound, with one shared CORRECTION, W1-C01, which was Claude's overstatement.
  - The note and the template README said that a score depending only on a number's count ranks exactly like counting. That holds only for the same strictly increasing function of each count over the same draws. Count-only scores need not be monotonic, and deliberately non-monotonic methods are not excluded.
  - The reviewer also checked E_8's moment estimator algebraically, and independently on 10,000 exhaustive synthetic histories.
- **EX_064** passed the corrected design v0.1r1 and README unchanged. Both of the reviewer's optional items were adopted: the reference script asserts E_8's cap example, and the template builder pins both draft-1 files.
- **The review copies,** installed with this register:
  - `review/Independent_ChatGPT_Wave1_R3_and_Template_Draft2_Review_v0_1.md` (LF, `76818fab4d16988ea89a0e52b55c42ada46163e5d10da288a4b558285aad1a21`);
  - `review/Independent_ChatGPT_Wave1_v0_1r1_Focused_RECHECK_v0_1.md` (LF, `780513e0b1f36ac1981f5b2e6476b985bec266a8ee01fa0fd2fb49b70d81763a`).
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** W1-RD-01..07.

**Owner decisions W1-1..W1-6 (OWNER-DECIDED 30 October 2026, as recommended, with the reviewer's support):**
- W1-1: one shared counting helper, `_common/occurrence_counts.py`, versioned with the four methods;
- W1-2: the 12 fixed variants of the design note's section 6;
- W1-3: E_7's full-history variant is kept as the pure calibration variant, although it ranks like E_1;
- W1-4: E_9 and E_10 are score-only; E_7 and E_8 publish marginal probabilities, with their limits stated;
- W1-5: the template's draft 2;
- W1-6: E_8 uses moment estimates, not a sampled Bayesian fit.

**The wave 1 package (installed with this register).**
- **What it adds:**
  - the helper `src/methods/_common/occurrence_counts.py`, revision 1;
  - `src/methods/E_007/`, `E_008/`, `E_009/` and `E_010/`, each with `variants.py`, `contract.py` and `IN_DEVELOPMENT.txt`;
  - 24 declarations and 24 `FORMULA_OPEN` entries;
  - `tests/test_occurrence_counts.py` (8 tests) and `tests/test_wave1_frequency.py` (18 tests);
  - the design note v0.1r1 and its reference script;
  - review evidence.
- **What it replaces:**
  - `src/methods/Method_Contract_Runner.py`: four imports and four `ADAPTERS` entries;
  - the template's `README.md`, `METHOD_SPECIFICATION_TEMPLATE.md` and `method_folder/contract.py.txt`, which become draft 2. The README has one bullet more than the reviewed draft 2 r1, from a finding in the code (below).
- **What it does not change:** the contract libraries, the reader, the coordinator, E_1, E_3, E_4, E_6 and their helpers, the launchers and owner tools, and the four methods' `NOT_YET_SPECIFIED` placeholders. The four switches stay False, and the allowlist stays empty.
- **The four methods cannot run** once this is installed: every request is refused with `NOT_SUPPORTED` before any data is read, and the flags are present.
- **A finding from the code, for the template** (the owner's keep-current rule):
  - E_8's three period lengths give identical scores whenever its weight is 0 and their whole periods cover the same draws. For example, Oz Lotto's 218 draws hold 16 quarters, 8 half-years or 4 years: the same 208 draws.
  - This follows from the design, and the tests check that variants differ exactly where their correct values differ.
  - The README gains one "things that bite" bullet saying so.
- **Review and acceptance:**
  - the owner's Windows run of all 268 tests comes before the commit;
  - E2R-T12 for this package's rehearsal and install run: OWNER-APPROVED 30 October 2026 (up to six ordinary Python worker processes that finish normally);
  - Claude verifies the commit from GitHub.

  The results are recorded after installation; this register does not predeclare them.

**Out-of-date statements (register v0.18).** This register prevails, and the files are not edited:
- Register v0.17, "installed with this register" for H-1 v1r5 and H-2 v1r6: done, at `8defe9d`, as above.
- Register v0.17 and H-1 v1r5 section 10, the owner's order of work: replaced by the revised order above.
- H-1 v1r5 section 7.4, "242 offline tests in 17 modules": 268 in 19 once the wave 1 package is installed.
- The template's draft 1 (`METHOD_TEMPLATE/`), where draft 2 replaces it.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_Wave1_E7_E8_E9_E10_Design_v0_1r1.md` | Claude; reviewed by the ChatGPT reviewer chat | Design PASS unchanged (W1-RD-05); owner decisions W1-1..W1-6 as above; installed with this register; `06b491225812e14962aef99e299cbd6c003be68bb5a73425e566f1b1fe685060` |
| `RATIFICATION_REGISTER_v0_17.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 30 Oct 2026; installed at `8defe9d`; superseded by this register; `268e72b2a435628550079682040ae2eab69b5a08baa3241e4ee9e47e54499d17` |

## Wave 1 installed, and wave 2 (register v0.19)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.19.

**Wave 1's code review (EX_065 to EX_067).**
- **EX_065** sent the wave 1 code package candidate (`W1_Install_v1_candidate.zip`) with register v0.18's candidate.
- **EX_066** gave R-2 PASS (0 BLOCKER, 0 CORRECTION, 0 OPTIONAL, 0 RECONSIDER), with the tests independently reproduced, and register v0.18 CONTENT PASS. Its review copy, `review/Independent_ChatGPT_Wave1_R2_and_Register_v18_Review_v0_1.md` (LF, `baf0914044f88ef5162ed6d71d7f5f0dc5d93f6f7e33f1dfa8af5541c38ffa90`), is installed with this register.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** W1-066-RD-01, REG18-066-RD-02 and W1-066-RD-03.
- **The owner** ratified register v0.18 and approved E2R-T12 for wave 1's rehearsal and install run (30 October 2026).
- **EX_067** recorded the final package, `W1_Install_v1.zip` (`51c81eb0757b92eff321ceb24227fa1ffcee976d5c5d72e1dd1df146d9da30c2`), and register v0.18 final; it needed no reply.

**Wave 1's rehearsal and installation.**
- **TASK_T007** (Claude Code, the local runner) rehearsed the final package in a task clone: PASS on all 15 steps. Its report is `CLAUDE_CODE_WORKING_FOLDER_TREE/outbox/REPORT_T007.md` at `b08f971`. Claude read it in full: 88 status lines (84 A and 4 M), 268 tests with 3 symlink skips, and no deviations.
- **The owner installed it** at `947c370d6f529e33e2dfc27b889713b298d364e5` (30 October 2026; parent `b08f971`). The log is clean: `PRE PASS`; 88 files copied; `POST PASS`; `SUITE PASS` (268 tests, 3 symlink skips) before the commit; 84 A + 4 M; `COMMITTED PASS`; then the push.
- **Claude verified the commit from a fresh GitHub clone:**
  - `COMMITTED PASS`;
  - all 87 manifest blobs;
  - register v0.18 `85125c49...3c97`;
  - nothing outside `doc`, `review`, `src` and `tests`;
  - all 268 tests on Linux.
- **The four wave 1 methods** are installed and not runnable.

**The wave 2 design review (EX_068 to EX_073).** The design note is `Predictive_Randomness_Wave2_E2_E17_E18_E19_Design_v0_1r2.md`, installed with this register. Its reference script, `review/W2_Install_v1/tools/reference_wave2.py`, computes and asserts every worked example.
- **EX_068** sent design v0.1.
- **EX_069: REVISIONS REQUIRED (1 BLOCKER, 1 CORRECTION, 1 OPTIONAL).**
  - **W2-B01 (BLOCKER) was Claude's error.** v0.1 claimed that a least-squares slope on the harmonic number H_k ranks exactly as Method A's logistic hazard on ln(age). The sign argument holds only for the same covariate. The reviewer proved the reversal with an exact 104-draw witness, and Claude confirmed it; on fair invented histories, the two signs differed at 10 of 312 targets.
  - **W2-C01 (CORRECTION):** section 3.2 had implied that E_18's fit uses the open stretch; it fits completed gaps only.
  - **W2-O01 (OPTIONAL):** the template rule on iterative floating-point fits was too categorical.
- **The owner's decisions after EX_069** (OWNER-DECIDED 30 October 2026):
  - **W2-3:** the faithful Method A rule, the reviewer's choice A. The sign of sum_k (n E_k - e R_k) ln k is decided exactly by prime exponents and rational bounds on ln p. The harmonic slope is withdrawn, not kept as a surrogate.
  - **W2-7:** the byte-reproducibility wording of W2-O01.
- **EX_070** sent design v0.1r1 (23 counted edits).
- **EX_071: REVISIONS REQUIRED (2 CORRECTION, 1 OPTIONAL).**
  - **W2R1-C01 was a gap of Claude's.** verify()'s second sign route could not end when the value is exactly zero; the reviewer's eight-draw witness has a_k = 6, -12, 0, 6.
  - **W2R1-C02** found a stale option line.
  - **W2R1-O01** asked for more precise wording on a future survival likelihood.
- **EX_072** sent design v0.1r2 (6 counted edits). verify()'s route 2 now has its own exact-zero test, by a smallest-prime-factor sieve, then direct bounds on each ln k, with a 1,024-term refusal cap.
- **EX_073: PASS UNCHANGED** (0/0/0/0). The reviewer also checked all 15,625 coefficient vectors in [-2, 2] for ages 1 to 6 (65 exact zeros).
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** W2-069-RD-01..04, W2-071-RD-05..08 and W2-073-RD-09..11.
- **The review copies,** installed with this register (LF):
  - `review/Independent_ChatGPT_Wave2_R3_Review_v0_1.md` (`75ec652caf27c1db5594625bbc0ad4b0f587ffc233e59c68bc25695841913c51`);
  - `review/Independent_ChatGPT_Wave2_v0_1r1_R3_RECHECK_v0_1.md` (`64a48a8cb91633fad3027860fd6ff2ca770d35a88040f936404294dbc2ade56a`);
  - `review/Independent_ChatGPT_Wave2_v0_1r2_Focused_RECHECK_v0_1.md` (`e5b5116be5448601d82eba27fb4efcd86fa3c6400a762a9ea275ece474ef2305`).

**The owner's ratification (OWNER-DECIDED 30 October 2026):** design v0.1r2 ratified, with W2-1, W2-2, W2-4, W2-5, W2-6 and W2-8 as recommended and supported by the reviewer:
- **W2-1:** one shared gaps helper, `_common/recurrence_gaps.py`, versioned with the four methods;
- **W2-2:** the 12 fixed variants of the design note's section 6;
- **W2-4:** all four score-only in revision 1;
- **W2-5:** E_18 as a fixed four-law library (FAST, FAIR, SLOW, REGULAR) fitted by exact minimum chi-square, not EM;
- **W2-6:** E_19 per label, with the trend and the label's level divided out, and cycles fixed at 2, 3 and 4;
- **W2-8:** the NIST Beacon seed (reminder R-004) is settled at WF-1's design, because wave 2 uses no random numbers and R3's N1 fair-draw simulator is the first part that does.

Method A's diagnostics A1 to A5 are a separate later package after WF-1 (W2-3). Method A's decisions 3 and 4 (drawn order; machine and ball-set metadata) are not pursued.

**The wave 2 package (installed with this register).**
- **What it adds:**
  - the helper `src/methods/_common/recurrence_gaps.py`, revision 1;
  - `src/methods/E_002/`, `E_017/`, `E_018/` and `E_019/`, each with `variants.py`, `contract.py` and `IN_DEVELOPMENT.txt`;
  - 24 declarations and 24 `FORMULA_OPEN` entries;
  - `tests/test_recurrence_gaps.py` (12 tests) and `tests/test_wave2_recurrence.py` (19 tests);
  - the design note v0.1r2 and its reference script;
  - the four review copies above;
  - review evidence.
- **What it replaces:**
  - `src/methods/Method_Contract_Runner.py`: four imports and four `ADAPTERS` entries;
  - the template's `README.md` and `METHOD_SPECIFICATION_TEMPLATE.md`, which become draft 3 with the design's findings (section 12, five items), the termination lesson of W2R1-C01, and a note from the code that hand-written test expectations need a tool too. The code skeletons are unchanged.
- **What it does not change:** the contract libraries, the reader, the coordinator, E_1, E_3, E_4, E_6, wave 1 and their helpers, the launchers and owner tools, and the four methods' `NOT_YET_SPECIFIED` placeholders. The four switches stay False, and the allowlist stays empty.
- **The four methods cannot run** once this is installed: every request is refused with `NOT_SUPPORTED` before any data is read, and the flags are present.
- **Review and acceptance:**
  - the owner's Windows run of all 299 tests comes before the commit;
  - E2R-T12 for this package's rehearsal and install run: OWNER-APPROVED 30 October 2026 (up to six ordinary Python worker processes that finish normally);
  - Claude verifies the commit from GitHub.

  The results are recorded after installation; this register does not predeclare them.

**Out-of-date statements (register v0.19).** This register prevails, and the files are not edited:
- Register v0.18, "installed with this register" for the wave 1 package: done, at `947c370`, as above.
- H-1 v1r5 section 7.4, "242 offline tests in 17 modules", and register v0.18's "268 in 19": 299 in 21 once the wave 2 package is installed.
- The template's draft 2 (`METHOD_TEMPLATE/`), where draft 3 replaces it.
- `exchange/OWNER_REMINDERS.md` R-004's "when": decided by W2-8.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_Wave2_E2_E17_E18_E19_Design_v0_1r2.md` | Claude; reviewed by the ChatGPT reviewer chat | Design PASS unchanged (W2-073-RD-11); OWNER-RATIFIED 30 Oct 2026 with W2-1..W2-8 as above; installed with this register; `2ab342911701edf1e93ad590e4765a3efac54a76d732b7fd2c5875c7d363fe74` |
| `RATIFICATION_REGISTER_v0_18.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 30 Oct 2026; installed at `947c370`; superseded by this register; `85125c4900dabee53d2674d0ca3a18abbed64d5179b7f0b178300f928de93c97` |

## Wave 2 installed, the reviewer chat's end, and the handovers (register v0.20)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.20.

**Wave 2's code review (EX_074 to EX_076).**
- **EX_074** sent the wave 2 code candidate (`W2_Install_v1_candidate.zip`, `30219330cd73687b12d2442fb176712c59966f92f8da6977ae7ca50d020e0515`) with template draft 3 and register v0.19's candidate.
- **EX_075** gave R-2 PASS (0 BLOCKER, 0 CORRECTION, 0 OPTIONAL, 0 RECONSIDER), and CONTENT PASS for template draft 3 and register v0.19. The reviewer reproduced 288 selected tests independently, including all 31 new ones; the ten real-master reader tests and E2R-T12 were not run by the reviewer.
- **The review copy,** `review/Independent_ChatGPT_Wave2_R2_Template3_Register19_Review_v0_1.md` (LF, `1d4cf3551b2311d8968f4f4ddc182ef11f8651ff2a49d246c57af946b86dff47`), is installed with this register.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** W2-075-RD-01..04.
- **The owner** ratified register v0.19 and approved E2R-T12 for wave 2's rehearsal and install run (30 October 2026).
- **EX_076** recorded the final package, `W2_Install_v1.zip` (`57ef34b67b8aa6cc023c5ea3d78c2940ab1a9875c3141626c5016355da53c429`), and register v0.19 final; it needed no reply.

**Wave 2's rehearsal and installation.**
- **TASK_T008** (Claude Code) rehearsed the final package in a task clone: PASS on all 15 steps. Its report is `CLAUDE_CODE_WORKING_FOLDER_TREE/outbox/REPORT_T008.md` at `94a5e95`. Claude read it in full: 90 status lines (87 A and 3 M), 80 declarations and 202 registry chains, 299 tests with 3 symlink skips, and no deviations.
- **The owner installed it** at `b61b1a27999dcdfce2e2e59c6ced4f349ee652b4` (30 October 2026; parent `94a5e95`). The log is clean: `PRE PASS`; 90 files copied; `POST PASS`; `SUITE PASS` (299 tests, 3 symlink skips) before the commit; 87 A + 3 M; `COMMITTED PASS`; then the push.
- **Claude verified the commit from a fresh GitHub clone:**
  - `COMMITTED PASS`;
  - all 89 manifest blobs;
  - register v0.19 `b3ae51fd...e6a0`, design v0.1r2 `2ab34291...fe74`, and template draft 3 (`README.md` `daac8da1...2214`, `METHOD_SPECIFICATION_TEMPLATE.md` `1ef9df2d...8cfa`);
  - nothing outside `doc`, `review`, `src` and `tests`;
  - all 299 tests on Linux.
- **The four wave 2 methods** are installed and not runnable.

**The reviewer chat's end (30 October 2026).** The ChatGPT reviewer chat that wrote every review from the role transition to EX_075 reached its maximum length without warning, before it could update its handover.
- **The owner's instruction (OWNER-DECIDED 30 October 2026):** Claude brings both handovers up to date (H-1 and the reviewer's H-2), and writes an introductory blurb for each new chat. There is no other route, because the old reviewer chat cannot continue.
- **The owner's order:** Claude's own handover first, then the reviewer's.
- **The owner's naming:** each blurb is saved next to its handover, as `<handover file name>_introductory_blurb.md`.
- **The departure, recorded:** H-2 v1r6 says that handovers receive one other-model factual review. This round has none before ratification, by the owner's decision. The safeguards are:
  1. H-2's protected reviewer-rights region is byte-identical: 7,676 bytes, SHA-256 `70e50dc3bc56d9800c046a773abb823b8cb659b4f23d7dba1f18f7bd31bc72db`, asserted by the builder;
  2. Claude changed only status, checkpoint, cold-start and change-control facts in H-2, and added no reviewer rule;
  3. H-2's header asks the new reviewer chat to read it critically on takeover, and its blurb makes that check part of the first reply;
  4. the owner may ask for a v1r8 after that check.

**The handovers (installed with this register):**
- `HANDOVER/Claude_Primary_Handover_H1_v1r6.md` (`a5f74126dfead7f5ea40a5999b3944e44fe7f0764d9bdef463df1075953f9509`): built from H-1 v1r5 by `make_h1_v1r6.py` (31 counted edits). Section 2A is byte-identical, which the builder asserts. Its Appendix B lists every change.
- `HANDOVER/Claude_Primary_Handover_H1_v1r6_introductory_blurb.md` (`5c6b30415baae6fbeda5a5e3c5073b472782c1f78d59b85eecd4b9e644c7de49`): the starter text for a new Claude chat.
- `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r7.md` (`a59ab8504d0d63d852d66efcc9491a05d3329656eb5164eef682df57da60ec38`): built from H-2 v1r6 by `make_h2_v1r7.py` (18 counted edits, the rights region asserted).
- `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r7_introductory_blurb.md` (`4d4d9b9b4a1a34fe4ce6256f64d67314ffb3a7a78ad0277df4f0b4c803d852ee`): the starter text for the new reviewer chat. It lists exactly what to attach: the repository as a ZIP without `source_data`, `results` and `transitory_data`, and the five files to read first. Its first task is a takeover check.

The builders, the four diffs and the register builder are installed with this register under `review/DOC8_Handovers_v1/`; this round has no EX message, because there was no reviewer chat to send it to.

**Out-of-date statements (register v0.20).** This register prevails, and the files are not edited:
- Register v0.19, "installed with this register" for the wave 2 package: done, at `b61b1a2`, as above.
- H-1 v1r5 and H-2 v1r6 throughout: superseded by H-1 v1r6 and H-2 v1r7 once installed.
- H-2 v1r6 section 0, "Handovers receive one other-model factual review": not applied to this round, by the owner's decision above.
- `exchange/OWNER_ROADMAP.md` item 9b: done once this round is installed.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `HANDOVER/Claude_Primary_Handover_H1_v1r6.md` | Claude; no other-model review (above) | Installed with this register on the owner's ratification; `a5f74126dfead7f5ea40a5999b3944e44fe7f0764d9bdef463df1075953f9509` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r7.md` | Claude, on the owner's instruction; rights region byte-identical | Installed with this register on the owner's ratification; `a59ab8504d0d63d852d66efcc9491a05d3329656eb5164eef682df57da60ec38` |
| `RATIFICATION_REGISTER_v0_19.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 30 Oct 2026; installed at `b61b1a2`; superseded by this register; `b3ae51fd162960b64a9d145a52646dceeb3aec5b91e4b359ad7166e5e4c8e6a0` |

## The new reviewer, releases and WF-1 (register v0.21)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.21.

**The DOC-8 installation.** H-1 v1r6, H-2 v1r7, their introductory blurbs and register v0.20 were installed at `03f7da470d0231354592c98b1b32f28e6a86d473` (30 October 2026; parent `9583f97`). Claude verified it from GitHub: 14 files added, all blobs as packaged. The owner's roadmap was updated at `1d836c6`.

**The new reviewer chat (30 October 2026).** The owner started a new ChatGPT reviewer chat from H-2 v1r7 and its introductory blurb, with the repository snapshot at `1d836c6`.
- **Its takeover reply** accepted the role, with the same rights (R-1 to R-11) and independence. It verified H-2's protected rights region (7,676 bytes, `70e50dc3...72db`) and H-2 v1r7's canonical hash, and found 0 BLOCKER, 0 CORRECTION, 1 OPTIONAL and 0 RECONSIDER.
- **H2-TAKEOVER-O01 (OPTIONAL):** H-2's historical wording still calls R-8 to R-11 proposed. They have been OWNER-RATIFIED since 27 October 2026 (H-2 v1r2). At the next H-2 revision, a clarification is to be added **outside** the protected region; the region stays byte-identical.
- **Its answers to five follow-up questions** (test reproduction under R-2 and R-9; E_17's scores are not probabilities, and mark-never-suppress; the pattern origins PO-1 to PO-4; a holdout exposure in an attachment; its first EX message) were checked by Claude against the record: all consistent. Its two terminology points on the method overview were adopted: "E_1 is the only `SUPPORTED` method"; E_17's variants publish ranking scores, not probabilities.

**The releases and WF-1 design review (EX_077 to EX_081).**
- **EX_077** (`4bdb060`): the design note v0.1 for REL-1, WF-1A, SEED-1 and WF-1B, with reference and timing probes on invented data. Section 8.1 announced N1's provisional seed policy `N1_ROOT_NIST_C2_20261106T0000Z_V1`: NIST Randomness Beacon 2.0, chain 2, the pulse at `2026-11-06T00:00:00.000Z`, field `outputValue`, `statusCode` 0, no fallback.
- **EX_078** (`b4b83c1`): R-3 RECHECK, with 1 BLOCKER (WF1-R3-B01: the driver would have continued after a data-admission failure), 4 CORRECTION (C01 NIST's certificate notice and the meaning of verification; C02 the search-log row written too late; C03 the downgrade rules for missing opportunities; C04 "exact everywhere" overstated) and 2 OPTIONAL. The copy installed with this register is `review/Independent_ChatGPT_WF1_Design_R3_Review_EX078.md` (LF, `8e117858a7b1e3bd92b5537efd0a5e0d99c95e600b98f2b66c46503e0a97be72`).
- **EX_079** (`be002c9`): design v0.1r1, resolving all seven.
- **EX_080** (`6df9585`): focused RECHECK PASS. B01 and C01 to C04 are resolved, O01 and O02 adopted. It adds C05 (CORRECTION, FIX AND PROCEED, REVIEWER-DECIDED: one phrase of WF1-7's summary) and O03 (OPTIONAL: probe_tails.py's second chain-link check is tautological; to be qualified at the next documentary update). The copy installed with this register is `review/Independent_ChatGPT_WF1_Design_Focused_RECHECK_EX080.md` (LF, `4c05c27b9907e18971f64cb3ae7568bb2ce7e7122452f6cc1ab418e342b51795`).
- **EX_081** (`4c68f3f`): Claude applied C05 exactly as permitted (a one-line change, recorded with its diff), giving the ratification candidate.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** WF1-R3-C05.

**The code review (EX_082 to EX_084).**
- **EX_082** (`4ba804e`): the REL-1 and WF-1A code candidates and this register's first candidate, with owner decision WF1-13 disclosed.
- **EX_083** (`faafe13`): R-2, RECHECK. REL-1: no finding; all 78 transitions, the 11 deletions and the unchanged E_1 checked independently. WF-1A: WF1A-R2-B01 (BLOCKER): resume counted a pair done from any terminal record with the same registry entry and revision, which binds neither the master pin nor the batch, and does not validate the records. WF1A-R2-O01 (OPTIONAL): per-module test times. WF1-13's interim exclusion of E_1 and M = 78: no objection. This register's content: consistent, with the package status to be reconciled.
- **EX_084:** WF-1A v2 resolves B01. Before each run, the driver appends a `WF_BATCH_ATTEMPT_V1` line (the batch ID, the pair, the fresh run ID and the digest of the exact request) to the batch's `attempts.jsonl`. A pair is done only through an attempt of the same batch whose run folder holds a valid canonical terminal record matching that request, in a CONTINUE class. For a SUCCESS it also needs a consumable forecast whose receipt and record carry the plan's master pin, run mode, view, declaration and registry entry. Runs of other batches are never reused. The RECHECK result and the owner's acceptance of WF-1A are recorded in the next register.

**The owner's decisions (30 and 31 October 2026).**
- **The design ratified:** `Predictive_Randomness_Releases_and_WF1_Design_v0_1r1.md` (`03f95fbe5c3f0e3771a07550b8b57d3c87fe5f7e06a8cc5d02974982ff7a12ee`), with C05 applied, OWNER-RATIFIED 31 October 2026 and installed with this register. Its decisions WF1-1 to WF1-5, WF1-7, WF1-8, WF1-10 and WF1-11 are OWNER-RATIFIED as recommended.
- **WF1-6 (OWNER-DECIDED 30 October 2026):** each track is scored on its own fixed grid, with a labelled common-set descriptive table, departing from R3 17.3.7's default intersection set; under the downgrade rules of the design's section 6.2A.
- **WF1-9:** the announced pulse is kept.
- **WF1-12 (OWNER-DECIDED 30 October 2026, after EX_078 C01):** N1's seed is trusted through NIST's official HTTPS service. The pulse's signature and certificate are not validated (`NOT_PERFORMED`), and NIST's certificate notice of 23 October 2026 does not block approval. D-9's two-person check stays: the owner fetches the pulse by hand, and Claude independently reads it from NIST's archive and compares five fields. The owner accepts the residual authenticity risk. D-9 to D-11 are unchanged.
- **D-10, as ratified (confirmed by the owner, 30 October 2026):** "no seed shopping" means no replacement except a new pre-announced policy, with every root kept and counted.
- **WF1-13 (OWNER-DECIDED 31 October 2026, during WF-1A's coding):**
  - **The finding:** E_1 revision 1's multi-game function refuses real data. It was kept byte-unchanged on purpose when E_1 was wired into the contract (E2RC-C04 option (a)). So E_1 cannot run in the walk-forward batches as the design assumed.
  - **The owner's choice (option C):** a new E_1 revision 2 that accepts real development runs, with E_1's legacy runner moved to revision 2 as well. CODE-3 (retirement tooling, D-5) comes first.
  - **In the meantime:** WF-1A names E_1 in every batch plan as not in the cohort, with the reason, and never runs it. The cohort is 39 variants, and the design's MR7 families have M = 78 until E_1 r2 joins with its own batch.
  - **The options not chosen:** leaving E_1 out for good (A); a one-line scoped exception keeping revision 1 (B); E_1 through its legacy D3 runner and record format (D).
  - **Recorded in** `exchange/OWNER_REMINDERS.md` R-005.

**Findings for R3, recorded here** (R3 v0.5's text is not edited; this register prevails for WF-1):
- **R3-1:** R3 17.3.7's default intersection set gives Oz Lotto 12 draws with this cohort; superseded for WF-1 by WF1-6.
- **R3-2:** Oz Lotto's default window starts at 1474, the era's first draw, which has no history; it is in no track's grid.
- **R3-3:** 17.13's stage-2 test list "21..23" is read as MRT-22 and MRT-23 in stage 2, and MRT-21 (MR15) in stage 3.
- **R3-4:** 17.11's production route (`lgamma`) and test oracle (`Fraction`) swap roles (WF1-7).

**The packages, reviewed in one round (R-2) and installed one after the other:**
- **REL-1** (`review/REL1_Install_v2/`), **installed with this register:** it releases the 39 variants of E_2, E_3, E_4, E_6, E_7, E_8, E_9, E_10, E_17, E_18 and E_19 in both games. It appends 78 `entry_0002.json` records (`SUPPORTED`), deletes the 11 `IN_DEVELOPMENT.txt` flags, adds tests/test_rel1_release.py, edits five existing tests' status expectations, and installs this register, the design and the two review copies. Contract runs stay synthetic until WF-1A.
- **WF-1A** (`review/WF1A_Install_v2/`), **installed after REL-1, in its own commit,** identified after installation:
  - it adds the walk-forward driver (`src/methods/Method_Walk_Forward.py` and `src/methods/_common/walk_forward.py`) and its tests;
  - it turns `ENABLE_CONTRACT_REAL_DEVELOPMENT` on (WF1-3);
  - it moves the runner's real run root to `results/real/development/contract_runs/` and git-ignores it, with each batch's `attempts.jsonl`.
  Its installation is the owner's decision to turn that switch on. Each real batch is a further owner authorisation, recorded in the next register.

**Out-of-date statements (register v0.21).** This register prevails, and the files are not edited:
- **D6-3's release order** (E_6's full-memory variant first): superseded by WF1-2.
- **D2-2 and E2R-1** ("`ENABLE_CONTRACT_REAL_DEVELOPMENT` stays False"; "contract runs are synthetic only"): superseded by WF1-3 once WF-1A is installed.
- **H-1 v1r6 and H-2 v1r7, "the four switches stay False":** three stay False; the fourth is on once WF-1A is installed. Their other status lines are superseded by this register.
- **Architecture 13.1 and R3 11.7:** real-development contract runs are published under `results/real/development/contract_runs/`, not `transitory_data/contract_runs/`, once WF-1A is installed.
- **The design's sections 8.2 and 9.5, on NIST's chain links:** their second chain-link line is illustrative only (EX_080 O03); qualified at the next documentary update.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_Releases_and_WF1_Design_v0_1r1.md` | Claude; reviewed by the ChatGPT reviewer chat (EX_078, EX_080; C05 applied) | OWNER-RATIFIED 31 Oct 2026; installed with this register; `03f95fbe5c3f0e3771a07550b8b57d3c87fe5f7e06a8cc5d02974982ff7a12ee` |
| `RATIFICATION_REGISTER_v0_20.md` | Claude; on the owner's instruction, no other-model review before ratification (register v0.20) | OWNER-RATIFIED 30 Oct 2026; installed at `03f7da4`; superseded by this register; `d273f7a16532935368d137ee404717873e66d8ea189b35336104c396d2c517d4` |

## The installs, E_1 revision 2 and the first walk-forward batches (register v0.22)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/`, `archive/`, `results/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.22. Every commit named here was verified by Claude from GitHub; the owner's Windows results are owner-reported.

**WF-1A's RECHECK and the owner's acceptance (EX_085, EX_086).**
- **EX_085** (`ef51305`): focused RECHECK PASS of WF-1A v2 (WF1A-R2-B01 resolved); REL-1 v2 has no new code or test change; register v0.21 candidate 2 is consistent. 0 BLOCKER, 0 CORRECTION, 0 OPTIONAL, 0 RECONSIDER. The reviewer ran 7 of WF-1A's 22 test methods and a probe of its own; the full suites are author evidence.
- **The owner (31 October 2026)** ratified register v0.21 and accepted REL-1 v2 and WF-1A v2 for installation, REL-1 first.
- **EX_086** (`1a90281`) recorded the final REL-1 package, `exchange/EX_086_Claude/REL1_Install_v2.zip` (`3ca731fe22ffc10a2dd4f59fd5f5725f9f6c88553a426f12eea395795e1e4b36`). Of its 100 members only three differ from candidate 2: register v0.21's version line, the manifest's register line, and the verifier's two constants for them. EX_087's part A checked that record.

**REL-1 installed.**
- **TASK_T009** (Claude Code; report `bf61c97`) rehearsed it in a task clone: PASS on all 16 steps; 304 tests with 3 symlink skips; 108 status lines (92 A, 5 M, 11 D). The task needed `git rm` in a task clone, which `CLAUDE_CODE_WORKING_FOLDER_TREE/tools/cc_clone.py` v0.3 allows (`1a90281`).
- **The owner installed it** at `6a1bed9e9de4c733e76afeea8cecbdd39e89f97d` (31 October 2026; parent `41d2da3`).
- **Claude verified it from a fresh GitHub clone:** `COMMITTED PASS` (92 A, 5 M, 11 D); `src/` and `tests/` equal the reviewed tree; register v0.21 is `65524f92...8405`. The 39 variants of E_2, E_3, E_4, E_6, E_7, E_8, E_9, E_10, E_17, E_18 and E_19 are released in both games.

**WF-1A installed.**
- **The final package** is `CLAUDE_CODE_WORKING_FOLDER_TREE/packages/WF1A_Install_v2.zip` (`9fa6577ab95d5a16931a6df7c056764f06a61282e2f78a497b2292610a9e3c06`; `6fd4955`). Of its 18 members only `VERIFY_WF1A_INSTALL.py` differs from the reviewed candidate, in its base constant (`6a1bed9`). It is in that folder, not `exchange/`, because it needed no EX number (the folder's README says so).
- **TASK_T010** (report `d0a1036`): PASS on all 15 steps; 326 tests with 3 symlink skips; 15 status lines (10 A, 5 M).
- **The owner installed it** at `0d98706dfcc40a8f09d3c8c94a13665ac152f168` (31 October 2026; parent `d0a1036`), with `COMMITTED PASS` before the push.
- **Claude verified it from a fresh GitHub clone:** `COMMITTED PASS` (10 A, 5 M); `src/`, `tests/` and `.gitignore` equal the reviewed tree.
- **`ENABLE_CONTRACT_REAL_DEVELOPMENT` is now True** (WF1-3). The other three switches stay False, and the science allowlist stays empty.

**CODE-3 and E_1 revision 2: the design (EX_086 to EX_091).**
- **EX_086** (`1a90281`) sent the design note v0.1 for R-3. **EX_087** (`cf5b065`): RECHECK, with 1 BLOCKER (E1R2-R3-B01: the install's interim states were not fail-closed: r2's code could run under r1's approval), 2 CORRECTION (C01: a test-time archive load; C02: no independent Oz Lotto real-namespace oracle) and 1 OPTIONAL (O01: the README's retirement date).
- **EX_088** (`d06eb25`): v0.1r1, resolving all four. **EX_089** (`ae190c7`): B01, C01 and C02 resolved, O01 adopted; a new C03 (CORRECTION: the barrier test's expected refusal codes did not follow the gate's order) and O02 (OPTIONAL: a STOP after the barrier's removal).
- **EX_090** (`13af75d`): v0.1r2, with a table of the exact refusal code for each request after each install step. **EX_091** (`babb238`): focused RECHECK PASS; O03 (OPTIONAL: the barrier test's step-0 planning wording), applied in the code's test.
- **The design ratified:** `Predictive_Randomness_CODE3_and_E1_Revision2_Design_v0_1r2.md` (`fb3b26daba2a14c6e2b5ad82e102ed9920faba14115046a820fbd0ee63b7209a`), OWNER-RATIFIED 31 October 2026 as reviewed, and installed with the package below.
- **The owner's decisions on it (31 October 2026):**
  - **ER-1:** one package for CODE-3's tooling and E_1 revision 2.
  - **ER-2r1** (replacing ER-2 after EX_087 B01): one package, installed in five named steps behind a temporary barrier, E_1's own `IN_DEVELOPMENT.txt`, copied first and deleted last and never committed. An exception to E2R-R58's recommended two packages, for E_1 only.
  - **ER-3:** the archive holds revision 1 complete, including the files revision 2 keeps unchanged and the legacy entry file; an old path is removed only when the successor does not reuse it.
  - **ER-4:** the contract adapter's stale docstring sentence is corrected, with no code change.
  - **ER-5:** records WF1-13 itself.
  - **ER-6 declined:** no method-restricted batch plan. Every batch holds the full cohort.

**CODE-3 and E_1 revision 2: the code (EX_092 to EX_097).**
- **EX_092** (`41d2da3`) sent `E1R2_Install_v1` for R-2. **EX_093** (`18f0d70`): RECHECK, with 1 BLOCKER (E1R2-R2-B01: the archive-execution check missed paths built in pieces, such as `Path("archive") / "methods"`, and the claim that `archive/` could not be imported was overstated, because Python 3's namespace packages need no `__init__.py`) and 1 OPTIONAL (O01: check every input before writing).
- **EX_094** (`3873461`): `E1R2_Install_v2`, resolving both. **EX_095** (`a4b5dfe`): focused RECHECK PASS; O02 (OPTIONAL: the check folds constants within one expression, so a path root assigned on one line and joined on another escaped it).
- **The owner (31 October 2026)** accepted the package and chose to apply O02 before installing, with the reviewer's check of that change: any path construction with an `archive` component is now flagged.
- **EX_096** (`c805bf8`): `E1R2_Install_v3` (`exchange/EX_096_Claude/E1R2_Install_v3.zip`, `8547fd37fea6e5dc6a1f1941322cc5844031f2351bd50fb4c1ee1179086a2394`), built on WF-1A's install commit `0d98706`. **EX_097** (`4f1aae2`): focused RECHECK PASS, 0 BLOCKER, 0 CORRECTION, 0 OPTIONAL, 0 RECONSIDER.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** none in this round; every change went back to the owner or to a RECHECK.

**CODE-3 and E_1 revision 2 installed.**
- **TASK_T011** (report `ef439c6`) rehearsed the five steps in a task clone: PASS on all 21 steps; every verifier phase passed (pre, barrier, code, release, post, committed); 350 tests with 3 symlink skips; 40 status lines (33 A, 7 M) and no barrier file.
- **The owner installed it** at `86d12ea913d443c4ad944ee8db167df705841af1` (31 October 2026; parent `4f1aae2`), with `COMMITTED PASS` before the push.
- **Claude verified it from a fresh GitHub clone:** `COMMITTED PASS` (33 A, 7 M); no barrier file in the commit; `src/`, `tests/` and `archive/` equal the reviewed tree.
- **What it installed:**
  - **CODE-3:** `src/package_tools/method_retirement.py`, the retirement tooling (E2R-R54 to R56, T15), reusable for later successors.
  - **The archive:** `archive/methods/E_001/r1/`, E_1 revision 1's seven files unchanged, with its README (no commit ID and no hash).
  - **E_1 revision 2:** its multi-game function admits `REAL_DEVELOPMENT` as well, with revision 1's counting, ranking and tie order; its legacy runner's release gate (D2-3) names revision 2; new r2 declarations and `SUPPORTED` entries in both games; WF-1A's `NOT_REAL_CAPABLE` is empty.
- **E2R-R56, as installed:** nothing in `src/` or `tests/` may refer to a path or module inside `archive/`, enforced by a static check (constants folded within one expression, plus any path construction with an `archive` component) and a runtime check (no module from `archive/`, namespace packages included). The missing `__init__.py` files are a layout rule, not an import barrier. It is a normal-workflow control, not a security boundary.

**The first walk-forward batches (owner-authorised and run, 31 October 2026).** The owner decided to run no batch until E_1 revision 2 was installed, so that each game's first batch holds all 40 variants. Each batch was planned and run by the owner with `Run_Experiment.bat Method_Walk_Forward.py`, led step by step by Claude; Claude Code runs no batch.
- **Powerball:** batch `wf-3347ad1160df45faaaab1e2eedcedd0f`, targets 1145-1576, 40 variants, master version 1 (`ce0ae7e77e09...`, as recorded for draws 1144-1576). `COMPLETE`: 17,280 runs, and every pair proven done by this batch's own attempts. The owner's `status` checks during the run (to about a third of it) showed only `SUCCESS`, consumable under the plan's pins. Its plan, segment record and search-log row were committed by the owner at `86a1a01`.
- **Oz Lotto:** batch `wf-a75988650fb04cc399f8f7409ea27243`, targets 1475-1693, 40 variants, master version 1 (`4a6cecc27fb6...`, as recorded for draws 1474-1693). `COMPLETE`: 8,760 runs, and every pair proven done by this batch's own attempts. Committed at `8430a15`.
- **What was committed:** only `results/audit/SEARCH_LOG.csv` and each batch's `plan.json` and segment record under `results/real/development/wf_batches/`. The run folders and `attempts.jsonl` stay local and git-ignored. Claude checked those commits' paths and sizes from GitHub, not their contents.
- **Evidence tier:** retrospective development walk-forward (`DEVELOPMENT_WF_EXPLORATORY`). Nothing is scored yet; scoring is WF-1B. No holdout target was predicted.

**The owner's performance proposal (owner-committed, not reviewed).** `Deferred_Performance_Engineering_Proposal_v0_1.md` (`a5ed53c7d0cfb3278ef8342043ab1d39a99557f6f79684f3bd3276d61a5b22cb`), committed by the owner at `1050338` (31 October 2026). It is scheduled as the project's final stage (`exchange/OWNER_ROADMAP.md` item 22; `exchange/OWNER_REMINDERS.md` R-006), to start only when the owner activates it. Not reviewed, not ratified, and it authorises nothing. The owner added a note to R-006: the walk-forward driver processes one method run at a time (the owner described this as running on one CPU core, but per-run CPU-core use, including native numerical-library threads, has not yet been profiled). Profiling and possible parallel variant execution are deferred to that stage.

**The owner's directions for WF-1B (31 October 2026).**
- **The report leads with the descriptive league tables:** methods ranked by their scores against the real draws only. The significance tables, against fair random draws (R3 17.5; N1), follow separately and are titled as such. This is presentation within R3 section 17, which already has both kinds of table, and changes no ratified rule.
- **A progress line in the walk-forward driver** (runs done, the current variant and target, elapsed time and an estimate) comes with WF-1B. Meanwhile the read-only `status` command gives the same facts.
- **Workers (WORKERS-1; the owner's decision, 31 October 2026, after EX_098).** WF-1B also replaces the coordinator's fixed limit of 1 to 6 workers with 1 up to the machine's logical processor count (24 on the owner's computer), defaulting to half that count (12), and gives the walk-forward driver the same `--workers` option: variants run in parallel, each variant's targets in order, and records are written in a fixed order, so that a batch's records do not depend on the worker count and it still stops cleanly at the first problem. This brings that part of the R-006 study forward into WF-1B; the rest of the study stays deferred to the final stage. It amends Architecture v0.8's six-worker limit (O-CPU-01; O-POL-03; ERR-R2-01) only when the WF-1B design and code have been reviewed and the owner ratifies them, and the identity checks (one worker against many on the coordinator, and a small walk-forward batch at 1 and 12 workers with its records compared byte for byte) run once at the new settings. Until then the six-worker limit and the one-run-at-a-time driver stand, and nothing here authorises a run.

**Other process records.**
- **Review copies installed with this register** (LF), for the reviews not yet under `review/`:
  - `review/Independent_ChatGPT_WF1A_REL1_Code_R2_Review_EX083.md` (`262fe0da97d147a4c78375f84a70ab47516bbe986d80bc82e017a404b336b9fe`);
  - `review/Independent_ChatGPT_WF1A_Code_Focused_RECHECK_EX085.md` (`0764cadf4d6a0f5c9284aae54ba9d284977d0a9c4db611fa98142babfcf52c54`);
  - `review/Independent_ChatGPT_E1R2_Code_Focused_RECHECK_EX097.md` (`7cfc20233104aff876573f013d189be462c6e09ce87f8efd62ad4c89a61035f3`).

  The E_1 revision 2 package installed the copies of EX_087, EX_089, EX_091, EX_093 and EX_095.
- **The exchange numbering:** a final package that differs from its reviewed candidate only in its verifier's base can go in `CLAUDE_CODE_WORKING_FOLDER_TREE/packages/`, named in a task file and recorded in the next register, so that it needs no EX number.
- **The owner's nine commits in this period:** the performance proposal (`1050338`); the three Claude Code reports (`bf61c97`, `d0a1036`, `ef439c6`); the three installations (`6a1bed9`, `0d98706`, `86d12ea`); and the two batch commits (`86a1a01`, `8430a15`). Claude's own commits touched only `exchange/` and `CLAUDE_CODE_WORKING_FOLDER_TREE/`.

**Out-of-date statements (register v0.22).** This register prevails, and the files are not edited:
- **Register v0.21, "installed with this register" and "WF-1A follows in its own commit":** done, at `6a1bed9` and `0d98706`.
- **Register v0.21 and WF1-13's interim:** "E_1 revision 1 is not real-capable; families have M = 78": ended with E_1 revision 2 (`86d12ea`). Each game's batch holds 40 variants, so WF-1B's MR7 families have M = 80, as designed.
- **E2R-CODE-2's E2RC-C04 reading,** "E_1 keeps revision 1 ... real runs stay off": superseded by WF1-13 and E_1 revision 2; the adapter's docstring is corrected.
- **D2-3,** the legacy runner's release gate pinned to revision 1: the gate is kept and now names revision 2.
- **H-1 v1r6 and H-2 v1r7, "the four switches stay False":** `ENABLE_CONTRACT_REAL_DEVELOPMENT` is True since WF-1A; the other three stay False. Their other status lines are superseded by this register.
- **The CODE-3 and E_1 revision 2 design v0.1r2, sections 4.1 and 7A,** where they imply that `archive/` is outside every import path: read as above (EX_093); the protection is that nothing refers to the archive, with the static and runtime checks.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_CODE3_and_E1_Revision2_Design_v0_1r2.md` | Claude; reviewed by the ChatGPT reviewer chat (EX_087, EX_089, EX_091) | OWNER-RATIFIED 31 Oct 2026; installed at `86d12ea`; `fb3b26daba2a14c6e2b5ad82e102ed9920faba14115046a820fbd0ee63b7209a` |
| `Deferred_Performance_Engineering_Proposal_v0_1.md` | The owner (committed at `1050338`); not reviewed | Scheduled as the final stage; not ratified; `a5ed53c7d0cfb3278ef8342043ab1d39a99557f6f79684f3bd3276d61a5b22cb` |
| `RATIFICATION_REGISTER_v0_21.md` | Claude; content checked by the ChatGPT reviewer chat (EX_083, EX_085) | OWNER-RATIFIED 31 Oct 2026; installed at `6a1bed9`; superseded by this register; `65524f92b99db2f9556c300536700af43bb1e449c55a998c8c87f427e1b78405` |

## Register v0.22 installed, the seed, WF-1B and PERF-1, and the snapshot (register v0.23)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/`, `archive/`, `results/`, `.gitattributes` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.23. Every commit named here was verified by Claude from GitHub; the owner's Windows results are owner-reported.

**Register v0.22: its content checks and installation (EX_099 to EX_102; DOC-9).**
- **EX_099** (`0b067f1`): content check of v0.22 candidate 1: 0 BLOCKER, 1 CORRECTION (C01, FIX AND PROCEED: the performance-proposal sentence described the driver as using one CPU core, which had not been profiled), 0 OPTIONAL, 0 RECONSIDER.
- **EX_100** (`d483617`): candidate 2, with C01 applied exactly and the owner's WORKERS-1 bullet added. **EX_101** (`80b7e31`): focused RECHECK PASS (0 BLOCKER, 0 CORRECTION, 0 OPTIONAL, 0 RECONSIDER). The WORKERS-1 text was read as a conditional direction, not an authorisation; four review obligations were carried to the workers design (memory headroom; which canonical bytes must agree across worker counts; failure semantics; the default on odd or unknown processor counts).
- **EX_102** (`d035fff`): the final DOC-9 package, recorded with no review requested. **The owner installed it** at `2b1e7e3` (31 October 2026; register v0.22, `ca955cf23b5681a534e784b4a4852acd2e8d0ccd0484e34150a05c824c0fe56b`, and three review copies); Claude verified it from GitHub (`a6d186c`).

**The owner's goal and the road to it (decision GOAL-1, 31 October 2026).** Next-draw forecasts for the draws of the week of 9 November 2026. The road, in order: the WF-1B scorer and report; a snapshot of the handovers and related documents; Mode H on the 10 holdout draws per game; the results update; the prospective (next-draw) mode; then the owner decides whether to declare the system developed. Mode H, the results update and the prospective mode are designed together.

**SEED-1: the pulse brought forward and approved (decisions SD-1 and SD-2).**
- **SD-1 (31 October 2026, about 20:00 Adelaide, 09:30 UTC; EX_103, `92a6cef`):** under WF1-9 and D-10, the owner replaced N1's announced pulse of 2026-11-06T00:00:00.000Z with the pulse of **2026-10-31T10:30:00.000Z** (NIST Randomness Beacon 2.0, `chainIndex` 2, field `outputValue`). The announcement was committed and pushed about an hour before that pulse existed. New policy `N1_ROOT_NIST_C2_20261031T1030Z_V1`. The replaced policy `N1_ROOT_NIST_C2_20261106T0000Z_V1` was never fetched and stays on file as `REPLACED_BEFORE_PULSE`, counted under design v0.1r1 section 8.4.
- **The retrieval (EX_110 section 1):** after the pulse time the owner opened the time-lookup address in his browser and saved the JSON (3,633 bytes, SHA-256 `d06fd535c27cda6ed4afc0ba93d3309b9c72e8b04db5e7a1d05f6e4ec0aa5dfd`); Claude checked it against EX_103's acceptance row and read the same pulse independently at its chain/pulse address over HTTPS. Pulse index 2007128; `outputValue` `E9C629FA...F1C79F97` (128 hexadecimal characters, as published); `statusCode` 0.
- **SD-2 (31 October 2026, about 23:15 Adelaide, 12:45 UTC):** the owner APPROVED the policy. Its `SEED_POLICY_V1` record (`src/evaluation/seed_policies/N1_ROOT_NIST_C2_20261031T1030Z_V1.json`, `4c429266b6471c0939e2d0b2d3d4bd12f62300af7085e3e9283f0e14705a154a`) carries the pulse identity, both read addresses with who read each, the saved file's SHA-256, `signature_verification: NOT_PERFORMED` and the WF1-12 trust basis. It was installed with WF-1B. EX_111 compared the saved JSON with the record (eight pulse fields and the file digest); the HTTPS reads and the approval are owner- and Claude-reported.

**The WF-1B supplement design (EX_104 to EX_107; decisions WB-0 to WB-2).**
- **EX_104** (`b37022c`): supplement v0.1 (the report's order, the progress line, WORKERS-1 with EX_101's obligations) for R-3. **EX_105** (`63f4a57`): RECHECK, with 1 BLOCKER (WF1BS-R3-B01: parallel STOP admission and parent-process loss), 5 CORRECTION (C01: the RK-4 disclosure block against the Part A test; C02: `compare` must check the master and execution identities; C03: evidence mixed with authorisation; C04: memory claims and simultaneous admission; C05: portable limit tests and the owner's 60-worker cap) and 2 OPTIONAL (O01: the canary guarantee; O02: progress counts and estimates).
- **WB-0 (OWNER-DECIDED 31 October 2026, after EX_105): two packages.** WF-1B (the scorer and report) went ahead; the workers change (WORKERS-1), the batch progress line and the `compare` command moved to a separate package, **WF-1C**, with its own design round, carrying EX_101's and EX_105's complete findings (B01, C02 to C05, O01, O02). Until WF-1C is reviewed and ratified, the coordinator's limit of 1 to 6 workers and the one-run-at-a-time walk-forward driver stand.
- **EX_106** (`795d5c3`): v0.1r1 (C01 resolved; the worker sections withdrawn under WB-0). **EX_107** (`a2e8ce0`): focused RECHECK PASS, 0 BLOCKER, 0 CORRECTION, 1 OPTIONAL (O03: an explicit carry-forward sentence, added word for word). EX_105's B01 and C02 to C05 are not resolved as worker findings; they are WF-1C obligations.
- **The design ratified:** `Predictive_Randomness_WF1B_Supplement_Design_v0_1r1.md` (`a2f470797f31e387f44b5492ed406f1376b3eb92f2181dc76f6ac4c80168185a`), OWNER-RATIFIED 31 October 2026 (recorded in EX_108, `b0f229f`), with **WB-1** (Part A, the descriptive tables against the real draws, first) and **WB-2** (the approved seed policy travels in WF-1B). WB-3 and WB-4 (v0.1's Windows evidence and limits) were withdrawn to WF-1C. Installed with WF-1B at `24d192f`.
- **R3 finding R3-5:** R3 17.10.2's order places the glossary and the fair-draw reference before the league tables; WB-1 puts the descriptive tables (Part A) first, as R3 7.2 asks, with RK-4's disclosure block at its top. This register records the reading; R3's text is not edited.

**The WF-1B code (EX_108 to EX_113; decisions WF1B-A1 and WF1B-A2).**
- **EX_108** (`b0f229f`): `WF1B_Install_v1` (37 A, 1 M; suite 447) for R-2. **EX_109** (`0c8799d`): RECHECK, with 1 BLOCKER (WF1B-R2-B01: an approved root need not match the announced pulse) and 3 CORRECTION (C01: N1's Monte Carlo uncertainty missing from the reports; C02: an out-of-range label dropped in display; C03: N1 replay reference coverage incomplete).
- **EX_110** (`c9d35f1`): `WF1B_Install_v2` (38 A, 1 M; suite 463; mutations 22 of 22), resolving all four, with the approved seed record. **EX_111** (`402d307`): focused RECHECK PASS, 0 BLOCKER, 0 CORRECTION, 1 OPTIONAL (O01: the seed record's reader names are not cross-bound to `fetched_by` and `verified_by`).
- **WF1B-A1 (OWNER-DECIDED 1 November 2026):** v2 accepted for installation; EX_111's O01 deferred to a later package (`exchange/OWNER_REMINDERS.md` R-007).
- **The Windows rehearsals (Claude Code; task clones; the main repository unchanged each time):**
  - **TASK_T012** (report `bf47668`): STOP at step 9. Two of the task file's commands named the report wrapper's `.bat` file, which `.claude/settings.json` refuses (`Bash(*.bat*)`); steps 1 to 8 passed (PRE, the overlay, POST, module origin). A fault in the task file, not the package. Claude now checks every task command against the settings' refuse list before committing a task file.
  - **TASK_T013** (`bde56b6`; report `40958d6`): STOP at step 11. One test, `test_a_linked_master_is_refused`, made a symbolic link without a guard, which Windows without the symlink privilege refuses. The other 462 tests passed, including `test_wf1b_crossplatform`: the first Windows evidence that the scorer's pinned output is byte-identical to Linux.
- **EX_112** (`bd2a268`): `WF1B_Install_v3`: that test split into a hard-link test (runs on every platform) and a symlink test (skips where symlinks are refused), and the suite runner prints a failing module's details; no source change; suite 464; mutations 23 of 23. **EX_113** (`8744121`): focused PASS, 0 BLOCKER, 0 CORRECTION, 1 OPTIONAL (O02: the runner's failure-detail label promises invented data only, which the older tests that read the development masters cannot guarantee).
- **WF1B-A2 (OWNER-DECIDED 1 November 2026):** v3 accepted unchanged; O02 deferred (R-010; the runner template already carries the new wording, so the next package has it).
- **TASK_T014** (report `2cc6933`): PASS on all 16 steps; 464 tests with 4 symlink skips; 39 status lines (38 A, 1 M).
- **The owner installed it** at `24d192fe596dc381fe2945e3b88503e68ff60d44` (1 November 2026; parent `f09c08b`), with `COMMITTED PASS` before the push. **Claude verified it from GitHub:** 39 paths changed (38 A, 1 M); every row of `review/WF1B_Install_v3/INSTALL_MANIFEST_SHA256.txt` matches its Git blob; no data folder touched.
- **What it installed:** `src/evaluation/` (the scorer, the outcome reader, N1 and its generator, the measures and divisions, the report and its writer, the seed-policy reader, the measure and family registries, the two seed-policy records), `Run_Method_Rankings.bat`, ten WF-1B test modules, the supplement design, the git-ignore line for `results/real/development/scores/`, and the review copies of EX_099, EX_101, EX_105 and EX_107.

**PERF-1: one measured hot spot, fixed with identical results (decisions PF-1 and PF-2).**
- **The cause:** the owner's first real report (Oz Lotto, below) was still in its statistics stage after an hour. Claude profiled that stage on invented data at full size: the exact Clopper-Pearson interval of WF-1B's Monte Carlo figures (EX_109 C01), computed by bisection on exact binomial tails over R = 10,000 trials, used most of the time.
- **PF-1 (OWNER-DECIDED 1 November 2026):** PERF-1 brought forward from the deferred performance study (R-006) as one small scoped item, with a process variation: coded and tested first, reviewed once at the end, with no separate design round. The rest of R-006 stays deferred and inactive.
- **EX_114** (`b4f55a1`): `PERF1_Install_v1` (8 A, 3 M; suite 471; mutations 9 of 9). The exact binomial sum by binary splitting (the same integers); the Clopper-Pearson interval found by a decimal-guided bisection and confirmed with the exact tails (the same float64 values, with a fallback to the exact bisection); count-only progress lines for the report tool. R stays 10,000; no measure, label, report format, registry or seed record changes. Statistics stage on invented data, Oz Lotto shape, R = 10,000: about 209 s.
- **EX_115** (`a51cb32`): focused code review PASS, 0 BLOCKER, 0 CORRECTION, 0 OPTIONAL, 0 RECONSIDER; 6 of the 7 new tests and 40 cases against an independent integer oracle reproduced by the reviewer.
- **PF-2 (OWNER-DECIDED 1 November 2026):** PERF-1 accepted, to be installed after its Windows rehearsal and after the Oz Lotto report's results were committed.
- **TASK_T015** (Claude Code; task `b4f55a1`, report `9eeb843`): PASS on all 16 steps; 471 tests with 4 symlink skips; `COMMITTED PASS` in the task clone (8 A, 3 M).
- **The owner installed it** at `3fce3270b4797198504c85893e77e1d8f3aa35a1` (1 November 2026; parent `441daf2`), with `COMMITTED PASS` before the push. **Claude verified it from GitHub:** every row of `review/PERF1_Install_v1/INSTALL_MANIFEST_SHA256.txt` (10) matches its Git blob, and the three replaced source files and the new test equal the reviewed tree. The suite is now 471 tests.

**The first real report runs (owner-run, 1 November 2026; WF-1B as installed at `24d192f`).**
- **Powerball, first attempt** (`--batch wf-3347ad1160df45faaaab1e2eedcedd0f --first 1286 --last 1576`): REFUSED at step 1, `unknown or altered batch: the plan file is not a valid, unaltered WF_BATCH_PLAN_V1`. Nothing was read or written. **The cause, confirmed:** both committed Powerball batch records (`plan.json` and the segment record, `86a1a01`) had been rewritten by Git with Windows line endings on the owner's computer (`git ls-files --eol`: `i/lf w/crlf`; the plan 12,029 bytes against 12,028 in Git). The Oz Lotto batch records were unaffected. The owner restored the committed bytes on 1 November 2026 (deleted the two files, then `git -c core.autocrlf=false checkout --` of the batch folder); all four batch records then showed `w/lf`. The permanent remedy, a `.gitattributes` rule for `results/` (R-011), is in this snapshot.
- **Oz Lotto** (`--batch wf-a75988650fb04cc399f8f7409ea27243 --first 1474 --last 1693`), with WF-1B as installed at `24d192f`: COMPLETE, attempt `rr-4be324abd2e04dfd84b3e8087e308770`, search-log row 3; 80 tracks, all `GRID_COMPLETE`; 1,640 declared tests. It ran from 09:55 to about 15:00 Adelaide: the forecasts were collected and scored by 10:06, and the rest was the statistics stage that PERF-1 then made fast. Committed by the owner at `441daf2` (the report's .txt, .csv and .json and the search-log row).
- **Powerball** (same arguments), with PERF-1 installed: COMPLETE, attempt `rr-97bb48617b994a8ea18332cd36bbc98f`, search-log row 4; 11,442 grid cells, all valid; 80 tracks, all `GRID_COMPLETE`; 2,080 declared tests. About 26 minutes: collecting and checking the frozen forecasts 22 minutes, N1 3 minutes 12 seconds, the measures 13 seconds. Committed by the owner at `608025c`.
- **The family results only** (development walk-forward evidence, DEVELOPMENT_WF_EXPLORATORY; descriptive, not a scientific claim): Oz Lotto `WF1_OZLOTTO_MR7_MAIN_V1`, Bonferroni P 0.0902 and N1 maximum statistic P 0.0668 (k = 667 of R = 10,000); Powerball `WF1_POWERBALL_MR7_MAIN_V1`, Bonferroni P 1.0 and N1 maximum P 0.728, and `WF1_POWERBALL_MR7_PB_V1`, N1 maximum P 0.987. No family figure, and no single track after allowing for the number of tracks, departs from what fair draws give. Every other figure is in the committed reports, which are the record.

**The holdout exposure (decision HX-1, 1 November 2026).** `HOLDOUT_EXPOSURE_RECORD_v0_2.md` (OWNER-RATIFIED 26 October 2026, as this register's table records, although its own header still says CANDIDATE) records, in its item 1, that a reviewer chat displayed Powerball draws 1585 to 1588; 1585 and 1586 are inside FINAL_HOLDOUT_10. The owner decided: the exposure stays on record; Mode H scores all 10 holdout draws of each game, with Powerball 1585 and 1586 flagged in Mode H's records and report; until Mode H all 10 are treated as unseen, with every rule in force (no display, quotation or computation of Powerball 1577 or later, or Oz Lotto 1694 or later). The flagged draws remain fully valid: they are scored and counted in every measure (no gap, nothing excluded); the flag is information only. The record's v0.3, in this snapshot, states this.

**The post-holdout draws a chat saw (decision HX-2, 1 November 2026).** The holdout stays fixed at Powerball 1577-1586 and Oz Lotto 1694-1703: it never slides and is never extended (R3 section 6). Powerball 1587 and 1588 are ordinary post-holdout draws that the same reviewer chat once displayed. They are not part of Mode H. When the weekly session's catch-up (MH-1) scores them, those two catch-up scores carry the same exposure flag as Powerball 1585 and 1586 in Mode H. The flagged draws remain fully valid: they are scored and counted in every measure like any other draw (no gap, nothing excluded); the flag is information only. Until they are scored, the rules for draws at or after 1577 apply to them unchanged. The record's v0.3 states this too.

**The order of work (decision ORD-1, 1 November 2026).** Asked whether to bring WF-1C forward before Mode H, the owner kept the order: the snapshot; Mode H, the results update and the prospective mode; then WF-1C. WF-1C changes no prediction (its records must agree across worker counts), and the report's slow stage was the scorer, not the batches.

**The chat switch and the snapshot (decision HO-1, 1 November 2026).** After the snapshot is installed, a new Claude chat takes over as primary designer and coder, starting from new editions of the handovers, made more complete than usual: Claude's working tools committed under `exchange/`, a working-knowledge section in H-1 (lessons, traps, the evidence routine), and a cold read of H-1 by a fresh helper before the switch. The reviewer chat switches only when it nears its own limit.

**The cold-read probes (1 November 2026).** At the owner's request, two fresh helpers read only the repository's documents and code (no data folder, no web) and described (A) the results updater and (B) the performance and worker plan. Claude compared their accounts with the decisions on record (`exchange/OWNER_REMINDERS.md` R-012):
- **Recorded or corrected in this snapshot:** the stale WORKERS-1 placement (B1), the identity wording (B2) and the driver's limit (B5), below; the scorer speed-up now recorded (PERF-1); the two-site checker's default mode, which drives The Lott's website automatically (A5; settled by decision TSC-1 below; the Claude Code rulebook v0.3 and H-1 say so); the updater launcher runs `update` when given no arguments (A4; recorded as a warning, the launcher unchanged); the data tools have not been run under Python 3.15 (A9).
- **Carried to the Mode H, results update and prospective design:** the readers accept only the version-1 master, so any results update makes every run and report refuse until a version-2 reader is designed (A1); the `HOLDOUT_OPENED` record is defined only in code (A2); how the holdout and later draws are added, and the Mode H store, which R3 leaves OPEN (A3); single-source updates against R2-C03 and the proposal's independent evidence and candidate promotion (A6); the owner's procedures for accepting a new master version and for recovering from an interrupted update (A7); the update window's overlap with the master (A8); R3 7.6's independent outcome ledger (A11).
- **Carried to WF-1C or the performance study:** the roadmap's WF-1C summary against EX_105's full obligations (B4); thread settings not recorded by walk-forward runs, and the differing thread-policy wordings (B8); the performance proposal's six-worker assumptions (B7); measured run times (B10); when the final study may start relative to the prospective mode (B11).

**The cold-read test of H-1 (1 November 2026).** Before the snapshot went to the reviewer, a third fresh helper, given only the repository and the new H-1, explained the project's state and next steps back and listed 20 gaps (missing pointers, stale or contradictory text, and three points that needed the owner). Candidate 2 of this snapshot fixes them in H-1, this register, the holdout record and Claude's working lists (`exchange/OWNER_ROADMAP.md`, `exchange/OWNER_REMINDERS.md`, `exchange/README.md` v0.5). The gap list travels with EX_116 (`cold_read_h1_gaps.md`). The owner decided the two points below (HX-2 above, FB-1 below); the rest are recorded as OPEN items for the Mode H design (H-1 sections 10 and 12.8).

**Owner decisions and design inputs after the reports (1 November 2026).**
- **TSC-1 (OWNER-DECIDED):** the two-site results checker (`src/two_site_results_check_v0_7.py`) stays unchanged and is never used again; its default mode drives The Lott's website and must never be run. No code change. This settles probe finding A5.
- **MH-1 (OWNER-DECIDED design input for the Mode H, results update and prospective design):** the weekly session per game is: the results update; then a catch-up of every draw that has no forecast, in draw order (predict draw N from draws up to N-1 only, then reveal N and score it); then the scoring of any open prospective forecast; then the forecast for the next draw is frozen and published, so that exactly one forecast is always open. Two labels, kept apart in records and league tables: PROSPECTIVE (frozen before its draw) and CATCH-UP (made after its draw, in order; valid only if the method revision was installed before that draw's date, otherwise ordinary walk-forward development evidence). One wrapper command per game; the owner's updater and the scoring and forecasting code stay separate programs. The league table is cumulative; no method is retuned because of its ranking. The production report cadence (weekly, monthly or on request) is an open choice for that design.
- **OFF-1 (OWNER-DECIDED; the 31 October 2026 principle reaffirmed):** everything installed runs without GitHub. A prospective forecast's timing evidence is a local, create-only, digest-chained forecast record with timestamps; a GitHub push or an emailed digest is an optional external witness, never required. A catch-up forecast's validity is checked against local registry install records, not Git history. R3-D20's wording about timing proof by GitHub push evidence is to be reworded in that design. Only the results update needs the internet.
- **EFF-1 (OWNER-DECIDED design requirement):** the weekly path is incremental: append-only forecast and score ledgers, reading only the new runs and the new draw; the league table built from the ledgers; N1 run over the prospective and catch-up draws only. Full walk-forward rebatches use WF-1C's workers. The report's collect stage (it rereads every frozen run record: 22 minutes for Powerball) is a candidate for a cached index in the deferred performance study, with identical results required.

- **FB-1 (OWNER-DECIDED):** if the forecasts for the draws of the week of 9 November 2026 cannot be ready in time, the first forecasts slip a week rather than the work being rushed: Mode H and the design keep their full review and rehearsal, and the catch-up (MH-1) covers any draws missed meanwhile. The draws are weekly: Oz Lotto on Tuesday, Powerball on Thursday.
- **Terms for that design (recorded, not decided):** "the prospective mode" is the weekly production loop of MH-1; "declaring the system developed" (GOAL-1) means the owner declares the pipeline ready for the released cohort, while later waves continue to add methods. How R3's FINAL mode and its freeze-and-publish rules relate to the prospective mode is OPEN for that design. Because R3 sections 10.1(6), 10.2 and R3-D20 name a GitHub push as the timing proof, a ratified R3 amendment, or a ratified design that supersedes those clauses under OFF-1, must come before the first prospective forecast. Mode H itself is: every released variant forecasts each of the 10 holdout draws walk-forward (each from the draws before it), all frozen before the holdout is opened, then scored once; whether Mode H's ten steps also serve as the first catch-up steps is OPEN. Running the results update for the first time, and opening the holdout (writing `HOLDOUT_OPENED_<GAME>.json`), each need the owner's separate approval at the Mode H stage; who or what writes that record is designed in Mode H.

**Other process records.**
- **Review copies installed with this register** (LF), for the reviews not yet under `review/`:
  - `review/Independent_ChatGPT_WF1B_Code_R2_Review_EX109.md` (`d00b0aaacca89aa86baf85cb64fa20268e4a37797bb237ff6f896bcb29c3f019`);
  - `review/Independent_ChatGPT_WF1B_Code_Focused_RECHECK_EX111.md` (`bf0f76f7bbcfc02a73c791a3b90af91c1b5294108c60b7cea86e0729fd7841a3`);
  - `review/Independent_ChatGPT_WF1B_v3_Focused_Review_EX113.md` (`724b307e1f701d7c4b4e3172df5ec84f38bdffdb29429e80cb40ca9114908f9a`);
  - `review/Independent_ChatGPT_PERF1_Code_Review_EX115.md` (`2c8f270617ea12651360bf504e4b0ff1909b11b8cf060b36e50679768beee5f5`).
- **The owner's commits in this period:** register v0.22 (`2b1e7e3`); two commits of the owner's own document `GASI_thought_experiments/Proposal_Methods_FROM_GAIS_MORE_EXPERIMENTS_v0.1.md` (`b67c045` and `b022606`; now `29307c472cd4dc52908b1148245cbd413f9934b4ba0c89506489e9aaebdeb9f5`; not reviewed) and a merge of `main` (`a6c3038`, which brought in only `exchange/OWNER_ROADMAP.md`); the four Claude Code reports (`bf47668`, `40958d6`, `2cc6933`, `9eeb843`); the WF-1B installation (`24d192f`); the Oz Lotto report (`441daf2`); the PERF-1 installation (`3fce327`); and the Powerball report (`608025c`). Claude's own commits touched only `exchange/` and `CLAUDE_CODE_WORKING_FOLDER_TREE/`.

**Out-of-date statements (register v0.23).** This register prevails, and the files are not edited:
- **Register v0.22, "The owner's directions for WF-1B", WORKERS-1:** "WF-1B also replaces the coordinator's fixed limit ..." is superseded by WB-0: the workers change, the batch progress line and `compare` belong to WF-1C. WF-1B changed no driver or coordinator code.
- **Register v0.22, WORKERS-1, "its records compared byte for byte" and "a batch's records do not depend on the worker count":** what must agree across worker counts is for WF-1C's design round to define, under EX_101's second obligation; WF-1C's draft (EX_104, v0.1 section 5.4) proposes the same outcome, reason prefix and canonical content digest for each pair, not a whole-folder byte comparison. Nothing here weakens a ratified canonical identity.
- **Register v0.22 and the roadmap, "the six-worker limit ... stand(s)", read for the walk-forward driver:** the driver has no worker limit; it runs one (variant, target) pair at a time in one process. The six-worker limit is the coordinator's.
- **Register v0.22, "A progress line in the walk-forward driver ... comes with WF-1B":** moved to WF-1C (WB-0). The report tool's own progress lines come with PERF-1.
- **H-1 v1r6 and H-2 v1r7:** superseded by H-1 v1r7 and H-2 v1r8 in this snapshot, once installed.

| Document (path under `doc/`, unless from the repository root) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_WF1B_Supplement_Design_v0_1r1.md` | Claude; reviewed by the ChatGPT reviewer chat (EX_105, EX_107) | OWNER-RATIFIED 31 Oct 2026; installed at `24d192f`; `a2f470797f31e387f44b5492ed406f1376b3eb92f2181dc76f6ac4c80168185a` |
| `GASI_thought_experiments/Proposal_Methods_FROM_GAIS_MORE_EXPERIMENTS_v0.1.md` | The owner (committed at `b67c045` and `b022606`); not reviewed | The owner's ideas; not ratified; `29307c472cd4dc52908b1148245cbd413f9934b4ba0c89506489e9aaebdeb9f5` |
| `RATIFICATION_REGISTER_v0_22.md` | Claude; content checked by the ChatGPT reviewer chat (EX_099, EX_101) | OWNER-RATIFIED 31 Oct 2026; installed at `2b1e7e3`; superseded by this register; `ca955cf23b5681a534e784b4a4852acd2e8d0ccd0484e34150a05c824c0fe56b` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_9.md` | Claude; for the reviewer's check | OWNER-RATIFIED 1 November 2026; installed with DOC-10, identified at installation |
| `HANDOVER/Claude_Primary_Handover_H1_v1r7.md` and its introductory blurb | Claude; for the reviewer's check | OWNER-RATIFIED 1 November 2026; installed with DOC-10, identified at installation |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r8.md` and its introductory blurb | Claude; for the reviewer's check | OWNER-RATIFIED 1 November 2026; installed with DOC-10, identified at installation |
| `HOLDOUT_EXPOSURE_RECORD_v0_3.md` | Claude, recording HX-1 and HX-2; for the reviewer's check | OWNER-RATIFIED 1 November 2026; installed with DOC-10, identified at installation |
| `METHOD_TEMPLATE/` (draft 4) | Claude; for the reviewer's check | OWNER-RATIFIED 1 November 2026; installed with DOC-10, identified at installation |
| `README.md` (repository root) | Claude; for the reviewer's check | OWNER-RATIFIED 1 November 2026; installed with DOC-10, identified at installation |
| `CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md` (the Claude Code rulebook v0.3) | Claude; for the reviewer's check | OWNER-RATIFIED 1 November 2026; installed with DOC-10, identified at installation |
| `.gitattributes` (repository root; a rule that Git never converts files under `results/`) | Claude, for R-011; for the reviewer's check | OWNER-RATIFIED 1 November 2026; installed with DOC-10, identified at installation |

## The snapshot installed, the chat switch, the stock-take and MHUP-1 ratified (register v0.24)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/`, `results/`, `source_data/`, `.claude/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.24, and "the design" means `Predictive_Randomness_ModeH_Update_Prospective_Design_v0_1r5.md` (installed with this register). Every commit named here was verified by Claude from GitHub; the owner's Windows results are owner-reported.

**The snapshot installed (DOC-10; decision HO-1 carried out).**
- **The owner installed DOC-10** at `7bb0bfd` (1 November 2026) with `COMMITTED PASS` and `EOL PASS`; Claude verified it from GitHub (30 of 30 manifest rows; `446bf38`). It installed register v0.23, Architecture v0.9, H-1 v1r7 and H-2 v1r8 with their introductory blurbs, the holdout exposure record v0.3, the new-method template draft 4, the repository `README.md`, the Claude Code rulebook v0.3, the `.gitattributes` rule `results/** -text` (R-011) and four review copies. Its install also found `results/audit/SEARCH_LOG.csv` with mixed line endings on the owner's PC; the owner restored its committed bytes before the commit. The identities of the files it installed are in the table at the end of this section.
- **The owner's deny entry** for the ranking report tool (rulebook v0.3 rule 7) was committed to `.claude/settings.json` at `905ecee` (1 November 2026).
- **The chat switch (HO-1).** A new Claude chat took over as primary designer and coder on 1 November 2026 from H-1 v1r7 and its blurb, without the previous chat's workspace. The ChatGPT reviewer chat checked the new chat's takeover reply and gave it PASS, with three notes the new chat carried into its first design (owner-reported; the notes are listed in `exchange/STOCKTAKE_2026_11_02_v0_8.md`, Response 4). The previous Claude chat commented once more in the stock-take (Responses 3 and 3b) and was **retired by the owner on 2 November 2026** (decision ST-4 below).

**The stock-take of 2 November 2026 (decisions ST-1 to ST-5).** At the owner's request the three chats and the owner compared their understanding of how the finished system will behave. The record is `exchange/STOCKTAKE_2026_11_02_v0_8.md` (`fd4bee1`; LF `87cbe55cb50b3ad8727ac2693125e922645b665a832650b751285519b7a9ed18`): the owner's part (d), his own picture of the system after implementation (also committed by him as `owner_stocktake_v1_0.txt`, `f47ce14`; the owner's own text, not reviewed); the new chat's answers (`exchange/Stocktake_answers_from_Claude_v0_2.md`, `c13ffcd`); the reviewer chat's Response 2; the previous chat's Responses 3 and 3b; and the new chat's Response 4. **The owner ratified on 2 November 2026 (22:44 Adelaide)** the positions below, as the record's last section states; they fixed the owner's inputs to the Mode H design and authorised no run:
- **ST-1 (frozen records):** the three-way split: a frozen forecast is never changed; an accepted score is kept and any new scoring run is added beside it, never over it; a league table is a view, so adding or retiring a method gives a new dated report while every earlier report stays as published. A retired revision is archived and indexed: its code and tests go to the archive and its registry entry becomes RETIRED, while its forecasts and scores stay where they are with an index pointing at them. Three labels: PROSPECTIVE, CATCH-UP and development evidence. Response 3b is the reading of the owner's part (d).
- **ST-2 (carried into the design):** the previous chat's Response 3 section 4, with Response 4's additions: nothing is ever scored twice; a draw whose result is not yet accepted is left open, never skipped; the weekly command prints a status block per game; at most one open forecast per variant per game. **Current interpretation (EX_134 C02; the owner's wording above is kept as history):** "nothing is ever scored twice" means that no duplicate routine accepted score is produced for a forecast under the same scoring contract. A newly identified scoring run for a corrected scorer or a new measure is permitted under ST-1, preserves the earlier accepted score, and has its own identity and provenance (as the direction document says, section 5 step 3). This permits no re-scoring of any real run now.
- **ST-3 (recommendations):** Response 3 section 5 as amended by Response 4 section 3: Q1 preference A with the honest wording, B kept as the alternative for the reviewer's R-3 review, C withdrawn; Q5 by a local install record (a one-off record for the cohort released on 31 October 2026, confirmed by the owner); the first design (EX_123) revised and cold-read before it went to the reviewer; the cross-batch report after WF-1C.
- **ST-4:** the previous Claude chat retired on 2 November 2026.
- **ST-5 (planning target):** Mode H and the weekly session installed by about 13 to 15 November 2026, so the first forecasts frozen before a draw are Oz Lotto 1709 (Tuesday 17 November) and Powerball 1592 (Thursday 19 November); the week of 9 November a stretch only. FB-1 applies: the schedule slips rather than any review or rehearsal being cut.
- **Correction (3 November 2026; the record's correction note):** the reason the stock-take gave for withdrawing option C, "no released method uses its target's draw number", is wrong as stated. The target is not a scientific input of any released method, but it enters every method's tie-break key (`src/methods/_common/contract_records.py` lines 405-409), every non-legacy view digest (`game_draws_reader.py` line 125) and E_1's own tie key (`E_001/multigame_e1.py` lines 23 and 50). The corrected reason: under C the ten forecasts from one training prefix would have identical scores and could differ only in the order of tied numbers, so C would test one scoring ten times. The withdrawal stands.

**The direction for the operational procedures (decision DIR-1).** The new chat wrote a plain-English direction document from the stock-take (`exchange/Direction_for_operational_procedures_v0_1.md`, `d58b09b`; the owner also kept copies under `doc/`, commits `d589933` to `ab6c3ee`). The reviewer chat's content check returned RECHECK with seven findings (`exchange/Direction_v0_1_review_ChatGPT_2026_11_02_RECHECK.md`), applied in v0.2 (`63557b2`); its focused recheck returned PASS with two wording improvements (`exchange/Direction_v0_2_review_ChatGPT_2026_11_02_PASS.md`), applied in **v0.2r1** (`3a9f6ac`). The owner removed the v0.2 copy from `doc/` at `6de0d99`, keeping the v0.2-to-v0.2r1 diff there. **DIR-1 (owner, 2 November 2026):** the document is the owner-ratified operational direction, to be referred to and checked against; it is not a specification, and the design and this register prevail wherever it is looser (it says so itself). A permanent copy of v0.2r1 is installed in `doc/` with this register (LF; its "Status and authority" paragraph is the status line reminder R-013 asked for), closing R-013.

**Process decisions recorded (2 and 3 November 2026).**
- **MC-1 (model choice; owner, 2 November 2026, refined 3 November 2026):** before designing a new subsystem or a major change to one, a statistical design or validity question, the root cause of an unexplained failure or STOP, or a cold-read review of a design before it goes to the reviewer, Claude says "Suggest switching to Fable (High) for this" and waits for the owner's "go"; everything else goes ahead without asking. Claude cannot see which model is selected, so it flags and holds; a mixed request is split at the boundary; when a Fable task finishes Claude says so. Refinement: Fable is saved for the hard core (new HIGH design, the core of a HIGH code module, a BLOCKER-level finding, an unexplained STOP), because of the owner's token allowance; at each step Claude recommends a model with a one-line reason; helper agents may run on a cheaper model whatever the chat's model. This is a working arrangement between the owner and Claude; it changes no review or safety rule.
- **KISS-1 (owner, confirmed 2 November 2026):** a comprehensive simplicity (KISS) review of the whole project's machinery after full implementation and the method waves, started only when the owner asks (`exchange/OWNER_REMINDERS.md` R-014). Not part of MHUP-1.
- **HO-2, the staged AI handover (owner, 3 November 2026, after discussing the risks with the ChatGPT reviewer chat):** to avoid both AI participants losing context at once, Claude is handed over first and the experienced ChatGPT reviewer chat stays in role throughout. The steps: (1) Claude completes its handover package (H-1 v1r8, comprehensive and functional, with the authoritative documents, reading list, project status, current decisions, outstanding work and deferred obligations: DOC-11); (1.1) before the replacement Claude chat starts, the owner gives the complete package to the current reviewer, which examines it for completeness, accuracy, consistency with this register and the design, missing obligations and risks of misunderstanding, and every problem found is resolved first; (2) the replacement Claude chat reads and verifies the prescribed documents and the repository state before any development work, and its first substantive reply explains in its own words what is implemented, designed, ratified and unresolved, the current position and priorities, the next tasks with their dependencies and outstanding approvals, the safety, scientific and operational restrictions, exactly what it believes it is authorised to do next and what it must not do without further approval, and any discrepancies or questions; it implements, installs and executes nothing merely because the handover names it as the next task; (3) the owner passes its replies to the reviewer, which assesses them and recommends targeted questions; the new chat answers before seeing the reviewer's suggested answers; material discrepancies are resolved before the takeover counts as successful; (4) normal work resumes only after satisfactory verification and the owner's authorisation; (5) a ChatGPT reviewer handover is considered only later, after the new Claude chat has shown reliable continuity. No simultaneous ChatGPT takeover is prepared; H-2 v1r8 stays in force, and this register prevails over its out-of-date checkpoint facts. The separation between ratified decisions, reviewed designs, implemented functionality and the owner's explicit authorisation to execute is preserved.
- **LW-1, the one results source named (owner, 4 November 2026, wording agreed with the ChatGPT reviewer chat):** "Lotterywest-GOV means exclusively the official Western Australian Government Lotterywest website, using HTTPS and the exact hostname `www.lotterywest.wa.gov.au`. No other Lotterywest-branded website, hostname or third-party source is authorised for retrieving production draw results." Where this register, the ratified design, the direction document or any earlier document names "Lotterywest" as the source of results, it means Lotterywest-GOV. `oz.lotterywest.com` is a different Lotterywest-branded site; it is never contacted, as before. LW-1 names the source the owner already chose (MHUP-C03); it changes no rule.
- **Backups:** on 2 November 2026 Claude asked the owner to copy `results/` and `source_data/` to a second drive before any update work; the design's checklist (section 7) makes a weekly backup and a monthly restore test routine.

**MHUP-1: Mode H, the results update and the prospective mode - the design reviews (EX_123 to EX_132).**
- **EX_123** (`c01717d`): design v0.1, committed but never sent (superseded under ST-3). **EX_124** (`c223b50`; zip `d65eced995c8e5c958822f14ddc4426db9639e7705e63e2b64a5ab16e49d90b8`): v0.1r1, after two cold reads by a fresh helper, for the reviewer's R-3 HIGH design review. The cold read found that E_1 revision 2 refuses every new run mode in its own code (`multigame_e1.py` lines 30-34), so E_1 needs a revision 3 with the same arithmetic.
- **EX_125** (`da8fcf1`): RECHECK, 5 BLOCKER (B01 real-mode requests could bypass authorisation; B02 the catch-up order was not MH-1's; B03 witness status unstable; B04 the study freeze incomplete; B05 a forecast set straddling the deadline had no tier), 9 CORRECTION, 3 OPTIONAL. It provisionally favoured option A, provided B01, B04 and C05 were met.
- **EX_126** (`aaaf1d1`; `ac0dcb71e20cc4c4c99c0c456916ff4071d4c097a27f5909ccbe612f0b4f5c3e`): v0.1r2. **EX_127** (`cf9e94b`): RECHECK, 5 BLOCKER (B01 the weekly lifecycle across weeks and interruptions; B02 an evolving cohort deadlocking at old freeze lines; B03 a later bound Mode H run and a sealing crash gap; B04 the updater not stopped by the freeze and the environment not byte-frozen; B05 the install barrier and a process listing), 5 CORRECTION, 2 OPTIONAL.
- **EX_128** (`7cf5606`; `dc1b62de0a77e9fe6f08ce22a0162daeaa9f36eec0999452a70ca67b7aec9cc4`): v0.1r3, after a fourth cold read (24 findings) and its recheck. **EX_129** (`7f5f5c4`): RECHECK, narrowly, 2 BLOCKER (B01 the first results update could add no or only some holdout draws and lock the study; B02 the install barrier did not stop the updater, and a short window before the new gate was only procedural), 2 CORRECTION (C01 an unfinished forecast set across a roster change; C02 the byte-code folder and a stale cross-reference).
- **EX_130** (`be02b31`; `92561a2c3f04fa7d2f505199423bd1aa0e7180c386091ac775a138a78d40b471`): v0.1r4, after a fifth cold read (18 findings) and its recheck. **EX_131** (`79f6ea6`): **R-3 HIGH CONDITIONAL PASS - FIX AND PROCEED**: one installation-recovery safeguard (no restore while a process may be running) and the footer's version, with no remaining design-stage objection once inserted.
- **EX_132** (`79f6ea6`; `cec02f6b60ade13ae4fcec4610083fe233f817eceba776bf8e5fabb07972a9de`): **v0.1r5**, the safeguard inserted as the reviewer worded it (Appendix J, "the restore rule"; L-I7; Appendix B.4), for the record; no reply needed.
- Every cold read was by a fresh helper with no knowledge of the chat, reading only the repository and the design; their reports travel in the EX zips. Each EX zip carries the design, the diff from the previous edition, the draft the helper read and the diff from draft to final.

**The owner's decisions during the MHUP-1 reviews (3 November 2026).** Each was given after the review that raised it and is recorded in the design (section 9 and Appendices B.1 to B.4):
- **MHUP-Q10:** the ER-2r1 one-package exception (register v0.23 line 1200) is extended to E_1 revision 3, inside MHUP-A, with the whole-package safety argument of the design's Appendix J.
- **MHUP-Q1:** option A: Mode H is **a precommitted holdout evaluation with N-1 isolation, not pre-draw forecasting**: the study plan, code and environment are frozen before the holdout is opened; the holdout is added once; one Mode H batch forecasts all ten targets per game, each from the draws before it; every planned run is DONE before any approved scoring reads a holdout result; then the ten are scored once. Option B stays described as the alternative; C is withdrawn (corrected reason above).
- **MHUP-B02:** MH-1's per-target order is implemented exactly (forecast N, reveal N, score N, then N+1), by a small sequencer that alternates a forecasting program and a scoring program inside the one weekly command.
- **MHUP-C03:** Lotterywest-GOV's published results (LW-1 below) are official and trusted as they stand; no second-source check of a new draw is required in production. The single-source decision waives none of the updater's other checks: overlap with every draw already held, consecutive numbering, dates, the closed grammar, the ledger chain and provenance. The updater v0.2 checks that the browser's final URL after page load uses HTTPS and has hostname exactly `www.lotterywest.wa.gov.au`; the path and query may identify the selected Lotterywest-GOV results-search page. No other origin, redirect destination, mirror, API or fallback is accepted. The browser can already have followed a redirect before this check, so the check is a refusal before parsing or writing, not proof that an untrusted host was never contacted (design section 7, A6; wording made exact after EX_134 C01, the rule unchanged).
- **MHUP-B04:** (a) the results updater gains a small reviewed change in MHUP-A, refusing to run while a game's holdout is open and its Mode H not yet sealed (after the one permitted first update), and while a weekly session lock exists; (b) the Mode H environment freeze covers the installed files themselves (the interpreter's files and the SHA-256 that pip's `RECORD` holds for every installed file, with an orphan-file check), not only package names and versions.
- **MHUP-Q11:** official real-mode runs come only through tickets written beforehand by the walk-forward driver or the weekly forecasting program; hand-typed runs stay available to the owner as an unofficial diagnostic route (their own root, never scored into any ledger).
- **MHUP-D1:** a fourth small updater addition: the first update after opening writes only if it is an `UPDATE` that brings in every holdout draw; otherwise it stops with the master and ledger unchanged, and the same approved update may be retried.
- **MHUP-D2:** an install holds the updater's own lock file for the whole install (taken before any file changes, released last), so the old and the new updater both refuse; no updater code change for this.
- **MHUP-D3 (extended the same day after a cold read):** the owner does not launch the coordinator's POC path, the WF-1B report tool or the WF-1A walk-forward driver during an install, and accepts the stated residual risks: one of those programs started and finished between two install checks, and a contract run straddling the few-second copy of the new gate files. Neither can change the master, the ledger or any Mode H or weekly record.

**MHUP-1 ratified (decision MHUP-R, 3 November 2026, about 20:42 Adelaide).** The owner ratified **design v0.1r5 as a whole** (`Predictive_Randomness_ModeH_Update_Prospective_Design_v0_1r5.md`, `e5fb491ca601fa71793d143871d99c40929d20cdd8398fe92e0c6858c44a5455`; reviewed through EX_131; installed in `doc/` with this register), on Claude's recommendation after EX_131. With it he accepted the design's recommendations for Q2 (the combined master), Q3 (the run modes and labels, including the new run mode and tier `CATCH_UP`), Q4 (the deadline: 00:00 local on the draw date, with a one-hour margin, recorded in UTC with the local offset), Q5's format and rule (install records for code arrival; release records, written after COMMITTED PASS, give the release date), Q6 (a logged weekly table; the full report on request or monthly), Q8 (the weekly session is R3's FINAL_NEXT_DRAW protocol as amended, and the owner's GOAL-1 declaration is a checked create-only record) and Q9 (two packages, MHUP-A then MHUP-B), and every other RECOMMENDED item in the design's section 9. **Q7 stays OPEN** (below). **The design authorises nothing:** no code is installed, no updater runs, nothing is opened, run or scored because of it; MHUP-A and MHUP-B each need their own code review (R-2), Windows rehearsal and the owner's acceptance, and each protected operation its own approval (the design's section 4.4: Approval 1 freezes the study manifest and writes the opening record; Approval 2 the first results update; Approval 3 the Mode H batch; Approval 4 the Mode H score and report; then the owner's GOAL-1 decision and the first weekly session). The binding rule stands: **no results updater runs in any form before the version-2 reader (MHUP-A) is installed and the first update is separately approved.**

**Rules amended or superseded by the ratification** (the design's Appendix K has the full list; the documents named are **not edited**, their next editions fold the changes in, and this register prevails meanwhile):
- **Register v0.23 "Terms for that design":** "all frozen before the holdout is opened" is replaced by the primary statement: "a locked holdout study: the study plan, the code and the environment were frozen before the holdout was opened; every forecast used only draws before its target; all planned attempts, and every successfully published forecast, were frozen before any scoring process read a holdout outcome" (design section 1). Its OPEN items are settled: Mode H's targets are not the first catch-up steps (the weekly scope starts at `holdout_last + 1`); the weekly session is R3's FINAL_NEXT_DRAW protocol as amended (Q8); the opening record is written by `Method_Mode_H.py open` (design 4.2).
- **R3 (v0.5):** for this project, under OFF-1, sections 1.3 (push before the target event), 1.5's "externally verifiable pre-draw proof" (made optional), 10.1(6), 10.2's push steps and its paragraph after the diagram, 11.5 item 4's remote evidence, 17.3.9's `PROSPECTIVE` wording and R3-D20's push requirement are superseded by the design's local forecast ledger and the separately derived publication status (design 6.5); R3 6's "development caps remain" and E2R-R52's run-time ceiling are amended (the caps define the development prefix; run-time targets are gated by master version, the opening record and the mode gates); R3 10.5's statuses and E2R-R40C apply as written.
- **R2-C03 and the proposal's candidate-then-promotion step:** superseded for production by MHUP-C03.
- **E2R-1 (v0.3r3):** E2R-R41's reserved rows for `REAL_HOLDOUT` and `FINAL_NEXT_DRAW` are unreserved as written; E2R-R44 ("Mode H and FINAL stay shut") is amended: they open only for ticketed, bound requests under the owner's records; section 9.1's closed vocabularies and R3 17.3.9 gain the run mode and tier `CATCH_UP` and the operational category `LATE_PRE_DRAW`.
- **H-1 section 5.4:** the switch list (no new switch: the owner's records, the tickets and the gates govern the new modes) and Option F's "no second production launcher" (`Run_Evaluation.bat` and `Run_Weekly_Session.bat` join `Run_Method_Rankings.bat` as evaluator and session launchers; method code still runs only through `Run_Experiment.bat`). H-1 v1r8 states both.
- **Architecture v0.9 section 5C.1 (protected; amended by ratification, not edited):** the weekly orchestrator is named as a sequencer of the two launchers and the process tool that is not a coordinator (no supervision, no termination, no PID use, no orphan writes), and `src/package_tools/process_check.py` as a read-only process tool that acts on no process. The orphan marker and its manual clearance are unchanged.
- **The updater:** "no change to the updater" (the stock-take position) is amended by MHUP-B04 and MHUP-D1: `results_master_v0_1.py` becomes `results_master_v0_2.py` with exactly the four additions and the permitted differences of design section 7.
- **ER-2r1:** extended to E_1 revision 3 (MHUP-Q10); the install procedure gains the release record and a second commit (design 4.3, Appendix J).
- **OFF-1's "local registry install records":** read as the design's release records (design 4.3).

**Q7 (OPEN, for the owner):** whether, after a game's holdout is opened and its Mode H scored, the restriction on displaying or computing with Powerball draws from 1577 and Oz Lotto draws from 1694 is relaxed. Recommended (and the reviewer leans the same way): keep the restriction on raw draw values in the AI chats. Until the owner decides, every rule stays exactly as it is.

**Future actions recorded (when each falls due).** These are not authorisations; each still needs its own review and approval where the rules require one.
1. **MHUP-A code** (HIGH; design sections 2 to 5 and 7): R-2 code review with the synthetic demonstrations EX_131 section 4 requires (the first-update admission, the old and new updater lock, failure-state restoration, the unfinished-set refusal, byte-code discipline direct and nested, the two-commit release order, and the stated Windows rehearsals and owner choices); Claude Code rehearsal T016; the owner's install with Appendix J's procedure. **Inside it:** the Claude Code rulebook's rule 7 and the owner's `.claude/settings.json` deny patterns gain `Run_Evaluation.bat`, `Method_Mode_H.py`, `process_check.py` and `results_master_v0_2.py` (Claude drafts the rulebook change; the settings file is the owner's edit); the same rulebook change names Lotterywest-GOV in rule 1 (LW-1); reminders R-007 (the seed record's reader names), R-008 (the verifier's wording for a missing file) and R-010 (the runner's failure label) are folded in.
2. **At MHUP-A's approval, two owner choices:** (a) because `Run_Experiment.bat` gains interpreter options, either authorise one rerun of the Windows POC suite after the install (with the owner-run byte-code checks of design 4.1) or accept it unrun with the reason recorded; (b) confirm the backup of `results/` and `source_data/`.
3. **MHUP-B code** (HIGH; design section 6 and the checklist of section 7): the same route, rehearsal T017 (including the first production contract run launched from a Python parent); rule 7 and the deny patterns gain `Run_Weekly_Session.bat`, `Method_Weekly_Forecast.py`, `Method_Weekly_Score.py` and `Weekly_Session_Orchestrator.py`. MHUP-B is installed before Approval 1, or else only after the Mode H score is sealed (design 4.4).
4. **Before Approval 2 (the first results update):** the owner's decision on Q7, and the updater's offline `--self-test` run under Python 3.15 (probe finding A9).
5. **Approvals 1 to 4 per game, then GOAL-1 and the first weekly session** (design 4.4 and 6), each separately.
6. **Next editions of the amended documents** (each when it is next edited for its own reasons; until then this register prevails): R3 v0.6; E2R-1; Architecture v0.10 (recommended with MHUP-B's documents, since MHUP-B adds the launch interfaces); the proposal's candidate-promotion text; the design's and the direction document's next editions, which use the name Lotterywest-GOV (LW-1); and, once Q7 is decided, the holdout exposure record, the Claude Code rulebook rules 4 and 5, H-1 section 5.1 and H-2 section 5.
7. **Register v0.25** records MHUP-A's and MHUP-B's reviews, rehearsals and installs, the approvals and their results.
8. **The staged Claude handover (HO-2), before any of items 1 to 7:** the reviewer's Step 1.1 review of the complete Claude handover package (DOC-11; EX_133 to EX_136), every problem resolved, the owner's ratification and install of DOC-11, the replacement Claude chat's verified takeover, and the owner's authorisation to resume. **A ChatGPT reviewer handover** is considered only after that, separately; a new H-2 edition (folding in register v0.24's facts) comes with it.
9. **After MHUP-1:** WF-1C (ORD-1); then the roadmap's efficiency items after WF-1C (the cross-batch report, the retired index, and a later method's back-history batch over post-holdout draws: design section 9, "not in scope"); the method waves; KISS-1 when the owner asks; the deferred performance study when the owner activates it.

**Other process records.**
- **Review copies installed with this register** (LF), for the reviews not yet under `review/`:
  - `review/Independent_ChatGPT_MHUP1_Design_R3_Review_EX125.md` (`546397c546a8a3dc8e0ba6d60c58c51619b7ada48741d145d8e46ce54e66c081`);
  - `review/Independent_ChatGPT_MHUP1_Design_Focused_RECHECK_EX127.md` (`4620321d51b29be913f0bc6db466432416200dab1a3753c3720bf423888ccfe2`);
  - `review/Independent_ChatGPT_MHUP1_Design_Narrow_RECHECK_EX129.md` (`cb8c8239a6cf0df3bc497a783621ad0c3888ea6b14426729de3b41e88cd7756b`);
  - `review/Independent_ChatGPT_MHUP1_Design_Conditional_PASS_EX131.md` (`01840b8dcafc7fad4382028dd87509f3b2414990583b51b8f7806eb4488b9efa`);
  - `review/Independent_ChatGPT_Direction_v0_1_Content_Check_RECHECK.md` (`45091f629cf6936e2222717466a0c45eaff420269ce15d5df8552dc7653c1580`);
  - `review/Independent_ChatGPT_Direction_v0_2_Focused_PASS.md` (`a8c61caedb3a7704f243bc96c52e6102f743b15bd244f5c8eb853633ee3c70fd`).
- **HO-2 Step 1.1, the reviewer's review of the Claude handover package:** EX_133 (`6904c3d`; `49fbee1159168f169eefa90d51081acb0ba1f044ed1c06da508f6282758a0824`) sent the CANDIDATE package. EX_134 returned **RECHECK** with three corrections: C01, H-1 described the updater's final-URL check as an exact match of the whole URL (the design checks the scheme and the exact host); C02, ST-2's "nothing is ever scored twice" obscured ST-1's separately identified new scoring run; C03, HX-2's "catch-up scores" for Powerball 1587 and 1588 could be read as the `CATCH_UP` tier; and one editorial item, O01 (H-1 section 1.6's reason for DOC-11's verifier). All four were applied, with the owner's naming decision LW-1, in the package sent as EX_135; EX_136 is the reviewer's recheck. The ratified design, the direction document and the owner's historical wording were not changed.
- **The owner's commits in this period:** DOC-10 (`7bb0bfd`); the settings deny line (`905ecee`); the stock-take documents and the direction document (`f47ce14`, `cb65b4f`, `d589933`, `2b780af`, `8db0eef`, `ab6c3ee`, `6de0d99`). Claude's own commits touched only `exchange/` and `CLAUDE_CODE_WORKING_FOLDER_TREE/`. No code was installed and no real-data run, update or report happened in this period.

**Out-of-date statements (register v0.24).** This register prevails, and the files are not edited:
- **Register v0.23, "Terms for that design":** see the amendments above (the primary statement; the OPEN items settled).
- **Register v0.23, OFF-1, "local registry install records":** the design's release records (4.3).
- **Register v0.23, MH-1, "then the scoring of any open prospective forecast":** an open forecast whose result has arrived is the lowest unclosed draw, so it is scored in draw order (design 6.3; MHUP-B02).
- **Register v0.23, "Other process records", and H-1 v1r7:** "the owner will not run `results_master update` ... until he separately approves the first update run at the Mode H stage" stands, and is now also bound to MHUP-A: no updater run before the version-2 reader is installed.
- **Register v0.23, HX-2 ("those two catch-up scores"), and H-1 v1r7 section 5.1 (current interpretation, EX_134 C03; the historical record is not rewritten):** the weekly chronological pass evaluates Powerball 1587 and 1588 with their exposure flags, regardless of evidence classification. For variants released on 31 October 2026, those evaluations are development evidence, **not** the `CATCH_UP` tier; later revisions are classified by their own release records. The flag is independent of classification, and the draws remain fully scored and counted.
- **Earlier documents naming "Lotterywest" as the results source:** read as Lotterywest-GOV (LW-1).
- **The stock-take record and the roadmap (before 3 November 2026):** "no released method uses its target's draw number" (corrected above).
- **H-1 v1r7 (sections 3, 5.1, 10 and 12.8):** its OPEN items for Mode H, the results update and the prospective mode are decided by the design; superseded by H-1 v1r8 once installed.
- **H-2 v1r8 (sections 0 and 6):** its checkpoint facts stop at the snapshot and its OPEN items for Mode H are decided by the design. Under HO-2 it stays in force unedited until the owner decides on a reviewer handover; this register prevails meanwhile.
- **R3, R2-C03, the proposal, E2R-1, H-1 v1r7 section 5.4 and Architecture v0.9 section 5C.1:** amended as listed above.
- **The direction document v0.2r1 (installed with this register), where it differs from the design** (the design prevails): its section 4 states Mode H without the ratified primary statement's "environment" and "all planned attempts" (read the primary statement above); its section 5 step 4 says a newly released revision has no open forecast "until its walk-forward is done" (the design: it joins the session roster at its next session and is first forecast at the first target frozen after its release; back-history is a separate, optional batch; design 6.3); its section 7 says a method's CATCH-UP record "starts at its install" (the design: at its release record's date; 4.3); its section 11 lists questions as open that MHUP-R has decided (only Q7 stays open).
- **The design v0.1r5 itself** (byte-identical to EX_132's member): its header, section 1 and section 8 table still read as before ratification ("for the owner's ratification"; the planned ratification date), and its section 8 names only `Run_Evaluation.bat` and `Method_Mode_H.py` for MHUP-A's rulebook and deny additions; this register's ratification and its future action 1 (four tools) prevail.

| Document (path under `doc/`, unless from the repository root) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `RATIFICATION_REGISTER_v0_23.md` | Claude; content checked by the ChatGPT reviewer chat (EX_117, EX_119, EX_121) | OWNER-RATIFIED 1 Nov 2026; installed at `7bb0bfd`; superseded by this register; `7502b75556c56f4c9b91e9022829ee18f05d02591260e87bfe053ec1c79bb6c2` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_9.md` | Claude; checked by the reviewer (DOC-10) | OWNER-RATIFIED 1 Nov 2026; installed at `7bb0bfd`; section 5C.1 amended by MHUP-R (above); `e0a03f41ddd561cf42b4d69367ab365d414c288f7943283fb47439f9c59df376` |
| `HANDOVER/Claude_Primary_Handover_H1_v1r7.md` and its blurb | Claude; checked by the reviewer (DOC-10) | OWNER-RATIFIED 1 Nov 2026; installed at `7bb0bfd`; superseded by H-1 v1r8 once installed; `b51f63792dde7f7d6c0c9e01ea6cecc5b5a12038ba748b91647738273ebc29fb`; blurb `bc46c07a1705aa49738ba6b8d8797f46df40cbc7996e4ba22a25eaefdab73240` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r8.md` and its blurb | Claude; checked by the reviewer (DOC-10) | OWNER-RATIFIED 1 Nov 2026; installed at `7bb0bfd`; stays in force under HO-2 (checkpoint facts out of date; this register prevails); `4e2737c28a69ab73577fa6c39c87c04518e42ed1be47f240295e80802774b956`; blurb `17633e4ec5413d12ed3c2909819b9f899a156af22631a31ee3e1b6f145ea0d2a` |
| `HOLDOUT_EXPOSURE_RECORD_v0_3.md` | Claude, recording HX-1 and HX-2 (DOC-10) | OWNER-RATIFIED 1 Nov 2026; installed at `7bb0bfd`; `39c54295777c1a40b84c680d6fc8dacb7404f7e70ef79b3d8d98d94bce6414b3` |
| `README.md` (repository root) | Claude (DOC-10) | OWNER-RATIFIED 1 Nov 2026; installed at `7bb0bfd`; `329f571c93f631ef3f5cce752d933c5bcc576a24e99e3f3162d9a81aac429dff` |
| `CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md` (the Claude Code rulebook v0.3) | Claude (DOC-10) | OWNER-RATIFIED 1 Nov 2026; installed at `7bb0bfd`; `509e381ed612e7572940014d33f2724172a12a0da8a8a1e76020571ede63b56b` |
| `.gitattributes` (repository root) | Claude, for R-011 (DOC-10) | OWNER-RATIFIED 1 Nov 2026; installed at `7bb0bfd`; `e73570de0a035b1dc00f6687c3b445a4d19f0db5340c79e2d3bf434499f6caee` |
| `METHOD_TEMPLATE/` (draft 4) | Claude (DOC-10) | OWNER-RATIFIED 1 Nov 2026; installed at `7bb0bfd`; identified by the DOC-10 manifest, `review/DOC10_Snapshot_v1/INSTALL_MANIFEST_SHA256.txt` |
| `owner_stocktake_v1_0.txt` | The owner (committed at `f47ce14`); not reviewed | The owner's own picture of the finished system, part (d) of the stock-take; not ratified as a document; `62b173a5f51ecccf3c5c451be5446ed515a576a3bde81efda7d506464c2e11f9` |
| `Direction_for_operational_procedures_v0_2_to_v0_2r1.diff` | Claude (committed by the owner at `6de0d99`) | The change list from v0.2 to v0.2r1; a record; `efab43429f690cacc7cd3d89d89f6e540663d6ee18a053a0e68be4361d640695` |
| `Direction_for_operational_procedures_v0_2r1.md` | Claude; content checked by the ChatGPT reviewer chat (RECHECK, then PASS) | Owner-ratified operational direction, 2 Nov 2026 (DIR-1); installed with this register; `0aa5967febb817707953b4634937a9a76e2a56e364360cfd1004d10d85c56855` |
| `Predictive_Randomness_ModeH_Update_Prospective_Design_v0_1r5.md` | Claude; reviewed by the ChatGPT reviewer chat (EX_125, EX_127, EX_129, EX_131) | OWNER-RATIFIED 3 Nov 2026 (MHUP-R); installed with this register; `e5fb491ca601fa71793d143871d99c40929d20cdd8398fe92e0c6858c44a5455` |
| `HANDOVER/Claude_Primary_Handover_H1_v1r8.md` and its introductory blurb | Claude; for the reviewer's check | OWNER-RATIFIED with this register; installed with DOC-11; `09e579ba008da0fd55e14ebd9e05d4f9b6c6bef54445fec85ca7bb120632a801`; blurb `f1833da327210c899b5e0bf2e65888c8b8234654bf2272a021f017ac3bca2d19` |
| `exchange/STOCKTAKE_2026_11_02_v0_8.md` | Claude (the record keeper), with the owner's and the chats' texts | A record, not a rule; the owner's ratification of 2 Nov 2026 is its last section but one; LF `87cbe55cb50b3ad8727ac2693125e922645b665a832650b751285519b7a9ed18` |

## DOC-11 installed, HO-2 completed, MHUP-A reviewed in two slices, amendment A1, and the reviewer chat's end (register v0.25)

Paths in this section are from the repository root, except those beginning `HANDOVER/` or naming a design, register or
direction document, which are under `doc/`. In this section, "this register" means register v0.25, "the design" means
`Predictive_Randomness_ModeH_Update_Prospective_Design_v0_1r5.md` as amended by A1, and "MHUP-A" means the first MHUP-1 code
package.

**Who verified what.** Every commit named here was checked by Claude from GitHub. The owner's Windows results are
owner-reported. **This edition has not been reviewed:** the reviewer chat that reviewed every round below ended before this
edition was written. Its findings are quoted from its own committed messages.

**DOC-11 installed; the staged Claude handover (HO-2) completed (4 November 2026).**
- **The install:** the owner installed DOC-11 at `3d4fa3c`, comprising register v0.24, H-1 v1r8 and its blurb, the ratified
  design v0.1r5 and the direction document v0.2r1. Claude verified it from GitHub (EX_138, `20a3f40`).
- **The takeover:**
  - the replacement Claude chat read and verified the package and gave its first reply;
  - the reviewer chat asked questions Q1 to Q9, which the new chat answered without seeing the reviewer's assessment;
  - all nine were assessed PASS;
  - Q9 led to the direction document v0.3 and then **v0.3r1**: reviewer RECHECK, then focused recheck PASS.
  The records are EX_139 and EX_140 (`2061055`), with
  `exchange/EX_140_Claude/HO2_Owner_decisions_and_completion_2026_11_04.md`.
- **Direction v0.3r1 ratified and installed** by the owner (4 November 2026, about 16:35 Adelaide; document-only route) at
  `dfc2d13`, comprising:
  - `Direction_for_operational_procedures_v0_3r1.md` `9c781716b8313e052ec29203e79cf4745e3c172bc587e96a1fe1f4be2c84b985`;
  - `Direction_for_operational_procedures_v0_2r1_to_v0_3r1.diff` `ddf28688a981fd701f8b6c1c88e9be73f7d90d5eefca1206b000c086d58b4596`;
  - `review/Independent_ChatGPT_HO2_Q9_and_Direction_v0_3_RECHECK.md` `506b22a9127d7ec0a79322e2f5bc431494a0b35ae24457017c1ccb87a96985ca`.
  Claude verified all three blobs. v0.2r1 is kept as history.
- **Q9-E1 to Q9-E4** (owner, 4 November 2026, about 16:36, "yes to all recommendations stated here"; the full text is in the
  EX_140 member named above):
  - **E1:** complete historical coverage is a deferred objective. Every method eventually gets retrospective forecasts for every
    applicable past draw, including the ten original holdout draws. A later method's holdout forecasts come only through a
    separately designed, reviewed and owner-approved process. They are development evidence only, never part of the sealed Mode
    H study and never pre-draw.
  - **E2:** one consolidated owner-facing report, keeping development, Mode H, CATCH-UP and PROSPECTIVE separate, with sample
    sizes shown, comparisons on common draws and no misleading single score. It is designed with the cross-batch report after
    WF-1C.
  - **E3:** deterministic recalculation for a new report is not by itself a second accepted score. The actual WF-1B behaviour
    is to be verified in the cross-batch report's design, and accepted records are never altered.
  - **E4:** after GOAL-1 and the required installs and approvals, the owner's deliberate run of the reviewed
    `Run_Weekly_Session.bat` is that week's authorisation. This excludes unattended scheduling, unusual recovery, bypassing a
    STOP, and anything outside the approved scope. The results updater stays a separate operation.
- **HO2-A** (owner, 4 November 2026, about 16:37):
  - HO-2 is declared successfully completed;
  - the replacement Claude chat is accepted as primary designer and coder;
  - option (a), resumption of normal work, within the limits the decision lists;
  - the experienced reviewer chat stays in role.
  The owner's further decisions of that day on retries after a STOP and on interrupted sessions are carried as reminder R-018
  (a) and (d). They go into MHUP-B's checklist and the next full H-1 edition.

**MHUP-A: two review slices, then one integrated package (owner, 4 November 2026).** The owner chose to have MHUP-A's code
reviewed in two slices (R-2 HIGH each), followed by **one integrated install package** with its own full review. A slice PASS is
a review checkpoint only; it is not an install candidate.

**Slice 1** (version-2 master rules, E_1 revision 3, one data kind, the binding and ticket gates, barrier P):

| EX (commit) | Content | Outcome |
|---|---|---|
| EX_141 (`32cc0e3`; zip `83c4a74dc21044895d53670d1723d9b7bc2b537f14d41ef676584d0c4fe7cae9`) | Candidate v1: 506 tests in the suite, 505 run and passed on each of Python 3.13 and 3.15.0b4 (E2R-T12 excluded; EX_153 TAKEOVER-C03); 67 mutants (61 caught, 6 equivalent) | |
| EX_142 (inside `exchange/EX_143_Claude/`) | Review | **RECHECK.** B01: the official request's pin was not bound to the frozen plan or session pin. B02: invalid weekly evidence could be read as absent evidence. B03: an INIT-only leniency was wider than the ratified closed ledger grammar. C01 to C03. |
| EX_143 (`5573035`; zip `4ac92eb491b598dad9dcd17dccdc0d178171bfe73f92d12857f01f8178733c18`) | Candidate v1r1: 507 tests in the suite, 506 run and passed on each Python (E2R-T12 excluded); 87 mutants (80 caught, 7 equivalent) | |
| EX_144 (inside `exchange/EX_145_Claude/`) | Review | B01 PASS; two narrow residuals: blank JSONL lines; strict CSV quoting |
| EX_145 (`3d825b3`; zip `03a8ce832839616e5f7b0e457b40419bcd58f14004e701a4e7f21310a91409f9`) | Candidate v1r2: 507 tests in the suite, 506 run and passed on each Python (E2R-T12 excluded; all 507 ran on Windows in T018); 90 mutants (81 caught, 9 equivalent, 0 survived) | |
| EX_146 (`8aa16c3`) | Review | **slice 1 PASS** (review checkpoint only). Its watchpoints for slice 2 and the integrated package are carried as reminder R-019 (a) to (e). |

- **C01-EFF** (owner, 4 November 2026; EX_142 C01, EX_143): E_1 revision 3's `effective_date` is the integrated package's actual
  preparation date. It is set before that package's final review freezes the registry bytes and digests, and it is never the
  admission or release date. The release record alone dates a release.

**Slice 2** (the Mode H batch kind and families, `src/evaluation/Method_Mode_H.py` and `mode_h.py`, the closure and environment
freeze, the install and release records tool, `src/package_tools/process_check.py`, the results updater v0.2, the launchers, the
freeze-before-outcome rule, and the Claude Code rulebook v0.4):

| EX (commit) | Content | Outcome |
|---|---|---|
| EX_147 (`2eb6dfb`; zip `a5ac750f5699b3a5f99bfda6d5b67f3aa85a6754ccaecef7a61f8cbb26d1ef25`) | Candidate v1: 561 tests on both Pythons; 85 mutants (76 caught, 9 equivalent) | |
| EX_148 and its evidence supplement (`b45cb0d`) | Review | **RECHECK.** B01: the per-pair score ledger against design 5.2 and 5.4. B02: a partial three-file report. B03: the roster against the registry and the release records. B04: a ledger accepted without full validation. C01: non-Python process ancestors. (iii-b): a corrective scoring run after the seal. (vi). (ix): COMMITTED PASS, accepted as conditional. C02: evidence status. Also: marking a mutant equivalent because no test plants its fault is test non-detection, not equivalence. |
| EX_149 (`534af84`; zip `b89513fddba66e62e058c4a54f812b51cc2d1f41ef2f9d11b432aa1de1b13b46`) | Candidate v1r1 with the A1 draft: 569 tests; 99 mutants (85 caught, 14 equivalent with printed reasons) | |
| EX_150 (`c498103`) | Review | B02 to B04 and C01 **PASS**; A1 reviewed favourably; one new blocker, **B05**: a resumed scorer bound neither to the scoring plan `SCORING_STARTED` froze nor to a complete `SCORE_COMPLETE` |
| EX_151 (`8b5acaa`; zip `327aaf7413b39eb5249a7df62b1f14bba7655810d5accb55bb7518866828a094`; inner candidate `MHUPA_Slice2_Review_v1r2.zip` `67701220d761924cc9ee1703c613cb3bf48b8f978050115de9ef242d60b751bc`) | Candidate v1r2: B05 corrected; 570 tests on both Pythons; 5 targeted mutants caught | |
| EX_152 (`f7d90da`) | Review | **slice 2 PASS.** It permits preparing the one integrated MHUP-A install candidate for its own review. It is not an integrated PASS, an install authorisation, or authority to read holdout outcomes or run on real data. |

- **The candidate's base:** the v1r2 candidate's `overlay/` holds slice 1 and slice 2 together: 70 files against the base tree,
  main at `2061055`. It removes `src/results_master_v0_1.py`, which is replaced by v0.2.
- **The reviewer's evidence boundary** (stated in EX_146, EX_150 and EX_152): the reviewer inspected the full packaged source
  statically, verified the artefact identities, and reproduced each candidate-to-candidate diff byte for byte. It **did not
  execute** the tests or the mutation runner. The suite and mutation results are Claude's (Linux) and the owner's (Windows).
- **The owner's decisions during slice 2 (5 November 2026):**
  - **A1-B:** EX_148 B01 to be resolved by route (B), the one-step atomic score ledger, through a design amendment.
  - **IIIB-1:** the corrective scoring run after the Mode H seal is deferred to MHUP-B, with its route stated (A1 section 6).
  - **A1-R (A1 ratified):** after EX_150 the owner wrote "i hereby authorise and ratify that A1". The ratified record is
    `exchange/MHUP1_design_amendment_A1_RATIFIED.md` (`c498103`; Git blob SHA-256
    `f2506c02297808ea260d5fa3a5d18f79069d2a317004e85683271129383db4b8`).
    - Its sections 1 to 5 replace **only** the quoted per-pair provisions of the design's sections 5.2 and 5.4 and Appendix
      L-H2. In order: the scorer reads the holdout outcomes once and computes the complete ledger; publishes it atomically,
      create-only; validates the published ledger as it stands; and only then writes `SCORE_COMPLETE` (with the ledger's
      digest), resumes or publishes the report, and seals. The recovery states are those of A1 section 4: no ledger; the
      complete ledger without `SCORE_COMPLETE`, where no outcome is read and a refused ledger is a STOP; and after
      `SCORE_COMPLETE`. A resumed scorer is bound to its frozen scoring plan and to a complete `SCORE_COMPLETE` record
      (EX_153 TAKEOVER-C01).
    - Section 6 is the MHUP-B route for a corrective scoring run. It authorises no implementation in MHUP-A.
    - Section 7 is explanatory.
    - EX_152 section 3 confirmed that the ratified text's sections 1 to 7 equal the reviewed draft.

**The owner's Windows runs (Claude Code, read-only task clones; owner-reported, reports committed by the owner):**

| Task | Candidate | Result | Report commit |
|---|---|---|---|
| T018 | slice 1 v1r2, 507 tests | **PASS**. The committed real ledgers also pass the full ledger grammar. | `110eb41` |
| T019 | slice 2 v1 | **STOPPED correctly at step 5**: its command lines named paths that the owner's `.claude/settings.json` denies by their text | `56abdf4` |
| T020 | slice 2 v1, 561 tests | **PASS**: 4 allowed symlink skips, 16 minutes 55 seconds | `cba73e5` |
| T021 | slice 2 v1r1 | **PENDING** at the date of this edition | |
| T022 | slice 2 v1r2 | **PENDING** at the date of this edition | |

**Claude Code tooling** (Claude's commits in `CLAUDE_CODE_WORKING_FOLDER_TREE/` and `exchange/`):
- **Rulebook v0.4** (`CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md`, committed at `87bf389`; Git blob SHA-256
  `a4c4cbfcbe783ba4063cfbc49e1dfc9582ccd052ae4b5f5453af001d4fecdc8a`; reviewed within slice 2):
  - rule 7 names, ahead of their installation, the MHUP-A programs the runner never runs: `Run_Evaluation.bat`, the Mode H
    command and its module, the walk-forward driver's Mode H plan mode, the process tool, the records tool and every version of
    the results updater.
- **The clone tool `tools/cc_clone.py` v0.4** reads denied paths from a plan file (`overlay --plan`, `verify-overlay`).
- **Claude's checker `exchange/CLAUDE_WEB_TOOLS/check_task_commands.py`** checks a task file's command lines against the deny
  list before it is sent.
- **Still to come:** the owner's `.claude/settings.json` deny lines for the MHUP-A programs (register v0.24, future action 1) are
  the owner's edit, made with MHUP-A's install. Naming Lotterywest-GOV in the rulebook's rule 1 (register v0.24 future action 1;
  reminder R-017) is also still to do. Rule 1 already forbids contacting any lottery website.

**The owner's own commits (5 and 6 November 2026; not reviewed; not part of MHUP-A).** `f1883df`, `653b80c`, `54d161f`,
`ece780a`, `456cefd` and `43dd069` (with merges `baf60fb` and `442597a`) added:
- `src/GAIS/` and `doc/GASI_thought_experiments/outlandish_01/`: the owner's "outlandish" thought experiments;
- three `.gitignore` lines for very large GAIS files;
- in `f1883df`, the package **`pyahocorasick`** in `DIRECT_PACKAGES` of `install_upgrade_dependencies_into_venv.bat`.

This register records these as facts only. They are the owner's work, not reviewed. Whether the dependency line is an approved
dependency change under the rules (H-1 section 2; register v0.24, "no ... dependency upgrade without the owner's separate
approval") is **OPEN for the owner** to state. The integrated MHUP-A package must allow for all three (reminder R-020 (d) to
(f)):
- the candidate's whole-file `.gitignore` predates the owner's lines;
- the environment freeze records whatever the venv holds at Approval 1;
- the code closure covers `src/`, and with it `src/GAIS/`.

**The reviewer chat's end and the emergency handovers (6 November 2026).**
- The ChatGPT reviewer chat that held the role from 30 October 2026 reached its conversation limit on 6 November 2026 **without
  writing its own handover**.
- On the owner's instruction, Claude wrote the following in `exchange/HANDOVER_2026_11_06/`, committing each in order of
  criticality (`c84e2dc`, `957a452`, `2660e46`, `dbde41f`):
  - H-1 v1r9, a delta on H-1 v1r8, with its blurb;
  - the owner's reminders and roadmap (R-016 overtaken; R-020 (d) to (f); R-022);
  - **H-2 v1r9 CANDIDATE**, reconstructed from H-2 v1r8 and the reviewer's own messages EX_142 to EX_152, with its blurb. Its
    builder asserts that the reviewer-rights region (`## 2.` to just before `## 4.`) is unchanged: 7,676 bytes, SHA-256
    `70e50dc3bc56d9800c046a773abb823b8cb659b4f23d7dba1f18f7bd31bc72db`.
- **H-2 v1r8 stayed the operative reviewer handover** until the owner ratified H-2 v1r9 (RAT-25 below).
- A new reviewer chat's first task is its takeover check of H-2 v1r9 and of this register (reminder R-022).
- **The new reviewer's takeover (EX_153, 6 November 2026):**
  - The new ChatGPT reviewer chat accepted the role on the operative H-2 v1r8.
  - It verified that the reviewer-rights region and sections 1, 4 and 5 of H-2 v1r9 equal v1r8's (canonical LF).
  - It found no narrowing of its independence.
  - It found five documentation corrections, TAKEOVER-C01 to C05 (C01, the order of A1's ledger publication and validation,
    for RECHECK; the others FIX AND PROCEED), plus one optional line-ending qualification, O01. Candidate 2 of H-2 v1r9 and of
    this register applies them (Claude's EX_154).
  - The candidates copied into `doc/` by the owner at `929eff5` are candidate 1. They become authoritative only after ratification.
- **Claude's verification questions to the new reviewer (HO-3)**, the counterpart of the reviewer's Q1 to Q9 for Claude in HO-2:
  - Claude sent Q1 to Q19 in EX_154, with its answer key sealed by SHA-256 and held by the owner.
  - The reviewer answered blind in EX_155, citing sources.
  - Claude's comparison (EX_156, with the published key): all nineteen answers agree in substance with the key and the cited
    records, and none shows a misunderstanding.
  - **RAT-25 (owner, 6 November 2026, about 01:53 Adelaide):** "ok review is ok. Ratify H-2 v1r9 and register v0.25
    candidate 3 ratified". The owner thereby:
    - accepted the new reviewer chat's takeover;
    - ratified **H-2 v1r9** (candidate 3) and **this register** (candidate 3).
    Only the status lines changed for ratification: H-2's title, header and closing lines; this register's version line, the
    RAT-25 record, the table rows and the current-status label. Both are installed as DOC-12.
  - **H-1 v1r9** (Claude's delta) was not ratified and stays a working document in `exchange/HANDOVER_2026_11_06/`. H-1 v1r8
    remains the ratified Claude handover.
- Register v0.24's future action 8 said a ChatGPT reviewer handover would be "considered only after" HO-2. The reviewer chat's
  end has overtaken it.

**Future actions (updating register v0.24's list; not authorisations).**
1. **The new reviewer's takeover** (R-022): its check (EX_153), the corrections and its RECHECK of TAKEOVER-C01, its answers to Claude's
   verification questions (EX_154), then the owner's acceptance, all before the integrated MHUP-A package is sent.
2. **The owner's T021 and T022 reports.** A Windows failure is corrected before integration.
3. **The integrated MHUP-A install package** (register v0.24 future actions 1 and 2, now with A1 cited). It contains:
   - the installer and the verifier (design Appendix J steps 0 to 19, including the verifier's `released` phase);
   - the LF and CRLF rehearsals and T016;
   - E_1 revision 3's `effective_date` set to the preparation date (C01-EFF);
   - the package manifest's `release_entries` naming E_1 revision 3 for both games (R-020 (a));
   - the environment-freeze orphan rule (R-020 (b));
   - the owner's POC-suite rerun choice (R-020 (c));
   - the rebase onto the current main and the owner's own commits (R-020 (d) to (f));
   - R-019 (a), (d) and (e), checked in the assembled behaviour;
   - EX_148 (ix): the verifier proves both commits, the barrier order, and that the records agree with the repository.

   Its review assesses the assembled behaviour; it is not inferred from the slice PASSes (EX_152 section 5).
4. **MHUP-B** (register v0.24 future action 3). It is installed either before Approval 1, or only after a game's Mode H is
   sealed, and never while a holdout is opened and unsealed (design 4.4). The owner chooses the route, and the integrated install
   plan states it (EX_153). It adds:
   - the full shape of `FREEZE_LINE_V1` (R-019 (b));
   - the `FINAL_NEXT_DRAW`/`CATCH_UP` binding mutant re-run (R-019 (c));
   - A1 section 6's corrective scoring route;
   - Q9-E4 and R-018 (a) and (d) in its checklist.
5. **The next documentation package:**
   - this register, ratified after review;
   - the full H-1 and H-2 editions (folding in the v1r9 delta and candidate);
   - the design's next edition citing A1 and naming Lotterywest-GOV;
   - the template README's draft number (R-018 (c)).
6. **Unchanged from register v0.24:** future actions 4 to 7 and 9, and Q7 (OPEN).

**Out-of-date statements (register v0.25).** This register prevails, and the files are not edited:
- **The design v0.1r5, sections 5.2 and 5.4 and Appendix L-H2:** the per-pair score ledger provisions are replaced by A1 sections
  1 to 5.
- **Register v0.24, future action 8, and H-1 v1r8's blurb** ("the reviewer is not changing"): overtaken by the reviewer chat's
  end (above).
- **H-2 v1r8:** superseded by H-2 v1r9 (RAT-25). The reviewer-rights region is byte-identical in both.
- **Register v0.24, "Current status":** extended by this section.

| Document (path) | Author / check | Status and Git-content SHA-256 (LF unless stated) |
|---|---|---|
| `RATIFICATION_REGISTER_v0_24.md` | Claude; checked by the reviewer chat (EX_133 to EX_136) | OWNER-RATIFIED 4 Nov 2026; installed at `3d4fa3c`; superseded by this register; `9d9fde67961d76fcc4823e97ac339c12e8b7e68ba309167652bd2c568f5c81ae` |
| `Direction_for_operational_procedures_v0_3r1.md` | Claude; reviewer RECHECK, then focused PASS | OWNER-RATIFIED 4 Nov 2026; installed at `dfc2d13`; `9c781716b8313e052ec29203e79cf4745e3c172bc587e96a1fe1f4be2c84b985` |
| `exchange/MHUP1_design_amendment_A1_RATIFIED.md` | Claude; reviewed by the reviewer chat (EX_150, EX_152) | OWNER-RATIFIED 5 Nov 2026 (A1-R); a record in `exchange/`, to be folded into the design's next edition; **stored CRLF bytes** (Git stores this file with CRLF; not reformatted; EX_153 TAKEOVER-C04) `f2506c02297808ea260d5fa3a5d18f79069d2a317004e85683271129383db4b8` |
| `CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md` (rulebook v0.4) | Claude; reviewed within slice 2 (EX_147 to EX_152) | In force for the runner since `87bf389` (5 Nov 2026); `a4c4cbfcbe783ba4063cfbc49e1dfc9582ccd052ae4b5f5453af001d4fecdc8a` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r9.md` | Claude; checked by the new reviewer (EX_153, EX_155) | OWNER-RATIFIED 6 Nov 2026 (RAT-25); installed with this register (DOC-12); supersedes H-2 v1r8; `99a84910b3333345e1ec5c9497fb77506d9f936e301f3a732897651c130fde69` |
| `HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r9_introductory_blurb.md` | Claude, edited by the owner; the text the owner pasted to start the new reviewer | A record of the takeover's start; installed with this register (DOC-12); identity in DOC-12's manifest |
| `exchange/HANDOVER_2026_11_06/` (H-1 v1r9 delta and blurb, the candidates, README) | Claude, 6 Nov 2026 | Working documents and candidate history; the H-1 v1r9 delta is not ratified |

## DOC-12, T022, the history clean-up, the integrated package started, the Claude handover of 8 November, and DOC-13 (register v0.26)

Paths in this section are from the repository root. In this section, "this register" means register v0.26. Every commit named
here was checked by Claude from GitHub; the owner's Windows results are owner-reported. **Commit IDs: the 27 commits of 5 and 6
November 2026 listed in `exchange/HISTORY_CLEANUP_2026_11_06/commit-map.txt` were renumbered on 6 November 2026 (below); register
v0.25 and every other record written before the rewrite cite their old IDs; this register cites the new ones, with the old in
brackets where it helps.**

**DOC-12 installed (6 November 2026).** The owner installed H-2 v1r9 (with its introductory blurb as he used it) and register
v0.25, both ratified by RAT-25, at `fafa1ba` (old `377e27a`), and removed the candidate copies from `doc/`; Claude verified the
install from GitHub (`exchange/DOC12/install_doc12.py verify`: DOC12 VERIFY PASS).

**Windows evidence.** **T022 PASS** (6 November 2026; `CLAUDE_CODE_WORKING_FOLDER_TREE/outbox/REPORT_T022.md`, commit `e963e0e`,
old `2eb9abb`; Git SHA-256 `972d7b4e9df9d50d8ffb0eae64108f3a61bcd3527c1742d4bb56b2ce45d4e1ac`): MHUP-A slice 2 candidate v1r2,
the reviewed one, 570 tests including E2R-T12, 4 allowed symlink skips, in a task clone of `main` with the owner's then
`src/GAIS/` files present. One recorded deviation: step 8 was started detached with its output redirected, to time it (command,
arguments and folder unchanged); Claude accepted the evidence. **T021** (v1r1) was withdrawn unrun.

**The owner's decisions of 6 November 2026.**
- **DEP-1:** `pyahocorasick`, added by the owner to `DIRECT_PACKAGES` in `install_upgrade_dependencies_into_venv.bat`, is
  installed in the project venv for a GAIS test and approved as a dependency ("we keep it"). MHUP-A's environment freeze records
  it at Approval 1. Nothing in `src/` or `tests/` imports it.
- **GAIS-1:** the owner's GAIS thought experiments moved from `src/GAIS/` to the top-level `GAIS/` (owner commit `9d28b9f`, old
  `6b99029`), outside MHUP-A's code closure, with the third-party y-cruncher program untracked by `.gitignore`.

**The Git history clean-up (6 November 2026, about 11:00 to 11:30 Adelaide).** At the owner's request, led by Claude (the owner's
choice), reviewed by the ChatGPT reviewer chat (its proposal v0.1, assessment v0.1 and Gate A RECHECK PASS), and run by the owner
in gates B to E. Record: `exchange/HISTORY_CLEANUP_2026_11_06/` (`CLOSEOUT.md`, Git SHA-256
`bcd8881969190e6e3df6b8f608d2539eee05f698430f0cd7dadb6926cbe31842`; `commit-map.txt`, SHA-256
`52b27bb30b32e07cbaab14b2553d318d5071d26421bc40a222859b6302974d1c`).
- Removed from all history: `src/GAIS/OUTLANDISH_01/y-cruncher v0.8.7.9547b/` (246 files), the `ycruncher_digits` placeholder and
  two 1 MB `.bin` files; tool `git filter-repo --refs 54d161f^..main --invert-paths` with those paths.
- `main` 6b99029 -> `9d28b9f`; the tree `e8be5988e18f79d13cd1e34bbbf461f3659cca2c` is identical; 389 earlier commits keep their
  IDs; 27 were renumbered; a fresh clone went from 82.84 to 45.61 MiB packed (the same method before and after).
- **No file changed, so every document SHA-256 in every record still holds.** Only commit IDs moved: translate with
  `commit-map.txt` (old ID in column 1).
- The owner's decisions in the clean-up: Claude to lead; the loss of 15 commit signatures (all Claude's) accepted; the reviewer's
  bundle-restore test waived (a bundle of the old history is kept by the owner). The owner then cleaned his local `.git` (a copy
  kept first).

**The owner's later own commits (6 to 8 November 2026; not reviewed; recorded as facts).** OUTLANDISH work under `GAIS/`;
`.gitignore` lines for `GAIS/OUTLANDISH_01/large_artifacts/` and its configuration files; a new root `create_venv.bat` (creates
`.venv` only if it does not exist; never overwrites; installs nothing). No change under `src/`, `tests/`, `doc/` (outside his
handover copies) or the data folders.

**The integrated MHUP-A package started (owner's "go", 8 November 2026, about 18:13).** The reviewed code (slice 1 and slice 2
v1r2) was rebuilt on `main` `009c985` with the committed tools; it equals the reviewed overlay in 66 of 70 files, the other four
being `.gitignore` (the MHUP-A block now after the owner's new lines) and the three files carrying E_1 revision 3's date
(C01-EFF). A **preliminary** run of all 570 tests on Linux Python 3.13.18 and 3.15.0b4 had one expected failure on each (the test
pinning that date); the build now sets the test's date with the package date (`integrated/build_dev_integrated.sh`), and that
module then passed 8/8 on both. **The full suite on the final, date-frozen package, the mutation chains, the LF and CRLF
rehearsals and T016 are still to be run, on the final candidate** (EX_157 C03). The step 6 gate files are ten. Nothing is
installed. Work list: the H-1 v1r10r1 delta's section 7 and `exchange/CLAUDE_WEB_TOOLS/mhupa/integrated/PLAN.md`.

**R-020 (g), OPEN for the owner.** Appendix J's steps run `process_check.py` and `install_records.py`, which Claude Code's
rulebook v0.4 rule 7 forbids. Option (i): rulebook v0.5 allows only those two tools, only inside T016's synthetic, non-pushing
clone, from the package's staging folder, under the task file; option (ii): the owner runs T016's steps. The reviewer (EX_157
section 3) and Claude prefer (i), under the conditions recorded in `exchange/OWNER_REMINDERS.md`.

**The Claude handover of 8 November 2026 (RAT-26).** Because the Claude chat had grown long, Claude wrote H-1 v1r10, a working
delta on H-1 v1r8, and its blurb. The reviewer's focused documentary check **EX_157** (at `b38bd0a`) passed the crosswalk, A1's
order and the boundaries and found three corrections (C01 the test status overstated; C02 the gate count; C03 the order of work)
and four optional points; Claude applied all as **H-1 v1r10r1** (EX_158); the reviewer's recheck **EX_159** was PASS with one
editorial point (O05, stale pointers, tidied in the working files). **RAT-26 (owner, 8 November 2026, about 19:43):** the H-1
v1r10r1 delta and blurb ratified as working supplements to H-1 v1r8; installed by the owner in `doc/HANDOVER/` at `b866e42`.

**DOC-13 (this register's package).** Sent for the reviewer's documentary check as EX_160. **EX_161:** P01-P03 PASS (ZIP
integrity, every diff reversed, both builders reproduced byte for byte, A1's integration exact) with three corrections, all
applied (EX_162): C01 the replacement-reviewer blurb's old reading route and hard-coded EX numbers replaced by the current route
and "check `exchange/` for the highest number"; C02 H-2 v1r4 stays in `doc/HANDOVER/` (H-2 v1r8 section 6 item 2 sends readers to
its sections 7 and 8.2), so 34 moves, not 35; C03 the template's "later variants: registry entries only" clarified: after MHUP-A
every release goes through the package route with its records; and optional O01 (EX numbers) and O02 (line endings), applied.
**RAT-27 (owner, 8 November 2026, about 20:05):** "if you agree with them then after your changes/updates then consider them also
ratified, except for R-020 (g)": DOC-13 ratified as corrected (the reviewer's focused recheck of the corrections was offered and
not waited for, by the owner's choice; EX_162 records the exact changes). The ratified documents:
- **H-2 v1r10 delta and blurb:** the reviewer's insurance: a working supplement to the ratified H-2 v1r9, written by Claude from
  the records (the reviewer-rights region is not touched); the blurb's reading route corrected (C01).
- **The design v0.1r6** (`Predictive_Randomness_ModeH_Update_Prospective_Design_v0_1r6.md`): v0.1r5 with amendment A1 folded in
  (the three passages A1 section 1 quotes, in 5.2, 5.4 and L-H2), the results source named Lotterywest-GOV where it means the
  source (LW-1), a new version line, and section 8's rulebook tool list brought to register v0.24's future action 1. Nothing else.
  Made by counted edits from the ratified v0.1r5 bytes (`exchange/CLAUDE_WEB_TOOLS/doc13/make_design_v0_1r6.py`). Once ratified,
  v0.1r6 is the design's current edition and A1 stays the ratified record of the amendment.
- **The new-method template draft 5:** the status line corrected (R-018 (c)); what MHUP-A changes for a new method once it is
  installed (release records and the release date, rosters that change only through an install, Mode H's fixed cohort) and the
  rule that a method never checks a run mode (E_1 revision 3's lesson). The code skeletons are unchanged.
- **The repository README:** a `GAIS/` row; the two venv tools among the root `.bat` files; where the handover deltas fit.
- **The move of superseded editions** (`exchange/DOC13/MOVES.txt`, 34 files): older editions that no current reading document
  names or sends a reader to (H-2 v1r4 stays: C02), moved into `doc/superseded/`, `doc/HANDOVER/superseded/` and
  `doc/contracts/superseded/`. Content unchanged; every hash
  still holds; earlier registers' path citations of those files are read with the move list. Older registers that current
  documents cite by name stay in `doc/`.
- **Not in DOC-13, on purpose:** the Claude Code rulebook v0.5 (it waits for R-020 (g)); Architecture v0.10 (with MHUP-B); R3,
  the E2R contract specification and the proposal (each when next edited; this register and register v0.24 prevail meanwhile);
  the holdout exposure record (after Q7); the next full H-1 and H-2 editions (after MHUP-A).

**Future actions (updating register v0.25's list; not authorisations).**
1. The owner's R-020 (g) decision, then the integrated MHUP-A package in the order of the H-1 v1r10r1 delta's section 7 (the final
   candidate with the date frozen; all evidence on it; the review request at the next free EX number).
2. Register v0.27 records the integrated package's review and install, rulebook v0.5, and anything DOC-13's review changes.
3. Unchanged from registers v0.24 and v0.25: MHUP-B and its timing route; Q7 before Approval 2; the owner's backup confirmation
   and POC-suite choice at MHUP-A's approval; WF-1C; the method waves; KISS-1 when asked.

**Out-of-date statements (register v0.26).** This register prevails, and the files are not edited:
- **Register v0.25 and records written before the rewrite:** commit IDs of the 27 renumbered commits: read with `commit-map.txt`.
- **Register v0.25, "T021 and T022 PENDING" and R-020 (e) and (f) as open:** settled above.
- **H-2 v1r9 sections 0 and 6:** read with the H-2 v1r10 delta (RAT-27).
- **H-1 v1r10r1 section 2:** its pointer "section 7, item 8" means section 7, item 7 (EX_159 O05; for the next full H-1 edition).
- **Design v0.1r5:** superseded by v0.1r6 (RAT-27); A1 stays the ratified record of the amendment. v0.1r5 stays in `doc/` because
  ratified records cite it by name.
- **The template draft 4:** superseded by draft 5 (RAT-27).

| Document (path) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `doc/RATIFICATION_REGISTER_v0_25.md` | Claude; checked by the reviewer (EX_153, EX_155) | OWNER-RATIFIED 6 Nov 2026 (RAT-25); installed at `fafa1ba`; superseded by this register; `2ef9d17cfbc76c556e00d659677e411686c60aab263e1b0f0ef002930ee6d874` |
| `doc/HANDOVER/Claude_Primary_Handover_H1_v1r10r1_delta.md` | Claude; checked by the reviewer (EX_157, EX_159) | OWNER-RATIFIED 8 Nov 2026 (RAT-26) as a working supplement to H-1 v1r8; installed at `b866e42`; `e9cede8470aff5d05af1785702321be2b25b5c912a35e9ce636929efd2157c2f` |
| `doc/HANDOVER/Claude_Primary_Handover_H1_v1r10r1_introductory_blurb.md` | as above | as above; `f3c6bea057c29cf66c053bf2e55b40919d26715d3da1cdf8379c1eaf29122d41` |
| `doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r10_delta.md` | Claude, from the records | OWNER-RATIFIED 8 Nov 2026 (RAT-27), installed with DOC-13; `35a5c70a4c02793caae27e21bfbdc53baf5777b16b89efa34c4458cc4fb49fe2` |
| `doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r10_introductory_blurb.md` | Claude | OWNER-RATIFIED 8 Nov 2026 (RAT-27), installed with DOC-13; `f30dd7792215107d4e2c310a4e11c1ec1051e0b56d353a6909e4ad1e6034ad37` |
| `doc/Predictive_Randomness_ModeH_Update_Prospective_Design_v0_1r6.md` | Claude, counted edits from v0.1r5 (`e5fb491c...`) | OWNER-RATIFIED 8 Nov 2026 (RAT-27), installed with DOC-13; `7332dd6c1b3f6d9ef858b1881333ded56782bc595b7f894f04a75255909beb9d` |
| `doc/METHOD_TEMPLATE/README.md` (draft 5) | Claude | OWNER-RATIFIED 8 Nov 2026 (RAT-27), installed with DOC-13; `9adfd6f17ac22675cb562c8b970650292b7009af25e0b2bdfb951b6018595841` |
| `doc/METHOD_TEMPLATE/METHOD_SPECIFICATION_TEMPLATE.md` (draft 5) | Claude | OWNER-RATIFIED 8 Nov 2026 (RAT-27), installed with DOC-13; `54d15e8f1fe42bdc51b87a57cfc1869bb3693465d5a88ec84cc3e543ddc33661` |
| `doc/METHOD_TEMPLATE/CHANGES.md` (draft 5) | Claude | OWNER-RATIFIED 8 Nov 2026 (RAT-27), installed with DOC-13; `25d5a3638f9eae62b5a2b27821ed4d90bf6059f3b579b4577ab864229fe0de73` |
| `README.md` (repository root) | Claude | OWNER-RATIFIED 8 Nov 2026 (RAT-27), installed with DOC-13; `030de52691b04e84f8e03f3926c0cfbbf50bddc95517402ff6e9d6953d222d05` |
| `exchange/HISTORY_CLEANUP_2026_11_06/commit-map.txt` | git-filter-repo's own map | The crosswalk for the 27 renumbered commits; `52b27bb30b32e07cbaab14b2553d318d5071d26421bc40a222859b6302974d1c` |

## The integrated MHUP-A package, rulebook v0.5, the install of 13 November 2026, and design v0.1r7 (register v0.27)

Paths in this section are from the repository root. In this section, "this register" means register v0.27. Every commit named
here was checked by Claude from GitHub; the owner's Windows results are owner-reported, with Claude Code's reports in
`CLAUDE_CODE_WORKING_FOLDER_TREE/outbox/`. This section records decisions already taken and events that happened; it makes
no new decision.

**The integrated package's development (9 to 11 November 2026).** Work list `exchange/CLAUDE_WEB_TOOLS/mhupa/integrated/PLAN.md`.
The owner's records and the reviewer's focused reviews are in `exchange/HO2_2026_11_10/`: the HO-2 closure and the GO for
items 1 and 2 (10 November); the items 1-2 review and the owner's decisions after it (N1: `-text` for the install records);
the item 3 review (N5, F2) and its follow-up (N4b, N5-C01/C02, F2-C04, REC-C01). The owner's decisions in this round: R-020
(g) option (i) (8 November; recorded in register v0.26 as open, now settled); N1; N4 and N4b (`-text` for three byte-checked
files); N5 option A (Appendix J step 10 on a barrier-free copy); the reviewer's point A (the release-record tool refuses
unless U is held by the package and E is gone); abandon-and-rebuild after a STOP at step 13 or 17 (REC-C01).

**RAT-28: rulebook v0.5 and the Appendix J amendments (owner, 11 November 2026, 19:31).** Drafts at `5e1a704`; the reviewer's
focused review (T016-C01 to C05, J-REVIEW); r2 at `19e45ff`; the reviewer's R-2 focused PASS. The owner's words: "I RATIFY the
substance of rulebook v0.5 and the proposed Appendix J amendments J-1 through J-4, including the two section 4.3 wording
corrections", the reviewer's two wording corrections W01 and W02 "approved for incorporation without another review", and the
T016 task design accepted in principle. Record:
`exchange/HO2_2026_11_10/MHUPA_Owner_Ratification_Rulebook_v05_AppJ_2026_11_11.md`. The final documents differ from r2 only by
their labels and W01/W02 (`exchange/CLAUDE_WEB_TOOLS/mhupa/t016/final/R2_TO_FINAL.diff`, at `398c0a2`). The same evening the
owner decided that restore after a STOP from Appendix J step 6 on is written per case (for the state the output shows,
reviewed, owner-approved), and gave the go for the freeze.
- **Rulebook v0.5** (`CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md`): new section 2A, the one allowance for TASK_T016 (it ended
  with T016's report); rule 1 names Lotterywest-GOV (R-017); rule 7 adds `create_venv.bat`.
- **The Appendix J amendments** (`exchange/CLAUDE_WEB_TOOLS/mhupa/t016/final/APPENDIX_J_AMENDMENTS_RATIFIED.md`): J-1 step 10
  runs the suite on a barrier-free copy with only the six development data files; J-2 the step 10 negative tests; J-3 and J-4
  abandon and rebuild after a STOP at step 13, or at step 17 after the release commit (exceptional recovery only); section 4.3:
  40 baseline entries per game, and the install record's time is the time it is written. Folded into **design v0.1r7** (DOC-14,
  below).

**The freeze and the gates (11 to 13 November 2026).** Gate list:
`exchange/CLAUDE_WEB_TOOLS/mhupa/t016/final/INSTALLATION_STEPS_PROPOSED.md`. Each gate had the owner's own go.
- **Gate A, the freeze** (EX_163, `d4af894`): `MHUPA_Install_v1.zip`, SHA-256
  `9d8b74657880917bf8a367b083c5e5926bc6803ee989f74c934afdf98156cf76`; manifest SHA-256
  `8ad51e769dfb03592241fe1965b493fb605176620c8c93bd3f8a8b3de8a324b5`; base `c48ac3c`; E_1 revision 3's `effective_date`
  2026-11-11 (C01-EFF). It differs from the reviewed draft only by the date, the status and fingerprints, and the instructions'
  labels and restore wording. **EX_164:** the reviewer's PASS; the member hashes, draft beside frozen, at `60533e4`.
- **Gate B:** rulebook v0.5 and `inbox/TASK_T016.md` installed by Claude at `760e0c6`.
- **T016 PASS** (reports `0035a22` and `3f348a1`): Appendix J steps 0-18 in a task clone on Windows, the suite 571/571 with
  four symlink skips, the three expected refusals, F2 rows 5, 6 (the real venv: 27 distributions, no orphan), 7 and 10. Two
  disclosed recording deviations.
- **Gate D:** the owner's settings commit `138e185` adds five deny lines (F1).
- **Gate E:** F2 rows 8 and 9 PASS at the real root, run by the owner (record at `5211a42`).
- **Gate F, the live install (13 November 2026):** every Appendix J step 0-19 gave its expected line; the package commit
  `2860e86` and the release commit `effc179`, pushed by the owner. Claude verified it from GitHub (`81bc689`): the 71 package
  files equal the frozen package; no barrier committed; `RECORDS PASS: 1 install record(s), 2 release record(s), 80 released
  unretired entries`. E_1 revision 3 is released for both games; its release record's local date, 2026-11-13, is its release
  date for MH-1's rule.

**The post-install test fix (13 November 2026).** The whole suite on the installed `main` failed 8 of 571: two test modules
copied the repository's live install records and assumed the state before the install. The test-only fix r1 (`0a164fe`)
passed the reviewer (EX_165) and was run on Windows by TASK_T023 (EX_166's two corrections applied; in the inbox at
`95c35ca`; report `179699c`, PASS, 571/571). The owner committed the two files at `87c4219`; Claude verified both blobs against
the reviewed SHA-256 values. Not a code package: the files are outside the code closure and release nothing (EX_165).

**The owner's decisions of 13 November 2026** (record: `exchange/DECISIONS/OWNER_DECISIONS_2026_11_13_MHUPA_CLOSED.md`):
MHUP-A accepted and closed; (1) DOC-14, this register and design v0.1r7, documents the ratified decisions and is installed after
the owner's approval; (2) future isolated install rehearsals also run the whole suite in the post-release state, designed with
the next package, with no second suite run added to the live procedure; (3) MHUP-B is the next substantive priority: an
assessment first, no substantial design or coding before the owner authorises it; (4) KISS-1 stays deferred, with its agreed
scope (including method-registry usability and operational simplification), until the owner starts it.

**DOC-14 (this register's package).** Register v0.27 and design v0.1r7, written by Claude from the records; approved by the
owner on 13 November 2026 as documentation of decisions already ratified (not a new ratification). Design v0.1r7 is v0.1r6 with only RAT-28's
amendments in their ratified wording, by counted edits (`exchange/CLAUDE_WEB_TOOLS/doc14/make_design_v0_1r7.py`).

**Future actions (updating register v0.26's list; not authorisations).**
1. MHUP-B: the assessment first; its design only on the owner's authorisation; a post-release full-suite run in its
   rehearsals (decision 2).
2. Unchanged from registers v0.24 to v0.26: Q7 before Approval 2; the owner's backup confirmation and POC-suite choice at
   MHUP-A's approval; the owner's Approvals 1 to 4 per game, each separately; WF-1C; the method waves; the next full H-1 and H-2
   editions; KISS-1 when the owner asks.

**Out-of-date statements (register v0.27).** This register prevails, and the files are not edited:
- **Register v0.26, "Current status" and future actions 1 and 2:** done (above).
- **Design v0.1r6:** superseded by v0.1r7. It stays in `doc/` because ratified records cite it by name.
- **Rulebook v0.4:** superseded by v0.5 (installed at `760e0c6`).
- **Files in `exchange/` labelled DRAFT for MHUP-A, rulebook v0.5 or T016:** superseded by the final and frozen files named above.

| Document (path) | Author / check | Status and Git-content SHA-256 |
|---|---|---|
| `doc/RATIFICATION_REGISTER_v0_26.md` | Claude; checked by the reviewer (EX_160, EX_161) | OWNER-RATIFIED 8 Nov 2026 (RAT-27); superseded by this register; `366e966d6584d86681891eb84fe5363ae94ecac00f2943daab8fbc01ca125414` |
| `doc/Predictive_Randomness_ModeH_Update_Prospective_Design_v0_1r7.md` | Claude, counted edits from v0.1r6 (`7332dd6c...`) | DOC-14, OWNER-APPROVED 13 Nov 2026; records RAT-28; `c115b289432756b50ff76549be6f44282ca30cd9a94524e6c3271965a085b8de` |
| `CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md` (rulebook v0.5) | Claude; checked by the reviewer (R-2 PASS of `19e45ff`) | OWNER-RATIFIED 11 Nov 2026 (RAT-28); installed at `760e0c6`; `fa7a5fe229be832880cda4704ed9e7d27af2f4b9462464f7af262e540acd5200` |
| `exchange/CLAUDE_WEB_TOOLS/mhupa/t016/final/APPENDIX_J_AMENDMENTS_RATIFIED.md` | Claude; as above | OWNER-RATIFIED 11 Nov 2026 (RAT-28); `6bdeb16405cf29b2bbef9fc5c3e1915741ac5ede6a0108869b0a7bda547301e9` |
| `exchange/EX_163_Claude/MHUPA_Install_v1.zip` | Claude; checked by the reviewer (EX_164) | The frozen MHUP-A package, installed 13 Nov 2026; `9d8b74657880917bf8a367b083c5e5926bc6803ee989f74c934afdf98156cf76` |

## A correction to register v0.27, and two ratifications it did not record (register v0.28)

In this section, "this register" means register v0.28. It corrects a numbering error and records two ratifications that
register v0.27 omitted; it makes no new decision, and register v0.27's file is not edited.

**Correction: the number of the 11 November 2026 ratification.** Register v0.27 (DOC-14, installed at `b8600d0`) calls the
owner's ratification of 11 November 2026 (rulebook v0.5, the Appendix J amendments J-1 to J-4 and the two section 4.3
corrections) "RAT-28". That number was already taken (below). **Read every "RAT-28" in register v0.27 as RAT-30.** Its
content, date, record (`exchange/HO2_2026_11_10/MHUPA_Owner_Ratification_Rulebook_v05_AppJ_2026_11_11.md`) and every other
statement of register v0.27 are unchanged. Design v0.1r7 names no ratification number and is not affected.

**RAT-28 (owner, 8 November 2026, about 20:49).** Claude's handover H-1 v1r10r2 delta and its blurb (the pointers after DOC-13,
and the model guidance for a new Claude chat) ratified as working supplements to H-1 v1r8, replacing r1. Installed at
`06c26a6` on 10 November 2026 and verified (H1 VERIFY PASS), as recorded in `exchange/OWNER_REMINDERS.md` R-024; now
superseded by r3 and kept in `doc/HANDOVER/superseded/`.

**RAT-29 (at the owner's instruction, 10 November 2026).** H-1 v1r10r3 delta and its blurb: r2 with only the owner's decision
R-020 (g) = option (i) and the state on 10 November 2026 added (its section 4.9). In `doc/HANDOVER/`; the new Claude chat took
over from it (HO-2).

**Out-of-date statements (register v0.28).** This register prevails, and the files are not edited:
- **Register v0.27:** "RAT-28" for the 11 November 2026 ratification means RAT-30.
- **`exchange/OWNER_REMINDERS.md` R-024, "Register v0.27 records RAT-28":** RAT-28 and RAT-29 are recorded here, in v0.28.

| Document (path) | Author / check | Status and Git-content SHA-256 |
|---|---|---|
| `doc/RATIFICATION_REGISTER_v0_27.md` | Claude, from the records (DOC-14) | OWNER-APPROVED 13 Nov 2026; installed at `b8600d0`; superseded by this register; `fee014c148c2cca10f12e4418d17a04b20d932645f3c0162b1f32e43285d70aa` |
| `doc/HANDOVER/Claude_Primary_Handover_H1_v1r10r3_delta.md` | Claude | RAT-29, 10 Nov 2026; `40429eb5cb5b55d137dfb51e364aff52b37765f9e623cd9d2644a236d350fd01` |
| `doc/HANDOVER/Claude_Primary_Handover_H1_v1r10r3_introductory_blurb.md` | Claude | RAT-29, 10 Nov 2026; `dcc67bf84c27ff830a5d286f446e244b93bbadd3e3ef95f88fb9d3b7e8e2801e` |

## The owner's decisions of 13 November 2026, the Mode H readiness reviews, and the handover round of 14 November 2026 (register v0.29)

Paths in this section are from the repository root. In this section, "this register" means register v0.29. Every commit named
here was checked by Claude from GitHub. This section records decisions already taken and events that happened; it makes no
new decision, and nothing in it authorises a check, an approval or a run.

**The owner's decisions of 13 November 2026, 22:08** (record, verbatim:
`exchange/DECISIONS/OWNER_DECISIONS_2026_11_13b_MODEH_FIRST_Q7.md`, committed at `fd80e3e`), after Claude's MHUP-B assessment:
1. **Route 2, in principle: Mode H first, then MHUP-B.** Not yet authorisation for Approval 1. **The fixed cohort:** the 40
   variants per game released at that date form the Mode H study's fixed cohort; methods developed later cannot claim a fresh
   evaluation on the same holdout draws. **CATCH_UP** is retrospective evidence and cannot replace missed genuine prospective
   predictions. **The freeze:** no MHUP-B install and no change to the frozen code or environment between the first Approval 1
   and the sealing of both games. This settles design 4.4 item 1's choice for MHUP-B: after both games are sealed.
2. **Q7 DECIDED:** "Retain the restriction on raw draw values in the AI chats after Mode H. Approved project programs may still
   read and score those values through their controlled interfaces. Appropriate aggregate reports remain shareable." No rule
   changes and no new restriction.
3. **R-015 (b):** the Windows POC rerun is preferred: the existing non-destructive synthetic POC suite and the direct launcher
   and byte-code checks, excluding the optional `--with-timeout` process-tree termination test unless separately reviewed and
   authorised. No execution authorised.
4. **R-015 (c):** the owner will confirm the backups of `source_data/` and `results/` before Approval 1 (on the readiness sheet);
   that confirmation is **PENDING**, and no backup check and no Mode H Approval 1 has been authorised. No restore test was run
   or is required.
5. **The Approval 1 readiness sheet**, reviewed independently by the reviewer before the owner authorises anything; neither
   holdout run or opened.
6. **MHUP-B:** detailed design and code only on the owner's separate authorisation; isolated design work acceptable in
   principle, never interfering with the frozen Mode H implementation; the post-step-18 suite run kept in its design; KISS-1
   stays deferred; a proportionate process, prioritising scientific correctness, functional reliability and the agreed safety
   protections.

On 14 November 2026 the owner also asked that Claude's handovers be produced this round as **full updated documents rather than
more addenda or deltas** (the reviewer prepares its own).

**The Mode H readiness work (13-14 November 2026).** Claude (on Fable) read the installed Mode H code against design v0.1r7,
ran a full-cohort dress rehearsal of the four steps on invented data with the installed code (PASS for both games: 40 variants,
400 of 400 forecasts, one score, sealed; a second plan and a second score refused; no drawn number in any report file), and
drafted the readiness sheet and the POC rerun instructions (`exchange/CLAUDE_WEB_TOOLS/modeh_readiness/`, `52821e3`).
- **EX_167** (the reviewer): PASS WITH CORRECTIONS. **B01:** a blank-page browser start does not show that the installed updater
  can fetch and parse the official page; before either Approval 1, a narrowly scoped, separately owner-authorised, read-only
  historical fetch-and-parse check with the installed fetcher and parser, or the owner's written acceptance of the risk of a
  permanently blocked first game. **B02:** the first update is not indivisible (grab, backup, master, ledger); every unexpected
  Approval 2 result is held until a case-specific reviewed recovery. C01-C05: counts on all-success only; the Git boundary
  during the freeze; the witness push's meaning; the three families' separate error rates and catch-up against development
  evidence; Q7's records and the reports' sharing.
- **r2** (`bbaa2e3`): all applied; the one-off read-only check `gov_fetch_parse_smoke.py` (Git blob
  `1cbd32941234661d422c32f53bbf3b5343af2ff7`; the installed `BrowserFetcher.fetch` and `parse_gov` unchanged, 31 May to 31 July
  2026, the quarantine closed, nine draws per game compared in memory with the master, nothing written, draw numbers and counts
  only) and its development test (13 of 13 cases on invented data with a stand-in browser; no website contacted); the POC
  instructions r3.
- **EX_168** (the reviewer): **PASS**, zero blocking findings; B01 and B02 closed at the instructions level; the master
  comparison kept; the earlier two-site checker's fetches of the same page are context, not a substitute; a Powerball-only rerun
  of the check is acceptable after Oz Lotto is sealed and before Powerball's Approval 1, on its own go; N01-N03 (wording of
  "writes nothing", a second identity check of the file on disk, `-B` and caches) applied as **r2a** (`496731c`) without a
  further recheck.
- **Open for the owner:** decisions D1 to D7 of the sheet's section 9 (Oz Lotto first; both games decided now; the witness push;
  the official-page check or the written risk acceptance; the updated masters left uncommitted until both seals; the reports
  shared after both seals; the order of his gos). Nothing was authorised or run; no AI chat contacted any lottery website.

**The reviewer's handover: H-2 v1r11, then the full H-2 v2 (14 November 2026).** At the owner's request the reviewer wrote
its own continuity refresh: a delta on H-2 v1r9 and v1r10, a continuity index and a blurb (EX_169), leaving H-2 v1r9's rights
region untouched (7,676 LF bytes, SHA-256 `70e50dc3bc56d9800c046a773abb823b8cb659b4f23d7dba1f18f7bd31bc72db`, checked by
Claude). Claude's factual check (recorded with EX_169 at `959b072`): PASS WITH CORRECTIONS, five corrections and two optional
points. **EX_170** (r1) applied exactly those nine lines (Claude's diff check: PASS; recorded at `ac2c063`). The owner then
asked for one full document instead of layers, and the reviewer wrote **H-2 v2** (EX_172): one file and its blurb, sections 1
to 5 byte-identical to the ratified H-2 v1r8 and v1r9 (the rights region unchanged), the rest consolidating H-2 v1r9, its
v1r10 delta and the v1r11 r1 content. Claude's factual check (EX_173): PASS WITH CORRECTIONS, four corrections and one
addition (the N1 seed policy and WF-1C's carried obligations); the reviewer accepted all and sent **H-2 v2 r1** (EX_174),
which Claude's diff check passed (EX_175). H-2 v1r11 r1 is never installed. H-2 v2 r1 is ratified by RAT-31 (below).

**The Claude handover H-1 v2 (14 November 2026).** At the owner's instruction, a full consolidated edition replacing H-1 v1r8
and all its deltas (v1r9, v1r10, v1r10r1, v1r10r2, v1r10r3), built from v1r8's ratified bytes by counted edits and section
replacements (`exchange/CLAUDE_WEB_TOOLS/h1v2/make_h1_v2.py`), with a section-by-section account of where every part of the
v1r10r3 delta went (its Appendix B), and a new introductory blurb. It changes no rule. Sent with this register as EX_171.
**EX_172** (the reviewer's documentary review): PASS WITH CORRECTIONS; both files rebuilt byte for byte from v1r8 and v0.28;
no binding loss; C01 (point to the full H-2 v2, not to layers), C02 (R-015 (c) still pending) and C03 (no inference from
absence), each a FIX AND PROCEED, applied in EX_173.

**RAT-31 (owner, 14 November 2026, about 14:36).** Record (verbatim):
`exchange/DECISIONS/OWNER_DECISIONS_2026_11_14_DOC_ROUND_RAT31.md`. Asked whether he ratifies "the five handover documents for
installation: Claude's H-1 v2 and its blurb, ChatGPT's H-2 v2 (r1) and its blurb, and register v0.29", the owner answered "Yes,
ratify all five"; asked whether the old handover files those editions replace move to `doc/HANDOVER/superseded/` in the same
install, he answered "Leave them where they are". **H-1 v2 replaces H-1 v1r8 and its v1r10r3 delta, and H-2 v2 r1 replaces H-2
v1r9 and its v1r10 delta, as the operative handovers; the replaced files stay in `doc/HANDOVER/` as history.** Only the status
lines of H-1 v2 and its blurb, and this register's version line and table, changed after the review; the reviewer's two files
are installed exactly as received in EX_174. The ratification authorises the documentation install only, nothing for Mode H.
The install commit cannot be named here; the next register edition records it.

**Future actions (updating register v0.27's list; not authorisations).**
1. The owner's decisions D1 to D7; then the preparatory checks, each with its own go: the Windows POC rerun (R-015 (b)), the
   updater's offline self-test, the read-only official-page check, the backup confirmation (R-015 (c)) and the tree checks;
   then Approvals 1 to 4 per game, each separately, with the freeze from the first Approval 1 until both games are sealed.
2. One owner-run documentation install of five files (H-1 v2 and its blurb, H-2 v2 and its blurb, this register), after the
   owner's ratification of the final files and before the first Approval 1, so that no `doc/` change is pending during the
   freeze.
3. After both seals: this register's next edition records the study; the holdout exposure record's next edition (Q7, the
   opening records); the full H-1 and H-2 editions refreshed; then MHUP-B (its design on the owner's authorisation),
   carrying A7's interrupted-update recovery, the corrective scoring run (A1 section 6), R-019 (b) and (c), R-018 (a), (d) and
   (h), the tests-only fix for the tests pinned to the version-1 masters and the J-1 step 10 wording they make inaccurate, a
   whole-suite run after the release step in its isolated rehearsals, and T017.
4. Q7 into the design's next edition (section 9 and the Q7 rows), H-2's next full edition and the holdout exposure record.
5. Unchanged from register v0.27: WF-1C; the method waves; KISS-1 when the owner asks; the next editions of R3, E2R-1,
   Architecture (v0.10, with MHUP-B) and the proposal.

**Out-of-date statements (register v0.29).** This register prevails, and the files are not edited:
- **Register v0.27, future action 2** ("Q7 before Approval 2; the owner's backup confirmation and POC-suite choice at MHUP-A's
  approval"): Q7 is decided; the backup confirmation and the POC rerun are preparatory checks before Approval 1.
- **Design v0.1r7, section 9's Q7 rows and the "OPEN, for the owner" paragraph; Appendix K's row "unchanged until Q7 is
  decided":** Q7 is decided (above); the rules named there stay as they are.
- **Design v0.1r7, section 4.4 item 1 and the plan table in section 8** ("MHUP-B is installed before Approval 1 ... or after the
  Mode H score is sealed"; "installed before Approval 1"): the owner chose after both games are sealed; the dates in the plan
  table have passed (FB-1).
- **H-1 v1r8 and the H-1 v1r10r3 delta:** replaced by H-1 v2 (RAT-31) once it is installed; they stay in `doc/HANDOVER/` as
  history.
- **H-2 v1r9 and its v1r10 delta, their status statements** ("nothing installed", R-020 (g) open): superseded by H-2 v2 once
  it is installed. **H-2 v1r11 r1** (EX_169, EX_170): superseded by H-2 v2 before installation; never installed.
- **The readiness drafts r1 and r2:** superseded by r2a.

| Document (path) | Author / check | Status and Git-content SHA-256 |
|---|---|---|
| `doc/RATIFICATION_REGISTER_v0_28.md` | Claude, from the records | OWNER-APPROVED 13 Nov 2026; installed at `cce4858`; superseded by this register; `79ff491ffebae33715f1d434104324ff8301e6adf78177080c784e5f18a38e62` |
| `doc/HANDOVER/Claude_Primary_Handover_H1_v2.md` | Claude, from H-1 v1r8 and the records; the reviewer (EX_172) | OWNER-RATIFIED 14 Nov 2026 (RAT-31); `8f15109ff6e789e5760f704e8b9177ba3e745838889008151a51a40234938a30` |
| `doc/HANDOVER/Claude_Primary_Handover_H1_v2_introductory_blurb.md` | Claude | OWNER-RATIFIED 14 Nov 2026 (RAT-31); `f5a0e35df5ef9361c063cb0772827214120fdfff85cea289a4961afc4c8695b5` |
| `doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v2.md` (r1) | the reviewer (EX_172, r1 EX_174); Claude's checks (EX_173, EX_175) | OWNER-RATIFIED 14 Nov 2026 (RAT-31); its header reads CANDIDATE r1, and this register decides its status; `dee6e106957e0c4f918349510fe948e98d180c7d784159eecfae9ee166045803` |
| `doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v2_introductory_blurb.md` (r1) | the reviewer (EX_172, r1 EX_174) | OWNER-RATIFIED 14 Nov 2026 (RAT-31); `e607f114d8ee00cea623180136a0980aee08c9512c00ef76b341ee407098ca11` |
| `exchange/DECISIONS/OWNER_DECISIONS_2026_11_13b_MODEH_FIRST_Q7.md` | the owner's words, recorded by Claude | OWNER DECISION 13 Nov 2026; as stored `68d919a7272276a20ae527ba929453e5397c81d9fee389ff54b4f0b05a3aac31` |
| `exchange/CLAUDE_WEB_TOOLS/modeh_readiness/APPROVAL_1_READINESS_SHEET_DRAFT.md` (r2a) | Claude; the reviewer (EX_167, EX_168 PASS) | REVIEWED DRAFT; authorises nothing; as stored `7f85d98fc948499b0841e5de9546bb801d649c01dd87528d3176738eca71b583` |
| `exchange/CLAUDE_WEB_TOOLS/modeh_readiness/OWNER_POC_RERUN_R015b_DRAFT.md` (r3) | Claude; the reviewer (EX_168 PASS) | REVIEWED DRAFT; not run; as stored `c0f1c59f38290dc53773efa534f95df1c8df285aa9520797d98a9ea3af99959a` |
| `exchange/CLAUDE_WEB_TOOLS/modeh_readiness/gov_fetch_parse_smoke.py` | Claude; the reviewer (EX_168 PASS) | REVIEWED; not run; Git blob `1cbd32941234661d422c32f53bbf3b5343af2ff7`, SHA-256 `f3d9785a278419fe978815991b17c6c0bdaa9784cd68833adb22da48b1f0af2a` |

## The handover round installed, the dependency change, the replacement reviewer, the owner's decisions and the first two Mode H prerequisites of 14 November 2026 (register v0.30)

Paths in this section are from the repository root. In this section, "this register" means register v0.30. Every commit named
here was checked by Claude from GitHub. This section records decisions already taken and events that happened; it makes no
new decision, and nothing in it authorises a check, an approval or a run.

**The documentation round installed.** The five files ratified by RAT-31 (H-1 v2 and its blurb, H-2 v2 r1 and its blurb,
register v0.29) were installed by the owner at **`5a8527b`** (14 November 2026); Claude's verifier
(`exchange/CLAUDE_WEB_TOOLS/doc_round_rat31/verify_doc_round.py`) reported COMMITTED PASS, every file equal to its ratified
bytes. The old handovers stay in `doc/HANDOVER/` as history, as the owner chose.

**The owner's dependency change.** On 14 November 2026 the owner edited and ran `install_upgrade_dependencies_into_venv.bat`
(39 direct packages; in its installation modes, its default included, it requests upgrades of pip and every listed package;
its `VERIFY` mode is read-only) and committed it at **`cc0ab73`** (with two duplicate GAIS
notes, outside the closure). At the owner's request Claude wrote TASK_T024; the Claude Code local runner reported **PASS**
(report `811d0cc`): the read-only `env_freeze_check.py` printed ENV PASS (90 distributions, every RECORD file present and
matching, no orphan; Python 3.15.2; environment digest `5bf4eb8a36ddb9063fbcb27ff1b692d38de3847321518e563f70c7219999a3f9`),
and the whole suite passed (571, with the 4 permitted symlink skips). The owner, asked whether dependency upgrades should stay
an always-review topic, chose to keep the review (W-23). EX_176 sent the change to the reviewer; **EX_177**: PASS WITH
CORRECTIONS. B01: T024 does not run the Windows W-suite, so W-23 needs the owner's decision (below). C01: the readiness sheet's
attribution wording, applied as sheet **r2c** (r2b had carried the new digest and the baseline `cc0ab73`). C02: the installer's
own evidence. C03: nothing to change. The environment digest at T016 (`966a2792...`, 27 distributions) is history; Approval 1
expects T024's value.

**The reviewer chat changed.** The ChatGPT reviewer chat that started on 6 November 2026 reached its maximum length on
14 November 2026, about 18:00, after EX_177. H-2 v2 r1 needed no new edition; Claude filled its blurb's placeholders
(`exchange/HANDOVER_2026_11_14_REVIEWER/NEW_REVIEWER_START_PASTE.md`) and wrote twelve blind takeover questions (**EX_178**),
whose answer key the owner held sealed (SHA-256 `8d3ca6db09ac419d75b22baa471b4a5f78848a7fc35d38d10277f7089c56697a`, published
in EX_178 before the answers). The new chat's first reply (recorded in
`exchange/HANDOVER_2026_11_14_REVIEWER/NEW_REVIEWER_FIRST_REPLY.md`) verified the rights region from Git's bytes (7,676 LF
bytes, SHA-256 `70e50dc3...72db`) and read RAT-31 as installed. Its answers (**EX_179**) were compared with the published key
(**EX_180**): 12 of 12. The owner accepted it as the standing independent reviewer under H-2 v2 r1. Its rights are unchanged.

**The owner's decisions of 14 November 2026 (evening).** Records: `exchange/DECISIONS/OWNER_DECISIONS_2026_11_14b_C02_AND_REVIEWER.md`
(as stored `7ba931c6d2cc1e216e851afb73bd3feba6243ab70371edffaa08e6becc62d6ac`) and the new living decision log
`exchange/DECISIONS/DECISION_LOG.md` (entries 1 to 5), each with the owner's exact words.
1. **The replacement reviewer accepted** (about 19:35).
2. **EX_177 C02 closed** (19:37): the installer's own output is gone; the owner reports that a separate ChatGPT conversation,
   not the project's reviewer and not in this repository, went through the run with him and judged it successful; with T024 he
   finds that sufficient and asks for no `pip check`.
3. **D1 to D7 decided as recommended** (about 19:50), after the reviewer's advice (**EX_181**, agreeing with each; D4
   strongly): D1 Oz Lotto from manifest to seal, then Powerball; D2 both games whatever the first shows, barring a technical
   or safety STOP; D3 a value-free witness push after each Approval 1 and before Approval 2, each on its own go; D4 the
   official-page check is done; D5 the updated masters and ledgers uncommitted until both seals, backups checked after each
   seal, any later push of raw files its own decision; D6 the value-free report files shared together after both seals where
   practicable; D7 each prerequisite and approval on its own go, in the sheet's order. They authorise nothing to run.
4. **The working approach P0-P6** (about 20:17; decision log entry 1): Claude's proposals (**EX_182**, with the owner's
   query recorded beside it), the reviewer's modifications (**EX_183**) and Claude's acceptance of every modification
   (**EX_184**) reached consensus, which the owner had said he would adopt. Working guidance only: one living recovery index
   (`exchange/CONTINUITY_NOW.md`), decisions classified by effect into three levels, one living decisions log, one NOW page, fixed
   identities for procedures used in high-consequence actions, an ideas backlog after Mode H, and a short independent process
   note from each AI at each substantial milestone. Where it differs from the installed handovers, they govern until their next
   editions; the reviewer's rights R-1 to R-11 and the eight RECHECK areas are unchanged; Mode H is unchanged.
5. **OUTLANDISH_01's method family** (about 20:32; decision log entry 3): it joins this project's method backlog, probably
   first among the methods still to do; it enters only through this project's normal route (an identity decision and a
   catalogue amendment for E_63 onward, design review, N-1 isolation, rework to the method contract, release, Q7); its runs in
   `GAIS/OUTLANDISH_01/` are not evidence for this project. The reviewer acknowledged it (EX_185).
6. **EX_177 B01 closed** (about 22:45; decision log entry 5), after the POC rerun (below), Claude's proposed wording (EX_186)
   and the reviewer's agreement with one qualification (EX_187): a **scoped W-23 acceptance for the dependency change of
   14 November 2026 (`cc0ab73`) only**. T024 and the POC rerun are accepted as sufficient. Not run: the timeout and process-tree
   cleanup case (`--with-timeout`), Ctrl+C, memory stress and the other W-suite lifecycle cases; the residual risk that those
   paths are unverified on the new environment is accepted, and it cannot be reliably quantified. This is not "W-23 PASS" and
   authorises nothing further.
The owner also said he plans no further package installs and will ask Claude first; his OUTLANDISH_01 work uses this venv and
is committed by naming `GAIS/OUTLANDISH_01/`.

**The first two Mode H prerequisites (14 November 2026; each on its own go).**
- **The Windows POC rerun (R-015 (b)):** run by the owner after the reviewer's agreement (EX_185), exactly as the reviewed
  instructions r3 (Git blob `1105ff1c6c37f8be9bbb99e8b833dfd8dfa0a097`), without `--with-timeout`. Every block matched its
  expected output: the five synthetic suite cases PASS, the launchers' success and exit-3 cases, both launchers refusing with
  exit 10 while the byte-code folder existed, the folder removed, no orphan marker, no byte-code, a clean tree before and after;
  the launcher's output digest equals the suite's built-in reference. **PASS** (EX_186; the reviewer's check EX_187). The window
  is recorded unchanged: `exchange/RUNS/POC_R015b_2026_11_14_owner_window.txt`
  (`8179ca7d56d0378e57ba4902f63bef10ea94042e0f21ed393f9c6ccb16fbb6d1`).
- **The updater's offline self-test:** `Run_Results_Updater.bat --self-test` printed only `[SELF-TEST] 13/13 PASS`, exit 0.
  Two untracked OUTLANDISH files were present before and after (expected: an empty status); both AIs judged the deviation
  benign. **PASS** (EX_188; the reviewer EX_189). The window: `exchange/RUNS/SELFTEST_2026_11_14_owner_window.txt`
  (`62b37f5c14d16715ac5d788b5129cf3cf8ff1d26ea237464d57b44f030a596da`). The owner then committed the OUTLANDISH files
  (`657a2c1`, merged at `a6c2894`); no file under `src/`, no root `.bat` and no `requirements.txt` has changed since `cc0ab73`.
No AI chat contacted any lottery website; no holdout was opened; the updater has never run live.

**The Claude handover H-1 v3 (15 November 2026).** A full edition built from H-1 v2's ratified bytes by counted edits and
whole-part replacements (`exchange/CLAUDE_WEB_TOOLS/h1v3/make_h1_v3.py`; the diffs from v2 in `exchange/CLAUDE_WEB_TOOLS/h1v3/out/`),
with its blurb, bringing H-1 to this checkpoint and recording the working approach as section 1.7. It changes no rule; section
2A is byte-identical. Sent with this register as **EX_190** for the reviewer's documentary review; **EX_191**: PASS WITH CORRECTIONS (C01 the
installer's modes; C02 the recovery index; O01 which steps share a day), applied as FIX AND PROCEED in EX_192. The reviewer
judged that H-2 v2 r1 needs no new edition before the freeze.

**RAT-32 (owner, 15 November 2026, about 09:10).** Record: `exchange/DECISIONS/DECISION_LOG.md`, entry 6. Asked whether he
ratifies "the three reviewed files for installation: H-1 v3, its blurb, and register v0.30 (RAT-32)", with H-1 v2 staying in
`doc/HANDOVER/` as history, the owner answered "Yes, ratify all three". H-1 v3 replaces H-1 v2 as the operative Claude
handover; H-2 v2 r1 stays the reviewer's. Only H-1 v3's status line, and this register's version line, this paragraph and
its table's status cells, changed after the review. The ratification authorises the documentation install only, nothing for
Mode H. The install commit cannot be named here; the next register edition records it.

**Future actions (updating register v0.29's list; not authorisations).**
1. The reviewer's review of H-1 v3 and this register (EX_190); the owner's ratification; one owner-run documentation install,
   before the day of the first Approval 1, so that no `doc/` change is pending during the freeze. The reviewer judges whether
   H-2 needs a new edition.
2. Each on its own go: the official-page check, which the readiness sheet requires on the same day as the first Approval 1;
   the backup confirmation (R-015 (c)), the tree and identity checks and a quiet machine; then Oz Lotto's Approval 1. The later
   approvals (Oz Lotto's 2 to 4, then Powerball's 1 to 4) keep their own gos and their own safe schedule, with the freeze from
   the first Approval 1 until both games are sealed; the sheet also allows a separately approved Powerball-only page recheck
   after Oz Lotto is sealed and before Powerball's Approval 1.
3. Unchanged from register v0.29, items 3 to 5: after both seals the study recorded, the holdout exposure record and the
   handovers refreshed, then MHUP-B with everything it must carry; Q7 into the next editions; WF-1C; the methods still to do,
   now with OUTLANDISH_01's family probably first; KISS-1 when the owner asks; the next editions of R3, E2R-1, Architecture
   and the proposal. The ideas backlog (P5) after Mode H.

**Out-of-date statements (register v0.30).** This register prevails, and the files are not edited:
- **Register v0.29, future actions 1 and 2:** D1-D7 are decided; the POC rerun and the self-test have run; the documentation
  install is done (`5a8527b`).
- **H-1 v2, sections 6, 10 and 11 and Appendix A:** the environment digest `966a27926d23...` (now `5bf4eb8a36dd...`); "D1 to D7"
  as open; the POC rerun and self-test as not run; the readiness sheet as r2a (now r2c). Replaced by H-1 v3 once it is installed.
- **H-2 v2 r1, its statements of the afternoon of 14 November 2026** (the reviewer chat in office then; D1-D7 pending; the
  prerequisites not run; EX_177 not yet written): overtaken by this register and by `exchange/CONTINUITY_NOW.md`; the
  reviewer decides whether its next edition is needed now. Its rights region is unaffected.
- **The readiness sheet r2a and r2b:** superseded by r2c.
- **The owner's roadmap's NOW block** (`exchange/OWNER_ROADMAP.md`): kept as history; the live NOW is `exchange/CONTINUITY_NOW.md`.

| Document (path) | Author / check | Status and Git-content SHA-256 |
|---|---|---|
| `doc/RATIFICATION_REGISTER_v0_29.md` | Claude, from the records | OWNER-RATIFIED 14 Nov 2026 (RAT-31); installed at `5a8527b`; superseded by this register; `03efd2bac52272494a177a2654f6bcc852a3337eb5f506a73a2784064042f752` |
| `doc/HANDOVER/Claude_Primary_Handover_H1_v3.md` | Claude, from H-1 v2 and the records | OWNER-RATIFIED 15 Nov 2026 (RAT-32); `ddefe7006aa17cfd0a9a8996bd7122aed537d8d66accee92b2e5d737aefbaa54` |
| `doc/HANDOVER/Claude_Primary_Handover_H1_v3_introductory_blurb.md` | Claude | OWNER-RATIFIED 15 Nov 2026 (RAT-32); `d1df63bf18bc7becc96212ac0d76d519a2a5c4d6b367251116b294382573dd4d` |
| `exchange/DECISIONS/OWNER_DECISIONS_2026_11_14b_C02_AND_REVIEWER.md` | the owner's words, recorded by Claude | OWNER DECISIONS 14 Nov 2026; as stored `7ba931c6d2cc1e216e851afb73bd3feba6243ab70371edffaa08e6becc62d6ac` |
| `exchange/DECISIONS/DECISION_LOG.md` and `exchange/CONTINUITY_NOW.md` | Claude, from the owner's words and the records | living files (P2, P0); no fixed hash; Git keeps their history |
| `exchange/CLAUDE_WEB_TOOLS/modeh_readiness/APPROVAL_1_READINESS_SHEET_DRAFT.md` (r2c) | Claude; the reviewer (EX_167, EX_168 PASS; EX_177) | REVIEWED DRAFT; authorises nothing; as stored `8f31c5ba1fd12984ce266f52e1e27a77d7208164e1974895bf9f774a4af357a1` |
| `install_upgrade_dependencies_into_venv.bat` (at `cc0ab73`) | the owner | the owner's change; scoped W-23 acceptance; `c45cc336b758c39d6ccf33269fc2d1e96dd508192719c638bcc2416096f388b3` |
| `CLAUDE_CODE_WORKING_FOLDER_TREE/outbox/REPORT_T024.md` (at `811d0cc`) | the Claude Code local runner | TASK_T024 PASS; `a68a05771e4dfb06cda610bec881e80dba5facfaa48ee5441e33c10780b900ee` |
| `exchange/EX_180_Claude_EX_178_ANSWER_KEY.md` | Claude (held sealed by the owner until EX_179) | as stored `8d3ca6db09ac419d75b22baa471b4a5f78848a7fc35d38d10277f7089c56697a` |

## Interpretation and verification

- **Current status (register v0.27; read this first).**
  - MHUP-A is installed and released (13 November 2026; commits `2860e86` and `effc179`), and its post-install test fix is
    committed (`87c4219`); the suite on `main` passes 571/571. E_1 revision 3 is released for both games, dated 2026-11-13.
  - No real-data science run, results update, report, holdout opening or Mode H took place. None of the owner's Approvals 1
    to 4 has been given.
  - Next: the MHUP-B assessment for the owner (decision 3 of 13 November 2026).
- **Current status (register v0.26; read this first).**
  - Since register v0.25 no reviewed code package was installed and no real-data run, results update, report, holdout opening or
    Mode H took place. MHUP-A is reviewed in slices and passed on Windows (T022) but is not installed; its integrated package is
    being built (preliminary evidence only so far).
  - Commit IDs of 5 and 6 November 2026 changed on 6 November (the crosswalk above); no file changed.
  - The owner's decision R-020 (g) is open; everything else waits on the integrated package's review and the owner's approvals.
- **Current status (register v0.25; read this first).**
  - Since register v0.24 no reviewed code package was installed: nothing of MHUP-A, and no additional production-science code
    package since PERF-1, whose installed science code (REL-1, E1R2, WF-1A, WF-1B, PERF-1) is unchanged (EX_155
    TAKEOVER-C06). No
    real-data run, results update, report, holdout opening or Mode H took place. The owner's own unreviewed additions, `src/GAIS/`
    and the `pyahocorasick` line, are recorded in the section above. They matter to MHUP-A's code-closure and environment
    accounting (EX_153 TAKEOVER-C02).
  - MHUP-A's two review slices have PASSED (EX_146, EX_152) and amendment A1 is ratified. Neither authorises an install or a
    run.
  - Next, in order:
    1. the new reviewer chat's takeover check;
    2. the owner's T021 and T022 reports;
    3. the integrated MHUP-A install package and its own review;
    4. its rehearsals and the owner's install;
    5. MHUP-B;
    6. the owner's Approvals 1 to 4 per game, each separately.
- **Current status (register v0.24; read this first).** Since register v0.23 no code was installed and no real-data run, results update or report took place. The MHUP-1 design is ratified (MHUP-R) and authorises nothing by itself. First comes the staged Claude handover (HO-2): the reviewer's review of the handover package, the replacement Claude chat's verified takeover and the owner's authorisation to resume; then MHUP-A's and MHUP-B's code reviews and installs, then the owner's Approvals 1 to 4 per game, each separately. The bullet below, from register v0.23, still describes the position on past runs and on permissions.
- **Current status (register v0.23; read this first, EX_117 C01).** The bullets below are kept as earlier editions wrote them. Two of their statements are historical and no longer describe the present position. (a) "Oz science ... not permission for new Oz runs" and "The current multi-game development pause remains binding": that general pause was superseded, for separately owner-authorised development only, by REL-1 and WF-1A (`ENABLE_CONTRACT_REAL_DEVELOPMENT` True, WF1-3) and by the owner's recorded approvals of the two walk-forward batches (Powerball `86a1a01`, Oz Lotto `8430a15`) and the two ranking reports (`441daf2`, `608025c`), all recorded above. Those past authorised runs are facts, not permission for any future one: every further real-data run, batch, report, results update, holdout opening, Mode H, FINAL run or science run still needs its own explicit owner approval, and nothing is authorised implicitly by this register or by any earlier approval. (b) "exposure record v0.2" in the first bullet: on the owner's ratification of this register and installation of DOC-10, `HOLDOUT_EXPOSURE_RECORD_v0_3.md` supersedes v0.2 (decisions HX-1 and HX-2). Everything else in this section stands as written.
- **Until the integration editions listed in the preceding table are owner-ratified**, the predecessor set identified below remains operative on its unaffected subjects, and the independently owner-ratified Method Ranking Measures Proposal v0.5 already governs its adopted subjects. **Upon owner ratification** (given 27 October 2026), the operative editions are Proposal v0.6, R1 v0.4, R2 v0.5, R3 v0.5, Architecture v0.8, the Windows POC Task Specification v0.2, P3 v0.2, TIE_SHA256_V1 v0.2, and exposure record v0.2.
- **Pre-integration predecessor set (ratified before this integration):** Proposal v0.5, R1 v0.4, R2 v0.4, R3 v0.4, Architecture v0.7, the Windows POC Task Specification v0.2, P3 v0.2 and TIE_SHA256_V1 v0.2. Their historical approvals and hashes remain valid; their operative status is superseded only on adoption of the corresponding later edition. Earlier editions and ChatGPT handovers remain historical sources, not replacement current specifications.
- ERR-R2-02 / Option F is **provisional for production** pending the P2 test evidence and owner disposition, even though the Architecture and POC Task Specification are ratified.
- The **failed/orphan-group result firewall** is OWNER-RATIFIED on 23 October 2026. Never consume downstream results from failed or orphan-suspected groups, even when a canonical result file exists.
- **Later owner report (23 October 2026):** the reviewed, incident-specific orphan-clearance utility completed `CHECK PASS` and `MANUAL CLEARANCE PASS`, preserving the archived FAILED evidence and writing a clearance record; a subsequent one-worker P2 canonical fixture passed and left no marker. The repository is not itself live-state proof; always recheck the current global marker before any future launch. These observations do not close P2 or authorise destructive tests.
- This register does not authorise process termination, destructive testing, holdout unsealing, Oz Lotto scraping or Oz science. Previously authorised Powerball E_1 historical development and the verified draw-1577 run are historical facts, not permission for new Oz runs. The current multi-game development pause remains binding. The historic-development draw ceiling is not a permanent constraint on later authorised prospective FINAL prediction, normal retraining, operation or maintenance; the holdout remains governed by its separate protections.
- To verify a Git-stored file hash on Windows CMD after committing, substitute the path and run: `git show HEAD:doc/EXAMPLE.md | python -c "import sys,hashlib;print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())"`. Git may normalise checkout line endings; `certutil -hashfile` on a CRLF working file can legitimately differ.
- Where an exact historic ratification day is not independently substantiated, the register says so rather than assigning a date without evidence. Improve those entries only when a documentary decision record supports the update.

## Change discipline

The owner-ratified v0.2 was the first committed register; the earlier v0.1 and single-line Architecture heading fix were uncommitted administrative housekeeping. They do not alter technical policy, scientific method contracts, executable code, or experiment evidence. Preserve earlier document versions. Until the effective commit, substantive changes followed ChatGPT draft, then Claude review at the required gates, then owner ratification. From the effective commit they follow the agreed roles position v0.1r1: normally Claude drafts, the ChatGPT reviewer chat independently reviews (always the other model), and the owner ratifies.


## Pre-integration consolidation - historical ratification inventory (26 October 2026)

This section preserves the prior consolidation's ratified identities, rules, decisions and Git-content hashes without deletion. The entries document the governing set **at the time of the v0.3 register's ratification**; they do not designate a second current set after the method-ranking integration is ratified. Present authority and supersession are stated in "Method ranking measures and integration editions" and "Interpretation and verification" above.

This register preserves the **17 previous ratified-file SHA-256 entries unchanged** in the tables above. Those are historical authority evidence, not hashes of the new ratified editions. Following the owner's decision to consolidate, the documents below became the **self-contained governing versions** on 26 October 2026, rather than layered amendments 0A/0B or a separate operative R2 erratum:

| Pre-integration ratified edition (path under `doc/`) | Historical governing predecessor | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_Research_Project_Proposal_v0_5.md` | Ratified Proposal v0.4 | OWNER-RATIFIED 26 Oct 2026; `834c0a8e738979ae5bed3527fd946d4f9b0f6a4d77dcbf6d087f1437db731d58` |
| `Predictive_Randomness_Experimental_Method_Specifications_R2_v0_4.md` | R2 v0.3 + previously approved ERR-R2-01..05 + owner-decided ERR-R2-06 | OWNER-RATIFIED 26 Oct 2026; ERR-R2-02 Option F remains PROVISIONAL pending Windows gates; `1a1853570197a4a62a7d5695417848aac2de65b5fc83c25a931d936c84e05ef4` |
| `Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_4.md` | Ratified R3 v0.3 | OWNER-RATIFIED 26 Oct 2026; `78e2818ab71f6fce68cf1b39b24f5d0f2ad5563f7143b4358a3bcf5b6d49c752` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_7.md` | Ratified Architecture v0.6 | OWNER-RATIFIED 26 Oct 2026; `6c7ba2bc1da0d7b1f81e6e2e62e7c1e69448122bdf149399ae560f0c361b7218` |
| `Predictive_Randomness_MultiGame_Infrastructure_P3_Task_Specification_v0_2.md` | Ratified multi-game P3 v0.1 | OWNER-RATIFIED 26 Oct 2026; no execution authority; `2f3ac0e82dfd159025c3933ba41e812a4af0254da13e56664ed36dd5c5dcb61c` |
| `HOLDOUT_EXPOSURE_RECORD_v0_1.md` | new, factual and value-free | OWNER-RATIFIED, factual record 26 Oct 2026; superseded by v0.2 (26 Oct 2026); `a98064494444831b703587c48523dfb5e4b3c8aa66a3d00729ffcaa9d563c33b` |
| `NUMERICAL_INTEGRITY_AND_RETRAINING_REFERENCE_v0_1.md` | new, NON-NORMATIVE; operative requirements in R2/R3/Architecture | OWNER-RATIFIED, NON-NORMATIVE 26 Oct 2026; `51bcc84bc2ce4c2eda9c99008e75817f85e3f17ef12fc6639c1be6fd0ac3108d` |
| `RATIFICATION_REGISTER_v0_3.md` | owner-ratified v0.2 | OWNER-RATIFIED 26 Oct 2026; own SHA in external manifest (no self-reference) |

**Owner-ratified on 26 October 2026:** fixed 1 August 2026 quarantine and first-ten holdouts, versioned development masters with ledgers, source and provenance, assumed published order, free choice of safe reader representations, byte-owning prefix views, full-width `int64`/`float64` numeric types, opt-in date digests, default install-and-upgrade with mandatory regression tests, fresh per-target fitting and fixed safety gates. These requirements were ratified in consolidated R2 v0.4, R3 v0.4 and Architecture v0.7; upon owner ratification of the integration, their continuing operative editions are R2 v0.5, R3 v0.5 and Architecture v0.8. The newer editions integrate the owner-ratified Method Ranking Measures Proposal v0.5 and the separately owner-approved R3 section 17.10.1 CSV row-key clarification; no unrelated earlier rule is amended. Ratification of either set grants no run authority.

**Historical handovers (as at the v0.3 consolidation):** ChatGPT handbacks v0.6 and v0.6r1 were reported committed and were historical, not the accepted replacement new-coder handover. Exact HEAD bytes were to be checked independently at final installation. A definitive handover was to be prepared and independently reviewed only after those consolidated governing documents were ratified, installed and pushed; that was done (coder handover v1.0r1 at commit `6726963`, succeeded by v1.1r1 at `618fe48`).

**Post-ratification / commit verification (as at the v0.3 consolidation):** The seven installed document SHA-256 values above were computed from that ratified installation package; the committed files were confirmed byte-identical at Git HEAD `2db2554`. Register v0.3 omitted its own SHA-256 to avoid self-reference (it is now recorded in the method-ranking section above). Historical editions, R1 v0.4 and TIE note v0.2 were preserved unchanged.

## Consolidated v0.4 reviewed source dispositions (informational; OWNER-RATIFIED)

| Source / status | Treatment |
|---|---|
| R1 v0.4 | Unchanged operative method-catalogue source; may contain historical Powerball 1587 results; exposure recorded; no edits |
| TIE_SHA256_V1 v0.2 | Unchanged operative tie contract |
| R2 v0.3 + ERR-R2-01..06 | Historical sources; operative contents incorporated into owner-ratified consolidated R2 v0.4 |
| Architecture v0.6, R3 v0.3, Proposal v0.4, P3 v0.1 | Historical ratified predecessors, superseded by owner-ratified consolidated editions 26 Oct 2026 |
| `doc/experiments/P3_E1_..._REVIEW_CANDIDATE` | Historical review candidate, not a replacement governing spec |
| Windows POC Task Specifications v0.1 / v0.2 | Historical engineering planning, superseded by approved §5C and current architecture |
| ChatGPT handovers v0.6 and v0.6r1 | Historical/previous continuity snapshots, not normative; since superseded (see Continuity documents above) |
| Claude reviewer handovers v2–v8 | Historical prior-state snapshots; succeeded by v9 and then v10 (see Continuity documents above) |
| Repository root `README.md` | **TO UPDATE LATER**, not adopted as scientific authority in this consolidation |
| Exposure record and numerical technical reference | OWNER-RATIFIED 26 Oct 2026; factual record and non-normative guidance respectively |

Installation was then pending Claude's final mechanical comparison and the owner's commit/push; both were completed (installed at `2db2554`). The seven file hashes above identify the ratified-install package bytes. Ratification grants no run, update, holdout, Mode H, FINAL, process termination or Package 2 code acceptance.

**v0.3 full minimal-edit consolidation evidence:** original ratified predecessor source files remain preserved historically after the 26 October 2026 owner ratification. R1 and TIE unchanged. R2 erratum v0.3 is historical after consolidated R2 v0.4 ratification. Prior ChatGPT handovers v0.6/v0.6r1 are historical; the definitive coder handover was then pending Git HEAD verification and Claude's independent handover review, both since completed (v1.0r1 at `6726963`; v1.1r1 at `618fe48`).
