# E2R-CODE-2 - wiring the contract library in (only after the reviewer's RECHECK PASS and the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\E2R_CODE2_*` folders, then extract it there (`tar -xf "E:\TEMP\E2R_CODE2_Install_v1.zip" -C E:\TEMP`). This package adds 16 new files and replaces 1 existing file (`src/methods/_common/multigame_method_registry.py`); nothing else changes.

## 1. Update, check, copy, check

```bat
git status --short
git pull --ff-only
python "E:\TEMP\E2R_CODE2_Install_v1\VERIFY_E2R_CODE2_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\E2R_CODE2_Install_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\E2R_CODE2_Install_v1\VERIFY_E2R_CODE2_INSTALL.py" --repo . --phase post
```

Expected: `git status --short` prints nothing; the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `17 File(s) copied`; `POST PASS`.

## 2. Tests (offline; nothing in the repository is changed)

```bat
.venv\Scripts\python.exe "E:\TEMP\E2R_CODE2_Install_v1\RUN_E2R_CODE2_SUITE.py" --repo .
```

Expected: `SUITE PASS` (166 tests; the only allowed skips are the two symlink tests). E2R-T12 starts up to six ordinary Python worker processes and lets them finish normally. **Send Claude the output whatever it says.** If anything in steps 1 or 2 prints `STOP` or `FAILED`, do not commit: send Claude the output.

## 3. Stage, commit, check, and only then push

```bat
git add doc review src tests
git status --short
git commit -m "E2R-CODE-2: dispatch gate, standalone contract runner and E_1 wrapper"
python "E:\TEMP\E2R_CODE2_Install_v1\VERIFY_E2R_CODE2_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 16 lines starting with `A` and 1 starting with `M`, and nothing else; then `COMMITTED PASS`.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub. Claude pushes nothing to the repository while you install.
