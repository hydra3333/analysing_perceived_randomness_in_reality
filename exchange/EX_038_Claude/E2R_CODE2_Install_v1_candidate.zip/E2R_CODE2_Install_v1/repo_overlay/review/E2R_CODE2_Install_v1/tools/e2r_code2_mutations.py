"""E2R-1 section 13 mutation checks for CODE-2: E2R-T14 and T16 (Claude-side evidence; disposable copies only).

Usage: python3 -I e2r_mutations.py TREE
For E2R-T14 (the dispatch gate) and E2R-T16 at run level, plants a defect in a temporary copy of src/ and tests/
and requires the named test to FAIL; the unchanged copy (control) must pass. The tree itself is never
changed and no bytecode is written to it.
"""
import os, shutil, subprocess, sys, tempfile
from pathlib import Path

tree = Path(sys.argv[1]).resolve()
C = 'src/methods/_common/'
T = 'tests.test_e2r_contract.'
D = 'tests.test_e2r_dispatch.'
R = 'tests.test_e2r_runner.'
P = None
MUTANTS = [
    ('T14', 'the gate ignores the IN_DEVELOPMENT flag', C + 'contract_dispatch.py',
     "    if flag.exists() or flag.is_symlink():\n        refuse('IN_DEVELOPMENT_FLAG_PRESENT'",
     "    if False:\n        refuse('IN_DEVELOPMENT_FLAG_PRESENT'", D + 'T14TruthTable'),
    ('T14', 'the gate admits a FORMULA_OPEN entry', C + 'contract_dispatch.py',
     "    if entry['registry_status'] != 'SUPPORTED':", "    if entry['registry_status'] == 'UNSUPPORTED_FOR_GAME':",
     D + 'T14TruthTable'),
    ('T14', 'the gate accepts a stale pinned entry', C + 'contract_dispatch.py',
     "    if request['registry_entry_digest'] != record_digest(entry):", "    if False:", D + 'T14ReleaseTransition'),
    ('T14', 'the gate ignores a declaration mismatch', C + 'contract_dispatch.py',
     "    if entry['declaration_digest'] != request['declaration_digest']:", "    if False:", D + 'T14TruthTable'),
    ('T14', 'the runner reads data before the gate', C + 'contract_runner.py',
     "    entry, declaration = dispatch_gate(request, data_root=data_root, methods_root=methods_root)  # reads no data",
     "    load_pinned_draw_view(repo_root=Path(repo_root), run_manifest=reader_pin(request))\n"
     "    entry, declaration = dispatch_gate(request, data_root=data_root, methods_root=methods_root)  # reads no data",
     D + 'T14TruthTable'),
    ('T14', 'the coordinator side skips the shared gate', 'src/coordinator_private/contract_coordinated_gate.py',
     "    dispatch_gate(request, data_root=data_root, methods_root=methods_root)\n", "", D + 'T14TruthTable'),
    ('T14', 'the gate trusts a cached registry', C + 'contract_dispatch.py',
     "        registry = InstalledRegistry(data_root)      # fresh every call, never a cached or caller copy",
     "        cache = globals().setdefault('_CACHE', {})\n        registry = cache[str(data_root)] if str(data_root) in cache "
     "else cache.setdefault(str(data_root), InstalledRegistry(data_root))", D + 'T14TruthTable'),
    ('T16', 'a failed run still names its receipts', C + 'contract_publication.py',
     "             'receipt_digests': sorted(self.receipts) if outcome == 'SUCCESS' else []}",
     "             'receipt_digests': sorted(self.receipts)}", R + 'T16RunLevel'),
    ('T16', 'a failure after a receipt is recorded as SUCCESS', C + 'contract_runner.py',
     "        return end('RUNTIME_FAILURE', reason)", "        return end('SUCCESS', reason)", R + 'T16RunLevel'),
    ('T16', 'publication overwrites an existing file (both existence guards removed)', C + 'contract_publication.py',
     ["    if path.exists() or path.is_symlink():\n        raise FileExistsError(f'{path.name} already exists; publication never overwrites')",
      "        if path.exists() or path.is_symlink():\n            raise FileExistsError(f'{path.name} appeared during publication; not overwritten')",
      "        os.rename(tmp, path)"],
     ["    if False:\n        raise FileExistsError(f'{path.name} already exists; publication never overwrites')",
      "        if False:\n            raise FileExistsError(f'{path.name} appeared during publication; not overwritten')",
      "        os.replace(tmp, path)"], R + 'T16RunLevel'),
    ('T16', 'a run folder can be reused', C + 'contract_publication.py',
     "        self.folder.mkdir(exist_ok=False)", "        self.folder.mkdir(exist_ok=True)", R + 'T16RunLevel'),
    ('T16', 'consumption ignores the group and firewall gates', C + 'contract_publication.py',
     "            result[out_key] = consumable(output, receipt, terminal, gates_pass=gates_pass, declaration=declaration)",
     "            result[out_key] = consumable(output, receipt, terminal, gates_pass=True, declaration=declaration)",
     R + 'E1ThroughTheContract'),
]


def run(root, test):
    env = {k: v for k, v in os.environ.items() if k != 'PYTHONPATH'}
    env['PYTHONPATH'] = os.pathsep.join(str(root / p) for p in ('src', 'src/methods', 'tests'))
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return subprocess.run([sys.executable, '-B', '-m', 'unittest', '-q', test], cwd=root, env=env,
                          capture_output=True, text=True).returncode


def copy(tmp, name):
    d = tmp / name
    for part in ('src', 'tests'):
        shutil.copytree(tree / part, d / part, ignore=shutil.ignore_patterns('__pycache__'))
    return d


fails = 0
with tempfile.TemporaryDirectory(prefix='e2r_mut_') as t:
    tmp = Path(t)
    c = copy(tmp, 'control')
    for test in sorted({m[5] or P for m in MUTANTS}):
        ok = run(c, test) == 0
        print(('PASS' if ok else 'FAIL'), 'control passes', test)
        fails += not ok
    for i, (tid, what, rel, old, new, test) in enumerate(MUTANTS):
        d = copy(tmp, f'm{i}')
        p = d / rel
        s = p.read_text(encoding='utf-8')
        for o, n in zip(*((old, new) if isinstance(old, list) else ([old], [new]))):
            assert s.count(o) == 1, (tid, what, o[:40])
            s = s.replace(o, n)
        p.write_text(s, encoding='utf-8')
        failed = run(d, test or P) != 0
        print(('PASS' if failed else 'FAIL'), f'{tid} mutation: {what} -> {test or P} fails')
        fails += not failed
print('RESULT', 'PASS' if not fails else f'FAIL ({fails})')
sys.exit(1 if fails else 0)
