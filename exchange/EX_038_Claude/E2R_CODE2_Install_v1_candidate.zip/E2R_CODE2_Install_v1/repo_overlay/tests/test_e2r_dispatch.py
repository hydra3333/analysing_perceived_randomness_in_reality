"""E2R-T14: the dispatch gate truth table and the release transition (E2R-CODE-2). OFFLINE, synthetic only.

Both launchers are exercised: the standalone contract runner (Method_Contract_Runner.main and
contract_runner.run_contract_method) and the coordinator side (coordinator_private.contract_coordinated_gate).
Registries, method folders and masters are temporary copies or invented files; nothing in the
repository is written, no real draw value is read, no process is started.
"""
from __future__ import annotations

import contextlib
import io
from pathlib import Path
import sys
import tempfile
import unittest
from unittest import mock

import e2r_fixtures as F
import e2r_code2_fixtures as C
from e2r_fixtures import ROOT
sys.path.insert(0, str(ROOT / 'src'))

from _common import contract_dispatch as CD
from _common import contract_runner as CR
from _common.contract_dispatch import DispatchRefused, dispatch_gate
from _common.contract_forecast import validate_forecast
from _common.contract_records import record_digest
from _common.contract_registry import InstalledRegistry
from coordinator_private.contract_coordinated_gate import gate_coordinated_contract_request


class Base(unittest.TestCase):
    def setUp(self):
        self._td = tempfile.TemporaryDirectory()
        self.td = Path(self._td.name)
        self.data = C.copy_data_root(self.td)
        self.methods = self.td / 'methods'
        self.methods.mkdir()
        self.ws, self.sha = C.workspace(self.td / 'ws', 'POWERBALL', 1300)

    def tearDown(self):
        self._td.cleanup()

    def flag(self, method='E_2', present=True):
        p = self.methods / CD.method_folder(method) / CD.FLAG_NAME
        if present:
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_text('in development\n')
        else:
            p.unlink()

    def both(self, req):
        """(standalone result or refusal text, coordinator refusal text)."""
        try:
            res = CR.run_contract_method(req, compute=C.probe_compute, verify=C.no_verify, repo_root=self.ws,
                                         run_root=self.td / 'runs', orphan_marker=self.td / 'no_marker',
                                         data_root=self.data, methods_root=self.methods)
            standalone = res
        except DispatchRefused as exc:
            standalone = exc.text
        with self.assertRaises(DispatchRefused) as cm:
            gate_coordinated_contract_request(req, data_root=self.data, methods_root=self.methods)
        return standalone, cm.exception.text

    def assert_refused_same(self, req, code):
        standalone, coordinated = self.both(req)
        self.assertIsInstance(standalone, str, 'the standalone runner admitted a request the gate must refuse')
        self.assertEqual(standalone, coordinated, 'both launchers must print the same refusal text')
        self.assertIn(f': {code}: ', standalone)
        self.assertTrue(standalone.startswith('DISPATCH REFUSED: '))
        self.assertTrue(standalone.endswith('No data was read.'))
        self.assertFalse((self.td / 'runs').exists(), 'a refused request created a run folder')


class T14TruthTable(Base):
    def test_status_times_flag(self):
        for status in ('SUPPORTED', 'FORMULA_OPEN', 'UNSUPPORTED_FOR_GAME'):
            for flagged in (False, True):
                with self.subTest(status=status, flag=flagged):
                    self.tearDown()
                    self.setUp()
                    d = C.release_declaration()
                    C.install_declaration(self.data, d)
                    e = C.entry(d, status)
                    C.append_entry(self.data, e)
                    if flagged:
                        self.flag()
                    req = C.request(d, e, 1300, self.sha)
                    if status == 'SUPPORTED' and not flagged:
                        standalone, coordinated = self.both(req)
                        self.assertEqual(standalone.outcome, 'SUCCESS')
                        self.assertIn(': COORDINATED_CONTRACT_DISPATCH_NOT_ENABLED: ', coordinated)
                    else:
                        self.assert_refused_same(req, 'NOT_SUPPORTED' if status != 'SUPPORTED'
                                                 else 'IN_DEVELOPMENT_FLAG_PRESENT')

    def test_missing_stale_and_mismatched_entries(self):
        d = C.release_declaration()
        C.install_declaration(self.data, d)
        e1 = C.entry(d, 'FORMULA_OPEN')
        C.append_entry(self.data, e1)
        e2 = C.entry(d, 'SUPPORTED', seq=2, prev=e1)
        C.append_entry(self.data, e2)
        unregistered = dict(d, variant_id='NEVER_REGISTERED_V1')
        self.assert_refused_same(C.request(unregistered, e2, 1300, self.sha), 'NO_REGISTRY_ENTRY')
        self.assert_refused_same(C.request(d, e1, 1300, self.sha), 'STALE_REGISTRY_ENTRY')
        other = dict(d, minimum_history_draws=2)
        self.assert_refused_same(C.request(other, e2, 1300, self.sha), 'DECLARATION_MISMATCH')
        # An approval for revision 1 is not an approval for revision 2's code.
        d2 = C.release_declaration(revision='2')
        self.assert_refused_same(C.request(d2, e2, 1300, self.sha), 'REVISION_MISMATCH')
        # The NOT_YET_SPECIFIED placeholders can never be requested.
        ph = InstalledRegistry(self.data).active_entry('POWERBALL', 'E_3', 'NOT_YET_SPECIFIED')
        req = dict(C.request(d, e2, 1300, self.sha), method_id='E_3', variant_id='NOT_YET_SPECIFIED',
                   registry_entry_digest=record_digest(ph))
        self.assert_refused_same(req, 'INVALID_RUN_REQUEST')

    def test_installed_e1_admitted_and_e2_to_e62_refused(self):
        reg = InstalledRegistry()
        e = reg.active_entry('POWERBALL', *C.E1)
        d = reg.declaration(e['declaration_digest'])
        got_e, got_d = dispatch_gate(C.request(d, e, 1300, self.sha))
        self.assertEqual((got_e, got_d), (e, d))
        for i in range(2, 63):
            with self.subTest(method=f'E_{i}'):
                ph = reg.active_entry('POWERBALL', f'E_{i}', 'NOT_YET_SPECIFIED')
                req = dict(C.request(d, e, 1300, self.sha), method_id=f'E_{i}', variant_id='NOT_YET_SPECIFIED',
                           registry_entry_digest=record_digest(ph))
                with self.assertRaises(DispatchRefused):
                    dispatch_gate(req)

    def test_gate_fetches_the_registry_again_every_time(self):
        """Reviewer's EX_036 watchpoint: a caller's copy is never trusted or reused."""
        reg = InstalledRegistry()
        e = reg.active_entry('POWERBALL', *C.E1)
        d = reg.declaration(e['declaration_digest'])
        req = C.request(d, e, 1300, self.sha)
        entry1, decl1 = dispatch_gate(req)
        entry1['registry_status'] = 'FORMULA_OPEN'
        decl1['channels']['MAIN']['top_rule_id'] = 'MAP_SET'
        entry2, decl2 = dispatch_gate(req)
        self.assertEqual((entry2, decl2), (e, d))
        with mock.patch.object(CD, 'InstalledRegistry', wraps=InstalledRegistry) as spy:
            dispatch_gate(req)
            dispatch_gate(req)
        self.assertEqual(spy.call_count, 2)

    def test_refusal_reads_no_data_and_creates_nothing(self):
        d = C.release_declaration()
        C.install_declaration(self.data, d)
        e = C.entry(d, 'FORMULA_OPEN')
        C.append_entry(self.data, e)
        req = C.request(d, e, 1300, self.sha)
        opened = []
        real_open = Path.open
        ws = self.ws.resolve()

        def watch(path, *a, **k):
            if Path(path).resolve().is_relative_to(ws):
                opened.append(path)
            return real_open(path, *a, **k)
        with mock.patch.object(CR, 'load_pinned_draw_view', side_effect=AssertionError('data read')), \
                mock.patch.object(Path, 'open', watch):
            with self.assertRaises(DispatchRefused):
                CR.run_contract_method(req, compute=C.probe_compute, verify=C.no_verify, repo_root=self.ws,
                                       run_root=self.td / 'runs', orphan_marker=self.td / 'no_marker',
                                       data_root=self.data, methods_root=self.methods)
        self.assertEqual(opened, [])
        self.assertFalse((self.td / 'runs').exists())

    def test_standalone_launcher_prints_the_refusal(self):
        """Method_Contract_Runner.py itself: a refused run exits 2 and prints the gate's text only."""
        sys.path.insert(0, str(ROOT / 'src' / 'methods'))
        import Method_Contract_Runner as M
        reg = InstalledRegistry()
        ph = reg.active_entry('POWERBALL', 'E_2', 'NOT_YET_SPECIFIED')
        e = reg.active_entry('POWERBALL', *C.E1)
        args = ['run', '--game', 'POWERBALL', '--method', 'E_1', '--variant', C.E1[1], '--revision', '1',
                '--target', '1300', '--view', 'UNORDERED_SET', '--mode', 'SYNTHETIC_CONTRACT_TEST',
                '--declaration-digest', e['declaration_digest'], '--registry-entry-digest', record_digest(ph),
                '--master-sha256', self.sha, '--workspace', str(self.ws)]
        err, out = io.StringIO(), io.StringIO()
        with contextlib.redirect_stderr(err), contextlib.redirect_stdout(out):
            code = M.main(args)
        self.assertEqual(code, 2)
        self.assertIn('DISPATCH REFUSED: POWERBALL E_1 FULL_HISTORY_RAW_COUNTS_V1 revision 1: STALE_REGISTRY_ENTRY', err.getvalue())
        self.assertEqual(out.getvalue(), '')
        self.assertFalse((self.ws / 'contract_runs').exists())


class T14ReleaseTransition(Base):
    def test_release_transition(self):
        d = C.release_declaration()
        decl_file = C.install_declaration(self.data, d)
        e1 = C.entry(d, 'FORMULA_OPEN')
        e1_file = C.append_entry(self.data, e1)
        self.flag()                                                  # installed non-runnable (E2R-R58)
        decl_bytes, e1_bytes = decl_file.read_bytes(), e1_file.read_bytes()
        self.assert_refused_same(C.request(d, e1, 1300, self.sha), 'NOT_SUPPORTED')
        # Release package, step 1 of 2: a SUPPORTED entry is appended for the same declaration.
        e2 = C.entry(d, 'SUPPORTED', seq=2, prev=e1)
        C.append_entry(self.data, e2)
        self.assert_refused_same(C.request(d, e2, 1300, self.sha), 'IN_DEVELOPMENT_FLAG_PRESENT')
        # Removing the flag alone, without the entry, never releases: shown above in reverse order too.
        self.flag(present=False)
        res = CR.run_contract_method(C.request(d, e2, 1300, self.sha, run_id='mg-release-transition-01'),
                                     compute=C.probe_compute, verify=C.no_verify, repo_root=self.ws,
                                     run_root=self.td / 'admitted_runs', orphan_marker=self.td / 'no_marker',
                                     data_root=self.data, methods_root=self.methods)
        self.assertEqual(res.outcome, 'SUCCESS')
        self.assertEqual((decl_file.read_bytes(), e1_file.read_bytes()), (decl_bytes, e1_bytes))
        import json
        validate_forecast(json.loads((res.folder / 'forecast.json').read_bytes()), d)
        self.assert_refused_same(C.request(d, e1, 1300, self.sha), 'STALE_REGISTRY_ENTRY')
        self.assert_refused_same(C.request(dict(d, uses_dates=True), e2, 1300, self.sha), 'DECLARATION_MISMATCH')

    def test_flag_removal_without_entry_never_releases(self):
        d = C.release_declaration()
        C.install_declaration(self.data, d)
        e1 = C.entry(d, 'FORMULA_OPEN')
        C.append_entry(self.data, e1)
        self.assert_refused_same(C.request(d, e1, 1300, self.sha), 'NOT_SUPPORTED')   # no flag at all


class Package2RosterFromRegistry(unittest.TestCase):
    """Package 2's per-method roster is now read from the installed contract registry."""

    def test_same_statuses_as_the_old_fixed_roster(self):
        from _common.multigame_method_registry import all_statuses, method_status
        for game in ('POWERBALL', 'OZLOTTO'):
            want = {f'E_{i}': ('SUPPORTED' if i == 1 else 'FORMULA_OPEN') for i in range(1, 63)}
            self.assertEqual(dict(all_statuses(game)), want)
            self.assertEqual(method_status(game, 'E_1'), 'SUPPORTED')
            with self.assertRaises(ValueError):
                method_status(game, 'E_63')

    def test_flag_makes_the_roster_open(self):
        from _common.multigame_method_registry import method_status
        with tempfile.TemporaryDirectory() as td:
            (Path(td) / 'E_001').mkdir()
            with mock.patch.object(CD, 'METHODS_ROOT', Path(td)):
                self.assertEqual(method_status('POWERBALL', 'E_1'), 'SUPPORTED')
                (Path(td) / 'E_001' / CD.FLAG_NAME).write_text('x')
                self.assertEqual(method_status('POWERBALL', 'E_1'), 'FORMULA_OPEN')


class StaticCode2Guards(unittest.TestCase):
    def test_switch_closed_and_no_flag_in_the_tree(self):
        self.assertIs(CR.ENABLE_CONTRACT_REAL_DEVELOPMENT, False)
        self.assertEqual(sorted(p.relative_to(ROOT).as_posix() for p in (ROOT / 'src').rglob(CD.FLAG_NAME)), [])

    def test_wrappers_read_no_data_and_name_no_receipts(self):
        for f in sorted((ROOT / 'src' / 'methods' / 'contract_adapters').glob('*.py')):
            text = f.read_text(encoding='utf-8')
            for word in ('game_draws_reader', 'source_data', 'contract_receipts', 'contract_publication',
                         'contract_runner', 'open(', 'read_bytes', 'write_bytes'):
                self.assertNotIn(word, text, f'{f.name} mentions {word}')

    def test_method_folder_locator(self):
        self.assertEqual([CD.method_folder(m) for m in ('E_1', 'E_2', 'E_62')], ['E_001', 'E_002', 'E_062'])
        for bad in ('E_0', 'e_1', 'E_1x', 1):
            with self.assertRaises(ValueError):
                CD.method_folder(bad)


if __name__ == '__main__':
    unittest.main()
