"""E_2-readiness contract (E2R-1 v0.3r3): the dispatch gate (section 12A.3, E2R-R57, E2R-T14).

E2R-CODE-2. One gate for every normal dispatch, standalone or coordinated. It reads only the installed
contract data and the method folder's IN_DEVELOPMENT.txt flag; it never reads a master, ledger or any
draw data, so a refused request has read no data (E2R-R23A). It always loads the installed registry
afresh and returns fresh copies of the active entry and its declaration (reviewer's EX_036 watchpoint):
a caller's own copy is never trusted. Admission is not authorisation for a scientific run; every
other safety, environment, data-admission and owner gate stays separate (E2R-R57 item 3).
"""
from __future__ import annotations

from collections.abc import Mapping
from pathlib import Path

import _common.contract_vocab as V
from _common.contract_records import record_digest, validate_run_request
from _common.contract_registry import DATA_ROOT, InstalledRegistry

METHODS_ROOT = Path(__file__).resolve().parents[1]      # src/methods
FLAG_NAME = 'IN_DEVELOPMENT.txt'


class DispatchRefused(Exception):
    """A refused dispatch. `text` is the one warning both launchers print; it names the method,
    the revision and the reason, and contains no data."""

    def __init__(self, text: str, reason: str):
        super().__init__(text)
        self.text = text
        self.reason = reason


def method_folder(method_id: str) -> str:
    """The locator-only folder for a method ID (E2R-R53, reviewer's ADD-C07): E_2 -> E_002."""
    if type(method_id) is not str or not V.METHOD_ID.fullmatch(method_id):
        raise ValueError('invalid method ID')
    return f'E_{int(method_id[2:]):03d}'


def refusal_text(game_id, method_id, variant_id, revision, reason: str) -> str:
    def show(v):
        return v if type(v) is str and v.isascii() and v.isprintable() and len(v) <= 96 else '?'
    return (f'DISPATCH REFUSED: {show(game_id)} {show(method_id)} {show(variant_id)} revision '
            f'{show(revision)}: {reason}. No data was read.')


def dispatch_gate(request: object, *, data_root: Path = DATA_ROOT,
                  methods_root: Path = METHODS_ROOT) -> tuple[dict, dict]:
    """Admit a RUN_REQUEST_V1 or raise DispatchRefused. Returns (active_entry, declaration), both new
    caller-owned copies fetched from the installed registry by this call.

    Admitted only if all hold: the request is a valid stage-1 request; the installed registry has a
    chain for its (game, method, variant); the chain's active entry is SUPPORTED; the request pins
    exactly that active entry's digest; the entry's revision and declaration digest equal the
    request's; and there is no src/methods/E_<nnn>/IN_DEVELOPMENT.txt.
    """
    r = request if isinstance(request, Mapping) else {}
    ident = (r.get('game_id'), r.get('method_id'), r.get('variant_id'), r.get('method_revision'))

    def refuse(code, detail):
        raise DispatchRefused(refusal_text(*ident, f'{code}: {detail}'), code)

    try:
        validate_run_request(request)
    except ValueError as exc:
        refuse('INVALID_RUN_REQUEST', str(exc))
    game, method, variant, revision = ident
    try:
        registry = InstalledRegistry(data_root)      # fresh every call, never a cached or caller copy
    except (ValueError, OSError) as exc:
        refuse('REGISTRY_INVALID', f'the installed registry did not load ({type(exc).__name__})')
    try:
        entry = registry.active_entry(game, method, variant)
    except ValueError:
        refuse('NO_REGISTRY_ENTRY', 'no installed registry chain for this game, method and variant')
    if entry['registry_status'] != 'SUPPORTED':
        refuse('NOT_SUPPORTED', f'the active registry entry is {entry["registry_status"]}')
    if request['registry_entry_digest'] != record_digest(entry):
        refuse('STALE_REGISTRY_ENTRY', 'the request does not pin the active registry entry')
    if entry['method_revision'] != revision:
        refuse('REVISION_MISMATCH', f'the active entry approves revision {entry["method_revision"]}')
    if entry['declaration_digest'] != request['declaration_digest']:
        refuse('DECLARATION_MISMATCH', 'the request names a different declaration')
    flag = Path(methods_root) / method_folder(method) / FLAG_NAME
    if flag.exists() or flag.is_symlink():
        refuse('IN_DEVELOPMENT_FLAG_PRESENT', f'src/methods/{method_folder(method)}/{FLAG_NAME} exists')
    declaration = registry.declaration(entry['declaration_digest'])
    return entry, declaration


def active_pins(game_id: str, method_id: str, variant_id: str, *, data_root: Path = DATA_ROOT) -> dict:
    """What a request must pin for this method variant now (read from the installed registry only)."""
    entry = InstalledRegistry(data_root).active_entry(game_id, method_id, variant_id)
    return {'registry_status': entry['registry_status'], 'method_revision': entry['method_revision'],
            'declaration_digest': entry['declaration_digest'], 'registry_entry_digest': record_digest(entry)}
