"""E_2-readiness contract (E2R-1 v0.3r3): run-level publication of records, receipts and the terminal record.

E2R-CODE-2. Orchestration side only: no method code is imported, and nothing here reads draw data.
Publication order (E2R-R38A): the output record (C1 or C2) is created, validated, and only then its
freeze receipt (D1 or the diagnostic receipt); a SUCCESS terminal record (D2) naming those receipts
comes last. Every file is create-only (E2R-R36): written to a new temporary name, flushed, then
renamed onto a name that must not exist, never replaced. Nothing here deletes, moves, quarantines or
terminates anything, and nothing retries: an interrupted run leaves its files as they are and is
not consumable (E2R-T16).

Run folder (E2R-R52): <run_root>/<game_id>/<method_id>/<variant_id>/<run_id>/, created exclusively.
"""
from __future__ import annotations

from collections.abc import Mapping
from datetime import datetime, timezone
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import platform
import uuid

import _common.contract_vocab as V
from _common.contract_forecast import validate_diagnostic, validate_forecast
from _common.contract_receipts import (
    consumable, status_at_freeze, validate_diagnostic_receipt, validate_freeze_receipt, validate_terminal,
)
from _common.contract_records import canonical, record_digest, sha256_hex, validate_run_request

FILES = {'forecast': 'forecast.json', 'forecast_receipt': 'forecast_receipt.json',
         'diagnostic': 'diagnostic.json', 'diagnostic_receipt': 'diagnostic_receipt.json',
         'terminal': 'terminal.json'}


def new_run_id() -> str:
    """A fresh Package 2 format run ID, mg-<32 hex> (E2R-R52)."""
    rid = 'mg-' + uuid.uuid4().hex
    assert V.RUN_ID.fullmatch(rid)
    return rid


def create_only(path: Path, raw: bytes) -> None:
    """Create a new file; never overwrite (E2R-R36). A crash can leave only a .part- file or a
    complete file, never a replaced one."""
    if path.exists() or path.is_symlink():
        raise FileExistsError(f'{path.name} already exists; publication never overwrites')
    tmp = path.with_name(path.name + '.part-' + uuid.uuid4().hex)
    try:
        with tmp.open('xb') as fh:
            fh.write(raw)
            fh.flush()
            os.fsync(fh.fileno())
        if path.exists() or path.is_symlink():
            raise FileExistsError(f'{path.name} appeared during publication; not overwritten')
        os.rename(tmp, path)
    finally:
        tmp.unlink(missing_ok=True)


def utc_now() -> str:
    return datetime.now(timezone.utc).strftime('%Y-%m-%dT%H:%M:%S.%fZ')


def environment_identity() -> dict:
    """Informational provenance for receipts (section 8.1): never part of any record's content."""
    def version(name):
        try:
            return importlib.metadata.version(name)
        except importlib.metadata.PackageNotFoundError:
            return 'NOT_INSTALLED'
    packages = sorted({f'{(d.metadata["Name"] or "").lower()}=={d.version}'
                       for d in importlib.metadata.distributions() if d.metadata['Name']})
    return {'python_version': platform.python_version(), 'numpy_version': version('numpy'),
            'psutil_version': version('psutil'), 'os_name': platform.system() or 'UNKNOWN',
            'os_build': platform.version() or 'UNKNOWN',
            'installed_packages_digest': hashlib.sha256('\n'.join(packages).encode('utf-8')).hexdigest()}


def run_folder(run_root: Path, request: Mapping) -> Path:
    return (Path(run_root) / request['game_id'] / request['method_id'] / request['variant_id'] /
            request['run_id'])


class RunPublication:
    """The files of one admitted run, published in E2R-R38A order. One instance per run."""

    def __init__(self, run_root: Path, request: Mapping, *, entry_digest: str, execution_path: str,
                 provenance: Mapping):
        validate_run_request(request)
        if execution_path not in V.EXECUTION_PATHS:
            raise ValueError('invalid execution path')
        if request['registry_entry_digest'] != entry_digest:
            raise ValueError('the admitted entry is not the one the request pins')
        self.request = dict(request)
        self.execution_path = execution_path
        self.provenance = dict(provenance)          # master_file .. init_record_sha256, from the runner
        self.folder = run_folder(run_root, request)
        self.folder.parent.mkdir(parents=True, exist_ok=True)
        self.folder.mkdir(exist_ok=False)           # a run folder belongs to one run only
        self.receipts: list[str] = []
        self.terminal_written = False

    def _write(self, key: str, record: Mapping) -> bytes:
        raw = canonical(record)
        create_only(self.folder / FILES[key], raw)
        if (self.folder / FILES[key]).read_bytes() != raw:
            raise ValueError(f'{FILES[key]} does not read back as written')
        return raw

    def _receipt(self, schema: str, record: Mapping, raw: bytes, product_digest_names) -> dict:
        r = {'schema': schema, 'game_id': record['game_id'], 'target_draw_number': record['target_draw_number'],
             'method_id': record['method_id'], 'variant_id': record['variant_id'],
             'method_revision': record['method_revision'],
             'master_file': self.provenance['master_file'], 'ledger_version': self.provenance['ledger_version'],
             'master_sha256': self.provenance['master_sha256'], 'ledger_sha256': self.provenance['ledger_sha256'],
             'init_record_sha256': self.provenance['init_record_sha256'],
             'environment_identity': environment_identity(), 'run_id': self.request['run_id'],
             'execution_path': self.execution_path, 'registry_entry_digest': self.request['registry_entry_digest'],
             'run_mode': record['run_mode'], 'product_kind': record['product_kind'],
             'evidence_tier': V.producible(record['run_mode'], record['schema'])[1],
             'window': None, 'outcome_opened_at_freeze': False, 'frozen_at_utc': utc_now()}
        content_name, file_name = product_digest_names
        r[content_name] = record['canonical_content_digest']
        r[file_name] = sha256_hex(raw)
        return r

    def freeze_forecast(self, record: Mapping, declaration: Mapping) -> dict:
        """C1 then D1. The record must already be valid; it is validated again from the file bytes."""
        self._before_terminal()
        validate_forecast(record, declaration)
        raw = self._write('forecast', record)
        frozen = json.loads(raw)
        validate_forecast(frozen, declaration)
        receipt = self._receipt(V.FREEZE_RECEIPT, frozen, raw, ('forecast_content_digest', 'forecast_file_sha256'))
        receipt.update(cohort_id=None, status_at_freeze=status_at_freeze(frozen))
        validate_freeze_receipt(receipt, frozen)
        self._write('forecast_receipt', receipt)
        self.receipts.append(record_digest(receipt))
        return receipt

    def freeze_diagnostic(self, record: Mapping, declaration: Mapping) -> dict:
        """C2 then its diagnostic receipt."""
        self._before_terminal()
        validate_diagnostic(record, declaration)
        raw = self._write('diagnostic', record)
        frozen = json.loads(raw)
        validate_diagnostic(frozen, declaration)
        receipt = self._receipt(V.DIAGNOSTIC_RECEIPT, frozen, raw,
                                ('diagnostic_content_digest', 'diagnostic_file_sha256'))
        validate_diagnostic_receipt(receipt, frozen)
        self._write('diagnostic_receipt', receipt)
        self.receipts.append(record_digest(receipt))
        return receipt

    def terminal(self, outcome: str, reason: str) -> dict:
        """D2, written once. SUCCESS names every receipt issued; any other outcome names none, so
        receipts issued before a failure stay on disk, unnamed and never consumable (E2R-R38A)."""
        self._before_terminal()
        if outcome == 'SUCCESS' and not self.receipts:
            raise ValueError('SUCCESS needs at least one receipt')
        t = {'schema': V.TERMINAL, 'run_id': self.request['run_id'], 'game_id': self.request['game_id'],
             'method_id': self.request['method_id'], 'variant_id': self.request['variant_id'],
             'method_revision': self.request['method_revision'],
             'target_draw_number': self.request['target_draw_number'], 'execution_path': self.execution_path,
             'outcome': outcome, 'outcome_reason': reason,
             'registry_entry_digest': self.request['registry_entry_digest'],
             'receipt_digests': sorted(self.receipts) if outcome == 'SUCCESS' else []}
        validate_terminal(t)
        self.terminal_written = True
        self._write('terminal', t)
        return t

    def _before_terminal(self):
        if self.terminal_written:
            raise ValueError('the terminal record is already written; nothing follows it')


def read_run(folder: Path, declaration: Mapping, *, gates_pass: bool) -> dict:
    """Read a run folder and decide, for each output, whether it is consumable (E2R-R38A).

    Read-only. Missing or unreadable files make the output not consumable; nothing is repaired,
    moved or deleted. `gates_pass` is the caller's result for every existing group and firewall gate.
    """
    def load(key):
        p = Path(folder) / FILES[key]
        if not p.is_file() or p.is_symlink():
            return None
        try:
            return json.loads(p.read_bytes().decode('ascii'))
        except (ValueError, UnicodeDecodeError):
            return 'UNREADABLE'
    terminal = load('terminal')
    result = {}
    for out_key, rec_key in (('forecast', 'forecast_receipt'), ('diagnostic', 'diagnostic_receipt')):
        output, receipt = load(out_key), load(rec_key)
        if output is None and receipt is None:
            continue
        if not isinstance(output, dict) or not isinstance(receipt, dict):
            result[out_key] = (False, 'OUTPUT_OR_RECEIPT_MISSING_OR_UNREADABLE')
        elif terminal == 'UNREADABLE':
            result[out_key] = (False, 'INVALID_TERMINAL_RECORD: unreadable')
        else:
            result[out_key] = consumable(output, receipt, terminal, gates_pass=gates_pass, declaration=declaration)
    return result
