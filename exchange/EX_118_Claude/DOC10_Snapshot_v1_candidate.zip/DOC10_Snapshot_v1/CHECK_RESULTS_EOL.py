#!/usr/bin/env python3
"""DOC-10 (EX_117 C03): read-only check that every tracked file under results/ has LF line endings in the working tree.

It runs only `git ls-files --eol -- results` and reads its output. It imports no project code, opens no record file and
changes nothing. Accepted: `w/lf`, and `w/none` (an empty file). Anything else (`w/crlf`, `w/mixed`, a missing working
file) is EOL STOP: do not continue, commit or push; send Claude the output. Do not try to repair anything yourself.
Usage (repository root):  python CHECK_RESULTS_EOL.py --repo .
"""
import argparse, subprocess, sys

ap = argparse.ArgumentParser()
ap.add_argument('--repo', required=True)
repo = ap.parse_args().repo
r = subprocess.run(['git', '-C', repo, 'ls-files', '--eol', '--', 'results'], capture_output=True, text=True)
if r.returncode != 0:
    print('EOL STOP: git ls-files failed:', r.stderr.strip())
    sys.exit(1)
bad, n, empty = [], 0, 0
for line in r.stdout.splitlines():
    meta, _tab, path = line.partition('\t')
    w = next((p for p in meta.split() if p.startswith('w/')), 'w/?')
    n += 1
    if w == 'w/lf':
        continue
    if w == 'w/none':
        empty += 1
        continue
    bad.append(f'{w:8} {path}')
if n == 0:
    print('EOL STOP: no tracked files under results/ (wrong folder?)')
    sys.exit(1)
if bad:
    for b in bad:
        print('  ' + b)
    print(f'EOL STOP: {len(bad)} of {n} tracked files under results/ are not LF in the working tree. Do not continue, '
          'commit or push. Send Claude this output; Claude gives the exact owner-run restore commands.')
    sys.exit(1)
print(f'EOL PASS: {n} tracked files under results/, all w/lf ({empty} empty, w/none). Read-only: nothing changed.')
