#!/usr/bin/env python3
"""Read-only installation verifier for E2R-CODE-1 (the E_2-readiness contract library; register v0.11).

Claude, 28 October 2026. Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 156 new paths are absent; guarded files unchanged in Git.
  post       after copying the overlay: exactly the 156 new paths appear, all with the expected
             bytes (CRLF tolerated: the comparison is on LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly
             those paths and nothing else, all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_E2R_CODE1_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = '2f4e84e1d8454e847fdfd7d8e832adb0d0187460'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/Predictive_Randomness_E2R_Code_Scope_v0_1.md': '2d0b0c6acf2f77a518276e24c1c69f6ab3c065ddda26b1cf153cbce0f50c08a1',
    'doc/RATIFICATION_REGISTER_v0_11.md': '704dbd6383fcef5a4501b8dbc867eedcdabd8df82d1945e80dcddb5a2e0996ea',
    'review/E2R_CODE1_EX034_Corrections_v0_1.md': 'a0a55f77d12bdb02b5962b4f8fb52615d264a91852c1b2f8f523a005e6110fe7',
    'review/E2R_CODE1_Implementation_Notes_v0_1.md': '0946f5dc9bc2846bcd2be2ffe9a266cdbff3c740f18707693bdcbb39ebcc3698',
    'review/E2R_CODE1_Install_v2/INSTALL_MANIFEST_SHA256.txt': 'cb60b3c8e272d76d7dd1221a2f49de518b6d8977895942b332e10b1aa915452b',
    'review/E2R_CODE1_Install_v2/code_v1_to_v2.diff': '38b001c8bc22049cac34263363b3659bd29d5975233becc3b65565007296585d',
    'review/E2R_CODE1_Install_v2/e2r_mutation_checks_linux.txt': '70313f85bc950e534e7a4e445a603328d2a967e91a25252a78149af800cf92cc',
    'review/E2R_CODE1_Install_v2/r4_oracle_agreement_linux.txt': '201f6424945caf66a741dcfe3222af9ddb676ef8f6301ea3c1edfd2d6330c229',
    'review/E2R_CODE1_Install_v2/suite_e2r_linux_py313.txt': '921b32fc1ca78a00b4d398eb19ba3000e3b50c58c92a7acb894c3e0f66bb6c31',
    'review/E2R_CODE1_Install_v2/suite_e2r_linux_py315b4.txt': 'ae9871371bef41deb167c8cce60cadd8d88828f3375dbc5d1612acfd2fb40ca8',
    'review/E2R_CODE1_Install_v2/tools/build_contract_data.py': '6cbb05012f820033170b9f223dc90ff132aa641768c77eb2c6d951f627c8da78',
    'review/E2R_CODE1_Install_v2/tools/e2r_mutations.py': 'f8442402e80307a6bd8ad59ea5416a9b15a6101361eded85b9b493d661580c93',
    'review/E2R_CODE1_Install_v2/tools/e2r_oracle_export.py': '946b16585ed983cf2c86f516715619292299a0bd7676c966b10ddcf17e12e652',
    'review/E2R_CODE1_Install_v2/tools/make_register_v11.py': '62f37fcf46ec3d34a45b3ee6c77fb08c4194373815bbe100d1c84cfd77717fd8',
    'review/E2R_CODE1_Install_v2/tools/r2_method_names.json': '9bf2ffb7710518919fb2b4e304fed8b0d2f897bcac9fedbc97333a89ff307c57',
    'review/Independent_ChatGPT_E1ALIGN_Code_RECHECK_v0_1.md': 'a7177012fafdedc44910f2a58c0721e0e6b89bc0b448b9b34454bd5099f8077d',
    'review/Independent_ChatGPT_E2R_CODE1_HIGH_RECHECK_v0_1.md': '5b6eceb15d7e9e88aee50a9109fd53041aab18a625255c3654541d855c4794fc',
    'review/Independent_ChatGPT_E2R_Code_Scope_Review_v0_1.md': '409d105c40afe6916dfaf5d0bf270b6bfe0e08c637bbf10e85e974442e183cff',
    'review/Independent_ChatGPT_Register_v0_10_Review_v0_1.md': '03c8dce49c764d8f515cc494a306c81c437cf213f873bc36a93c8f015b7e77ce',
    'review/Independent_E2R_T05_Oracle_Plan_v0_1.md': '95f13ae03780809b69006562631cbebe0313fd89c1d1d39033f06c2f23416e69',
    'review/Independent_E2R_T05_Oracle_v0_1.py': 'fe24b53a49330666d0478bed20e92368660bd407edeb011c7eaab9ccc7772aee',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_1/FULL_HISTORY_RAW_COUNTS_V1/r1.json': 'd800c99b0faa66377d2acd422b63a41129cd9a6f9b11870e7ce0b3b9bf3d833d',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_1/FULL_HISTORY_RAW_COUNTS_V1/r1.json': '678ef411ddd04a325e7adc7ceb52b47a90818904007373f95375523c1e3d426e',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_1/FULL_HISTORY_RAW_COUNTS_V1/entry_0001.json': 'bf39ed497665b6b99e86aaf633c4482ceb63176f1c7643eac804d5e761fb8d28',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_10/NOT_YET_SPECIFIED/entry_0001.json': '1d659628637eeaa5bdd5f446c540ed5bc75540300d8f1f44acdfa9d6cc30f825',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_11/NOT_YET_SPECIFIED/entry_0001.json': '10bbf0965ea16616e22cc62b29fab79fb97bde5c104c9f0c0751bf83c640c878',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_12/NOT_YET_SPECIFIED/entry_0001.json': 'd1e4aa8daba3f57e31a8064c4aa24bbf1ef5fbcae86ac3dcffa812de6957b793',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_13/NOT_YET_SPECIFIED/entry_0001.json': '12e195df900a712eb0232257e8b6fb4ade53a6837f321bdbb005d3500650be07',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_14/NOT_YET_SPECIFIED/entry_0001.json': '0a8779378a2a48e5db81d7349063464ce25c163dcddbfe3545dbea8169bade19',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_15/NOT_YET_SPECIFIED/entry_0001.json': '85caccac231409d8f002729c64a87fe1d1fcefb81a8ec67d7eb48a87cbe32b25',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_16/NOT_YET_SPECIFIED/entry_0001.json': '4ccd377595cbd936ce5189d8fa618d912f332c223fbd325c64e13880304a7127',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_17/NOT_YET_SPECIFIED/entry_0001.json': 'd347320ff3e595d57f26e96daabd927172fb4a73fcd7410914176c6968f650ed',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_18/NOT_YET_SPECIFIED/entry_0001.json': 'ece98a31f70abbd3908c4c127d3c30979c700bcccb76a3b689622992e4d4020d',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_19/NOT_YET_SPECIFIED/entry_0001.json': '817637a3af9d41009cd0be83a7918ab1ca6bf3dd8ebf55336ea0b0dff0dc20de',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_2/NOT_YET_SPECIFIED/entry_0001.json': 'f52e82c332269334a76f5868d19774b642cfd40775fcf8a09d99b141f7bd18df',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_20/NOT_YET_SPECIFIED/entry_0001.json': 'e07fed3a90e6e88e24777c7057c2f8a5cb5019bdcfdb159b40b6b536b3a7ef90',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_21/NOT_YET_SPECIFIED/entry_0001.json': 'efccf2dde9163951d270d0b437e5d1577681ca6cf66d32c3a0a0203d7410dacb',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_22/NOT_YET_SPECIFIED/entry_0001.json': 'b100d03e129d2d675465b2fef9f768cdef3f9ddbe3f3fbcff3d404528553d84d',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_23/NOT_YET_SPECIFIED/entry_0001.json': 'fcc1e1f1892b3d34b22d7c4b659962fc5ee39309c4c732f31b16a70d5c310463',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_24/NOT_YET_SPECIFIED/entry_0001.json': '204782a02210e328034e6abd9342105abacfcff91dce12f152703f420cec2fd2',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_25/NOT_YET_SPECIFIED/entry_0001.json': '6166199a40e300e0400f8c38712ee6e524fcc9a637cd1f88a30f47ff5436fc52',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_26/NOT_YET_SPECIFIED/entry_0001.json': '03c7dd50a08d77ddcb171c3825443d15781f57895bc8713caa34ef8063d24c50',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_27/NOT_YET_SPECIFIED/entry_0001.json': '790573c2bbcf33ac3febbaed2b4ead1016797e0cc3a407dea5009aeb473f535d',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_28/NOT_YET_SPECIFIED/entry_0001.json': '31e5dae56181e7c0afc65d7a9412e4f25184fda4764aee3c06a61d528ab71beb',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_29/NOT_YET_SPECIFIED/entry_0001.json': 'a10a10da34066c29ea6deb5c457c23062c4a1f06050004e9ba25d96906a14f95',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/NOT_YET_SPECIFIED/entry_0001.json': '8873fe2102b037099755951da8f6c1d75951a902c3ca7179dc913b3de2f8ceee',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_30/NOT_YET_SPECIFIED/entry_0001.json': 'cf75abffeb7bb29b7c9c302f850dec7963c7ef00f9f6e3702e481fa8e16501bc',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_31/NOT_YET_SPECIFIED/entry_0001.json': '085c64a0bd9aee67f0261ea59a5a5a177293757ae12d66b76c2f1ef2067d65e0',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_32/NOT_YET_SPECIFIED/entry_0001.json': '339f92524c13ac4370c76bbd6e20bb476eba98fc6204f25587278b7fadc304a9',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_33/NOT_YET_SPECIFIED/entry_0001.json': '44c241f73581676df969f1c011766b6141d11c025355452a74620ae24df3595d',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_34/NOT_YET_SPECIFIED/entry_0001.json': '862fa1d64cbf788290cff78f20000e4f02530c5fcee0b070733ac0f9de83b57a',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_35/NOT_YET_SPECIFIED/entry_0001.json': 'b615126158098a028376ffb4fa8bf65b84eb92f6a65a873a574bdd3634890a6c',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_36/NOT_YET_SPECIFIED/entry_0001.json': 'd370bc41383da215520ec98f0039900d410733daecbbe478644bdbe9a60d0ebe',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_37/NOT_YET_SPECIFIED/entry_0001.json': '8457f291918130c9458c9ee432b0ea189caee027b2465a6d315abe00c3750010',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_38/NOT_YET_SPECIFIED/entry_0001.json': 'a07cc051b8698bf3e7632e4684523523c281f86476f2144c79b85d3f39d91fbc',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_39/NOT_YET_SPECIFIED/entry_0001.json': 'c8144148501ff7741af35630cbc519588c63f06506ea6d597e29a30149de06d5',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/NOT_YET_SPECIFIED/entry_0001.json': '5b9eb0a7dba26f79b7d2c5607ba2b0023431c91f4d0d70d5cc428960abf26b1c',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_40/NOT_YET_SPECIFIED/entry_0001.json': '0bc4e870195af079d8fb7784a1d899c53e5d59533abdca0cc895888b8e354530',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_41/NOT_YET_SPECIFIED/entry_0001.json': '9746ba2dc40df037ba2a2f4ecde654a169702ab326490a026b439f3ce87a170e',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_42/NOT_YET_SPECIFIED/entry_0001.json': '783915c944dc6fd7b49246ad758d2e76b6780f0cec5f0f3ae3f5ee2d6e2d0778',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_43/NOT_YET_SPECIFIED/entry_0001.json': '536d8b711bf73db3360dc836f6fa2af04fae641c2123ae06d1307945b8185697',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_44/NOT_YET_SPECIFIED/entry_0001.json': '3971dce486f76a85d4c87febd7850699ac3d6eb2447e6d71ac4f8efe14eb84c4',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_45/NOT_YET_SPECIFIED/entry_0001.json': '5c433bb791e2b291c7971a7d27c091b86132007425fbc0188434b3d00899d0e3',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_46/NOT_YET_SPECIFIED/entry_0001.json': '2359875946452339918ccd8581b969c937ce39e636dc27f2fef4f3b355ff3022',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_47/NOT_YET_SPECIFIED/entry_0001.json': 'dcda64bc5d6f56be5a37a31799dbaa60c5a71185a6134bed6320caf1a344fa22',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_48/NOT_YET_SPECIFIED/entry_0001.json': 'a2804681ef9e97ac83d03eff59c3495100407b7812950d2b813eb84a145da17b',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_49/NOT_YET_SPECIFIED/entry_0001.json': '5eb60f6bb67d1b210925c7774727f3527580ac00796850bcdd19e23cc81b7ef0',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_5/NOT_YET_SPECIFIED/entry_0001.json': '474af964cf98b145e6c4fa8f2dc9313f5da57d65afa65c1cd94a7440ce05b4d7',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_50/NOT_YET_SPECIFIED/entry_0001.json': 'e3944f4988972ffe758d2edd0ce70242404c0906bf8852ab852bbbfe04809cad',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_51/NOT_YET_SPECIFIED/entry_0001.json': '81ca3e04e58569ebf8feae07686c4ef28978493f3854cf7255dfb21d8434b289',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_52/NOT_YET_SPECIFIED/entry_0001.json': '064b31ae77f66c6c66451636099effeaaca5ee94c3990e7bcc5dc369bab76c21',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_53/NOT_YET_SPECIFIED/entry_0001.json': '2268938c7034a6c4e6d8c0271631646f530a76a6a90284321ef028eeb7997077',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_54/NOT_YET_SPECIFIED/entry_0001.json': '4d8d03ee9cfcec5d7d81cc22b3766c5626643b0fe605398fd2c5533529eb5eb0',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_55/NOT_YET_SPECIFIED/entry_0001.json': '34a87d1ac979bddc03bcec054ee13dd5f9ce5e1b17bce7bb2281d609edf82b1a',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_56/NOT_YET_SPECIFIED/entry_0001.json': '7fe28fefbe235695c9fd9722a920d8819db53b891b6fb1b27982531fa6930c82',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_57/NOT_YET_SPECIFIED/entry_0001.json': '7f5ba42ab83fc9f4d486d2c63dbca4567c3e29eca8c0c4f9284dde9cecd3100a',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_58/NOT_YET_SPECIFIED/entry_0001.json': '32259b416be6e3acbf629c896db71a6ae3b0fb2a39cfe6af84adc8d0c9a718eb',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_59/NOT_YET_SPECIFIED/entry_0001.json': '314c65deb9d49e775a9c559bf7b71483688a86f32ec9d08da997a70e3fa7a701',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_6/NOT_YET_SPECIFIED/entry_0001.json': '2020dadf77b9640b8aa3dbc63c607d235036235f546cbbf7b73735904278ac9a',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_60/NOT_YET_SPECIFIED/entry_0001.json': 'e27b7a1de1c2c04ae952b89709b8caaed43b19f25cda59c214e2d1596687ab1e',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_61/NOT_YET_SPECIFIED/entry_0001.json': 'cce520a33320b38db09bdcf5812c74c7cec9f80d6bacea62adea38fb0851a615',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_62/NOT_YET_SPECIFIED/entry_0001.json': '26cc8c8bcb2e81d77807c6bbc1520ce890a45c7e3a985ced9e0270d572d66719',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_7/NOT_YET_SPECIFIED/entry_0001.json': '0c47a72d419435686e03a8a37a5751b9b38da78ee67a7e138f01fbce4a6db801',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_8/NOT_YET_SPECIFIED/entry_0001.json': 'b5602b7dca16815d46039a8e7ca2a49b4305d82e3fa5403bcea3de589b3f4dad',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_9/NOT_YET_SPECIFIED/entry_0001.json': 'ed05c8596ec9cb1cb19774d76ecdab7d259898c99bc5436e435820cde6e19604',
    'src/methods/_common/contract_data/registry/POWERBALL/E_1/FULL_HISTORY_RAW_COUNTS_V1/entry_0001.json': '544891641041f27ba5ac66ef7b8910945eb0a1c95261c27115372e365eba86bc',
    'src/methods/_common/contract_data/registry/POWERBALL/E_10/NOT_YET_SPECIFIED/entry_0001.json': 'daa7d24a9ffc42f3e5ce1a06137c683e3a1bd21121de0320399b5e2098dacd1f',
    'src/methods/_common/contract_data/registry/POWERBALL/E_11/NOT_YET_SPECIFIED/entry_0001.json': '35698577a97be52b197cdac33e0d1d4454b46e66d2959921b280c1dbb8ad5ec7',
    'src/methods/_common/contract_data/registry/POWERBALL/E_12/NOT_YET_SPECIFIED/entry_0001.json': '0cb0828c3a140add7bb7e012a07ecac9c4edc84fe184de48cd51984f6ee87b44',
    'src/methods/_common/contract_data/registry/POWERBALL/E_13/NOT_YET_SPECIFIED/entry_0001.json': '317273a6f74a7359ff37c78a294da7aa625e4b98e6927114c713cea2764896e8',
    'src/methods/_common/contract_data/registry/POWERBALL/E_14/NOT_YET_SPECIFIED/entry_0001.json': '56bfd2d432263922bda0bfa116b821e0748f8c425fed96fbb83bbaf285c816c9',
    'src/methods/_common/contract_data/registry/POWERBALL/E_15/NOT_YET_SPECIFIED/entry_0001.json': '59103b8e248be6307af1cf5253b741eb39b1d713b7d2dbccebbb0e1a367b2cfb',
    'src/methods/_common/contract_data/registry/POWERBALL/E_16/NOT_YET_SPECIFIED/entry_0001.json': '38c8e1710c2b5d134230cb2524241618d2d3e2dc90713a8f2daa20ce625d0d36',
    'src/methods/_common/contract_data/registry/POWERBALL/E_17/NOT_YET_SPECIFIED/entry_0001.json': 'c1c8562000c1b15ac5579da8e033a8744e82a016c3e758ac6b4fd067a26db7a6',
    'src/methods/_common/contract_data/registry/POWERBALL/E_18/NOT_YET_SPECIFIED/entry_0001.json': 'dd915b1a8c5a07c51763d59e19f820966405f628dc26bdaa138f77aef4337dd2',
    'src/methods/_common/contract_data/registry/POWERBALL/E_19/NOT_YET_SPECIFIED/entry_0001.json': 'cf94e16147ab807f9ed6e60cac8346fd9fa229595e6acdbc7e89211414dc8216',
    'src/methods/_common/contract_data/registry/POWERBALL/E_2/NOT_YET_SPECIFIED/entry_0001.json': '73f57ea86f48b865b515c5857725bec32d9ee784e7c6faf966e3e24d3c97c8d2',
    'src/methods/_common/contract_data/registry/POWERBALL/E_20/NOT_YET_SPECIFIED/entry_0001.json': '02bce1f8f13753a5aee3f9c40689ce9f3823e37923b4b640358d5e0b07519985',
    'src/methods/_common/contract_data/registry/POWERBALL/E_21/NOT_YET_SPECIFIED/entry_0001.json': '8f4ca7322e969a1daad82f07d5a6211800af350fe5e0f7844f6948d3da4d0763',
    'src/methods/_common/contract_data/registry/POWERBALL/E_22/NOT_YET_SPECIFIED/entry_0001.json': '031d83da799cfd065c5537a7ca89c4e648eb018f7365325d8614f4e8364c1468',
    'src/methods/_common/contract_data/registry/POWERBALL/E_23/NOT_YET_SPECIFIED/entry_0001.json': '0a78c70b6d9615bee0389088629ce859b581c780aec381cc7176727d65b2b4a7',
    'src/methods/_common/contract_data/registry/POWERBALL/E_24/NOT_YET_SPECIFIED/entry_0001.json': 'be25aacd4db53dd1be58044b39776b139753403282771d452ffb9d90ea58cf8d',
    'src/methods/_common/contract_data/registry/POWERBALL/E_25/NOT_YET_SPECIFIED/entry_0001.json': '3c482809d89559d435dfc0e1a8d6b0801753ba6c0ad6f10d0472aba991a3ce06',
    'src/methods/_common/contract_data/registry/POWERBALL/E_26/NOT_YET_SPECIFIED/entry_0001.json': 'bcc4de4293e22d96a66b589b722d3208b90a6b3ddc781b6325d8e4053321336e',
    'src/methods/_common/contract_data/registry/POWERBALL/E_27/NOT_YET_SPECIFIED/entry_0001.json': '1f11f3f8eef1b44268c62176490e5879589ba37d5309eb5405563e8808833022',
    'src/methods/_common/contract_data/registry/POWERBALL/E_28/NOT_YET_SPECIFIED/entry_0001.json': '36f90c4b5e484d8f2fd4bc105ee9970b8ace6977d8ba24f11ba6532158247888',
    'src/methods/_common/contract_data/registry/POWERBALL/E_29/NOT_YET_SPECIFIED/entry_0001.json': '47e6056aaa5d64a28f2e54d0bd551c81dfc949561461735d3b7d3d48a508bddc',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/NOT_YET_SPECIFIED/entry_0001.json': '10d435477b6f9ce542ed85b44e341e501f8f35d0ffb8c67569100d80b7438ef8',
    'src/methods/_common/contract_data/registry/POWERBALL/E_30/NOT_YET_SPECIFIED/entry_0001.json': 'b3c11d6c2277a86f4df9f1f6d7c2c04e894aee06c752cdb060627ac85f52b3ef',
    'src/methods/_common/contract_data/registry/POWERBALL/E_31/NOT_YET_SPECIFIED/entry_0001.json': '3d3af64a8ebbd635ef05b789ecf7d429c6f871133a793e5beaae60d2d45a2029',
    'src/methods/_common/contract_data/registry/POWERBALL/E_32/NOT_YET_SPECIFIED/entry_0001.json': 'ecf63dc78d1167e02b1e1a972d7df75c14d7e3ba863a0164d97723610e98ddc0',
    'src/methods/_common/contract_data/registry/POWERBALL/E_33/NOT_YET_SPECIFIED/entry_0001.json': '5141ae913c7f66855fe0e2c12b6a3b960449e42112a38ff713297ce719f234f9',
    'src/methods/_common/contract_data/registry/POWERBALL/E_34/NOT_YET_SPECIFIED/entry_0001.json': '73107056759aed75334a5b81872b0fcdf5c53cb699cd79153107979d3e55daec',
    'src/methods/_common/contract_data/registry/POWERBALL/E_35/NOT_YET_SPECIFIED/entry_0001.json': 'fbd1e863fad8c1758b2ab9dee860f7fc6efb9878de154f7dbd92467393999d20',
    'src/methods/_common/contract_data/registry/POWERBALL/E_36/NOT_YET_SPECIFIED/entry_0001.json': '10372215ec6739bd2282bd9effc98688d5e0e9f06723b3c2ab43ce5d1cb3223b',
    'src/methods/_common/contract_data/registry/POWERBALL/E_37/NOT_YET_SPECIFIED/entry_0001.json': '7704a8492ff1cd0c53b4e51aa9f4c59f33193ea2a583172eee2b2ae7e11d88e3',
    'src/methods/_common/contract_data/registry/POWERBALL/E_38/NOT_YET_SPECIFIED/entry_0001.json': '288a9fce1bdef0cc1cd4c08a11bf38bfa60c2d9538bb77da51e182ad2fd7e891',
    'src/methods/_common/contract_data/registry/POWERBALL/E_39/NOT_YET_SPECIFIED/entry_0001.json': '3f81ebf2ae2dd2e951e65ded4cdff20cb15ee0447ec8236d238045bfd09f8536',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/NOT_YET_SPECIFIED/entry_0001.json': '3b3b30fc7269901c2a40c4ead28523cbf3d7fb597de318e13270e4661127bc20',
    'src/methods/_common/contract_data/registry/POWERBALL/E_40/NOT_YET_SPECIFIED/entry_0001.json': '36e46aafc511e81aaa636aefa9b43a1fab27b62b62c9463a1297da64c2e70c9a',
    'src/methods/_common/contract_data/registry/POWERBALL/E_41/NOT_YET_SPECIFIED/entry_0001.json': '43f9f3739a5f4a710c63c7d16331b84ec2264324dd4a780f0cc80999010da184',
    'src/methods/_common/contract_data/registry/POWERBALL/E_42/NOT_YET_SPECIFIED/entry_0001.json': '60415e71c73b3392c74f3cbe5f90a301479d7a1e23132961765b962201bd90e6',
    'src/methods/_common/contract_data/registry/POWERBALL/E_43/NOT_YET_SPECIFIED/entry_0001.json': 'bc46287e344108a863fd6b7a5f0da96217f9859374814d3a92238f3c008b81f6',
    'src/methods/_common/contract_data/registry/POWERBALL/E_44/NOT_YET_SPECIFIED/entry_0001.json': '488b95325ed893619dd4a4003e117401f6841b750e35c38bf1e15303f4bdf794',
    'src/methods/_common/contract_data/registry/POWERBALL/E_45/NOT_YET_SPECIFIED/entry_0001.json': '5ffb4fd144346a72097fb419f1e248e7e425c53dd6bf595136a3e37dd1508f10',
    'src/methods/_common/contract_data/registry/POWERBALL/E_46/NOT_YET_SPECIFIED/entry_0001.json': 'e49ee1eeeeb78a6382aaf90416d69431a35a5b077ec925769c28283739d5b965',
    'src/methods/_common/contract_data/registry/POWERBALL/E_47/NOT_YET_SPECIFIED/entry_0001.json': 'f64c13109ce2dc4e1d19a99acc657d7dbcb912120b7f2fe8209dd02c5af2714f',
    'src/methods/_common/contract_data/registry/POWERBALL/E_48/NOT_YET_SPECIFIED/entry_0001.json': 'dd2acccf49326187ae193f67e9ba44316143bce7a6b35686b19a150a132f588a',
    'src/methods/_common/contract_data/registry/POWERBALL/E_49/NOT_YET_SPECIFIED/entry_0001.json': 'd65ddba2d5908fd74ba753d4d86885f78a197c0e9ff9974c4f24938898c225b5',
    'src/methods/_common/contract_data/registry/POWERBALL/E_5/NOT_YET_SPECIFIED/entry_0001.json': '0643b8db6d094d0fc4b502a78359bdc7f6322cd4f3b91664286b35b196b2b2a7',
    'src/methods/_common/contract_data/registry/POWERBALL/E_50/NOT_YET_SPECIFIED/entry_0001.json': '9042887349e4d82d1d501fdb3b6ab5d335a9436800160988c40d1d42ed8296ba',
    'src/methods/_common/contract_data/registry/POWERBALL/E_51/NOT_YET_SPECIFIED/entry_0001.json': 'e175c5ade0e1c171c956a015e1c6d0c3e5cbc3c53ce15ec0270046317159c7d9',
    'src/methods/_common/contract_data/registry/POWERBALL/E_52/NOT_YET_SPECIFIED/entry_0001.json': '61c22ea522c83ae574f1393f657f1404f5f1855df09d38008a72cbfad3e29ea6',
    'src/methods/_common/contract_data/registry/POWERBALL/E_53/NOT_YET_SPECIFIED/entry_0001.json': 'de4e8b84fb01a19105795916fbaf4ae8d7d4c4eb282e9697d1ece24f2bf89a36',
    'src/methods/_common/contract_data/registry/POWERBALL/E_54/NOT_YET_SPECIFIED/entry_0001.json': '6926bfbae6c80ae0aeb98fa8bb637cc67074ebde4030f8602ee5772265dfded4',
    'src/methods/_common/contract_data/registry/POWERBALL/E_55/NOT_YET_SPECIFIED/entry_0001.json': 'e8129a4f6d977456d420a7b83d54fb7bd05bfc691f0b7859443097e42146e9e2',
    'src/methods/_common/contract_data/registry/POWERBALL/E_56/NOT_YET_SPECIFIED/entry_0001.json': '55185e0c1a8083b9fc9940759b769f965c77f4311a999b1c3ca187367d4e8531',
    'src/methods/_common/contract_data/registry/POWERBALL/E_57/NOT_YET_SPECIFIED/entry_0001.json': '875a6c938252d02c46b1d72ebee2c217bee54ff529f479e3af78877d1775f647',
    'src/methods/_common/contract_data/registry/POWERBALL/E_58/NOT_YET_SPECIFIED/entry_0001.json': '9a322548eacff22e3f71217ee39f7d337f130653c76d36db5cef5766b25d7ad9',
    'src/methods/_common/contract_data/registry/POWERBALL/E_59/NOT_YET_SPECIFIED/entry_0001.json': '489264735b23ad63df30696d4f2039509be6e39247dbe3c788fd59cea5e4ac29',
    'src/methods/_common/contract_data/registry/POWERBALL/E_6/NOT_YET_SPECIFIED/entry_0001.json': 'acdc145972e6372c756a0a1c064890e19787c830efaabcbc3c166da403240dee',
    'src/methods/_common/contract_data/registry/POWERBALL/E_60/NOT_YET_SPECIFIED/entry_0001.json': '5242b719e6589d66cee897740d4b81aefe0f89f04ce33e9eb281ca96d3fbc5e0',
    'src/methods/_common/contract_data/registry/POWERBALL/E_61/NOT_YET_SPECIFIED/entry_0001.json': '1740b94d9dc8684c028d565d52a8006ee69808a1d0b03e7d85da61c2257eafc2',
    'src/methods/_common/contract_data/registry/POWERBALL/E_62/NOT_YET_SPECIFIED/entry_0001.json': 'c3e96488462b974d22bbe1903eea15c2d7c93a6f43d7e269f0f708dca3cf4694',
    'src/methods/_common/contract_data/registry/POWERBALL/E_7/NOT_YET_SPECIFIED/entry_0001.json': '30d0c3cf68e21cfe96fd6d0d0b0efcec996151830596aa470738063f313987dc',
    'src/methods/_common/contract_data/registry/POWERBALL/E_8/NOT_YET_SPECIFIED/entry_0001.json': '7d2ac52dbdbcc7f3f41b0bd30e787e20b4c6f47d92d9089480ebe64f38bddbe6',
    'src/methods/_common/contract_data/registry/POWERBALL/E_9/NOT_YET_SPECIFIED/entry_0001.json': '3ebf3849e34e323e21934771fee9273dfdddd1ca34361fac232a0ea12f478f84',
    'src/methods/_common/contract_forecast.py': 'be88a1d640098a6990f14090108524e1d7437a425e1b6254672164b6fc7f8121',
    'src/methods/_common/contract_receipts.py': 'e6d159e65dcf8269ea5576a7338d3ebcbf2d5dc0c06b06f1517189cc215908fd',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/methods/_common/contract_registry.py': '00082aad1754edbf2380c2caa144b0c79a12e2b6f26eb806d85903f177f11064',
    'src/methods/_common/contract_task.py': 'e58c0ab288b3292d3eeaf49e7cf9170b0341ff53d23cbde839b8cdbd716a31b3',
    'src/methods/_common/contract_vocab.py': '6e30b5be8d024fa647a2406e38b44cdf3b3c0c84f0468d84e168e9fde40d4ec8',
    'tests/e2r_fixtures.py': '6755c9fe44ba2d222d2522cd81090c11044f59c2e2344e4bd27b9f02ecab643d',
    'tests/test_e2r_contract.py': 'eda52fa4046831cb78cec075c05c810cce09d16824553da6c70ad2207d82a3dd',
    'tests/test_e2r_prefix.py': '633bf1ee9b99b7d542012635175eff052329be8b8fe35bc23ecf3fbb3b662c4f',
}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'doc/RATIFICATION_REGISTER_v0_10.md': '8ee8307e3c98eabbf24743391c7ebb821e6700f8efa8a093996f97d3d43475a4',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r3.md': 'ddf4de23b726b2abf55ffcab613f926b62775469076476f939288a278e6422fc',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r4.md': '73b90ea348aea5fc337097a14ec4a8669258bc6cba55ce5a2485de26575f3f3a',
    'doc/Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md': '0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/canonical_encoding.py': '2096d8adb40737373169aea6c5d94147daa2b16ae6c961bbfcc6063e333efcac',
    'src/methods/_common/multigame_method_registry.py': '78693c06d109f584b3ce987baaf633028fb8d6eb036f4068006173754b46aacd',
    'src/methods/E_001_Historical_Appearance_Frequency.py': '3ee292f226be2a93a8222f6d7646fe7cc4dc140dbb345c535dd6a2e5b0f43b39',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in NEW.items():  # the package itself must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent. Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        need(all(ln.startswith('?? ') for ln in lines), 'changes other than new files:\n' + status[:600])
        changed = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines}
        need(changed == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(changed ^ set(NEW))))
        for p, h in NEW.items():
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in NEW.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    need(got == {p: 'A' for p in NEW}, 'the last commit did not add exactly the expected paths: ' + repr(sorted(got.items())))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
