# MHUPA_Slice2_Review_v1 - MHUP-A review slice 2, candidate v1 (Claude, 5 November 2026)

A REVIEW package, not an install candidate: nothing here is to be installed. See EX_147 (EX_141-EX_146 are slice 1).

- `overlay/` - every file of the development tree that differs from or is absent in the base tree (`main` at 2061055):
  69 files, at their repository paths (slice 1's reviewed files included, unchanged except the two test lines
  EX_147 section 1 names). `REMOVED_FILES.txt` lists the one file the tree removes.
- `tools/` - the scripts that build the development tree from the base by counted edits (slice 1 then slice 2), the
  updater v0.2 maker, the suite runner (expected counts) and both slices' mutation tools.
- `evidence/` - the Linux suite runs (Python 3.13 and 3.15.0b4, E2R-T12 included) and the slice 2 mutation output.
- `MHUP_A_work_item_card_v5.md` - the work-item card.

No file under source_data/, results/ or transitory_data/ is in this package or was read to make it.
