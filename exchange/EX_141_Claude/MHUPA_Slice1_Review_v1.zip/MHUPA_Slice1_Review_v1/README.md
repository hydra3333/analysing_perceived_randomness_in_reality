# MHUPA_Slice1_Review_v1 - MHUP-A review slice 1 (Claude, 4 November 2026)

A REVIEW package, not an install candidate: nothing here is to be installed. See EX_141.

- `overlay/` - every file of the development tree that differs from or is absent in the base tree (`main` at 2061055):
  41 files, at their repository paths.
- `tools/` - the scripts that build the development tree from the base by counted edits, the E_1 revision-2 reference
  maker, the slice's suite runner (expected counts) and the mutation tool.
- `evidence/` - the Linux suite runs (Python 3.13 and 3.15.0b4, E2R-T12 excluded) and the mutation outputs.
- `MHUP_A_work_item_card_v2.md` - the work-item card.

No file under source_data/, results/ or transitory_data/ is in this package or was read to make it.
