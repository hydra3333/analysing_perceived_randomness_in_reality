# DOC-3 - installation of H-1 v1r3 and register v0.9 (both owner-ratified 28 October 2026)

Windows CMD, repository root. Delete any earlier extracted `E:\TEMP\DOC3_*` folders, then save this ZIP to `E:\TEMP` and extract it there (`tar -xf "E:\TEMP\DOC3_Install_v1.zip" -C E:\TEMP`).

**Step 1 - bring your copy up to date and check it** (`git status --short` must print nothing; the pull must say `Fast-forward` or `Already up to date`):

```bat
git status --short
git pull --ff-only
python "E:\TEMP\DOC3_Install_v1\VERIFY_DOC3_INSTALL.py" --repo . --phase pre
```

Expected: `PRE PASS`. If the pull or PRE fails, stop and send Claude the output. Nothing has changed yet.

**Step 2 - copy, check, stage:**

```bat
xcopy "E:\TEMP\DOC3_Install_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\DOC3_Install_v1\VERIFY_DOC3_INSTALL.py" --repo . --phase post
call "E:\TEMP\DOC3_Install_v1\STAGE_EXACT_FILES.cmd"
git diff --cached --name-status
```

Expected: `6 File(s) copied` (all new; nothing is replaced or deleted); `POST PASS`; 6 lines starting with `A`. If POST prints `STOP`, stop and send Claude the output (nothing is committed; the copied files are only new files).

**Step 3 - commit and check the commit (do not push yet):**

```bat
git commit -m "DOC-3: H-1 v1r3 and register v0.9 (owner-ratified 28 October 2026)"
python "E:\TEMP\DOC3_Install_v1\VERIFY_DOC3_INSTALL.py" --repo . --phase committed
```

Expected: `COMMITTED PASS`.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** The verifier then prints the commit identities (HEAD, its parent, the commit's paths, anything not yet pushed, the working-tree status). Send Claude the whole output. Claude confirms from those identities exactly what the latest commit is, and only then gives you the exact recovery commands. Nothing has left your PC at that point.

**Step 4 - push, only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub. No test run is needed: no code changes. Claude pushes nothing to the repository while you install.
