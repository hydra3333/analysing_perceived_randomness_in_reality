@echo off
setlocal
rem OPTIONAL owner-run staging of exactly the 6 DOC-3 paths. No commit, push or deletion.
git add -- ^
  "doc\HANDOVER\Claude_Primary_Handover_H1_v1r3.md" ^
  "doc\RATIFICATION_REGISTER_v0_9.md" ^
  "review\DOC3_Install_v1\INSTALL_MANIFEST_SHA256.txt" ^
  "review\DOC3_Register_v0_9_candidate_to_final.diff" ^
  "review\Independent_ChatGPT_EX_016_DOC3_H1_v1r3_Register_v0_9_Review.md" ^
  "review\Independent_ChatGPT_EX_018_DOC3_Register_v0_9_r1_Recheck.md"
if errorlevel 1 (echo STAGING FAILED & exit /b 1)
git status --short
endlocal
