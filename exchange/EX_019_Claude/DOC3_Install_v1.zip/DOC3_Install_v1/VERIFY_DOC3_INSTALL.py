#!/usr/bin/env python3
"""Read-only installation verifier for DOC-3 (H-1 v1r3, register v0.9 and their review history).

Claude, 28 October 2026. Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; the 6 new paths are absent;
             guarded files unchanged in Git.
  post       after copying the overlay: exactly the 6 new paths appear, all with the expected
             bytes (CRLF tolerated: the comparison is on LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly
             those paths and nothing else, all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_DOC3_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = 'd8bb8d84338016c8b6803ff3857363282a9e8307'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r3.md': 'ddf4de23b726b2abf55ffcab613f926b62775469076476f939288a278e6422fc',
    'doc/RATIFICATION_REGISTER_v0_9.md': 'e84a7a208d99775bbbbf15af8a177d956c5a8e4819cf5b35537f6b70f5dfc6c8',
    'review/DOC3_Install_v1/INSTALL_MANIFEST_SHA256.txt': '60e16fcb4c55843b76dc0ab42bbc4424d0e3094661a27a34f48b8f54f23d9009',
    'review/DOC3_Register_v0_9_candidate_to_final.diff': '8e79ef9b7078dc8eb419f4c0a7a526e53fc3a4e26d5f6c879f281cd96f3eb559',
    'review/Independent_ChatGPT_EX_016_DOC3_H1_v1r3_Register_v0_9_Review.md': 'ff2b252195978ce70b08ef52626e74b52db26c437ba231627eb7ee9c09fe356d',
    'review/Independent_ChatGPT_EX_018_DOC3_Register_v0_9_r1_Recheck.md': '74042cb4060c96ff60604f55538fbfb22dabc596452a0d6f8d1a8ba9cd46b521',
}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r2.md': '55543ba522a4085fc4f2476d421a4940171bcd4c183a1fab5a691d291605eac0',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r3.md': 'a2fb5c641a6fa8010aa59ff811aeba23145703bd5c0d4e2dbd70ac2fb419edb1',
    'doc/RATIFICATION_REGISTER_v0_8.md': '3f217c6875d443a0cc1bba2f6c329b1fda455fb4a97bf7fe06090394736fffcf',
    'exchange/README.md': 'a20589e5c5bdeed043e78815f86b1a71679426f17528aedfb14aef7d72ed10ef',
    'review/NAMES1_Code_Install_v1/INSTALL_MANIFEST_SHA256.txt': '9d8664f38c33ee374ace06d29d98a4d84477af9199359e22bfcef84e1897f6a7',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'src/methods/_common/game_draws_reader.py': '9ed28e3db821272cbeb47725a587eaefb3d38a13f20403a549b82cd0cdd973e3',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in NEW.items():  # the package itself must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent. Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        need(all(ln.startswith('?? ') for ln in lines), 'changes other than new files:\n' + status[:600])
        changed = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines}
        need(changed == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(changed ^ set(NEW))))
        for p, h in NEW.items():
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    for p, h in NEW.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    need(got == {p: 'A' for p in NEW}, 'the last commit did not add exactly the expected paths: ' + repr(sorted(got.items())))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
