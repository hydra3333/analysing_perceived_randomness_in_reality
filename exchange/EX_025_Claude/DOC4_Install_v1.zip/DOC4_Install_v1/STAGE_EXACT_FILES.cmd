@echo off
setlocal
rem OPTIONAL owner-run staging of exactly the 8 DOC-4 paths. No commit, push or deletion.
git add -- ^
  "doc\HANDOVER\ChatGPT_Reviewer_Handover_H2_v1r4.md" ^
  "review\ChatGPT_Reviewer_Handover_H2_v1r3_to_v1r4.diff" ^
  "review\ChatGPT_Reviewer_Handover_H2_v1r4_fact_corrections.diff" ^
  "review\ChatGPT_Reviewer_Handover_H2_v1r4_initial_draft.md" ^
  "review\Claude_Fact_Check_H2_v1r4_v1.md" ^
  "review\DOC4_Install_v1\INSTALL_MANIFEST_SHA256.txt" ^
  "review\Independent_ChatGPT_EX_024_H2_v1r4_Final_Candidate.md" ^
  "review\Owner_Decisions_H2_v1r4_and_Exchange_v0_4_28Oct2026.md"
if errorlevel 1 (echo STAGING FAILED & exit /b 1)
git status --short
endlocal
