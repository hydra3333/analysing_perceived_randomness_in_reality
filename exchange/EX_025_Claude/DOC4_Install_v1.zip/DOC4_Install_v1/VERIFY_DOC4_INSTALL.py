#!/usr/bin/env python3
"""Read-only installation verifier for DOC-4 (H-2 v1r4, its review history and the owner-decisions record).

Claude, 28 October 2026. Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; the 8 new paths are absent;
             guarded files unchanged in Git.
  post       after copying the overlay: exactly the 8 new paths appear, all with the expected
             bytes (CRLF tolerated: the comparison is on LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly
             those paths and nothing else, all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_DOC4_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = '63c19e7515e02acc10af1a9c7a290acc73371b7e'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r4.md': '73b90ea348aea5fc337097a14ec4a8669258bc6cba55ce5a2485de26575f3f3a',
    'review/ChatGPT_Reviewer_Handover_H2_v1r3_to_v1r4.diff': '7ab39c21667bc8067f4d1202ebdab5b9e0480bd26d3d0d98ca74183298de095c',
    'review/ChatGPT_Reviewer_Handover_H2_v1r4_fact_corrections.diff': 'b472e5067d8c7ccf9b89556b09321fc7c78e827af65e8849dc32cfb20ae9cb39',
    'review/ChatGPT_Reviewer_Handover_H2_v1r4_initial_draft.md': 'f27b7612f74ae89a242cb5618d4c3808e41e4c7196e1d71945d119e3eaac3d91',
    'review/Claude_Fact_Check_H2_v1r4_v1.md': 'f86cc3245a27eec356a78a3d71acf918de861362a6689cc9c0988fe1cfcacc00',
    'review/DOC4_Install_v1/INSTALL_MANIFEST_SHA256.txt': '24073921f34f6c108316a0d8df6fdc9942a3accddaafb65a8f1a5cca271895ca',
    'review/Independent_ChatGPT_EX_024_H2_v1r4_Final_Candidate.md': '8d3bddaa7ca258aed46504a4d2153e85e0fb4e6f04f8ebfe3aea410d033823a3',
    'review/Owner_Decisions_H2_v1r4_and_Exchange_v0_4_28Oct2026.md': '5c3ab5d94598a0bbeb21064f9be4c4de464b314eec2743459b20932b3496a9ce',
}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r3.md': 'a2fb5c641a6fa8010aa59ff811aeba23145703bd5c0d4e2dbd70ac2fb419edb1',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r3.md': 'ddf4de23b726b2abf55ffcab613f926b62775469076476f939288a278e6422fc',
    'doc/RATIFICATION_REGISTER_v0_9.md': 'e84a7a208d99775bbbbf15af8a177d956c5a8e4819cf5b35537f6b70f5dfc6c8',
    'exchange/README.md': 'b08d9e2b62daf1f435c5c02b8908e447c1bc790b28d1d92c2866f110846b2256',
    'review/DOC3_Install_v1/INSTALL_MANIFEST_SHA256.txt': '60e16fcb4c55843b76dc0ab42bbc4424d0e3094661a27a34f48b8f54f23d9009',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'src/methods/_common/game_draws_reader.py': '9ed28e3db821272cbeb47725a587eaefb3d38a13f20403a549b82cd0cdd973e3',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in NEW.items():  # the package itself must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent. Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        need(all(ln.startswith('?? ') for ln in lines), 'changes other than new files:\n' + status[:600])
        changed = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines}
        need(changed == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(changed ^ set(NEW))))
        for p, h in NEW.items():
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    for p, h in NEW.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    need(got == {p: 'A' for p in NEW}, 'the last commit did not add exactly the expected paths: ' + repr(sorted(got.items())))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
