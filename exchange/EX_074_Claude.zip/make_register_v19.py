"""Draft register v0.19 from the installed register v0.18 by counted in-place edits (Claude, 30 Oct 2026).

Records: wave 1's code review and final package (EX_065 to EX_067), its rehearsal (TASK_T007) and installation
(947c370), Claude's GitHub verification; the wave 2 design review (EX_068 to EX_073) with the owner's decisions
and ratification; and the wave 2 package (E_2, E_17, E_18, E_19, their shared helper and the template's
draft 3), installed with this register. Every old string must occur exactly once; inserted text is ASCII.
The input is the Git blob of doc/RATIFICATION_REGISTER_v0_18.md (85125c49...3c97).
Placeholders, finalised after review and the owner's ratification: "RATIFICATION CANDIDATE" (version line)
and [T12-W2] (the owner's T12 decision for this package's rehearsal and install).
Usage: python3 -I make_register_v19.py REGISTER_v0_18 OUT_v0_19
"""
import hashlib, sys

src, out = sys.argv[1:3]
raw = open(src, 'rb').read()
assert hashlib.sha256(raw).hexdigest() == '85125c4900dabee53d2674d0ca3a18abbed64d5179b7f0b178300f928de93c97'
t = raw.decode('utf-8')
assert '\r' not in t

NEW_SECTION = """## Wave 1 installed, and wave 2 (register v0.19)

Paths in this section are under `doc/`, except those beginning `review/`, `exchange/`, `src/`, `tests/` or `CLAUDE_CODE_WORKING_FOLDER_TREE/`, which are from the repository root. In this section, "this register" means register v0.19.

**Wave 1's code review (EX_065 to EX_067).**
- **EX_065** sent the wave 1 code package candidate (`W1_Install_v1_candidate.zip`) with register v0.18's candidate.
- **EX_066** gave R-2 PASS (0 BLOCKER, 0 CORRECTION, 0 OPTIONAL, 0 RECONSIDER), with the tests independently reproduced, and register v0.18 CONTENT PASS. Its review copy, `review/Independent_ChatGPT_Wave1_R2_and_Register_v18_Review_v0_1.md` (LF, `baf0914044f88ef5162ed6d71d7f5f0dc5d93f6f7e33f1dfa8af5541c38ffa90`), is installed with this register.
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** W1-066-RD-01, REG18-066-RD-02 and W1-066-RD-03.
- **The owner** ratified register v0.18 and approved E2R-T12 for wave 1's rehearsal and install run (30 October 2026).
- **EX_067** recorded the final package, `W1_Install_v1.zip` (`51c81eb0757b92eff321ceb24227fa1ffcee976d5c5d72e1dd1df146d9da30c2`), and register v0.18 final; it needed no reply.

**Wave 1's rehearsal and installation.**
- **TASK_T007** (Claude Code, the local runner) rehearsed the final package in a task clone: PASS on all 15 steps. Its report is `CLAUDE_CODE_WORKING_FOLDER_TREE/outbox/REPORT_T007.md` at `b08f971`. Claude read it in full: 88 status lines (84 A and 4 M), 268 tests with 3 symlink skips, and no deviations.
- **The owner installed it** at `947c370d6f529e33e2dfc27b889713b298d364e5` (30 October 2026; parent `b08f971`). The log is clean: `PRE PASS`; 88 files copied; `POST PASS`; `SUITE PASS` (268 tests, 3 symlink skips) before the commit; 84 A + 4 M; `COMMITTED PASS`; then the push.
- **Claude verified the commit from a fresh GitHub clone:**
  - `COMMITTED PASS`;
  - all 87 manifest blobs;
  - register v0.18 `85125c49...3c97`;
  - nothing outside `doc`, `review`, `src` and `tests`;
  - all 268 tests on Linux.
- **The four wave 1 methods** are installed and not runnable.

**The wave 2 design review (EX_068 to EX_073).** The design note is `Predictive_Randomness_Wave2_E2_E17_E18_E19_Design_v0_1r2.md`, installed with this register. Its reference script, `review/W2_Install_v1/tools/reference_wave2.py`, computes and asserts every worked example.
- **EX_068** sent design v0.1.
- **EX_069: REVISIONS REQUIRED (1 BLOCKER, 1 CORRECTION, 1 OPTIONAL).**
  - **W2-B01 (BLOCKER) was Claude's error.** v0.1 claimed that a least-squares slope on the harmonic number H_k ranks exactly as Method A's logistic hazard on ln(age). The sign argument holds only for the same covariate. The reviewer proved the reversal with an exact 104-draw witness, and Claude confirmed it; on fair invented histories, the two signs differed at 10 of 312 targets.
  - **W2-C01 (CORRECTION):** section 3.2 had implied that E_18's fit uses the open stretch; it fits completed gaps only.
  - **W2-O01 (OPTIONAL):** the template rule on iterative floating-point fits was too categorical.
- **The owner's decisions after EX_069** (OWNER-DECIDED 30 October 2026):
  - **W2-3:** the faithful Method A rule, the reviewer's choice A. The sign of sum_k (n E_k - e R_k) ln k is decided exactly by prime exponents and rational bounds on ln p. The harmonic slope is withdrawn, not kept as a surrogate.
  - **W2-7:** the byte-reproducibility wording of W2-O01.
- **EX_070** sent design v0.1r1 (23 counted edits).
- **EX_071: REVISIONS REQUIRED (2 CORRECTION, 1 OPTIONAL).**
  - **W2R1-C01 was a gap of Claude's.** verify()'s second sign route could not end when the value is exactly zero; the reviewer's eight-draw witness has a_k = 6, -12, 0, 6.
  - **W2R1-C02** found a stale option line.
  - **W2R1-O01** asked for more precise wording on a future survival likelihood.
- **EX_072** sent design v0.1r2 (6 counted edits). verify()'s route 2 now has its own exact-zero test, by a smallest-prime-factor sieve, then direct bounds on each ln k, with a 1,024-term refusal cap.
- **EX_073: PASS UNCHANGED** (0/0/0/0). The reviewer also checked all 15,625 coefficient vectors in [-2, 2] for ages 1 to 6 (65 exact zeros).
- **REVIEWER-DECIDED, checked by Claude, no exception to report:** W2-069-RD-01..04, W2-071-RD-05..08 and W2-073-RD-09..11.
- **The review copies,** installed with this register (LF):
  - `review/Independent_ChatGPT_Wave2_R3_Review_v0_1.md` (`75ec652caf27c1db5594625bbc0ad4b0f587ffc233e59c68bc25695841913c51`);
  - `review/Independent_ChatGPT_Wave2_v0_1r1_R3_RECHECK_v0_1.md` (`64a48a8cb91633fad3027860fd6ff2ca770d35a88040f936404294dbc2ade56a`);
  - `review/Independent_ChatGPT_Wave2_v0_1r2_Focused_RECHECK_v0_1.md` (`e5b5116be5448601d82eba27fb4efcd86fa3c6400a762a9ea275ece474ef2305`).

**The owner's ratification (OWNER-DECIDED 30 October 2026):** design v0.1r2 ratified, with W2-1, W2-2, W2-4, W2-5, W2-6 and W2-8 as recommended and supported by the reviewer:
- **W2-1:** one shared gaps helper, `_common/recurrence_gaps.py`, versioned with the four methods;
- **W2-2:** the 12 fixed variants of the design note's section 6;
- **W2-4:** all four score-only in revision 1;
- **W2-5:** E_18 as a fixed four-law library (FAST, FAIR, SLOW, REGULAR) fitted by exact minimum chi-square, not EM;
- **W2-6:** E_19 per label, with the trend and the label's level divided out, and cycles fixed at 2, 3 and 4;
- **W2-8:** the NIST Beacon seed (reminder R-004) is settled at WF-1's design, because wave 2 uses no random numbers and R3's N1 fair-draw simulator is the first part that does.

Method A's diagnostics A1 to A5 are a separate later package after WF-1 (W2-3). Method A's decisions 3 and 4 (drawn order; machine and ball-set metadata) are not pursued.

**The wave 2 package (installed with this register).**
- **What it adds:**
  - the helper `src/methods/_common/recurrence_gaps.py`, revision 1;
  - `src/methods/E_002/`, `E_017/`, `E_018/` and `E_019/`, each with `variants.py`, `contract.py` and `IN_DEVELOPMENT.txt`;
  - 24 declarations and 24 `FORMULA_OPEN` entries;
  - `tests/test_recurrence_gaps.py` (12 tests) and `tests/test_wave2_recurrence.py` (19 tests);
  - the design note v0.1r2 and its reference script;
  - the four review copies above;
  - review evidence.
- **What it replaces:**
  - `src/methods/Method_Contract_Runner.py`: four imports and four `ADAPTERS` entries;
  - the template's `README.md` and `METHOD_SPECIFICATION_TEMPLATE.md`, which become draft 3 with the design's findings (section 12, five items), the termination lesson of W2R1-C01, and a note from the code that hand-written test expectations need a tool too. The code skeletons are unchanged.
- **What it does not change:** the contract libraries, the reader, the coordinator, E_1, E_3, E_4, E_6, wave 1 and their helpers, the launchers and owner tools, and the four methods' `NOT_YET_SPECIFIED` placeholders. The four switches stay False, and the allowlist stays empty.
- **The four methods cannot run** once this is installed: every request is refused with `NOT_SUPPORTED` before any data is read, and the flags are present.
- **Review and acceptance:**
  - the owner's Windows run of all 299 tests comes before the commit;
  - E2R-T12 for this package's rehearsal and install run: [T12-W2];
  - Claude verifies the commit from GitHub.

  The results are recorded after installation; this register does not predeclare them.

**Out-of-date statements (register v0.19).** This register prevails, and the files are not edited:
- Register v0.18, "installed with this register" for the wave 1 package: done, at `947c370`, as above.
- H-1 v1r5 section 7.4, "242 offline tests in 17 modules", and register v0.18's "268 in 19": 299 in 21 once the wave 2 package is installed.
- The template's draft 2 (`METHOD_TEMPLATE/`), where draft 3 replaces it.
- `exchange/OWNER_REMINDERS.md` R-004's "when": decided by W2-8.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `Predictive_Randomness_Wave2_E2_E17_E18_E19_Design_v0_1r2.md` | Claude; reviewed by the ChatGPT reviewer chat | Design PASS unchanged (W2-073-RD-11); OWNER-RATIFIED 30 Oct 2026 with W2-1..W2-8 as above; installed with this register; `2ab342911701edf1e93ad590e4765a3efac54a76d732b7fd2c5875c7d363fe74` |
| `RATIFICATION_REGISTER_v0_18.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 30 Oct 2026; installed at `947c370`; superseded by this register; `85125c4900dabee53d2674d0ca3a18abbed64d5179b7f0b178300f928de93c97` |

"""

EDITS = [
    ('**Register version:** v0.18 OWNER-RATIFIED 30 October 2026, recording',
     '**Register version:** v0.19 RATIFICATION CANDIDATE (drafted 30 October 2026), recording the wave 1 installation, the wave 2 design review, the owner\'s decisions and ratification, and the wave 2 package; v0.18 OWNER-RATIFIED 30 October 2026, recording'),
    ("For v0.18, the handover installation commit `8defe9d` was verified by Claude from GitHub. The wave 1 package and this register are installed together, in one commit identified after installation; the owner's Windows results for it are recorded after installation.",
     "For v0.18, the handover installation commit `8defe9d` was verified by Claude from GitHub. The wave 1 package and this register are installed together, in one commit identified after installation; the owner's Windows results for it are recorded after installation. For v0.19, the wave 1 installation commit `947c370` was verified by Claude from GitHub. The wave 2 package and this register are installed together, in one commit identified after installation; the owner's Windows results for it are recorded after installation."),
    ('\n## Interpretation and verification\n',
     '\n' + NEW_SECTION + '## Interpretation and verification\n'),
]
for old, new in EDITS:
    n = t.count(old)
    assert n == 1, (n, old[:80])
    assert all(ord(c) < 128 for c in new), old[:60]
    t = t.replace(old, new)
open(out, 'wb').write(t.encode('utf-8'))
print(out, hashlib.sha256(t.encode()).hexdigest(), len(t.splitlines()), 'lines')
