# Wave 1 package v1 - E_7, E_8, E_9 and E_10 revision 1 with their shared helper, installed non-runnable; the template's draft 2; register v0.18 (only after the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\W1_Install_*` folders, then extract it there (`tar -xf "E:\TEMP\W1_Install_v1.zip" -C E:\TEMP`). This package adds 84 new files and replaces 4 existing files (`doc/METHOD_TEMPLATE/METHOD_SPECIFICATION_TEMPLATE.md`, `doc/METHOD_TEMPLATE/README.md`, `doc/METHOD_TEMPLATE/method_folder/contract.py.txt`, `src/methods/Method_Contract_Runner.py`); nothing else changes. The four methods are installed **non-runnable**: every request is refused until a separate release package.

## 1. Update, check, copy, check, and the tests (one block; do not skip the last command)

```bat
git status --short
git pull --ff-only
python "E:\TEMP\W1_Install_v1\VERIFY_W1_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\W1_Install_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\W1_Install_v1\VERIFY_W1_INSTALL.py" --repo . --phase post
.venv\Scripts\python.exe "E:\TEMP\W1_Install_v1\RUN_W1_SUITE.py" --repo .
```

Expected: `git status --short` prints nothing (if it prints anything, stop and send Claude the output); the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `88 File(s) copied`; `POST PASS`; then `SUITE PASS` (268 tests; the only allowed skips are symlink tests: on Windows without symlink rights, up to 3). E2R-T12 starts up to six ordinary Python worker processes and lets them finish normally. The tests change nothing in the repository. If anything prints `STOP` or `FAILED`, do not commit: send Claude the output.

## 2. Stage, commit, check, and only then push

```bat
git add doc review src tests
git status --short
git commit -m "Wave 1: E_7, E_8, E_9 and E_10 revision 1 with the shared counting helper (installed non-runnable), the template's draft 2 and register v0.18"
python "E:\TEMP\W1_Install_v1\VERIFY_W1_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 84 lines starting with `A` and 4 starting with `M`, and nothing else; then `COMMITTED PASS`. Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub. Claude pushes nothing to the repository while you install.
