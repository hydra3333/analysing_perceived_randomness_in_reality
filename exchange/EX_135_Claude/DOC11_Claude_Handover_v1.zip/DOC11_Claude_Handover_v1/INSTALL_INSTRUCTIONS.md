# DOC11_Claude_Handover_v1 - DOC-11 Claude handover package (register v0.24, H-1 v1r8 and blurb, the MHUP-1 design v0.1r5, the direction document; document-only)

**Install only after the ChatGPT reviewer's Step 1.1 review of this package is resolved and you have ratified it (HO-2).**
Windows CMD, repository root. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\DOC11_Claude_Handover_v1` folder, then extract it there (`tar -xf "E:\TEMP\DOC11_Claude_Handover_v1.zip" -C E:\TEMP`). This package adds 20 new files, all under `doc/` and `review/`, and replaces and deletes nothing. No file under `src/` or `tests/` changes, so the test suite is not needed.

## 1. Update, check, copy, check

```bat
git status --short
git pull --ff-only
python "E:\TEMP\DOC11_Claude_Handover_v1\VERIFY_DOC11_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\DOC11_Claude_Handover_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\DOC11_Claude_Handover_v1\VERIFY_DOC11_INSTALL.py" --repo . --phase post
```

Expected: the first `git status --short` prints nothing; the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `20 File(s) copied`; `POST PASS`. If anything prints `STOP`, do not commit: send Claude the whole output.

## 2. Stage, commit, check, and only then push

```bat
git add doc review
git status --short
git commit -m "DOC-11: the Claude handover package - register v0.24, H-1 v1r8 and blurb, the ratified MHUP-1 design v0.1r5, the direction document v0.2r1, six review copies (document-only install)"
python "E:\TEMP\DOC11_Claude_Handover_v1\VERIFY_DOC11_INSTALL.py" --repo . --phase committed
git status --short
```

Expected: the first `git status --short` lists 20 lines starting with `A` and nothing else; then `COMMITTED PASS`; then the last `git status --short` prints nothing. Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub. Then start the replacement Claude chat with the text of `doc\HANDOVER\Claude_Primary_Handover_H1_v1r8_introductory_blurb.md` (everything below its line), as HO-2 step 2 says.
