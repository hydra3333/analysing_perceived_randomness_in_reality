# DOC9_Register22_v1 - DOC-9 package (register v0.22 and three review copies; document-only) (only after the owner's ratification)

Windows CMD, repository root. **Save the ZIP to `E:\TEMP`, not into the repository**, and extract it there (`tar -xf "E:\TEMP\DOC9_Register22_v1.zip" -C E:\TEMP`). This package adds 7 new files and changes nothing else: register v0.22, three review copies, and its builder, diff and manifest. No code changes, so no tests are needed.

## 1. Update, check, copy, check

```bat
git status --short
git pull --ff-only
python "E:\TEMP\DOC9_Register22_v1\VERIFY_DOC9_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\DOC9_Register22_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\DOC9_Register22_v1\VERIFY_DOC9_INSTALL.py" --repo . --phase post
```

Expected: `git status --short` prints nothing (if it prints anything, stop and send Claude the output); the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `7 File(s) copied`; `POST PASS`. If anything prints `STOP`, do not commit: send Claude the output.

## 2. Stage, commit, check, and only then push

```bat
git add doc review
git status --short
git commit -m "DOC-9: register v0.22 (owner-ratified 31 October 2026) and three review copies (document-only install)"
python "E:\TEMP\DOC9_Register22_v1\VERIFY_DOC9_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 7 lines starting with `A`, and nothing else; then `COMMITTED PASS`.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:** `git push`, then `git rev-parse HEAD`, and send Claude the commit ID.
