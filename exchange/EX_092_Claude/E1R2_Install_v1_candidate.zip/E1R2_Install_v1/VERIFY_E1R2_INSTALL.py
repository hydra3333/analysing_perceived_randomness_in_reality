#!/usr/bin/env python3
"""Read-only installation verifier for the CODE-3 and E_1 revision 2 package (E1R2_Install_v1).

Claude, 31 October 2026 (design v0.1r2 section 5, ER-2r1; from the REL-1/WF-1A verifier). Standard library only; does
not import project code, run tests, change files or touch Git state (every Git call uses --no-optional-locks and
GIT_OPTIONAL_LOCKS=0). The install runs behind a temporary barrier, E_1's own IN_DEVELOPMENT.txt, created first and
deleted last, never committed. Each phase accepts exactly one state of the whole working tree:
  pre        step 0: clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the base's;
             no barrier, no new path, no release entry; the 7 files to be replaced hold their base bytes.
  barrier    step 1, after copying barrier_overlay/: as pre, plus the barrier flag with the package's exact bytes.
  code       step 2, after copying repo_overlay/: the barrier; exactly the 29 new paths and the 7 modified files,
             with the expected bytes; NO release entry; every archived file equals the base commit's src/ file.
  release    step 3, after copying release_overlay/: as code, plus the 2 release entries with the expected bytes,
             each linked to its entry_0001 and naming revision 2's declaration.
  post       step 4, after deleting the barrier: as release, without the barrier.
  committed  after the commit: clean tree; one parent; the commit added exactly the new paths and release entries and
             modified exactly the modified files, with the expected Git blobs; no barrier in HEAD or on disk; every
             archived blob equals the base commit's src/ blob.
A STOP before step 4 leaves the barrier in place: run nothing, push nothing, send Claude the whole output.
A STOP after step 4: do not push, run no E_1 run and no batch, send Claude the whole output; nothing is undone
automatically. To close the gate again, copy barrier_overlay/ again: the release phase accepts exactly that state.
Usage: python VERIFY_E1R2_INSTALL.py --repo . --phase pre|barrier|code|release|post|committed
"""
import argparse, hashlib, json, os, re, subprocess, sys
from pathlib import Path

BASE = '0000000000000000000000000000000000000000'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
FLAG = 'src/methods/E_001/IN_DEVELOPMENT.txt'
FLAG_SHA = '15e47820c897b63ad6987da6f2073aebdb6c68ca5ef28952d448d123a6129e50'
NEW = {  # repo_overlay new paths: Git-content SHA-256 (LF)
    'archive/methods/E_001/r1/E_001/__init__.py': 'cd73a76370e0aa1934c1de0ec9b8a831bbea9556b9fcfddac103e6c5c28c8460',
    'archive/methods/E_001/r1/E_001/e1_common_reader_bridge.py': '2bfa693485cb2f417f4a0f24bd57a9b090c0f154bed8fa53299f4ed0cd9054db',
    'archive/methods/E_001/r1/E_001/e1_historical_appearance_frequency.py': '2c727d3b20584cd9a30c89863b6b51c72a1e0c373b48751e3da27d55f514f250',
    'archive/methods/E_001/r1/E_001/e1_standalone_contract.py': 'd9ef642c2949b1b2a10232d614ba1306365abaefe65338b5c0aa9e3d9f285e50',
    'archive/methods/E_001/r1/E_001/e1_training_view.py': 'e75e13729ffcdb5f14c4d7f762d8b31e590adbb1498142f9731eaf452394cad8',
    'archive/methods/E_001/r1/E_001/multigame_e1.py': '3c4a2305873aed7dc0457efcb898519f6e888ed72557670da1e8b0f9687ca462',
    'archive/methods/E_001/r1/E_001_Historical_Appearance_Frequency.py': 'f060944e7db40ac950f20d9bfe245e2cf5f64e2f7ef716766069d9973e5e767c',
    'archive/methods/E_001/r1/README.md': '4b76afed3bf4676b5de24d8e81626874da8335fae871f7ebd965c2dff808de07',
    'doc/Predictive_Randomness_CODE3_and_E1_Revision2_Design_v0_1r2.md': 'fb3b26daba2a14c6e2b5ad82e102ed9920faba14115046a820fbd0ee63b7209a',
    'review/E1R2_Install_v1/INSTALL_MANIFEST_SHA256.txt': 'b406f1314cba48f532b5977deb6da951499ae0cd3bfa4e62bdd27bd9ee25b3d8',
    'review/E1R2_Install_v1/mutations_e1r2_py313.txt': '31d6449b4813b9fbd2082aed2767209ee2c9e9bc4dd635634283af94984eefbe',
    'review/E1R2_Install_v1/replaced_files_base_to_v1.diff': '5738a7531c4670de9e303e845dfa7a3c8dc5f786a64c6879fe593d2128244791',
    'review/E1R2_Install_v1/suite_e1r2_py313.txt': '0bcc1de63788656e34d8367d08166074569fcb7ae722ed7351009764ece14759',
    'review/E1R2_Install_v1/suite_e1r2_py315.txt': '49b70af94b300808e7ded7ba313cb7519fa56c812bf4317b60390f9d503f0643',
    'review/E1R2_Install_v1/tools/build_dev.sh': 'c9bf7dae04020ac2e62990460f5e0191b03a1c98eaa8756fbb949a4638fb6fae',
    'review/E1R2_Install_v1/tools/e1r2_mutations.py': '9e56c5e02be9f79e2713c9354f1f10b4a58d2ce37f9b1c4f14e09224323469e7',
    'review/E1R2_Install_v1/tools/edit_tests_e1r2.py': 'e23a5e88a276b2f66d4e678fef2efe11d01da5900a04f5f3778b0992fec0dc75',
    'review/E1R2_Install_v1/tools/make_e1_r1_reference.py': 'ae25b0503ff0bc2c447cc516d3b7e809ef351253a36b02cafafee7ced7e678c5',
    'review/E1R2_Install_v1/tools/make_e1r2.py': '7cd32e67ba2135010530fff1270a5bd4bac3210a17f80bf797b47628ea8274b3',
    'review/Independent_ChatGPT_E1R2_Design_Focused_RECHECK_EX089.md': '434b5ef54a6e35d96367af8532458d6cda1510d26ccfe8ccc8efb83ac8e17283',
    'review/Independent_ChatGPT_E1R2_Design_Focused_RECHECK_EX091.md': '9bf7575ef8f605b8bd03b16bf83bb0fadd7b07bcedf6a6738de5552213eb3f70',
    'review/Independent_ChatGPT_E1R2_Design_R3_Review_EX087.md': 'cd588ae334b9eca27254241703497520cdc58b451219848e692c4d900dd963d0',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_1/FULL_HISTORY_RAW_COUNTS_V1/r2.json': 'e8f3cc797c78ca0d5e028c03608c5b2cbc220b0b4dab0840ae2da49be3c3c3df',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_1/FULL_HISTORY_RAW_COUNTS_V1/r2.json': '9c648d73680050395cd23d261cef96a836a1286da90d3009d4a2a2e64c3e53d6',
    'src/package_tools/__init__.py': 'e99f3ab48b74d546b4ec03bc4f7edc91135024919061922b80c386b3a182a200',
    'src/package_tools/method_retirement.py': '213ca30da619a1dfcf13a3ca7126f7a55252e511d4eab20c9381d81a63b0e60e',
    'tests/fixtures/e1_r1_reference_v1.json': '68dee62dec11339d0195c04b62dc32f26645f1c43845be2018a0e3adcb4f5db7',
    'tests/test_code3_retirement.py': '08813250d2009039fe9690e0e7c139330c804b1abdb72905046fb64c194dbc2e',
    'tests/test_e1r2_revision2.py': '6fd3ed164c66a82deba1303c4944c3d72f35e6fb7bd6b62a3dd637c86eef3b78',
}
MODIFIED = {  # repo_overlay replacements: (base Git-content SHA-256, new Git-content SHA-256), LF
    'src/methods/E_001/multigame_e1.py': ('3c4a2305873aed7dc0457efcb898519f6e888ed72557670da1e8b0f9687ca462', 'a07dac7558eb5bbc79bbf803b95d133c3248bdb2fa623e98f2fd6824d7a91019'),
    'src/methods/E_001_Historical_Appearance_Frequency.py': ('f060944e7db40ac950f20d9bfe245e2cf5f64e2f7ef716766069d9973e5e767c', '547c833cbe0ca0e9e3e7c6ffafccb54f54b5e60f25393bc4027ccad196378ce8'),
    'src/methods/_common/walk_forward.py': ('6f75597fa2e1fc1e889ca779c0b63fdaae50353bbd019de7f8d3a4d0907ae5a0', 'c11cf709e8a5bf6fb87b7467c94b56a82e16355e0a1bb7265efb4b4ac45922a7'),
    'src/methods/contract_adapters/e_001.py': ('b7b86cc19a522655d0f1be34e7a869572cd905eb038bb61d312f8201b129abaa', '5f83f3d7e7d5b7859d612daa69640bd2478e372e680f00fa00dc20fa7f3cfd02'),
    'tests/test_e2r_dispatch.py': ('8538202be06228a38350a65268e4d17a45b493575d9bf3475dcfea17e2d4465a', '8e5eba4f643fa8519c48f3367683373b2bbd6f39dd6ba424cd5b2868f3eb7095'),
    'tests/test_rel1_release.py': ('ea6b32d604a5203f8c53d91ee9e61ac9f0a4e8935feee7311c52bcc73af1d618', '4b49fee9a63f071a3e6bfa804a6f2ae73eb2758d6bb5277c8ffbfe2f711b3bb5'),
    'tests/test_wf1a_walk_forward.py': ('3e5aa86de37652c55aad92ebaa8e4846f79a5a236abd2c0b9fa8cefc8a87e98e', '3cc30ba74c826c58cafdc136ab964392f426dcdcb38bc558a3f9c1c5b001710f'),
}
RELEASE = {  # release_overlay new paths: Git-content SHA-256 (LF)
    'src/methods/_common/contract_data/registry/OZLOTTO/E_1/FULL_HISTORY_RAW_COUNTS_V1/entry_0002.json': '552a29cf63683980200f81f67e4349010f90c93a40fc315dd60fa840dc1635c6',
    'src/methods/_common/contract_data/registry/POWERBALL/E_1/FULL_HISTORY_RAW_COUNTS_V1/entry_0002.json': 'c28ab7c343460f2a869b42530aada5c7ff511b45f5365d8a14c95e2be9232902',
}
ARCHIVE = {  # archived path -> the src/ path whose base-commit bytes it must equal (E2R-R55)
    'archive/methods/E_001/r1/E_001/__init__.py': 'src/methods/E_001/__init__.py',
    'archive/methods/E_001/r1/E_001/e1_common_reader_bridge.py': 'src/methods/E_001/e1_common_reader_bridge.py',
    'archive/methods/E_001/r1/E_001/e1_historical_appearance_frequency.py': 'src/methods/E_001/e1_historical_appearance_frequency.py',
    'archive/methods/E_001/r1/E_001/e1_standalone_contract.py': 'src/methods/E_001/e1_standalone_contract.py',
    'archive/methods/E_001/r1/E_001/e1_training_view.py': 'src/methods/E_001/e1_training_view.py',
    'archive/methods/E_001/r1/E_001/multigame_e1.py': 'src/methods/E_001/multigame_e1.py',
    'archive/methods/E_001/r1/E_001_Historical_Appearance_Frequency.py': 'src/methods/E_001_Historical_Appearance_Frequency.py',
}
GUARDED = {  # must stay byte-identical in Git (Git-content SHA-256 at the base)
    'src/methods/E_001/__init__.py': 'cd73a76370e0aa1934c1de0ec9b8a831bbea9556b9fcfddac103e6c5c28c8460',
    'src/methods/E_001/e1_common_reader_bridge.py': '2bfa693485cb2f417f4a0f24bd57a9b090c0f154bed8fa53299f4ed0cd9054db',
    'src/methods/E_001/e1_historical_appearance_frequency.py': '2c727d3b20584cd9a30c89863b6b51c72a1e0c373b48751e3da27d55f514f250',
    'src/methods/E_001/e1_standalone_contract.py': 'd9ef642c2949b1b2a10232d614ba1306365abaefe65338b5c0aa9e3d9f285e50',
    'src/methods/E_001/e1_training_view.py': 'e75e13729ffcdb5f14c4d7f762d8b31e590adbb1498142f9731eaf452394cad8',
    'src/methods/_common/contract_data/registry/POWERBALL/E_1/FULL_HISTORY_RAW_COUNTS_V1/entry_0001.json': '544891641041f27ba5ac66ef7b8910945eb0a1c95261c27115372e365eba86bc',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_1/FULL_HISTORY_RAW_COUNTS_V1/entry_0001.json': 'bf39ed497665b6b99e86aaf633c4482ceb63176f1c7643eac804d5e761fb8d28',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_1/FULL_HISTORY_RAW_COUNTS_V1/r1.json': '678ef411ddd04a325e7adc7ceb52b47a90818904007373f95375523c1e3d426e',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_1/FULL_HISTORY_RAW_COUNTS_V1/r1.json': 'd800c99b0faa66377d2acd422b63a41129cd9a6f9b11870e7ce0b3b9bf3d833d',
    'src/methods/_common/canonical_encoding.py': '2096d8adb40737373169aea6c5d94147daa2b16ae6c961bbfcc6063e333efcac',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/contract_dispatch.py': '7f026bc8ff6a0a13120031371acee455734d12a79cbe923f988ba12c6a92a322',
    'src/methods/_common/contract_registry.py': '00082aad1754edbf2380c2caa144b0c79a12e2b6f26eb806d85903f177f11064',
    'src/methods/_common/contract_runner.py': 'c023fdc90d2ae0552558371489c39d3b583ef5c707d96394a77c2403b8dc4683',
    'src/methods/_common/contract_publication.py': '665ed261bb1504854b0c3be7c60a84ad6ecab6559d74d949c19f85eaa7ae809b',
    'src/methods/_common/contract_receipts.py': 'e6d159e65dcf8269ea5576a7338d3ebcbf2d5dc0c06b06f1517189cc215908fd',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/methods/_common/contract_forecast.py': 'be88a1d640098a6990f14090108524e1d7437a425e1b6254672164b6fc7f8121',
    'src/methods/_common/contract_task.py': 'e58c0ab288b3292d3eeaf49e7cf9170b0341ff53d23cbde839b8cdbd716a31b3',
    'src/methods/_common/contract_vocab.py': '6e30b5be8d024fa647a2406e38b44cdf3b3c0c84f0468d84e168e9fde40d4ec8',
    'src/methods/Method_Contract_Runner.py': 'fcbf02d851464e62d5019a1767bffd1b72ecb0f25e074f67c4887bea15368990',
    'src/methods/Method_Walk_Forward.py': '1a1edd445566a2e9537a1636ede00ddcef6fca18cbaa021785cd35264faa7856',
    'src/coordinator_private/contract_coordinated_gate.py': '22e9686c1fc4589c981a73e5aacfc3fab2333fcd449388e9c6a50f56db560094',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'doc/RATIFICATION_REGISTER_v0_20.md': 'd273f7a16532935368d137ee404717873e66d8ea189b35336104c396d2c517d4',
}
HERE = Path(__file__).resolve().parent
CD = 'src/methods/_common/contract_data/'


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def check_bytes(repo, table):
    for p, h in table.items():
        f = repo / p
        need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
        need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')


def check_archive(repo, read):
    """E2R-R55: each archived file equals the base commit's src/ file; no package marker above the revision's own
    files; lower-case unique revision folders; the README's helper references resolve to current src/ files."""
    for arch, src in ARCHIVE.items():
        need(sha(norm(read(arch))) == sha(git(repo, 'show', f'{BASE}:{src}')),
             f'archived file differs from the base commit: {arch} (base {src})')
    for level in ('archive', 'archive/methods', 'archive/methods/E_001', 'archive/methods/E_001/r1'):
        need(not (repo / level / '__init__.py').exists(), f'{level}/__init__.py: the archive must not be a package')
    revs = [d.name for d in (repo / 'archive/methods/E_001').iterdir() if d.is_dir()]
    need(revs == ['r1'], f'archive/methods/E_001 revision folders: {revs}, expected exactly r1')
    readme = norm(read('archive/methods/E_001/r1/README.md')).decode('ascii')
    helpers = re.findall(r'^- `(_common/[A-Za-z0-9_]+\.py)` \(revision (\d+)\)', readme, re.M)
    need(helpers, 'the archive README lists no shared helper')
    for path, _rev in helpers:
        need((repo / 'src' / 'methods' / path).is_file(), f'README helper reference does not resolve: {path}')


def check_release_links(read):
    for p in RELEASE:
        e2 = json.loads(read(p))
        game = e2['game_id']
        e1 = read(f'{CD}registry/{game}/E_1/FULL_HISTORY_RAW_COUNTS_V1/entry_0001.json')
        d2 = read(f'{CD}declarations/{game}/E_1/FULL_HISTORY_RAW_COUNTS_V1/r2.json')
        need((e2['entry_sequence'], e2['method_revision'], e2['registry_status']) == (2, '2', 'SUPPORTED'),
             f'{p}: not entry 2, revision 2, SUPPORTED')
        need(e2['previous_entry_digest'] == sha(norm(e1)), f'{p}: not linked to its entry_0001')
        need(e2['declaration_digest'] == sha(norm(d2)), f"{p}: does not name revision 2's declaration")


def state(repo, status, untracked_want, modified_want, flag_want):
    lines = status.splitlines()
    unt = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
    mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
    need(len(unt) + len(mod) == len(lines), 'changes other than new files and modified files:\n' + status[:600])
    want_unt = set(untracked_want) | ({FLAG} if flag_want else set())
    need(unt == want_unt, 'new paths differ from this step: ' + ', '.join(sorted(unt ^ want_unt)[:20]))
    need(mod == set(modified_want), 'modified paths differ from this step: ' + ', '.join(sorted(mod ^ set(modified_want))))
    if flag_want:
        need((repo / FLAG).is_file() and sha(norm((repo / FLAG).read_bytes())) == FLAG_SHA, 'the barrier flag is not the package\'s')
    else:
        need(not (repo / FLAG).exists() and not (repo / FLAG).is_symlink(), 'the barrier flag is present')


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for d, table in (('repo_overlay', {**NEW, **{p: n for p, (_o, n) in MODIFIED.items()}}),
                     ('release_overlay', RELEASE), ('barrier_overlay', {FLAG: FLAG_SHA})):
        for p, h in table.items():                                   # the package must be intact
            need(sha(norm((HERE / d / p).read_bytes())) == h, f'package file damaged: {d}/{p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    need(run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD').returncode == 0,
         f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')
    disk = lambda p: (repo / p).read_bytes()

    if a.phase in ('pre', 'barrier', 'code', 'release', 'post'):
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests', 'archive').decode().split()
        need(not diff, 'src/, tests/ or archive/ changed since the base commit: ' + ', '.join(diff[:20]))
    if a.phase in ('pre', 'barrier'):
        state(repo, status, [], [], a.phase == 'barrier')
        for p in [*NEW, *RELEASE]:
            need(not (repo / p).exists(), f'new path already exists: {p}')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm(disk(p))) == old, f'file to be replaced differs on disk: {p}')
        if a.phase == 'pre':
            print(f'PRE PASS: clean tree; no barrier; {len(NEW)} new paths and {len(RELEASE)} release entries absent; '
                  f'{len(MODIFIED)} files to replace at their base version. Nothing was changed.')
        else:
            print('BARRIER PASS: E_1 is closed by its IN_DEVELOPMENT.txt flag; nothing else has changed.')
        return
    if a.phase in ('code', 'release', 'post'):
        unt = [*NEW, *(RELEASE if a.phase != 'code' else [])]
        state(repo, status, unt, MODIFIED, a.phase != 'post')
        if a.phase == 'code':
            for p in RELEASE:
                need(not (repo / p).exists(), f'a release entry is already present: {p}')
        check_bytes(repo, {**NEW, **{p: n for p, (_o, n) in MODIFIED.items()}})
        check_archive(repo, disk)
        if a.phase == 'code':
            print(f'CODE PASS: the barrier is in place; exactly the {len(NEW)} new paths and {len(MODIFIED)} modified files, '
                  'with the expected bytes; the archive equals the base commit; no release entry yet.')
            return
        check_bytes(repo, RELEASE)
        check_release_links(disk)
        if a.phase == 'release':
            print(f'RELEASE PASS: the barrier is in place; the {len(RELEASE)} release entries are present, linked and '
                  'name revision 2; everything else as in the code phase.')
        else:
            print(f'POST PASS: the barrier is gone; exactly the {len(NEW)} new paths, {len(RELEASE)} release entries and '
                  f'{len(MODIFIED)} modified files, all with the expected bytes; the archive equals the base commit.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    need(not (repo / FLAG).exists(), 'the barrier flag is present after the commit')
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests', 'archive').decode().split()
    need(not diff, "the commit's parent has src/, tests/ or archive/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *RELEASE.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    need(run(repo, 'cat-file', '-e', f'HEAD:{FLAG}').returncode != 0, 'the barrier flag was committed')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in [*NEW, *RELEASE]}, **{p: 'M' for p in MODIFIED}}
    need(got == want, 'the last commit did not change exactly the expected paths; differences (path, status): ' +
         repr(sorted(set(got.items()) ^ set(want.items()))))
    check_archive(repo, lambda p: git(repo, 'show', f'HEAD:{p}'))
    check_release_links(lambda p: git(repo, 'show', f'HEAD:{p}'))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW) + len(RELEASE)} files and modified '
          f'{len(MODIFIED)}; all Git blobs match; no barrier; the archive equals the base commit.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'barrier', 'code', 'release', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
