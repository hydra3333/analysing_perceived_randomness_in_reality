@echo off
setlocal
rem E1-ALIGN: the 5 explicit moves (git mv) into the new method folder. Run from the repository
rem root after PRE PASS. Stops at the first failure. No commit, push or deletion of content.
if not exist "src\methods\E_001" mkdir "src\methods\E_001" || goto :fail
git mv -- "src\methods\_common\e1_historical_appearance_frequency.py" "src\methods\E_001\e1_historical_appearance_frequency.py" || goto :fail
git mv -- "src\methods\_common\e1_training_view.py" "src\methods\E_001\e1_training_view.py" || goto :fail
git mv -- "src\methods\_common\e1_standalone_contract.py" "src\methods\E_001\e1_standalone_contract.py" || goto :fail
git mv -- "src\methods\_common\e1_common_reader_bridge.py" "src\methods\E_001\e1_common_reader_bridge.py" || goto :fail
git mv -- "src\methods\_common\multigame_e1.py" "src\methods\E_001\multigame_e1.py" || goto :fail
echo MOVES DONE
endlocal
exit /b 0
:fail
echo MOVE FAILED: stop and send Claude this output.
endlocal
exit /b 1
