#!/usr/bin/env python3
"""E1-ALIGN E1A-T05/T06/T09: fresh-interpreter location, origin and refusal checks, then the firewall and
shared-code mutations, on the installed tree.

Claude, 28 October 2026. Owner-run on Windows, after the overlay is copied and before committing.
- Each import check runs in its own new `python -I -B` process with an explicit sys.path (src,
  src/methods, tests) and no PYTHONPATH. Importing a module runs only its definitions: no data is read,
  no process is started, and no orphan marker is created, read or removed.
- The mutations run in a temporary copy of src/ and tests/ only, which is deleted afterwards. Each
  mutant must make the named guard test fail; the unchanged copy (control) must pass. The repository
  itself is not changed, and no bytecode is written to it.
Usage (repository root):  .venv\\Scripts\\python.exe CHECK_E1ALIGN_IMPORTS.py --repo .
"""
import argparse, ast, os, shutil, subprocess, sys, tempfile
from pathlib import Path

E1 = ['e1_historical_appearance_frequency', 'e1_training_view', 'e1_standalone_contract',
      'e1_common_reader_bridge', 'multigame_e1']
fails = 0


def check(ok, what):
    global fails
    print(('PASS ' if ok else 'FAIL ') + what)
    fails += not ok


def fresh(code, root, cwd):
    pre = ('import sys; sys.path[:0] = [%r, %r, %r]\n'
           % (str(root / 'src'), str(root / 'src' / 'methods'), str(root / 'tests')))
    r = subprocess.run([sys.executable, '-I', '-B', '-c', pre + code], cwd=cwd, capture_output=True, text=True)
    return r.returncode, (r.stdout + r.stderr).strip()


def unittest(root, test):
    env = {k: v for k, v in os.environ.items() if k != 'PYTHONPATH'}
    env['PYTHONPATH'] = os.pathsep.join(str(root / p) for p in ('src', os.path.join('src', 'methods'), 'tests'))
    env['PYTHONDONTWRITEBYTECODE'] = '1'
    return subprocess.run([sys.executable, '-B', '-m', 'unittest', '-q', test], cwd=root, env=env,
                          capture_output=True, text=True).returncode


FW = 'test_multigame_static_and_timing.StaticSafetyTests.test_method_loader_import_firewall_except_accepted_legacy_e1'
GUARD = 'test_e1_align'
SHARED = 'test_e1_align.E1AlignGuards.test_shared_code_imports_no_method_code'
BR = 'src/methods/E_001/e1_common_reader_bridge.py'
BRL = 'from _common.game_draws_reader import DrawView'
FUT = 'from __future__ import annotations\n'
MUTANTS = [  # name, what, edits (path, old, new; old must occur once), new files (path, text), guard that must fail
    ('m1', 'new E_001 file importing the reader', [], [('src/methods/E_001/e1_probe.py', BRL + '\n')], FW),
    ('m2', 'E_002 file: import _common.game_draws_reader', [], [('src/methods/E_002/probe.py', 'import _common.game_draws_reader as r\n')], FW),
    ('m3', 'E_002 file naming source_data', [], [('src/methods/E_002/probe.py', "P = 'source_data'\n")], FW),
    ('m4', 'second source_data in an allowed E_1 file', [('src/methods/E_001/e1_training_view.py', FUT, FUT + '# source_data\n')], [], FW),
    ('m5', 'unused allowance (bridge import removed)', [(BR, BRL, 'DrawView = object')], [], FW),
    ('m6', 'shared reader importing E_1 code again', [('src/methods/_common/game_draws_reader.py', 'from _common.canonical_encoding import canonical_bytes', 'from E_001.e1_historical_appearance_frequency import canonical_bytes')], [], GUARD),
    ('m7', 'changed shared encoder', [('src/methods/_common/canonical_encoding.py', "separators=(',', ':')", "separators=(', ', ':')")], [], GUARD),
    ('m8', 'moved orphan-marker path (no marker created)', [('src/methods/E_001/e1_standalone_contract.py', '.parents[3] /', '.parents[2] /')], [], GUARD),
    ('m9', 'E_002 file: from _common import game_draws_reader', [], [('src/methods/E_002/probe.py', 'from _common import game_draws_reader\n')], FW),
    ('m10', 'bridge imports load_pinned_draw_view instead of DrawView', [(BR, BRL, 'from _common.game_draws_reader import load_pinned_draw_view as DrawView')], [], FW),
    ('m11', 'bridge adds an extra reader symbol', [(BR, BRL, 'from _common.game_draws_reader import DrawView, load_pinned_draw_view')], [], FW),
    ('m12', 'bridge aliases DrawView', [(BR, BRL, 'from _common.game_draws_reader import DrawView as DV\nDrawView = DV')], [], FW),
    ('m13', 'bridge star import', [(BR, BRL, 'from _common.game_draws_reader import *')], [], FW),
    ('m14', 'E_002 file: dynamic import by string', [], [('src/methods/E_002/probe.py', "import importlib\nr = importlib.import_module('_common.game_draws_reader')\n")], FW),
    ('m15', 'E_001 file: from _common import game_draws_reader', [], [('src/methods/E_001/e1_probe.py', 'from _common import game_draws_reader\n')], FW),
    ('m16', 'shared module: from methods import E_001', [('src/methods/_common/game_profiles.py', FUT, FUT + 'from methods import E_001\n')], [], SHARED),
    ('m17', 'shared module: from _common import e1_training_view', [('src/methods/_common/game_profiles.py', FUT, FUT + 'from _common import e1_training_view\n')], [], SHARED),
    ('m18', 'coordinator_private module: from methods.E_001 import x', [('src/coordinator_private/multigame_launch_spec.py', FUT, FUT + 'from methods.E_001 import e1_training_view\n')], [], SHARED),
]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    repo = ap.parse_args().repo.resolve()
    with tempfile.TemporaryDirectory(prefix='e1align_check_') as tmp:
        tmp = Path(tmp)
        # E1A-T06: location and origin, in fresh interpreters
        for n in E1:
            rc, out = fresh(f'import importlib.util as u; print(u.find_spec("_common.{n}"))', repo, tmp)
            check(rc == 0 and out == 'None', f'old name refused: _common.{n}')
            rc, out = fresh(f'import importlib, pathlib; m = importlib.import_module("E_001.{n}"); '
                            f'print(m.__name__, pathlib.Path(m.__file__).resolve())', repo, tmp)
            want = (repo / 'src' / 'methods' / 'E_001' / f'{n}.py').resolve()
            check(rc == 0 and out == f'E_001.{n} {want}', f'new origin: E_001.{n}')
            check(not (repo / 'src' / 'methods' / '_common' / f'{n}.py').exists(), f'no old file remains: _common/{n}.py')
        rc, out = fresh('import importlib, pathlib; m = importlib.import_module("_common.canonical_encoding"); '
                        'print(pathlib.Path(m.__file__).resolve())', repo, tmp)
        check(rc == 0 and out == str((repo / 'src' / 'methods' / '_common' / 'canonical_encoding.py').resolve()),
              'shared module origin: _common.canonical_encoding')
        # E1A-T05: E_1's names are the shared functions; the reader uses the shared module
        rc, out = fresh('import _common.canonical_encoding as c, E_001.e1_historical_appearance_frequency as e; '
                        'print(e.canonical_bytes is c.canonical_bytes, e._length32_tuple is c.length32_tuple)', repo, tmp)
        check((rc, out) == (0, 'True True'), "E_1's names are the shared functions")
        reader = (repo / 'src' / 'methods' / '_common' / 'game_draws_reader.py').read_text(encoding='utf-8')
        tree = ast.parse(reader)
        froms = [(n.module, a.name) for n in ast.walk(tree) if isinstance(n, ast.ImportFrom) for a in n.names
                 if a.name == 'canonical_bytes']
        mods = [n.module or '' for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)] + \
               [a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names]
        check(froms == [('_common.canonical_encoding', 'canonical_bytes')] and
              not any('E_001' in m or any(e in m for e in E1) for m in mods),
              'the shared reader takes canonical_bytes from _common.canonical_encoding only, and imports no E_1 module')

        # E1A-T09: mutations in a temporary copy
        def mutant(name, edits=(), new_files=()):
            d = tmp / name
            for part in ('src', 'tests'):
                shutil.copytree(repo / part, d / part, ignore=shutil.ignore_patterns('__pycache__'))
            for rel, old, new in edits:
                p = d / rel
                s = p.read_text(encoding='utf-8')
                assert s.count(old) == 1, (name, rel, s.count(old))
                p.write_text(s.replace(old, new), encoding='utf-8')
            for rel, text in new_files:
                (d / rel).parent.mkdir(parents=True, exist_ok=True)
                (d / rel).write_text(text, encoding='utf-8')
            return d
        c = mutant('c0')
        check(unittest(c, FW) == 0 and unittest(c, GUARD) == 0 and unittest(c, SHARED) == 0,
              'control: the installed tree passes the firewall, guard and shared-code tests')
        for name, what, edits, new_files, test in MUTANTS:
            check(unittest(mutant(name, edits, new_files), test) != 0, f'mutation {name}: {what} is rejected')
    print('RESULT', 'PASS' if not fails else f'STOP ({fails} failed)')
    sys.exit(1 if fails else 0)


if __name__ == '__main__':
    main()
