# E1-ALIGN - code installation (only after the reviewer's RECHECK PASS and the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\E1ALIGN_*` folders, then extract it there (`tar -xf "E:\TEMP\E1ALIGN_Code_Install_v1.zip" -C E:\TEMP`).

## 1. Update, check, move, copy, check

```bat
git status --short
git pull --ff-only
python "E:\TEMP\E1ALIGN_Code_Install_v1\VERIFY_E1ALIGN_INSTALL.py" --repo . --phase pre
call "E:\TEMP\E1ALIGN_Code_Install_v1\RENAME_FILES.cmd"
xcopy "E:\TEMP\E1ALIGN_Code_Install_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\E1ALIGN_Code_Install_v1\VERIFY_E1ALIGN_INSTALL.py" --repo . --phase post
```

Expected: `git status --short` prints nothing; the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `MOVES DONE`; `21 File(s) copied` (10 replace moved or existing files, as intended; 11 are new); `POST PASS`.

## 2. Tests and import checks (offline; nothing is changed)

```bat
.venv\Scripts\python.exe "E:\TEMP\E1ALIGN_Code_Install_v1\RUN_E1ALIGN_SUITE.py" --repo .
.venv\Scripts\python.exe "E:\TEMP\E1ALIGN_Code_Install_v1\CHECK_E1ALIGN_IMPORTS.py" --repo .
```

Expected: `SUITE PASS` (84 tests; the only allowed skips are the two symlink tests, if Windows cannot create symlinks), then `RESULT PASS`. **Send Claude both outputs whatever they say.**

If anything in steps 1 or 2 prints `STOP` or `FAILED`, do not commit. Send Claude the output. Nothing is committed at that point; Claude will then give you the commands that put the repository back as it was.

## 3. Stage, commit, check, and only then push

```bat
call "E:\TEMP\E1ALIGN_Code_Install_v1\STAGE_EXACT_FILES.cmd"
git diff --cached --name-status
git commit -m "E1-ALIGN: E_1 modules into src/methods/E_001, shared canonical encoding, symbol-aware firewall; register v0.10"
python "E:\TEMP\E1ALIGN_Code_Install_v1\VERIFY_E1ALIGN_INSTALL.py" --repo . --phase committed
```

Expected: the staged list shows 5 renames (`R`), 6 modifications (`M`) and 11 lines starting with `A`; then `COMMITTED PASS`.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** The verifier prints the commit identities; send Claude the whole output, and Claude gives you the exact recovery commands after confirming them.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID. Claude then verifies it from GitHub and runs the immediate recovery check (E1A-T13) in a disposable clone. Claude pushes nothing to the repository while you install.
