@echo off
setlocal
rem Owner-run staging of exactly the 21 E1-ALIGN files with new bytes (the 5 moves are already
rem staged by RENAME_FILES.cmd). No commit, push or deletion.
git add -- ^
  "doc\RATIFICATION_REGISTER_v0_10.md" ^
  "review\E1ALIGN_Code_Install_v1\INSTALL_MANIFEST_SHA256.txt" ^
  "review\E1ALIGN_Code_Install_v1\check_imports_linux_py313.txt" ^
  "review\E1ALIGN_Code_Install_v1\e1align_allowlist.json" ^
  "review\E1ALIGN_Code_Install_v1\e1align_checks_output_linux.txt" ^
  "review\E1ALIGN_Code_Install_v1\e1align_trial_diff.diff" ^
  "review\E1ALIGN_Code_Install_v1\suite_e1align_linux_py313.txt" ^
  "review\E1ALIGN_Code_Install_v1\suite_e1align_linux_py315b4.txt" ^
  "src\methods\E_001\__init__.py" ^
  "src\methods\E_001\e1_common_reader_bridge.py" ^
  "src\methods\E_001\e1_historical_appearance_frequency.py" ^
  "src\methods\E_001\e1_training_view.py" ^
  "src\methods\E_001\multigame_e1.py" ^
  "src\methods\E_001_Historical_Appearance_Frequency.py" ^
  "src\methods\_common\canonical_encoding.py" ^
  "src\methods\_common\game_draws_reader.py" ^
  "tests\test_e1_align.py" ^
  "tests\test_e1_standalone.py" ^
  "tests\test_multigame_console_and_synthetic_scorer.py" ^
  "tests\test_multigame_reader_contracts.py" ^
  "tests\test_multigame_static_and_timing.py"
if errorlevel 1 (echo STAGING FAILED & exit /b 1)
git status --short
endlocal
