#!/usr/bin/env python3
"""Read-only installation verifier for the DOC-11 Claude handover package (register v0.24, H-1 v1r8 and blurb, the MHUP-1 design v0.1r5, the direction document; document-only).

Claude, 31 October 2026 (from the wave 2 package verifier; adds deleted paths). Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 20 new paths are absent; the 0 modified files and the 0 files
             to be deleted still have their base bytes; guarded files unchanged in Git.
  post       after copying the overlay (and the git rm step, if any): exactly the 20 new paths
             appear, exactly the 0 modified files change and exactly the 0 deleted files are gone
             (staged deletions), all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths, modified exactly the modified files and deleted exactly the deleted files,
             all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_DOC11_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = 'a9e52db'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/Direction_for_operational_procedures_v0_2r1.md': '0aa5967febb817707953b4634937a9a76e2a56e364360cfd1004d10d85c56855',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r8.md': '09e579ba008da0fd55e14ebd9e05d4f9b6c6bef54445fec85ca7bb120632a801',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r8_introductory_blurb.md': 'f1833da327210c899b5e0bf2e65888c8b8234654bf2272a021f017ac3bca2d19',
    'doc/Predictive_Randomness_ModeH_Update_Prospective_Design_v0_1r5.md': 'e5fb491ca601fa71793d143871d99c40929d20cdd8398fe92e0c6858c44a5455',
    'doc/RATIFICATION_REGISTER_v0_24.md': '9d9fde67961d76fcc4823e97ac339c12e8b7e68ba309167652bd2c568f5c81ae',
    'review/DOC11_Claude_Handover_v1/H1_blurb_v1r7_to_v1r8.diff': '94512efe1636f9ca49895753074e4b1e15a79cf2024b227faed50e08c7a5154b',
    'review/DOC11_Claude_Handover_v1/H1_v1r7_to_v1r8.diff': 'a27ca8b6ab21879b10525b24a752d0779bcddba051572632619be0e67480e1bd',
    'review/DOC11_Claude_Handover_v1/INSTALL_MANIFEST_SHA256.txt': '9544ee4ff8ee6a139e3523a865898cbb38968ecc53b77bb2931cc2a1b0165daf',
    'review/DOC11_Claude_Handover_v1/build_doc11.py': '85bc0ef3ce2d600d31a9a56366f828e76c3a6a9e4b8353feba6d07543d84c5fe',
    'review/DOC11_Claude_Handover_v1/e2e_doc11.sh': '661d6f97719c52fd5856d34f38bee00d273e8645a14751fcc920217974927778',
    'review/DOC11_Claude_Handover_v1/make_h1_v1r8.py': '41718ec0583114cc5d9c7c48ae7d93557faf95dda7eedaec17a2c7fbbc45ec25',
    'review/DOC11_Claude_Handover_v1/make_register_v24.py': 'b0745aa77150c01de60abdf8dd1351ca3aad80ede5516a12f78a200643d6701e',
    'review/DOC11_Claude_Handover_v1/reg24_section.md': 'f213b79ef63ee5e55ba4427632f05db22db50fd25eaa0770fc86ca19cfb61183',
    'review/DOC11_Claude_Handover_v1/register_v0_23_to_v0_24.diff': 'bce37da7473bbd5b934aeef639cc13574894c9dcde32f372c11a5a3a6309d442',
    'review/Independent_ChatGPT_Direction_v0_1_Content_Check_RECHECK.md': '45091f629cf6936e2222717466a0c45eaff420269ce15d5df8552dc7653c1580',
    'review/Independent_ChatGPT_Direction_v0_2_Focused_PASS.md': 'a8c61caedb3a7704f243bc96c52e6102f743b15bd244f5c8eb853633ee3c70fd',
    'review/Independent_ChatGPT_MHUP1_Design_Conditional_PASS_EX131.md': '01840b8dcafc7fad4382028dd87509f3b2414990583b51b8f7806eb4488b9efa',
    'review/Independent_ChatGPT_MHUP1_Design_Focused_RECHECK_EX127.md': '4620321d51b29be913f0bc6db466432416200dab1a3753c3720bf423888ccfe2',
    'review/Independent_ChatGPT_MHUP1_Design_Narrow_RECHECK_EX129.md': 'cb8c8239a6cf0df3bc497a783621ad0c3888ea6b14426729de3b41e88cd7756b',
    'review/Independent_ChatGPT_MHUP1_Design_R3_Review_EX125.md': '546397c546a8a3dc8e0ba6d60c58c51619b7ada48741d145d8e46ce54e66c081',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF

}
DELETED = {  # path: base Git-content SHA-256 (LF)

}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'doc/RATIFICATION_REGISTER_v0_23.md': '7502b75556c56f4c9b91e9022829ee18f05d02591260e87bfe053ec1c79bb6c2',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r7.md': 'b51f63792dde7f7d6c0c9e01ea6cecc5b5a12038ba748b91647738273ebc29fb',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r7_introductory_blurb.md': 'bc46c07a1705aa49738ba6b8d8797f46df40cbc7996e4ba22a25eaefdab73240',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r8.md': '4e2737c28a69ab73577fa6c39c87c04518e42ed1be47f240295e80802774b956',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r8_introductory_blurb.md': '17633e4ec5413d12ed3c2909819b9f899a156af22631a31ee3e1b6f145ea0d2a',
    'doc/Predictive_Randomness_Software_Architecture_Discussion_v0_9.md': 'e0a03f41ddd561cf42b4d69367ab365d414c288f7943283fb47439f9c59df376',
    'doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md': '53e30a3e649b48b8a88923d08bf578caf04a4ce93d6ea6468891ca97e93a57b6',
    'doc/Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md': '0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954',
    'doc/HOLDOUT_EXPOSURE_RECORD_v0_3.md': '39c54295777c1a40b84c680d6fc8dacb7404f7e70ef79b3d8d98d94bce6414b3',
    'doc/Direction_for_operational_procedures_v0_2_to_v0_2r1.diff': 'efab43429f690cacc7cd3d89d89f6e540663d6ee18a053a0e68be4361d640695',
    'doc/owner_stocktake_v1_0.txt': '62b173a5f51ecccf3c5c451be5446ed515a576a3bde81efda7d506464c2e11f9',
    'README.md': '329f571c93f631ef3f5cce752d933c5bcc576a24e99e3f3162d9a81aac429dff',
    '.gitattributes': 'e73570de0a035b1dc00f6687c3b445a4d19f0db5340c79e2d3bf434499f6caee',
    '.claude/settings.json': '471c1b180af151b45a2ca5fb40169de77fd6c3bbdd7b9f97e6e3dc1d6c8f0ab5',
    'CLAUDE_CODE_WORKING_FOLDER_TREE/CLAUDE.md': '509e381ed612e7572940014d33f2724172a12a0da8a8a1e76020571ede63b56b',
    'Run_Experiment.bat': 'dfd324d645cbbe5d528883f7a0309d5f5f3cbea47c4a49ddffaf6b0bdc7f0c5d',
    'Run_Results_Updater.bat': 'c01ac19ed4a04ad133f28f4873dfe8c161bac811237b2176e70717f63bb80230',
    'Run_Coordinator.bat': '6ccb23302c897747432d84d1a1f4ed6fd7b2cf99faa8298ec4f3b5d82841bc70',
    'Run_Method_Rankings.bat': '087813da95aa163d2f308b47284710bc4f3bf1fc88014faa80dc0df9a1eb2973',
    'src/results_master_v0_1.py': '3436da9f560172606f4b9e010cd85a806b58e55597685f2ab7f65c3e17523619',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/contract_dispatch.py': '7f026bc8ff6a0a13120031371acee455734d12a79cbe923f988ba12c6a92a322',
    'src/methods/_common/contract_runner.py': 'c023fdc90d2ae0552558371489c39d3b583ef5c707d96394a77c2403b8dc4683',
    'src/evaluation/outcome_reader.py': '8852361b271c45998867b4c18441b7287651744e73d897d03e6e18e1d8b0a8d7',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        for p, old in DELETED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be deleted is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be deleted differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} files to replace and {len(DELETED)} to delete '
              'at their base version. Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        dele = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('D  ')}
        need(len(new) + len(mod) + len(dele) == len(lines),
             'changes other than new files, modified files and staged deletions:\n' + status[:600])
        need(dele == set(DELETED), 'unexpected staged deletions: ' + ', '.join(sorted(dele ^ set(DELETED))))
        for p in DELETED:
            need(not (repo / p).exists(), f'deleted path still on disk: {p}')
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths, {len(MODIFIED)} modified files and '
              f'{len(DELETED)} staged deletions, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    for p, old in DELETED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the deleted file: {p}')
        need(run(repo, 'cat-file', '-e', f'HEAD:{p}').returncode != 0, f'deleted file still in HEAD: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}, **{p: 'D' for p in DELETED}}
    need(got == want, 'the last commit did not change exactly the expected paths; differences (path, status): ' +
         repr(sorted(set(got.items()) ^ set(want.items()))))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files, modified '
          f'{len(MODIFIED)} and deleted {len(DELETED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
