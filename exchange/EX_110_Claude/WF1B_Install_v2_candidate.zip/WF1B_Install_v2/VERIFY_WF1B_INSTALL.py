#!/usr/bin/env python3
"""Read-only installation verifier for the WF-1B package (the R3 stage-2 scorer and ranking report, N1 and its seed policy).

Claude, 31 October 2026 (from the wave 2 package verifier; adds deleted paths). Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 38 new paths are absent; the 1 modified files and the 0 files
             to be deleted still have their base bytes; guarded files unchanged in Git.
  post       after copying the overlay (and the git rm step, if any): exactly the 38 new paths
             appear, exactly the 1 modified files change and exactly the 0 deleted files are gone
             (staged deletions), all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths, modified exactly the modified files and deleted exactly the deleted files,
             all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_WF1B_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = '0c8799d7b5a98cd6a0c37da88961e81f19d37379'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'Run_Method_Rankings.bat': '087813da95aa163d2f308b47284710bc4f3bf1fc88014faa80dc0df9a1eb2973',
    'doc/Predictive_Randomness_WF1B_Supplement_Design_v0_1r1.md': 'a2f470797f31e387f44b5492ed406f1376b3eb92f2181dc76f6ac4c80168185a',
    'review/Independent_ChatGPT_Register_v0_22_Content_Check_EX099.md': 'c948844083625c63cf20f041abc93fa8b6a55ab276fb17720e5de3237b525292',
    'review/Independent_ChatGPT_Register_v0_22_Focused_RECHECK_EX101.md': '32f464bdd19ee4bf984c5f980884f282ccea43eb7ad924f3affa30201080fabb',
    'review/Independent_ChatGPT_WF1B_Supplement_Design_Focused_RECHECK_EX107.md': 'a88011455862a52b86e379dd7c9bd9a3b358487ccde007b698e91538de95657d',
    'review/Independent_ChatGPT_WF1B_Supplement_Design_R3_Review_EX105.md': '07b71a62793ab56d2b12e355ffb3fa9befb8bddd139c12fa0a281681d3ff570d',
    'review/WF1B_Install_v2/INSTALL_MANIFEST_SHA256.txt': '6635d68bbc612e43a49773c311797cd48ff609db837dd6332df255be5df9a85f',
    'review/WF1B_Install_v2/mutations_wf1b_v2_py313.txt': '41ece9f3bfa5ebbb6c4b383db1f6cd52d1ea80c97edbe27ba503d1a802b00df4',
    'review/WF1B_Install_v2/replaced_files_base_to_v1.diff': 'da0c667f61961afcc9b250649cbadf7b4f14f64d2defce63e283043290b6b13b',
    'review/WF1B_Install_v2/tools/build_wf1b_pkg.py': '2f3d6d02d6b331873efb466f7827cc529b8ca232ac530e353685e700d5a81042',
    'review/WF1B_Install_v2/tools/make_wf1b_registries.py': '02d65f9fd70c7c1a34627269f97e9050dfcc035659ec1d0e86dcd2ab54798636',
    'review/WF1B_Install_v2/tools/wf1b_mutations.py': '6439bbc5ca8bccffd0ab1b1fc323d686d23d1e41f571468f30da816882c72894',
    'src/evaluation/Method_Rankings_Report.py': '06261a6f1f867543faec79d5971a1c2d52d2ef042f033058858fa2f56b7d25f0',
    'src/evaluation/__init__.py': 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855',
    'src/evaluation/collect.py': 'ea9214ebc7320a2a197e7164b97474085e116ef46cdc735c82f821a3f9486c02',
    'src/evaluation/divisions.py': 'bd6201c310e3b9eea085062d5b84627f9d8b30fc593c06a0d82e2743a288deb2',
    'src/evaluation/measures.py': '2081d324e12fab909411d14346b19a24cec28316e2c13e263d194e464e9867bf',
    'src/evaluation/n1.py': 'f5008a72b93eb0c69f951e60e90759d2c45bbe7a721b6bed1f70672e1b9a1330',
    'src/evaluation/n1_generator.py': '004583a8d02f4282fbfefd1ec46bc3983f50bc78e0a186a836ec7b521f88e36f',
    'src/evaluation/numerics.py': '85a35cbc2f66eeb544bb6dfd872d17534b2a27e334f0bc21da268527dc62bf24',
    'src/evaluation/outcome_reader.py': '8852361b271c45998867b4c18441b7287651744e73d897d03e6e18e1d8b0a8d7',
    'src/evaluation/registry/FAMILY_REGISTRY_V1.json': '97299f32475e3e7311adc421f3dedf09f9a9c88aca2f8906adf4944904b341ac',
    'src/evaluation/registry/MEASURE_REGISTRY_V1.json': '133d5608c3772c3fb95a8cda586bc1ff822d5f8e003c11a386a84ae117ef9bcf',
    'src/evaluation/report.py': '79671f381fddd20ad9ee4e5762350f379fac3267859330d852a10cb3095030c8',
    'src/evaluation/report_writer.py': '914c8e4f883c8d4c975da6be0075afb6f4c700367d03d57be1a7e98c3e678db4',
    'src/evaluation/seed_policies.py': '83723109d13f98d91226c1b1c711bfeca5aacd6080a5fbb36b5ffaf2f708e094',
    'src/evaluation/seed_policies/N1_ROOT_NIST_C2_20261031T1030Z_V1.json': '4c429266b6471c0939e2d0b2d3d4bd12f62300af7085e3e9283f0e14705a154a',
    'src/evaluation/seed_policies/N1_ROOT_NIST_C2_20261106T0000Z_V1.json': '117008099e17db296cf9c6b0d2ca39b4a858e5c16a2380b8519c7b58834c17b2',
    'tests/test_wf1b_crossplatform.py': '317cd866428c47dee4ec1340e34f445f797eda5f9f688dda7e55e20194a2a4f4',
    'tests/test_wf1b_divisions.py': '89fb02a18c708640350ce7e64636773fdab01474c417d503556ad7aec5d341f3',
    'tests/test_wf1b_measures.py': '6cbb1138205c690927f58eeee645a5afbfc3fcf83b83586629d7ed7fd0f81507',
    'tests/test_wf1b_n1_generator.py': '3645a0130204be46f7f8a2c28ec9f37e0a5d63aa4aeccdadee4c60f5bb2a5293',
    'tests/test_wf1b_n1_replay.py': '8cc25761244d2f976f57f26d864f72d7fb31d5a001fe5c33fd4d61fb24962079',
    'tests/test_wf1b_numerics.py': '79db742a4f5a288c2276cf411f6dd0d72cac3f7783080bad8f57d2cc260fd5c9',
    'tests/test_wf1b_outcome_reader.py': 'e018a10eb9c2715c353d167244067ea9ce8d549fa4b4ca1916ec5e7fe745988a',
    'tests/test_wf1b_report.py': 'f8e615bc02d4192a08b746afff54e5e687c4fa4988147fb38fbe72f6575814f1',
    'tests/test_wf1b_seed_policy.py': 'fbb6c7b707e1600ada8d99d6be2e34e696bd150500ac5ccbc4cb9f2077130bc2',
    'tests/test_wf1b_static.py': 'a45c47f1a58d355692c1e5672b398325352ef728e8bb3880c0273ec114974ca8',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF
    '.gitignore': ('96cbd1c5a0894f0f5d1b6acda31de1a10081d39a9c15bf9405b4ea18db9adb0b', '0ec3517e881385f843c189c9a3736d4b18fa36cc181f2b11d9c786454607ebf6'),
}
DELETED = {  # path: base Git-content SHA-256 (LF)

}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'src/methods/_common/walk_forward.py': 'c11cf709e8a5bf6fb87b7467c94b56a82e16355e0a1bb7265efb4b4ac45922a7',
    'src/methods/Method_Walk_Forward.py': '1a1edd445566a2e9537a1636ede00ddcef6fca18cbaa021785cd35264faa7856',
    'src/methods/_common/contract_runner.py': 'c023fdc90d2ae0552558371489c39d3b583ef5c707d96394a77c2403b8dc4683',
    'src/methods/Method_Contract_Runner.py': 'fcbf02d851464e62d5019a1767bffd1b72ecb0f25e074f67c4887bea15368990',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/contract_publication.py': '665ed261bb1504854b0c3be7c60a84ad6ecab6559d74d949c19f85eaa7ae809b',
    'src/methods/_common/contract_receipts.py': 'e6d159e65dcf8269ea5576a7338d3ebcbf2d5dc0c06b06f1517189cc215908fd',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/methods/_common/contract_registry.py': '00082aad1754edbf2380c2caa144b0c79a12e2b6f26eb806d85903f177f11064',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'Run_Experiment.bat': 'dfd324d645cbbe5d528883f7a0309d5f5f3cbea47c4a49ddffaf6b0bdc7f0c5d',
    'Run_Coordinator.bat': '6ccb23302c897747432d84d1a1f4ed6fd7b2cf99faa8298ec4f3b5d82841bc70',
    'results/audit/SEARCH_LOG.csv': 'bf57d5fa019993dd02484a7d1612b73605e76acf728a3c8dc18fcc4ea4ea8cfb',
    'doc/RATIFICATION_REGISTER_v0_22.md': 'ca955cf23b5681a534e784b4a4852acd2e8d0ccd0484e34150a05c824c0fe56b',
    'doc/Predictive_Randomness_Releases_and_WF1_Design_v0_1r1.md': '03f95fbe5c3f0e3771a07550b8b57d3c87fe5f7e06a8cc5d02974982ff7a12ee',
    'doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md': '53e30a3e649b48b8a88923d08bf578caf04a4ce93d6ea6468891ca97e93a57b6',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        for p, old in DELETED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be deleted is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be deleted differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} files to replace and {len(DELETED)} to delete '
              'at their base version. Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        dele = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('D  ')}
        need(len(new) + len(mod) + len(dele) == len(lines),
             'changes other than new files, modified files and staged deletions:\n' + status[:600])
        need(dele == set(DELETED), 'unexpected staged deletions: ' + ', '.join(sorted(dele ^ set(DELETED))))
        for p in DELETED:
            need(not (repo / p).exists(), f'deleted path still on disk: {p}')
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths, {len(MODIFIED)} modified files and '
              f'{len(DELETED)} staged deletions, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    for p, old in DELETED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the deleted file: {p}')
        need(run(repo, 'cat-file', '-e', f'HEAD:{p}').returncode != 0, f'deleted file still in HEAD: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}, **{p: 'D' for p in DELETED}}
    need(got == want, 'the last commit did not change exactly the expected paths; differences (path, status): ' +
         repr(sorted(set(got.items()) ^ set(want.items()))))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files, modified '
          f'{len(MODIFIED)} and deleted {len(DELETED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
