#!/usr/bin/env python3
"""DOC-10 (EX_117 C03): read-only check that every tracked file under results/ has LF line endings in the working tree.

It runs only `git ls-files --eol -- results` and reads its output. It imports no project code, opens no record file and
changes nothing. Accepted: `w/lf`; and `w/none` only when the working file's size is zero (checked with os.stat,
metadata only; EX_119 C03). Anything else (`w/crlf`, `w/mixed`, `w/none` on a nonempty file, a missing or unstatable
working file) is EOL STOP: do not continue, commit or push; send Claude the output. Do not try to repair anything yourself.
Usage (repository root):  python CHECK_RESULTS_EOL.py --repo .
"""
import argparse, os, subprocess, sys

ap = argparse.ArgumentParser()
ap.add_argument('--repo', required=True)
repo = ap.parse_args().repo
r = subprocess.run(['git', '-C', repo, 'ls-files', '--eol', '--', 'results'], capture_output=True, text=True)
if r.returncode != 0:
    print('EOL STOP: git ls-files failed:', r.stderr.strip())
    sys.exit(1)
bad, n, empty = [], 0, 0
for line in r.stdout.splitlines():
    meta, _tab, path = line.partition('\t')
    w = next((p for p in meta.split() if p.startswith('w/')), 'w/?')
    n += 1
    if w == 'w/lf':
        continue
    if w == 'w/none':
        try:
            size = os.stat(os.path.join(repo, path)).st_size
        except OSError:
            bad.append(f'{w:8} {path}  (cannot stat the working file)')
            continue
        if size == 0:
            empty += 1
            continue
        bad.append(f'{w:8} {path}  (not empty, yet has no line ending at all)')
        continue
    bad.append(f'{w:8} {path}')
if n == 0:
    print('EOL STOP: no tracked files under results/ (wrong folder?)')
    sys.exit(1)
if bad:
    for b in bad:
        print('  ' + b)
    print(f'EOL STOP: {len(bad)} of {n} tracked files under results/ are not LF in the working tree. Do not continue, '
          'commit or push. Send Claude this output; Claude gives the exact owner-run restore commands.')
    sys.exit(1)
print(f'EOL PASS: {n} tracked files under results/, all w/lf ({empty} empty, w/none). Read-only: nothing changed.')
