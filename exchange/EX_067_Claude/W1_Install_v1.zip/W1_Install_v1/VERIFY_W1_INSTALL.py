#!/usr/bin/env python3
"""Read-only installation verifier for the wave 1 package (E_7, E_8, E_9 and E_10 revision 1 with their shared helper, installed non-runnable; the template's draft 2).

Claude, 30 October 2026 (from the E_3/E_4 package verifier). Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 84 new paths are absent; the 4 modified files still have their
             base bytes; guarded files unchanged in Git.
  post       after copying the overlay: exactly the 84 new paths appear and exactly the 4
             modified files change, all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths and modified exactly the modified files, all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_W1_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = '7462ea9d5c2009e354b720fde26371fbaf4f0997'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/Predictive_Randomness_Wave1_E7_E8_E9_E10_Design_v0_1r1.md': '06b491225812e14962aef99e299cbd6c003be68bb5a73425e566f1b1fe685060',
    'doc/RATIFICATION_REGISTER_v0_18.md': '85125c4900dabee53d2674d0ca3a18abbed64d5179b7f0b178300f928de93c97',
    'review/Independent_ChatGPT_Wave1_R3_and_Template_Draft2_Review_v0_1.md': '76818fab4d16988ea89a0e52b55c42ada46163e5d10da288a4b558285aad1a21',
    'review/Independent_ChatGPT_Wave1_v0_1r1_Focused_RECHECK_v0_1.md': '780513e0b1f36ac1981f5b2e6476b985bec266a8ee01fa0fd2fb49b70d81763a',
    'review/W1_Install_v1/INSTALL_MANIFEST_SHA256.txt': '2126d8e069a705134799d1efdfac83878e0d87d4d1dab47416b528fb1027fd9f',
    'review/W1_Install_v1/mutations_py313.txt': 'a03737ca51a57bdf0ad0a3b4d42f085be5c32a37352b851b24b04b3f9ab75272',
    'review/W1_Install_v1/replaced_files_base_to_v1.diff': '4a8e847189fb7b4a12c933e8a54acb9329b5439843a5b133f851bf4f6e12f8cd',
    'review/W1_Install_v1/suite_py313.txt': 'e5e6570a9e1457dfa60c05b2a8caf5b2a1ed7f34013916ccf51295b14dcd08f6',
    'review/W1_Install_v1/suite_py315.txt': 'fabfebf26786551c2030ea9ceabe241caeae72cfb088e7c80561300b27fc14f8',
    'review/W1_Install_v1/template_trial_v2.txt': 'b52777d14f671bac575b9aa0c70fd3f35000cb5d43ff03e7e042906678154860',
    'review/W1_Install_v1/tools/make_template_draft2.py': 'ffd2d442f976f9667895edd2f4dadef1350d473c1c0b3e288bccd3fa771a9db7',
    'review/W1_Install_v1/tools/make_template_draft2_code.py': '0a6e353f82356197f82822099d3f176260972dff311459cd5f2cc8fc84d31509',
    'review/W1_Install_v1/tools/make_wave1_contract_data.py': '96471f37cd4ec019aabb0b5f3a23c1ac51120efc44075b30f3206fd7620b0b8e',
    'review/W1_Install_v1/tools/reference_wave1_examples.py': 'f72fca13889ff71ae075f1b5ff6caebe5e9e2c5cca9853fa9d2e4792fa1605c3',
    'review/W1_Install_v1/tools/template_trial_v2.py': '7dec0f6367d18048bff5fa3385876523ec17fe1e068748ea5dfb638c6eae5d45',
    'review/W1_Install_v1/tools/w1_mutations.py': 'e82b4eb84a9138bd09ae745f11a8955ed014cd95e192917fb169f85215c9c1ea',
    'review/W1_Install_v1/tools/write_wave1_methods.py': '80eabac03eac16306bcb5f7b06eedaf121fb066253335a4d54ba538cfcd9f6aa',
    'src/methods/E_007/IN_DEVELOPMENT.txt': '1f1b5bc827e4c6b8f0545b3fc4931909f3cd1055140f486387c275d96bc16a06',
    'src/methods/E_007/__init__.py': '1da98a22935f560337c44054f6720365f405d26e3256526b207753db644ca0ce',
    'src/methods/E_007/contract.py': '756e526776eb6a0a8e991d41bafcdd17ddd68259e5dba631dac9a4458f51487d',
    'src/methods/E_007/variants.py': '96f0a31cc54a57f5c1fb2e50961a7b740fd97ce1e916cd64c8cb8541cd15eaf9',
    'src/methods/E_008/IN_DEVELOPMENT.txt': 'ff16a0768ce49fcee9e300a8cddb2b4a40ebc140086607ddb8ecc3c34ec0ba7a',
    'src/methods/E_008/__init__.py': 'e9575cdbbd2d0705325867834b8d0928dbac7460565b3726507b3e20a6640c04',
    'src/methods/E_008/contract.py': 'd5073c29e3ce6de75d53884af31133c2e77b83f1d3a40fbb234d509e885f5000',
    'src/methods/E_008/variants.py': 'c231433c1071787ebaea1ddbdbe1ccb8f768cb8938acac9a50404599a05f2dbb',
    'src/methods/E_009/IN_DEVELOPMENT.txt': '60171715ba11c97ccf4ca2d2d912546d0abaf60d06c62a806eb34220ed328e75',
    'src/methods/E_009/__init__.py': '19b5becca8080f89b8def212847576e0a03a5cabbf781fa4b9f0f7c1cfcf7559',
    'src/methods/E_009/contract.py': '09538733263b95167dfdd1bde3e87252659df84648a3fbd7ea3205118b642dcd',
    'src/methods/E_009/variants.py': '739a8a2f631f0e1da9bb39397dd225dea86893df95f6d1bb088c384e39ca43ea',
    'src/methods/E_010/IN_DEVELOPMENT.txt': 'c4ed10bb77c2bfd39cdb2cc8f72b174528c75f97d3cb4f5328785c08f0b36c71',
    'src/methods/E_010/__init__.py': 'e8a831c4b2b8a75fa1b24a5cca5d83f41838d5cfa56f97f6a0a9c9b48deea12d',
    'src/methods/E_010/contract.py': '99324f3310899499633c61fe50001be8ea96938567ea0eb35610c58004e39f7a',
    'src/methods/E_010/variants.py': '883213f497e641e80b477eb076272b70e46c0ebc9a11220320bd8c4feadb1a5f',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_10/CONTRAST_S13_L104_V1/r1.json': 'f84a52a8a0166fdefab600af35d3c5601233cb127c4ff4e8a54eaf082a2b26fd',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_10/CONTRAST_S26_L208_V1/r1.json': 'ecdda09748d87b2f2e3c8c55248694be220e40e46da1e75518fb7add87e92f10',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_10/CONTRAST_S52_FULL_V1/r1.json': '4f3ec7b83bb6b5c888f170f13ac8466195772eb4631fb81b307fdfb78842cf3b',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_7/BETA_SHRINK_FULL_C52_V1/r1.json': '3e9d1ea5545e6230ec4e4d7eaaf078ea8ecf1e12ded0718eb9acffb3e2656744',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_7/BETA_SHRINK_W104_C52_V1/r1.json': 'c5f38726a05c04af8f18c793e7d460c8e1d68bf34ebfa3795e1815140c457871',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_7/BETA_SHRINK_W52_C52_V1/r1.json': 'c8ee37ec4c3ae75a04d071216a10ed6ebaf78493fc9a1fe476ef3fd2f05df503',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_8/HIER_PERIODS_P13_V1/r1.json': 'c43b3a7358a4ec594f9f8d6e26c06206fcd983cce82713480174203b7277645b',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_8/HIER_PERIODS_P26_V1/r1.json': 'c1e2d1ae739db14bac72a8e73895d8dd034b311869b7186a5a11f5d6572b2d7c',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_8/HIER_PERIODS_P52_V1/r1.json': '5171d6a270603908f33854cdf8e3ba3a7a4735f4d3e7ae8d1c1a39bf01f5c58a',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_9/EXP_DECAY_18_19_V1/r1.json': '4b11ba8d8f3d399739b38a7ac7e5c7360f5c9af7ea4452d37ab6f4c44db461ed',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_9/EXP_DECAY_37_38_V1/r1.json': 'a1ba80fe86c2f00ee03c2d9110a9b48d130e1311fcd528e9d6bb5ccac60a056b',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_9/EXP_DECAY_5_6_V1/r1.json': '1b2ba5ba26982474f8dfbb3272c985b8fdab83a2801fb143fb6666c6a0a61ef5',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_10/CONTRAST_S13_L104_V1/r1.json': 'df0ff5f7a4560c6464b573a127890363671e7490592af7160df8ec864c1c6541',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_10/CONTRAST_S26_L208_V1/r1.json': 'd5e0252f59fc7af644c98246c57948915849cd830bee21aaf3fb9f4f0656572a',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_10/CONTRAST_S52_FULL_V1/r1.json': '00ae71b55fd15533262bb89983ab5b273fa8ff07c3862aa2382320d15bb8176b',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_7/BETA_SHRINK_FULL_C52_V1/r1.json': 'cac7d6c00b1800b80ef6c51d5a0b86819a197ae210d47326a72f3904fe0746fb',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_7/BETA_SHRINK_W104_C52_V1/r1.json': 'c857b67b48ee2fba5d2f58224d4c71ee79b6fdb80156d4b8fe97f712bd9eb475',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_7/BETA_SHRINK_W52_C52_V1/r1.json': 'd76b89163b55387cd2971bb3e3cf46d6af43ec16e2bc047d29031103b29f8bcf',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_8/HIER_PERIODS_P13_V1/r1.json': 'fc62b2fcbd44750d0e0b1a5deb2300aa544a6396d62a3ac2ff5c4d048eb8b912',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_8/HIER_PERIODS_P26_V1/r1.json': '0ca221ece605e677fe977dc8da7ef01e182f28c928150dd2d6a53f482d32b4ac',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_8/HIER_PERIODS_P52_V1/r1.json': '0d5140f6154d5ca3b6ab2b9125d635270f93b031cadf934586d5cce20014682f',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_9/EXP_DECAY_18_19_V1/r1.json': '1fbdb8e00848f4180973e33ddfafe0bb4f6fdc97484bef8f3e550442ea745aea',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_9/EXP_DECAY_37_38_V1/r1.json': '7443276c3eb73491b9068818fc981632c67f9434c174e61e861a1bd628333291',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_9/EXP_DECAY_5_6_V1/r1.json': 'ad422f9385ac1e185ce3c7c8bc5cec3f2be4ea341a8dc5c8cae9e3d4a67c9172',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_10/CONTRAST_S13_L104_V1/entry_0001.json': '991111bbb59b35711cf4bfb58cb09f035f794db4f8a100284be2b39831b03024',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_10/CONTRAST_S26_L208_V1/entry_0001.json': 'b37fc4c37a99d4139b16dc86c88dc33eabc46eae0c0bd363f7847efc0f068c2b',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_10/CONTRAST_S52_FULL_V1/entry_0001.json': '41a9128aa9d4db1ed52d0ffb09e30cb0de6be5821ec0dafe2947aa82ebea0d4e',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_7/BETA_SHRINK_FULL_C52_V1/entry_0001.json': '943510767f002d19ff9d2df3fd4ecc6d082087def886795df0e7f5eab065a3f3',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_7/BETA_SHRINK_W104_C52_V1/entry_0001.json': '62767d54bb259c4ca10d300a189638f38ff25e22159aec3b391d956e06905d20',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_7/BETA_SHRINK_W52_C52_V1/entry_0001.json': 'ea4fca1f1fa12b3fc43f5caf2b24c33d9948a48d6338cb3be8999fde7ecdb03d',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_8/HIER_PERIODS_P13_V1/entry_0001.json': '079e438a21b494b3cf98524a930f00aba526f73315cb17d0378cd899e53bb752',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_8/HIER_PERIODS_P26_V1/entry_0001.json': '08d77c6c0c72ebdf7625167a108c9b5a848cb3d9d2cce6680255577f3842dce4',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_8/HIER_PERIODS_P52_V1/entry_0001.json': 'b0d91e5874909cfee4f9865738469fa39d6bc7da87c593e24e56245d1a014fda',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_9/EXP_DECAY_18_19_V1/entry_0001.json': '52927e366a02ccc2eb3f7359ffd7ae9784dcaa8ff4dc5ad1ed42198cb526926a',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_9/EXP_DECAY_37_38_V1/entry_0001.json': 'a5b454c54e8f56cd22c6b6fef4603bb82d9bc292884abadc9bf4edbd75e3184e',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_9/EXP_DECAY_5_6_V1/entry_0001.json': '671fabf8c1bf49ef41a0753c6e5d823a73ea29a2243afb9cbbd6d359088738fc',
    'src/methods/_common/contract_data/registry/POWERBALL/E_10/CONTRAST_S13_L104_V1/entry_0001.json': 'dd0b5dc16f7ba277e721f1ff74848f7602ea94f3aa22c4fc3578d39e5a3dc941',
    'src/methods/_common/contract_data/registry/POWERBALL/E_10/CONTRAST_S26_L208_V1/entry_0001.json': '494e7ac345bfd3eb157e97145d9fdd8603efb68339dad851fe04536144463f6e',
    'src/methods/_common/contract_data/registry/POWERBALL/E_10/CONTRAST_S52_FULL_V1/entry_0001.json': '19262deeef49763cc57d4990554e4406d69229f1c61a1437462877e143b73493',
    'src/methods/_common/contract_data/registry/POWERBALL/E_7/BETA_SHRINK_FULL_C52_V1/entry_0001.json': 'c774d702532e77025d382149eea4760c438c0a59c8549f427655ce2701ca6b1e',
    'src/methods/_common/contract_data/registry/POWERBALL/E_7/BETA_SHRINK_W104_C52_V1/entry_0001.json': '36f436aebd232f275f93569cfeb98211fa55e2194631191d6a85b30214009739',
    'src/methods/_common/contract_data/registry/POWERBALL/E_7/BETA_SHRINK_W52_C52_V1/entry_0001.json': '4a6bb0506c65511f394885715e5ecc6878cd09e0ca901bd802856915fdb76775',
    'src/methods/_common/contract_data/registry/POWERBALL/E_8/HIER_PERIODS_P13_V1/entry_0001.json': 'dfb7ae65f5b05e914a4f69ae5803bce2095ba278bdd5ec079d1ca54b6af143b4',
    'src/methods/_common/contract_data/registry/POWERBALL/E_8/HIER_PERIODS_P26_V1/entry_0001.json': '9e0d87005e7353c48a4e7e2ae494f8a042f48b65a6ba51ea546a1cbe300551ac',
    'src/methods/_common/contract_data/registry/POWERBALL/E_8/HIER_PERIODS_P52_V1/entry_0001.json': 'db796ab9bdddb5c0a0845312fc244d339dc75ebd8d744ddf9151a8a857585255',
    'src/methods/_common/contract_data/registry/POWERBALL/E_9/EXP_DECAY_18_19_V1/entry_0001.json': '531fe39d8d23b5e63acf4129103745ad059c4c9bb57bdf915dc501bdc544864a',
    'src/methods/_common/contract_data/registry/POWERBALL/E_9/EXP_DECAY_37_38_V1/entry_0001.json': '9e815342fca2c891f13a6b51ebdaf757596c0d2041285a83a3243a1a850e3414',
    'src/methods/_common/contract_data/registry/POWERBALL/E_9/EXP_DECAY_5_6_V1/entry_0001.json': '5041d345f1bad8ad3e8b6c0aacd3cadd7ae3c2fe1bfbf38deb0985ded5811220',
    'src/methods/_common/occurrence_counts.py': '76e39bf0aeb3273d0f5a9a41391d0ceac1cfd6a7b06955cbb80518e05f5cbde9',
    'tests/test_occurrence_counts.py': '473c33ef15c13e9d44d6c53119ff8ccf49baeb4eab33406cc257f3273a84bbdb',
    'tests/test_wave1_frequency.py': 'd82d98173658f0d6edc766cbd21e51cdb3c7f3834db0a82846061c236aa78313',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF
    'doc/METHOD_TEMPLATE/METHOD_SPECIFICATION_TEMPLATE.md': ('3812f671977382fc94e89477de5c417133800e71d0002397c40843b051fbadf6', '759ad3a0151e7292a45abfc0ea8b8b1f9ba70210511b19ebf38e5be7425a31c3'),
    'doc/METHOD_TEMPLATE/README.md': ('f17e2d6eb489797415252689038078047011b7aa7ba2e24f987c265078df3e26', '91eca77e9b3e0ec46d8ef2ae4186c7035f97f0caddbdde816b42e44470764b68'),
    'doc/METHOD_TEMPLATE/method_folder/contract.py.txt': ('8aefa8b17e70be4b63aa3add66722b4ac099bc4507623fb5a38ae225849294fa', 'fe2c4242fdeb3910d043541fb1c88ca9dc8c2ddce6eecb037118cdea4f0596b9'),
    'src/methods/Method_Contract_Runner.py': ('678e4627b668f3482d080194427cd427344549f0fd4004f7f9908b2ad6d686cd', 'aca387afa81472cc6b9e3eff7c9e89f52a2c627e6dae70221fa2f82fb67c93c8'),
}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'doc/RATIFICATION_REGISTER_v0_17.md': '268e72b2a435628550079682040ae2eab69b5a08baa3241e4ee9e47e54499d17',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r5.md': '1214bd971058ddd6cc680526fd80375bdbbd6db17397e41ba4c14ae5467101e1',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r6.md': 'db40f40ef22995fc65a949243001858f1d7d1285713c9954531ae6b601fc5616',
    'doc/Predictive_Randomness_E3_E4_Polynomial_Fit_Design_v0_1.md': 'b9d60b4c753bb90c6a7ca302fb4802c353b0ae23fbe82c2b417ae7b089fad072',
    'src/methods/_common/polynomial_fits.py': '1d1c8d1078638607c0c0f584184834a95285f6d3e00b544a2a8a103e5d831615',
    'src/methods/E_003/contract.py': '8509ea3641d48ed8b3771237beaa3205d31a09a491049b1687bc09177059e87f',
    'src/methods/E_004/contract.py': '68f967e1b86d9076235d8a94c15d3098f226ad7b97b24afbfed60406ccc74043',
    'tests/test_e3_e4_polynomial.py': 'ee038a2dd045698b81ace4bdfa2c9571290838ad97714bb273178ec55dddd562',
    'doc/METHOD_TEMPLATE/method_folder/model.py.txt': '2baf07c9a2c980012777c6cd370262aea8647d62e5d94a97bc025c4af1c9d72f',
    'doc/METHOD_TEMPLATE/test_template.py.txt': 'dcdb3c061d24f3029f5aafdb8aa0b64db35ca713f55c65462505d60f19d6fff4',
    'doc/Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md': '0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954',
    'doc/Predictive_Randomness_E6_Specification_and_Method_Template_Design_v0_1.md': 'cef16b44fb7088ec018e0a8d6f233231c04e3fe6d5431cf0a2e604ad8f6fc82e',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/canonical_encoding.py': '2096d8adb40737373169aea6c5d94147daa2b16ae6c961bbfcc6063e333efcac',
    'src/methods/E_001/multigame_e1.py': '3c4a2305873aed7dc0457efcb898519f6e888ed72557670da1e8b0f9687ca462',
    'src/methods/E_001/e1_standalone_contract.py': 'd9ef642c2949b1b2a10232d614ba1306365abaefe65338b5c0aa9e3d9f285e50',
    'src/methods/_common/contract_vocab.py': '6e30b5be8d024fa647a2406e38b44cdf3b3c0c84f0468d84e168e9fde40d4ec8',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/methods/_common/contract_task.py': 'e58c0ab288b3292d3eeaf49e7cf9170b0341ff53d23cbde839b8cdbd716a31b3',
    'src/methods/_common/contract_forecast.py': 'be88a1d640098a6990f14090108524e1d7437a425e1b6254672164b6fc7f8121',
    'src/methods/_common/contract_receipts.py': 'e6d159e65dcf8269ea5576a7338d3ebcbf2d5dc0c06b06f1517189cc215908fd',
    'src/methods/_common/contract_registry.py': '00082aad1754edbf2380c2caa144b0c79a12e2b6f26eb806d85903f177f11064',
    'src/methods/_common/contract_dispatch.py': '7f026bc8ff6a0a13120031371acee455734d12a79cbe923f988ba12c6a92a322',
    'src/methods/_common/contract_publication.py': '665ed261bb1504854b0c3be7c60a84ad6ecab6559d74d949c19f85eaa7ae809b',
    'src/methods/_common/contract_runner.py': 'a45c2612fdef0130b7b2a755b4d1db6aaafbdbc337d1bdcf9c83154782b1ed40',
    'src/methods/contract_adapters/e_001.py': 'b7b86cc19a522655d0f1be34e7a869572cd905eb038bb61d312f8201b129abaa',
    'src/coordinator_private/contract_coordinated_gate.py': '22e9686c1fc4589c981a73e5aacfc3fab2333fcd449388e9c6a50f56db560094',
    'src/coordinator_private/multigame_launch_spec.py': '2f4717f4e6be2d2084a01205c24a9ab048b55239da334b4b79181616ce675507',
    'src/methods/_common/multigame_method_registry.py': '496df7ae50df36fcbf5bb9818be434b706ebec31f58751b3dd7329d0cc77f67b',
    'src/methods/E_006/beta_bernoulli.py': '2c94d463f4020e7eb4f29949d12cb0cc8d0456f54dd5e1a89504c8f2d7fd976c',
    'src/methods/E_006/contract.py': '1752ecc51046ffcc49ce1d8b95986872f7422c8a50feafc221c057f3ab800b4b',
    'src/methods/E_006/IN_DEVELOPMENT.txt': '853862022b400247cce6e2fac4421d90be71f52475db8f6681f35bfe5fa63a5e',
    'tests/e2r_fixtures.py': '6755c9fe44ba2d222d2522cd81090c11044f59c2e2344e4bd27b9f02ecab643d',
    'tests/e2r_code2_fixtures.py': '20c92643998634b5eb6acac45bfcf8bf6253b8ca01ce6e524fdb795b622110f4',
    'tests/test_e2r_runner.py': 'a2d2384c0f7369f554db0235886aeed6b90443d90e012645c2b46e046ffbee9d',
    'tests/test_e2r_contract.py': 'e09139279401b202c70fd3de230607a9a1755dde42f533a2a164c639c460dd47',
    'tests/test_e2r_dispatch.py': '7c37981283ec0f640eb1c59121fec5ebe5aa1d2bd3ccfdc4d6d79c64fffd3ab9',
    'tests/test_e6_beta_bernoulli.py': '8750b1e3bf134d2994bf3569f4970ca5aa54846bdbb64e17cac582261d48e8b4',
    'src/methods/_common/contract_data/registry/POWERBALL/E_7/NOT_YET_SPECIFIED/entry_0001.json': '30d0c3cf68e21cfe96fd6d0d0b0efcec996151830596aa470738063f313987dc',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_10/NOT_YET_SPECIFIED/entry_0001.json': '1d659628637eeaa5bdd5f446c540ed5bc75540300d8f1f44acdfa9d6cc30f825',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} files at their base version. '
              'Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        need(len(new) + len(mod) == len(lines), 'changes other than new files and modified files:\n' + status[:600])
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths and {len(MODIFIED)} modified files, '
              'all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}}
    need(got == want, 'the last commit did not change exactly the expected paths: ' + repr(sorted(got.items())))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files and modified '
          f'{len(MODIFIED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
