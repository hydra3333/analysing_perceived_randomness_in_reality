# PERF1_Install_v1 - PERF-1 package (faster exact Clopper-Pearson intervals with identical results; report progress lines) (only after the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\PERF1_Install_*` folders, then extract it there (`tar -xf "E:\TEMP\PERF1_Install_v1_candidate.zip" -C E:\TEMP`). This package adds 8 new files and replaces 3 existing files (`src/evaluation/numerics.py`, `report.py` and `Method_Rankings_Report.py`); nothing else changes. It runs no report. Your working tree must be clean first: commit or settle any report results before you start.

## 1. Update, check, copy, check, and the tests (one block; do not skip the last command)

```bat
git status --short
git pull --ff-only
python "E:\TEMP\PERF1_Install_v1\VERIFY_PERF1_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\PERF1_Install_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\PERF1_Install_v1\VERIFY_PERF1_INSTALL.py" --repo . --phase post
.venv\Scripts\python.exe "E:\TEMP\PERF1_Install_v1\RUN_PERF1_SUITE.py" --repo .
```

Expected: `git status --short` prints nothing (if it prints anything, stop and send Claude the output); the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `11 File(s) copied`; `POST PASS`; then `SUITE PASS` (471 tests; the only allowed skips are symlink tests: on Windows without symlink rights, up to 4). E2R-T12 starts up to six ordinary Python worker processes and lets them finish normally. The WF-1B and PERF-1 tests run on invented data in temporary folders, with an invented N1 root. If anything prints `STOP` or `FAILED`, do not commit: send Claude the output.

## 2. Stage, commit, check, and only then push

```bat
git add review src tests
git status --short
git commit -m "PERF-1: faster exact binomial sums and Clopper-Pearson intervals (identical results) and progress lines for the ranking report tool"
python "E:\TEMP\PERF1_Install_v1\VERIFY_PERF1_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 8 lines starting with `A` and 3 starting with `M`, and nothing else; then `COMMITTED PASS`. Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub.
