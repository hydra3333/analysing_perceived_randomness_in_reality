#!/usr/bin/env python3
"""Read-only installation verifier for the PERF-1 package (faster exact Clopper-Pearson intervals with identical results; report progress lines).

Claude, 31 October 2026 (from the wave 2 package verifier; adds deleted paths). Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 8 new paths are absent; the 3 modified files and the 0 files
             to be deleted still have their base bytes; guarded files unchanged in Git.
  post       after copying the overlay (and the git rm step, if any): exactly the 8 new paths
             appear, exactly the 3 modified files change and exactly the 0 deleted files are gone
             (staged deletions), all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths, modified exactly the modified files and deleted exactly the deleted files,
             all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_PERF1_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = '209db44c22efabdda0cf064cc84f88108bcc4d52'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'review/PERF1_Install_v1/INSTALL_MANIFEST_SHA256.txt': '64faaa9f76f0d0b5228f2461f9b77d3e868556a3b5203a27ecc7fbfb82eb32e9',
    'review/PERF1_Install_v1/mutations_perf1_v1_py313.txt': 'd49a2a3ef5ab15de60d3ec4944a466474a4ff25cb66546da9c6c4dcb858f298d',
    'review/PERF1_Install_v1/perf1_timings.txt': '1bd2c86e8f267d69f1a9366b16557f54a1c9776e63b47435b379e8813d63116b',
    'review/PERF1_Install_v1/replaced_files_base_to_perf1.diff': '9dabf7cea7fdd4ef3dade19b34d92cc7e0af3faa682d9aea6fe671395cf9532c',
    'review/PERF1_Install_v1/tools/build_perf1_pkg.py': 'a3f4c78ffcdb45adcdbc2f95d69a2cae9cfd5e5d13623ba8757c9dcf65fbae8b',
    'review/PERF1_Install_v1/tools/perf1_mutations.py': '838862c05788aaeab7d497ab8316b440309ae408ef8d24a3fb81c17a25f2a453',
    'review/PERF1_Install_v1/tools/profile_stats.py': '2cc6930940778829aefce97bba7c2c353145fb1243fc57a4cc7bb980cc4be592',
    'tests/test_perf1_numerics.py': '41e65ba59e76d1e7a28b0a5ceb3ba9acb3d9d8fba5c0f420b2b262010b2c26dd',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF
    'src/evaluation/Method_Rankings_Report.py': ('06261a6f1f867543faec79d5971a1c2d52d2ef042f033058858fa2f56b7d25f0', '42b081a5303f63e243772c08de508bf8bd04c575da8b70564a24fcc31e2aed19'),
    'src/evaluation/numerics.py': ('85a35cbc2f66eeb544bb6dfd872d17534b2a27e334f0bc21da268527dc62bf24', '8f3aaa3e698e941077407cc0e1401ced2a82a9af95244190de8f10b10e163a40'),
    'src/evaluation/report.py': ('79671f381fddd20ad9ee4e5762350f379fac3267859330d852a10cb3095030c8', 'b1ce781436268332daa0bf5f6037564f7774a70ab5d68de71b16811de29da82b'),
}
DELETED = {  # path: base Git-content SHA-256 (LF)

}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'src/evaluation/n1.py': 'f5008a72b93eb0c69f951e60e90759d2c45bbe7a721b6bed1f70672e1b9a1330',
    'src/evaluation/n1_generator.py': '004583a8d02f4282fbfefd1ec46bc3983f50bc78e0a186a836ec7b521f88e36f',
    'src/evaluation/measures.py': '2081d324e12fab909411d14346b19a24cec28316e2c13e263d194e464e9867bf',
    'src/evaluation/divisions.py': 'bd6201c310e3b9eea085062d5b84627f9d8b30fc593c06a0d82e2743a288deb2',
    'src/evaluation/collect.py': 'ea9214ebc7320a2a197e7164b97474085e116ef46cdc735c82f821a3f9486c02',
    'src/evaluation/outcome_reader.py': '8852361b271c45998867b4c18441b7287651744e73d897d03e6e18e1d8b0a8d7',
    'src/evaluation/report_writer.py': '914c8e4f883c8d4c975da6be0075afb6f4c700367d03d57be1a7e98c3e678db4',
    'src/evaluation/seed_policies.py': '83723109d13f98d91226c1b1c711bfeca5aacd6080a5fbb36b5ffaf2f708e094',
    'src/evaluation/registry/MEASURE_REGISTRY_V1.json': '133d5608c3772c3fb95a8cda586bc1ff822d5f8e003c11a386a84ae117ef9bcf',
    'src/evaluation/registry/FAMILY_REGISTRY_V1.json': '97299f32475e3e7311adc421f3dedf09f9a9c88aca2f8906adf4944904b341ac',
    'src/evaluation/seed_policies/N1_ROOT_NIST_C2_20261031T1030Z_V1.json': '4c429266b6471c0939e2d0b2d3d4bd12f62300af7085e3e9283f0e14705a154a',
    'src/evaluation/seed_policies/N1_ROOT_NIST_C2_20261106T0000Z_V1.json': '117008099e17db296cf9c6b0d2ca39b4a858e5c16a2380b8519c7b58834c17b2',
    'src/methods/_common/walk_forward.py': 'c11cf709e8a5bf6fb87b7467c94b56a82e16355e0a1bb7265efb4b4ac45922a7',
    'src/methods/_common/contract_runner.py': 'c023fdc90d2ae0552558371489c39d3b583ef5c707d96394a77c2403b8dc4683',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/contract_publication.py': '665ed261bb1504854b0c3be7c60a84ad6ecab6559d74d949c19f85eaa7ae809b',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'Run_Method_Rankings.bat': '087813da95aa163d2f308b47284710bc4f3bf1fc88014faa80dc0df9a1eb2973',
    'Run_Experiment.bat': 'dfd324d645cbbe5d528883f7a0309d5f5f3cbea47c4a49ddffaf6b0bdc7f0c5d',
    'Run_Coordinator.bat': '6ccb23302c897747432d84d1a1f4ed6fd7b2cf99faa8298ec4f3b5d82841bc70',
    '.gitignore': '0ec3517e881385f843c189c9a3736d4b18fa36cc181f2b11d9c786454607ebf6',
    'doc/Predictive_Randomness_WF1B_Supplement_Design_v0_1r1.md': 'a2f470797f31e387f44b5492ed406f1376b3eb92f2181dc76f6ac4c80168185a',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        for p, old in DELETED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be deleted is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be deleted differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} files to replace and {len(DELETED)} to delete '
              'at their base version. Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        dele = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('D  ')}
        need(len(new) + len(mod) + len(dele) == len(lines),
             'changes other than new files, modified files and staged deletions:\n' + status[:600])
        need(dele == set(DELETED), 'unexpected staged deletions: ' + ', '.join(sorted(dele ^ set(DELETED))))
        for p in DELETED:
            need(not (repo / p).exists(), f'deleted path still on disk: {p}')
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths, {len(MODIFIED)} modified files and '
              f'{len(DELETED)} staged deletions, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    for p, old in DELETED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the deleted file: {p}')
        need(run(repo, 'cat-file', '-e', f'HEAD:{p}').returncode != 0, f'deleted file still in HEAD: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}, **{p: 'D' for p in DELETED}}
    need(got == want, 'the last commit did not change exactly the expected paths; differences (path, status): ' +
         repr(sorted(set(got.items()) ^ set(want.items()))))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files, modified '
          f'{len(MODIFIED)} and deleted {len(DELETED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
