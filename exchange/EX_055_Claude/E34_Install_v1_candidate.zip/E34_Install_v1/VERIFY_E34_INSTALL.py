#!/usr/bin/env python3
"""Read-only installation verifier for the E_3/E_4 package (E_3 and E_4 revision 1 and their shared helper, installed non-runnable).

Claude, 30 October 2026 (from the E_6 package verifier). Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; src/ and tests/ in HEAD are exactly the
             base commit's; the 69 new paths are absent; the 1 modified files still have their
             base bytes; guarded files unchanged in Git.
  post       after copying the overlay: exactly the 69 new paths appear and exactly the 1
             modified files change, all with the expected bytes (CRLF tolerated: the comparison is on
             LF-normalised bytes).
  committed  after the commit: clean tree; HEAD has one parent; the last commit added exactly the
             new paths and modified exactly the modified files, all with the expected Git blobs.
On any STOP in the committed phase, the verifier prints the identities needed to decide what
to do (HEAD, its parent, the last commit's paths, the working-tree status). Do NOT push and do
NOT reset: send Claude the whole output.
Usage: python VERIFY_E34_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = '7c93320c2cce853b94e23203bb47e3f66aaa7994'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {  # path: Git-content SHA-256 (LF)
    'doc/Predictive_Randomness_E3_E4_Polynomial_Fit_Design_v0_1.md': 'b9d60b4c753bb90c6a7ca302fb4802c353b0ae23fbe82c2b417ae7b089fad072',
    'doc/RATIFICATION_REGISTER_v0_16.md': '66f3c977714960cb64193bf87daa612f970fb25edf1980c4434ac6935be85ab1',
    'review/E34_Install_v1/INSTALL_MANIFEST_SHA256.txt': '3f60496cb5113806f22ac80d1f62642625679e1f4e92984e2b5f78891b6e4746',
    'review/E34_Install_v1/mutations_py313.txt': 'cd0bca069b5348ac2552d4c11911c766e22884c1cc381adbd08f38b0dfa6ace1',
    'review/E34_Install_v1/replaced_file_base_to_v1.diff': '87305229624e4e2a6c276af2fa557a64246f739f62c7c118b3ac3d80f3360527',
    'review/E34_Install_v1/suite_py313.txt': '99e7359197b2f667c67f19adcfbba4350d08624dfc9b36441c589916515935b3',
    'review/E34_Install_v1/suite_py315.txt': '9e11b9ddec960c4eb7b8c04acb65c9659e0f9314310e158a631c10670facb1e7',
    'review/E34_Install_v1/tools/e34_mutations.py': '9a913f41454f00a00a5e7d2e638b5b9e90c538557673015b81e7c97c52ba9406',
    'review/E34_Install_v1/tools/make_e3e4_contract_data.py': '37ac2483f123c4eff7fee7c85338e799d64bcd9c0e51bd27522ed9e309af01be',
    'review/Independent_ChatGPT_EX052_Three_Part_Review_v0_1.md': '8cb7519e72c01751d8a88e211517e65daf8ea63d88fef3fbafd35fc21a1b6491',
    'src/methods/E_003/IN_DEVELOPMENT.txt': '068ce17c1855b5e666b046e6397fdf96a36f970d35f407a3f7f61cce386da72e',
    'src/methods/E_003/__init__.py': 'b6ca2d3f76e05ef842cb7071bcd648936a6500ba80019c3ed3235a308b980a7d',
    'src/methods/E_003/contract.py': '8509ea3641d48ed8b3771237beaa3205d31a09a491049b1687bc09177059e87f',
    'src/methods/E_003/variants.py': 'bdd60d39e404e162060c2707c6ead227cd2f61e0ec99893ba86a9942b5e8224b',
    'src/methods/E_004/IN_DEVELOPMENT.txt': 'aca1b3f57e18307be94114cd22702cb9059ecd607f43f3ad9688fdcee05d4c9d',
    'src/methods/E_004/__init__.py': '964d1e906244d2148875a9305eee034c302e8d2e53ab5600aefe907376134883',
    'src/methods/E_004/contract.py': '68f967e1b86d9076235d8a94c15d3098f226ad7b97b24afbfed60406ccc74043',
    'src/methods/E_004/variants.py': '4c5494ca3ec938934ff7fa695b4d86218068ba18bb7c278e409155bbb6c0165b',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_3/POLY_INTERP_W52_D4_H4_V1/r1.json': '675e93c117290794940faace2d15ed3aa337a50766f634e7e8be6ea64a88fd29',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_3/POLY_LS_W104_D3_V1/r1.json': '261ad0d2e80421c110ad4f7ed704b0a9988e799876a91b98c84b55a81bb50eb6',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_3/POLY_LS_W52_D2_V1/r1.json': '49273d2b2e524862eb362b873dbad1e9da0cd6e7e4d3aca190db7b2dd1878677',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_3/POLY_LS_W52_D3_V1/r1.json': 'f12204f0cd635bfcd7c641ad4263daf0434b2e48aec42ac7e66e9ce8730c9087',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_3/POLY_MINIMAX_W52_D2_H4_V1/r1.json': '3d07d811c6dab777e4c4ec55dd55ee88e087232a02a38de5d5eafe2262baf64b',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_3/POLY_MINIMAX_W52_D3_H4_V1/r1.json': '883720ba68a95473a7067bfad13a18d31ad3991fc3920c043c58bc34526de2c2',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_4/POLY_INTERP_W52_D4_H4_V1/r1.json': '72391bf05c58e5350ce91bf78f0b65aa05a8b8bde87c6c4125a90e38a54092ab',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_4/POLY_LS_W104_D3_V1/r1.json': '92fe0ad56058a1f5ef77fbd9881a5c94f56674b4a265665aebad00aed63e06d7',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_4/POLY_LS_W52_D2_V1/r1.json': 'b72d38cfc669682c79d0c5c0c4c494593d0212e26a487d7fdffedb5f996b62e4',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_4/POLY_LS_W52_D3_V1/r1.json': 'e65aa7d4cbedc2e78580d6b5243129aa2c4cda0315c508806a79ca1ab0e89af7',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_4/POLY_MINIMAX_W52_D2_H4_V1/r1.json': '4b5b465678ce9e29e0fa8d4bd529af1dbb95c436dacffcb7dfd142f313d8a827',
    'src/methods/_common/contract_data/declarations/OZLOTTO/E_4/POLY_MINIMAX_W52_D3_H4_V1/r1.json': '0f35ede3bc44e29b0e1f62810f433f84144288670af0c38ef2a61e6bc5b45e42',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_3/POLY_INTERP_W52_D4_H4_V1/r1.json': '1a3b9d454e70716cad3f7d8d0e3191911ae53a2b9292ff8b0f1696aa37680168',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_3/POLY_LS_W104_D3_V1/r1.json': '04610e9d022a3856c441cf1727b9c626edec8a06012b4f8e37696734fd11e860',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_3/POLY_LS_W52_D2_V1/r1.json': '985d2a4df7884986104d0a22cc2f50c92577851462d775b760b72e687c1d2b3a',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_3/POLY_LS_W52_D3_V1/r1.json': '804114dab5dbf4ae8d193e89fa3774c8217fed5a25b7ea23f1634dcf713f7239',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_3/POLY_MINIMAX_W52_D2_H4_V1/r1.json': 'c46a2bcbc9d80eb17c99957dd8690fe2e1a15f4a903054b1b41a886ccde84fda',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_3/POLY_MINIMAX_W52_D3_H4_V1/r1.json': '4cf1ffc1cb3cccd70304644b5118b46b1257ff320da5fad7a441cf9ae08dee5d',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_4/POLY_INTERP_W52_D4_H4_V1/r1.json': '47c37f44f07ec611bff45a1cb886a61a09c25cf3594b1d5ba5dc55a3ff9d85a4',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_4/POLY_LS_W104_D3_V1/r1.json': 'dd195e3237e98593981ed06e1bce91b841cd9cae1f642ab775e9f290a7cc580b',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_4/POLY_LS_W52_D2_V1/r1.json': '552fa7653c6124a79bfbce67e9d98b31b08035cd80c1108a50a22a983c6eb092',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_4/POLY_LS_W52_D3_V1/r1.json': '56e526b593ef3eaae892b2eebea7639684cf46050bab74a6c447ce88349dc707',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_4/POLY_MINIMAX_W52_D2_H4_V1/r1.json': 'dedb27e0551cef4d8fd91b3dd1674d4f15b462eb6404c6f5fa43f1ee7d42ddaf',
    'src/methods/_common/contract_data/declarations/POWERBALL/E_4/POLY_MINIMAX_W52_D3_H4_V1/r1.json': 'e4f2cd1ea5116cc12d1a761d63ab1bd33efb8de474e9963cad369d67477e64e8',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_INTERP_W52_D4_H4_V1/entry_0001.json': '7dff805e5b0e64f26ce808ca105f4f7aa36e87fc707735adffd0d9723b90ed86',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_LS_W104_D3_V1/entry_0001.json': '89b098d291d0c72835a2ebf74504becf7a4b5eb7e05400e016cac0f32211d673',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_LS_W52_D2_V1/entry_0001.json': 'e2531842178da8713e7952073bf6480b4b9d51b2332b76854322fb8999083012',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_LS_W52_D3_V1/entry_0001.json': '69c5fb83ac8456b987cab3168ca7e175b4c8949d5ffbca8bbf78c45dcd12a594',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_MINIMAX_W52_D2_H4_V1/entry_0001.json': '50603b414ec695edece4e0e132bdf5af37c44e95bb63726a7102375dd11bf644',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_3/POLY_MINIMAX_W52_D3_H4_V1/entry_0001.json': 'cefb58efa1e5e378cac15dc11004aae35bacda049a177780103fc528694f8e7d',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_INTERP_W52_D4_H4_V1/entry_0001.json': '3e1b7461d7df17550133455220480c92ee17e8a2f803354e82402237d29eb856',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_LS_W104_D3_V1/entry_0001.json': '2709ff6934139df5e50d98875aa5e20975a7d2afb5398d04322354632c731568',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_LS_W52_D2_V1/entry_0001.json': '4ae83061ee9f0f1cdd212129be5686f02d7de494382e179903061cb3c5dd2ba2',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_LS_W52_D3_V1/entry_0001.json': '857ba88928ec2d572d512556a47d2c89f1161c8719956600924f9ab46862d135',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_MINIMAX_W52_D2_H4_V1/entry_0001.json': '256c13878881e3c1d8010e390bfd3085df8e1186e7f34d3590dbd8db8123c72c',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/POLY_MINIMAX_W52_D3_H4_V1/entry_0001.json': 'b1c259b7429f06c17f0169ea7f2a10dcc83c5b85840481441fa57d5342c9e1ae',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_INTERP_W52_D4_H4_V1/entry_0001.json': 'cc9f8cc2500553b9ba60473c6031cf1c8c45b15a064ff7b3c4a58c15995b80ac',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_LS_W104_D3_V1/entry_0001.json': '86e9ce0e91cf29f4515cda7cfa52f2e8606fdee206103ed415cd97b4aa55ba9a',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_LS_W52_D2_V1/entry_0001.json': '103a4092379f04bf1fc4c3c78cd49b28bed6176fda0c0399f524f866f9881c3c',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_LS_W52_D3_V1/entry_0001.json': '2b904c8a55441cfeecc9d08a4347393d1de0042024bcc1977ead4d71b9edabb8',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_MINIMAX_W52_D2_H4_V1/entry_0001.json': '09beb9cb461a292ebd42175a6d6896b559635890cef7ff3d0060677b2aac7fba',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/POLY_MINIMAX_W52_D3_H4_V1/entry_0001.json': 'aee2fc69641cc798c91c51270ae184afc9450980bf20a656a58eb9bb7ddd501e',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_INTERP_W52_D4_H4_V1/entry_0001.json': '23cfb5f590248b0419003eb6a8439e5591dd5a381d2ba6dedc34b7867e021076',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_LS_W104_D3_V1/entry_0001.json': '501697e0c4b832c83256a98eb1e9ff4b614509f53c4aff314f6f742fecb684d7',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_LS_W52_D2_V1/entry_0001.json': 'a2b8c1b266c03343a9a07eee053205b50eef75bd2f110d7831153e00b7d41a32',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_LS_W52_D3_V1/entry_0001.json': 'd14a8bea7283b8ae03b40b7c2d3688c725d494615382a3573c1e461a53ea646f',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_MINIMAX_W52_D2_H4_V1/entry_0001.json': 'a4ffd3a13c920308d16617aab528ffabaa33fe8497f788bc77c34f6634b7b889',
    'src/methods/_common/contract_data/registry/POWERBALL/E_4/POLY_MINIMAX_W52_D3_H4_V1/entry_0001.json': '97a4a87a7ba51b8f73cc494fa1ea1b6e3fa7283c219d82bb72b12a719dd3ef66',
    'src/methods/_common/polynomial_fits.py': '1d1c8d1078638607c0c0f584184834a95285f6d3e00b544a2a8a103e5d831615',
    'tests/test_e3_e4_polynomial.py': 'ee038a2dd045698b81ace4bdfa2c9571290838ad97714bb273178ec55dddd562',
    'tests/test_polynomial_fits.py': 'dd2f9ce83cf00e015b375bd87fadc968af2790f3871342ebf52b7e5b017c656b',
}
MODIFIED = {  # path: (base Git-content SHA-256, new Git-content SHA-256), LF
    'src/methods/Method_Contract_Runner.py': ('2fbb2e5080e7f2f97e19691e1d64fb25e88e304480f414a32344563b9b4f7c2a', '678e4627b668f3482d080194427cd427344549f0fd4004f7f9908b2ad6d686cd'),
}
GUARDED = {  # must stay byte-identical in Git (hashes of the Git blobs at the base commit)
    'doc/RATIFICATION_REGISTER_v0_15.md': '405cc2f964db5a86cdf6a94bfc1382d01911ef9f41162b047c43c7f1af04ea2e',
    'doc/HANDOVER/Claude_Primary_Handover_H1_v1r4.md': '2050e9363d841634ecf2a9c308d3efb1ed51b359fbdaf2aa3531a60eb1f1c16a',
    'doc/HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r5.md': '67a1b3eaa3e1f51415eceba513fd7e1a39de91619296f0efba97ba108570a094',
    'doc/Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md': '0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954',
    'doc/Predictive_Randomness_E6_Specification_and_Method_Template_Design_v0_1.md': 'cef16b44fb7088ec018e0a8d6f233231c04e3fe6d5431cf0a2e604ad8f6fc82e',
    'src/Powerball_Experiment_Coordinator.py': '6d202f5efd164c8e4a0eba97d435a0ec55787da87fcb2930af51309f573adcff',
    'src/methods/_common/game_draws_reader.py': 'de4631572160214464e0ecdf9b0f6564b193fe244859a3d2d86f703299819ee5',
    'src/methods/_common/game_profiles.py': 'd49e83b5f91f5a0b299c6e08ae48c598d03b969a5dec70e05932daa3e4827a9b',
    'src/methods/_common/canonical_encoding.py': '2096d8adb40737373169aea6c5d94147daa2b16ae6c961bbfcc6063e333efcac',
    'src/methods/E_001/multigame_e1.py': '3c4a2305873aed7dc0457efcb898519f6e888ed72557670da1e8b0f9687ca462',
    'src/methods/E_001/e1_standalone_contract.py': 'd9ef642c2949b1b2a10232d614ba1306365abaefe65338b5c0aa9e3d9f285e50',
    'src/methods/_common/contract_vocab.py': '6e30b5be8d024fa647a2406e38b44cdf3b3c0c84f0468d84e168e9fde40d4ec8',
    'src/methods/_common/contract_records.py': '1596d60a3de8853e4249afba9471ab5c1958c39fda5c3d989bfc650ee256b1d3',
    'src/methods/_common/contract_task.py': 'e58c0ab288b3292d3eeaf49e7cf9170b0341ff53d23cbde839b8cdbd716a31b3',
    'src/methods/_common/contract_forecast.py': 'be88a1d640098a6990f14090108524e1d7437a425e1b6254672164b6fc7f8121',
    'src/methods/_common/contract_receipts.py': 'e6d159e65dcf8269ea5576a7338d3ebcbf2d5dc0c06b06f1517189cc215908fd',
    'src/methods/_common/contract_registry.py': '00082aad1754edbf2380c2caa144b0c79a12e2b6f26eb806d85903f177f11064',
    'src/methods/_common/contract_dispatch.py': '7f026bc8ff6a0a13120031371acee455734d12a79cbe923f988ba12c6a92a322',
    'src/methods/_common/contract_publication.py': '665ed261bb1504854b0c3be7c60a84ad6ecab6559d74d949c19f85eaa7ae809b',
    'src/methods/_common/contract_runner.py': 'a45c2612fdef0130b7b2a755b4d1db6aaafbdbc337d1bdcf9c83154782b1ed40',
    'src/methods/contract_adapters/e_001.py': 'b7b86cc19a522655d0f1be34e7a869572cd905eb038bb61d312f8201b129abaa',
    'src/coordinator_private/contract_coordinated_gate.py': '22e9686c1fc4589c981a73e5aacfc3fab2333fcd449388e9c6a50f56db560094',
    'src/coordinator_private/multigame_launch_spec.py': '2f4717f4e6be2d2084a01205c24a9ab048b55239da334b4b79181616ce675507',
    'src/methods/_common/multigame_method_registry.py': '496df7ae50df36fcbf5bb9818be434b706ebec31f58751b3dd7329d0cc77f67b',
    'src/methods/E_006/beta_bernoulli.py': '2c94d463f4020e7eb4f29949d12cb0cc8d0456f54dd5e1a89504c8f2d7fd976c',
    'src/methods/E_006/contract.py': '1752ecc51046ffcc49ce1d8b95986872f7422c8a50feafc221c057f3ab800b4b',
    'src/methods/E_006/IN_DEVELOPMENT.txt': '853862022b400247cce6e2fac4421d90be71f52475db8f6681f35bfe5fa63a5e',
    'tests/e2r_fixtures.py': '6755c9fe44ba2d222d2522cd81090c11044f59c2e2344e4bd27b9f02ecab643d',
    'tests/e2r_code2_fixtures.py': '20c92643998634b5eb6acac45bfcf8bf6253b8ca01ce6e524fdb795b622110f4',
    'tests/test_e2r_runner.py': 'a2d2384c0f7369f554db0235886aeed6b90443d90e012645c2b46e046ffbee9d',
    'tests/test_e2r_contract.py': 'e09139279401b202c70fd3de230607a9a1755dde42f533a2a164c639c460dd47',
    'tests/test_e2r_dispatch.py': '7c37981283ec0f640eb1c59121fec5ebe5aa1d2bd3ccfdc4d6d79c64fffd3ab9',
    'tests/test_e6_beta_bernoulli.py': '8750b1e3bf134d2994bf3569f4970ca5aa54846bdbb64e17cac582261d48e8b4',
    'doc/METHOD_TEMPLATE/README.md': 'f17e2d6eb489797415252689038078047011b7aa7ba2e24f987c265078df3e26',
    'src/methods/_common/contract_data/registry/POWERBALL/E_3/NOT_YET_SPECIFIED/entry_0001.json': '10d435477b6f9ce542ed85b44e341e501f8f35d0ffb8c67569100d80b7438ef8',
    'src/methods/_common/contract_data/registry/OZLOTTO/E_4/NOT_YET_SPECIFIED/entry_0001.json': '5b9eb0a7dba26f79b7d2c5607ba2b0023431c91f4d0d70d5cc428960abf26b1c',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def norm(b):
    return b.replace(b'\r\n', b'\n')


def run(repo, *args):
    return subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                          stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)


def git(repo, *args):
    r = run(repo, *args)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def identities(repo):
    """Read-only facts for deciding after a committed-phase STOP."""
    print('--- identities for Claude (read-only) ---', file=sys.stderr)
    for label, args in [('HEAD and parents', ['log', '-1', '--format=%H %P %s', 'HEAD']),
                        ('last 3 commits', ['log', '--oneline', '-3']),
                        ('last commit paths', ['diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD']),
                        ('upstream', ['rev-parse', '--abbrev-ref', '--symbolic-full-name', '@{u}']),
                        ('commits not yet pushed', ['log', '--oneline', '@{u}..HEAD']),
                        ('working tree and index', ['status', '--porcelain=v1', '--untracked-files=all'])]:
        r = run(repo, *args)
        out = (r.stdout if r.returncode == 0 else r.stderr).decode(errors='replace').rstrip()
        print(f'[{label}]\n{out[:1500] or "(none)"}', file=sys.stderr)
    print('--- Do NOT push. Do NOT reset. Send Claude this whole output. ---', file=sys.stderr)


def main(a):
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:  # the package must be intact
        need(sha(norm((HERE / 'repo_overlay' / p).read_bytes())) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = run(repo, 'merge-base', '--is-ancestor', BASE, 'HEAD')
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain=v1', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        diff = git(repo, 'diff', '--name-only', BASE, 'HEAD', '--', 'src', 'tests').decode().split()
        need(not diff, 'src/ or tests/ changed since the base commit: ' + ', '.join(diff[:20]))
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        for p, (old, _new) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not its base version in Git: {p}')
            need(sha(norm((repo / p).read_bytes())) == old, f'file to be replaced differs on disk: {p}')
        print(f'PRE PASS: clean tree; {len(NEW)} new paths absent; {len(MODIFIED)} files at their base version. '
              'Nothing was changed.')
        return

    if a.phase == 'post':
        lines = status.splitlines()
        new = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith('?? ')}
        mod = {ln[3:].strip().strip('"').replace('\\', '/') for ln in lines if ln.startswith(' M ')}
        need(len(new) + len(mod) == len(lines), 'changes other than new files and modified files:\n' + status[:600])
        need(new == set(NEW), 'unexpected new paths: ' + ', '.join(sorted(new ^ set(NEW))))
        need(mod == set(MODIFIED), 'unexpected modified paths: ' + ', '.join(sorted(mod ^ set(MODIFIED))))
        for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(norm(f.read_bytes())) == h, f'wrong bytes: {p}')
        print(f'POST PASS: exactly the {len(NEW)} expected new paths and {len(MODIFIED)} modified files, '
              'all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    parents = git(repo, 'log', '-1', '--format=%P', 'HEAD').decode().split()
    need(len(parents) == 1, f'HEAD has {len(parents)} parents, expected 1')
    diff = git(repo, 'diff', '--name-only', BASE, 'HEAD~1', '--', 'src', 'tests').decode().split()
    need(not diff, "the commit's parent has src/ or tests/ changes since the base: " + ', '.join(diff[:20]))
    for p, h in [*NEW.items(), *((p, n) for p, (_o, n) in MODIFIED.items())]:
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    for p, (old, _n) in MODIFIED.items():
        need(sha(git(repo, 'show', f'HEAD~1:{p}')) == old, f'parent does not hold the base version: {p}')
    names = git(repo, 'diff', '--no-renames', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = {**{p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED}}
    need(got == want, 'the last commit did not change exactly the expected paths: ' + repr(sorted(got.items())))
    print(f'COMMITTED PASS: the last commit ({head[:7]}) added exactly {len(NEW)} files and modified '
          f'{len(MODIFIED)}; all Git blobs match.')


if __name__ == '__main__':
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    args = ap.parse_args()
    try:
        main(args)
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        if args.phase == 'committed':
            try:
                identities(args.repo.resolve())
            except Exception as exc2:
                print('(could not list identities:', exc2, ')', file=sys.stderr)
        sys.exit(2)
