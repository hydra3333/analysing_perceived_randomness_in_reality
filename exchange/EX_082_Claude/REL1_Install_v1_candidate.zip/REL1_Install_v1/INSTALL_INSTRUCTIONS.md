# REL1_Install_v1 - REL-1 package (release of the 39 variants of the 11 installed methods, both games) (only after the owner's go-ahead)

Windows CMD, repository root, with the project venv. **Save the ZIP to `E:\TEMP`, not into the repository.** Delete any earlier extracted `E:\TEMP\REL1_Install_*` folders, then extract it there (`tar -xf "E:\TEMP\REL1_Install_v1.zip" -C E:\TEMP`). This package adds 92 new files, replaces 5 existing files (`tests/test_e2r_dispatch.py`, `tests/test_e3_e4_polynomial.py`, `tests/test_e6_beta_bernoulli.py`, `tests/test_wave1_frequency.py`, `tests/test_wave2_recurrence.py`) and deletes 11 files (the `IN_DEVELOPMENT.txt` flags); nothing else changes.

## 1. Update, check, copy, delete, check, and the tests (one block; do not skip the last command)

```bat
git status --short
git pull --ff-only
python "E:\TEMP\REL1_Install_v1\VERIFY_REL1_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\REL1_Install_v1\repo_overlay\*" . /E /Y
git rm -q -- src/methods/E_002/IN_DEVELOPMENT.txt src/methods/E_003/IN_DEVELOPMENT.txt src/methods/E_004/IN_DEVELOPMENT.txt src/methods/E_006/IN_DEVELOPMENT.txt src/methods/E_007/IN_DEVELOPMENT.txt src/methods/E_008/IN_DEVELOPMENT.txt src/methods/E_009/IN_DEVELOPMENT.txt src/methods/E_010/IN_DEVELOPMENT.txt src/methods/E_017/IN_DEVELOPMENT.txt src/methods/E_018/IN_DEVELOPMENT.txt src/methods/E_019/IN_DEVELOPMENT.txt
python "E:\TEMP\REL1_Install_v1\VERIFY_REL1_INSTALL.py" --repo . --phase post
.venv\Scripts\python.exe "E:\TEMP\REL1_Install_v1\RUN_REL1_SUITE.py" --repo .
```

Expected: `git status --short` prints nothing (if it prints anything, stop and send Claude the output); the pull says `Fast-forward` or `Already up to date`; `PRE PASS`; `97 File(s) copied`; the `git rm` line prints nothing; `POST PASS`; then `SUITE PASS` (304 tests; the only allowed skips are symlink tests: on Windows without symlink rights, up to 3). E2R-T12 starts up to six ordinary Python worker processes and lets them finish normally. The tests change nothing in the repository. If anything prints `STOP` or `FAILED`, do not commit: send Claude the output.

## 2. Stage, commit, check, and only then push

```bat
git add doc review src tests
git status --short
git commit -m "REL-1: release the 39 variants of E_2, E_3, E_4, E_6, E_7, E_8, E_9, E_10, E_17, E_18 and E_19 (both games); WF-1 design v0.1r1 and register v0.21"
python "E:\TEMP\REL1_Install_v1\VERIFY_REL1_INSTALL.py" --repo . --phase committed
```

Expected: `git status --short` lists 92 lines starting with `A`, 5 starting with `M` and 11 starting with `D`, and nothing else; then `COMMITTED PASS`. Git's "LF will be replaced by CRLF" warnings while staging are normal.

**If the committed check prints `STOP`: do not push, and do not reset or undo anything.** Send Claude the whole output.

**Push only after `COMMITTED PASS`:**

```bat
git push
git rev-parse HEAD
```

Send Claude the commit ID; Claude verifies it from GitHub. Claude pushes nothing to the repository while you install.
