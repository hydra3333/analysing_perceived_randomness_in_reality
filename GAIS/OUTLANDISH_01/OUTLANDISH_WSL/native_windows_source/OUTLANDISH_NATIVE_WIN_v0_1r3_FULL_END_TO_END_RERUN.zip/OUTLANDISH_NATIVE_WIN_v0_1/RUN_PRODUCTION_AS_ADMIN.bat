@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_EXE=C:\Users\u\AppData\Local\Programs\Python\Python315\python.exe"
if not exist "%PYTHON_EXE%" (
  echo ERROR: Python 3.15.2 missing at "%PYTHON_EXE%"
  exit /b 1
)
echo ============================================================
echo OUTLANDISH_01 TWO-CONSTANT PRODUCTION (10,000,000,000 each)
echo gamma THEN lemniscate. No prompts, no automatic retries.
echo Must be run from an ELEVATED administrator Command Prompt.
echo ============================================================
"%PYTHON_EXE%" -u "%~dp0outlandish_windows_production.py" --mode production --confirm-production-digits 10000000000
set "RC=%ERRORLEVEL%"
echo.
echo OUTLANDISH_PRODUCTION_EXIT=%RC%
exit /b %RC%
