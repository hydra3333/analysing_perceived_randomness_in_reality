@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_EXE=C:\Users\u\AppData\Local\Programs\Python\Python315\python.exe"
if not exist "%PYTHON_EXE%" (
  echo ERROR: Python 3.15.2 missing at "%PYTHON_EXE%"
  exit /b 1
)
echo ============================================================
echo OUTLANDISH_01 LEMNISCATE-ONLY TEST (1,000,000 digits)
echo Existing verified gamma TEST binary will be left untouched.
echo This does NOT start any production calculation.
echo ============================================================
"%PYTHON_EXE%" -u "%~dp0outlandish_windows_production.py" --mode test --only-test-constant lemniscate
set "RC=%ERRORLEVEL%"
echo.
echo OUTLANDISH_LEMNISCATE_TEST_EXIT=%RC%
exit /b %RC%
