# OUTLANDISH_01 native Windows 10 unattended two-constant generator — v0.1

**Status:** test candidate; must pass on the i5-4670 before the production launcher is authorised. Python standard library only. No WSL or E: required.

## Exact objective

Run **Euler–Mascheroni gamma, then lemniscate**, generating **10^10 decimal digits (including the integer digit) each**, under native Windows y-cruncher v0.8.7.9547b on the i5-4670. Do mathematical and output verification (`-verify:1`), reuse the existing packed-BCD converter, independently read/hash the whole persisted `.bin`, publish the `.bin` and `.wsl-receipt.json`, archive small report/logs, and remove owned large temporary source/swap only after successful publication. No automatic retry on failure. Final files are **manually copied** to the Ryzen 3900X later and their hashes verified there.

### Prerequisites (already established on i5)

- Windows 10 x64 22H2; Python 3.15.2 64-bit at `C:\Users\u\AppData\Local\Programs\Python\Python315\python.exe`. The batch launchers use this absolute path because an elevated administrator account may not inherit the ordinary user's PATH. No Python packages beyond the standard library are required.
- y-cruncher at `G:\OUTLANDISH_01\tools\y-cruncher v0.8.7.9547b\y-cruncher.exe`.
- `G:\OUTLANDISH_01\large_artifacts\{staging,digits,logs}` and `T:\OUTLANDISH_01\work` exist.
- **Elevated administrator Command Prompt is essential** for this y-cruncher version's NTFS swap files. Ordinary user with `SeManageVolumePrivilege` alone is insufficient for its restrictive swap-file ACL and `RawFile::rename()`.
- Run after any system-image backup completes; prevent sleep/restarts for the duration. **T: must have plenty of space.** Code uses `-M:3g`, `-TD:4`, `-PF:taskqueue`, `-mode:swap`, `-verify:1`.


## v0.1r3 — repeat FULL end-to-end test, overwriting TEST-ONLY outputs (owner decision)

The owner prefers repeating the entire real Windows gamma -> lemniscate end-to-end test. The normal `RUN_TEST_AS_ADMIN.bat` now permits repeat runs. **Only in test mode**, after preflight passes, it deletes the four exact previously published `.bin`/`.wsl-receipt.json` test files for gamma and lemniscate and any matching staged test files, then recalculates both from scratch. It first rejects symlinks, junctions and unexpected file types. Older archived test logs and failed attempt directories are retained. The production `RUN_PRODUCTION_AS_ADMIN.bat` is entirely unchanged and remains create-only, refusing any existing production binary/receipt.

**Run from an elevated administrator command prompt:**

```cmd
cd /d "G:\OUTLANDISH_01\scripts\OUTLANDISH_NATIVE_WIN_v0_1"
RUN_TEST_AS_ADMIN.bat
```

Expect `BOTH CONSTANTS VERIFIED AND PUBLISHED — SUCCESS` and `OUTLANDISH_TEST_EXIT=0`. Do not start production until the real test passes and output is reviewed.

## v0.1r2 — single Windows integration fix after first real test

The first live two-constant Windows test on 9 Nov 2026 **successfully completed and published gamma**, but stopped after y-cruncher **successfully calculated and verified lemniscate** because the validator expected `Constant: Lemniscate` rather than y-cruncher's actual `Constant: Lemniscate Constant`. Both the orchestrator and the shared conversion report validator now accept the exact actual label. No packing or lemniscate divide-by-two algorithm was changed.

**To continue that existing test without recalculating gamma**, copy/overwrite the updated files from this ZIP into the established `G:\OUTLANDISH_01\scripts\OUTLANDISH_NATIVE_WIN_v0_1\`, then run **only**:

```cmd
cd /d "G:\OUTLANDISH_01\scripts\OUTLANDISH_NATIVE_WIN_v0_1"
RUN_TEST_LEMNISCATE_ONLY_AS_ADMIN.bat
```

This uses a *new* T: work attempt, does not reuse or delete the prior failed lemniscate work directory, and writes only the missing test lemniscate binary. The published test gamma remains untouched. For the owner-preferred full rerun, use `RUN_TEST_AS_ADMIN.bat` as described in v0.1r3; it replaces only the prior test binaries and receipts.

Do not start `RUN_PRODUCTION_AS_ADMIN.bat` until this lemniscate-only test passes and its verification and publication output have been inspected. Production still always runs gamma then lemniscate and cannot be narrowed by the test-only option.

## Installation

Extract the supplied ZIP **with its folder** into `G:\OUTLANDISH_01\scripts\`. The resulting location should be:

```text
G:\OUTLANDISH_01\scripts\OUTLANDISH_NATIVE_WIN_v0_1\
    RUN_TEST_AS_ADMIN.bat
    RUN_TEST_LEMNISCATE_ONLY_AS_ADMIN.bat
    RUN_PRODUCTION_AS_ADMIN.bat
    outlandish_windows_production.py
    wsl_convert.py
    wsl_format.py
    test_portable_logic.py
    test_orchestrator_integration.py
    README_START_HERE.md
```

The converter and BCD format modules are **based on the previously supplied OUTLANDISH_WSL.zip**; the lemniscate report-name check was corrected for the actual Windows y-cruncher output, without changing the packing algorithm or original `.wsl-receipt.json` naming. The lemniscate source y-cruncher computes is `5.244115...` (full perimeter); the converter deliberately performs **exact streaming division by two** to produce our specified `2.622057...` half-perimeter binary. Do not replace that with direct BCD packing.

## Step A — first actual Windows test (both constants)

Open **Command Prompt → Run as administrator**, then enter:

```cmd
cd /d "G:\OUTLANDISH_01\scripts\OUTLANDISH_NATIVE_WIN_v0_1"
RUN_TEST_AS_ADMIN.bat
```

It runs **gamma then lemniscate**, each **1,000,000 decimal digits**, with real Windows y-cruncher and end-to-end conversion/verification/publication/cleanup.

- Test `.bin` files go **only** to `G:\OUTLANDISH_01\large_artifacts\test_only\digits\`.
- Test receipts are beside the test binaries; test reports, status and logs under `test_only\logs\<attempt>\`.
- Each test `.bin` should be exactly **500,000 bytes**.
- The script prints `BOTH CONSTANTS VERIFIED AND PUBLISHED — SUCCESS` and `OUTLANDISH_TEST_EXIT=0` only upon full success.
- If any step fails, stop and send the failure text and `run.log`; do **not** delete files or rerun before inspection.
- **Repeated test runs are supported:** the launcher replaces only the named `test_only` binaries and receipts; all production files remain create-only.

A portable synthetic converter/orchestrator test was run on Linux when constructing this candidate and passed. **That does not establish Windows compatibility**; this Step A is mandatory.

## Step B — production (only after Step A passes and result inspection)

From **elevated Command Prompt**, same folder:

```cmd
RUN_PRODUCTION_AS_ADMIN.bat
```

The production mode hard-codes **10,000,000,000 digits per constant**, `-dec:9999999999`, and requires an exact internal production acknowledgment. It automatically does gamma then lemniscate; no intervening prompts or manual conversion commands. **Do not launch until we review Step A's actual Windows results.**

Expected published results:

```text
G:\OUTLANDISH_01\large_artifacts\digits\digits_gamma_10_to_10.packed.bin
G:\OUTLANDISH_01\large_artifacts\digits\digits_gamma_10_to_10.packed.bin.wsl-receipt.json
G:\OUTLANDISH_01\large_artifacts\digits\digits_lemniscate_10_to_10.packed.bin
G:\OUTLANDISH_01\large_artifacts\digits\digits_lemniscate_10_to_10.packed.bin.wsl-receipt.json
G:\OUTLANDISH_01\large_artifacts\logs\<per-constant-attempt>\run.log
G:\OUTLANDISH_01\large_artifacts\logs\<per-constant-attempt>\status.json
G:\OUTLANDISH_01\large_artifacts\logs\<per-constant-attempt>\<y-cruncher-validation-report>.txt
```

Each production `.bin` must be exactly **5,000,000,000 bytes**. Each SHA-256 is calculated during conversion **and independently checked by reading the entire staged binary from G:** before publication or cleanup. The script logs both the streamed and read-back hashes, and publishes create-only hard links to the final `digits` folder. The same-volume G: hard links are removed from staging after successful checks.

The algorithm output report is copied to G:; the full y-cruncher console output is saved to G: as `run.log`; `status.json` records the digest and paths. **The large decimal source and that attempt's swap directory on T: are removed only after full published verification.** Small T: report files may remain; no bulk wiping of work or unrelated directories.

On any generation, converter, hash, publication or cleanup error, the script **stops** and does not begin the next constant. It performs no automatic retries and does not discard unverified source/swap data. If an error occurs after binary publication but before cleanup, inspect `status.json` and the staging/final paths before any rerun.

## Practical details and limitations

- This package does **not** do scientific matching or alter the ratified matching/reporting spec.
- The `.wsl-receipt.json` suffix and receipt's `scope` value remain unchanged for compatibility with the original packed-binary workflow, despite using native Windows for generation.
- Running under an elevated administrator token also elevates the Python orchestrator; only use the supplied scripts from the controlled G: directory.
- The Windows y-cruncher report filenames and complete output/receipt format must pass Step A on the actual PC before production. No algorithm time estimate is promised; large gamma can take days or longer.
- A fatal y-cruncher prompt or process hang is a possible limitation outside script control. Do not trust unattended completion unless the result status and report/log show success.
- After both production constants finish, **manually transfer** the binary, receipt, validation report and preserved logs to the Ryzen 3900X. Verify full SHA-256 after transfer before deleting the i5 copies. Never confuse either machine's G:/T: volumes.
- Fail-safe create-only output means the production launcher will refuse to overwrite existing published or staged output. Cleanup/repair of a failed run requires explicit inspection.
- The Ryzen 3900X's T: cleanup is a separate later task, only after preserving needed evidence.
