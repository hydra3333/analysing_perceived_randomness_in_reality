#!/usr/bin/env python3
"""Regression: actual Windows y-cruncher lemniscate report header."""
import tempfile
from pathlib import Path
import wsl_convert
import outlandish_windows_production as prod

with tempfile.TemporaryDirectory() as folder:
    path=Path(folder)/'Lemniscate - 20261109-173211.txt'
    valid='''Constant: Lemniscate Constant
Decimal Digits: 999,999
Verifying Base Conversion:
Verifying Decimal Output:
Spot Check: Good through 750,000
'''
    path.write_text(valid, encoding='utf-8')
    prod.validate_report(path,'lemniscate',1_000_000)
    wsl_convert.report_evidence(path,'lemniscate',1_000_000)
    path.write_text(valid.replace('Constant: Lemniscate Constant','Constant: Wrong Constant'),encoding='utf-8')
    for cb in (prod.validate_report,wsl_convert.report_evidence):
        try:
            cb(path,'lemniscate',1_000_000)
        except (prod.Stop,ValueError):
            pass
        else:
            raise AssertionError('bad constant label must be refused')
print('WINDOWS_REPORT_NAMES_REGRESSION_PASS')
