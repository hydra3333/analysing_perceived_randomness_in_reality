@echo off
setlocal
cd /d "%~dp0"
set "PYTHON_EXE=C:\Users\u\AppData\Local\Programs\Python\Python315\python.exe"
if not exist "%PYTHON_EXE%" (
  echo ERROR: Python 3.15.2 missing at "%PYTHON_EXE%"
  exit /b 1
)
echo ============================================================
echo OUTLANDISH_01 TWO-CONSTANT END-TO-END TEST (1,000,000 each)
echo Test results go in G:\OUTLANDISH_01\large_artifacts\test_only
 echo No production outputs will be created by this launcher.
echo ============================================================
"%PYTHON_EXE%" -u "%~dp0outlandish_windows_production.py" --mode test
set "RC=%ERRORLEVEL%"
echo.
echo OUTLANDISH_TEST_EXIT=%RC%
exit /b %RC%
