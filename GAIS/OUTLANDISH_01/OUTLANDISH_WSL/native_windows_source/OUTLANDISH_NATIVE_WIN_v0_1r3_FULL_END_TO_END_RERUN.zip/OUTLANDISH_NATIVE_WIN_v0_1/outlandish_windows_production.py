#!/usr/bin/env python3
"""OUTLANDISH_01 native Windows two-constant unattended verified pipeline.

Uses the existing WSL packed-BCD converter and receipt schema unchanged.
Test and production output roots are separate. Python standard library only.
"""
from __future__ import annotations

import argparse
import ctypes
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
import uuid

from wsl_format import FORMAT, STEMS, packed_bytes, safe_regular

G = Path(r"G:\OUTLANDISH_01")
T = Path(r"T:\OUTLANDISH_01")
YCRUNCHER = G / 'tools' / 'y-cruncher v0.8.7.9547b' / 'y-cruncher.exe'
SCRIPT_DIR = Path(__file__).resolve().parent
CONVERTER = SCRIPT_DIR / 'wsl_convert.py'
CONSTANTS = ('gamma', 'lemniscate')
PRODUCTION_DIGITS = 10_000_000_000
TEST_DIGITS = 1_000_000
THREADS = 4
MEMORY = '3g'
MIN_FREE_T_PROD = 100_000_000_000
MIN_FREE_G_PROD = 10_000_000_000


class Stop(Exception):
    pass


def stamp() -> str:
    return datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%SZ')


def emit(msg: str, logfile=None) -> None:
    line = str(msg)
    print(line, flush=True)
    if logfile is not None:
        logfile.write(line + '\n')
        logfile.flush()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise Stop(message)


def proper_file(p: Path) -> bool:
    try:
        safe_regular(p)
        return True
    except (ValueError, OSError):
        return False


def new_file_copy(src: Path, dst: Path) -> None:
    """Create-only copy; no silent overwrite."""
    require(proper_file(src), f'Expected regular file missing: {src}')
    require(not dst.exists() and not dst.is_symlink(), f'Refuse overwrite: {dst}')
    try:
        with src.open('rb') as r, dst.open('xb') as w:
            shutil.copyfileobj(r, w, length=8 * 1024 * 1024)
            w.flush()
            os.fsync(w.fileno())
        require(dst.stat().st_size == src.stat().st_size, f'Archive copy size mismatch: {dst}')
    except BaseException:
        # If failed copying, preserve partial copy for diagnosis; never overwrite.
        raise


def hash_file(path: Path) -> tuple[str, int]:
    digest = hashlib.sha256()
    size = 0
    with path.open('rb', buffering=4 * 1024 * 1024) as inp:
        while data := inp.read(8 * 1024 * 1024):
            digest.update(data)
            size += len(data)
    return digest.hexdigest(), size


def validate_report(path: Path, constant: str, digits: int) -> None:
    require(proper_file(path) and path.stat().st_size <= 256_000,
            f'Missing or oversized y-cruncher report: {path}')
    content = path.read_text(encoding='utf-8', errors='replace')
    expected_name = {'gamma':'Euler-Mascheroni Constant', 'lemniscate':'Lemniscate Constant'}[constant]
    require(re.search(r'^\s*Constant:\s*' + re.escape(expected_name) + r'\s*$',
                      content, re.I | re.M) is not None,
            f'Validation report constant mismatch: {path}')
    require(re.search(r'^\s*Decimal Digits:\s*' + re.escape(f'{digits-1:,}') + r'\s*$',
                      content, re.M) is not None,
            f'Validation report digits mismatch: {path}')
    for phase in ('Verifying Base Conversion', 'Verifying Decimal Output'):
        require(phase.lower() in content.lower(), f'Report lacks {phase}: {path}')
    require(re.search(r'Spot Check:\s*Good through\s+[\d,]+', content, re.I) is not None,
            f'Report lacks positive spot-check: {path}')
    require(not re.search(r'^\s*Verify Output:\s*Disabled\s*$', content, re.I | re.M),
            'Report indicates disabled verification')


def run_stream(cmd: list[str], cwd: Path, logfile, label: str) -> int:
    emit('COMMAND: ' + subprocess.list2cmdline(cmd), logfile)
    emit('START ' + datetime.now(timezone.utc).isoformat() + ' ' + label, logfile)
    # stdin=NUL avoids interactive input from the script. Do not use shell=True.
    proc = subprocess.Popen(cmd, cwd=cwd, stdin=subprocess.DEVNULL,
                            stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                            text=True, encoding='utf-8', errors='replace', bufsize=1)
    assert proc.stdout is not None
    for line in proc.stdout:
        emit(line.rstrip('\r\n'), logfile)
    exit_code = proc.wait()
    emit(f'EXIT {exit_code} FINISH {datetime.now(timezone.utc).isoformat()} {label}', logfile)
    return exit_code


def preflight(mode: str, digits: int, output_root: Path, selected_constants: tuple[str, ...]) -> None:
    require(sys.platform == 'win32', 'Requires native Windows Python')
    require(ctypes.windll.shell32.IsUserAnAdmin() != 0,
            'Start this .bat with Run as administrator (Windows Swap Mode requirement)')
    require(sys.maxsize > 2**32, 'Requires 64-bit Python')
    for path in (YCRUNCHER, CONVERTER, SCRIPT_DIR / 'wsl_format.py'):
        require(proper_file(path), f'Missing required program: {path}')
    for path in (G, T, T / 'work', G / 'large_artifacts'):
        require(path.is_dir(), f'Missing established root directory: {path}')
    # Avoid accidental drive redirection, aliases, or junctions in the new destination paths.
    for path in (output_root, T / 'work'):
        safe_regular(path, must_exist=False)
    test_root = G / 'large_artifacts' / 'test_only'
    prod_root = G / 'large_artifacts'
    require(output_root == (test_root if mode == 'test' else prod_root), 'Invalid output root')
    if mode == 'production':
        require(digits == PRODUCTION_DIGITS, 'Production digit count mismatch')
        require(shutil.disk_usage(T / 'work').free >= MIN_FREE_T_PROD,
                'T: requires at least 100 GB free before production')
        require(shutil.disk_usage(prod_root).free >= MIN_FREE_G_PROD,
                'G: requires at least 10 GB free before production')
    else:
        require(digits == TEST_DIGITS, 'Unexpected test digit count')
    for const in selected_constants:
        name = f'digits_{STEMS[const]}_{digits}.packed.bin' if mode == 'test' else f'digits_{STEMS[const]}_10_to_10.packed.bin'
        for suffix in (name, name + '.wsl-receipt.json'):
            for folder in ('digits', 'staging'):
                p = output_root / folder / suffix
                if mode == 'production':
                    require(not p.exists() and not p.is_symlink(),
                            f'Destination exists: {p}. Production never overwrites.')
                elif p.exists() or p.is_symlink():
                    require(proper_file(p), f'Unsafe existing test-only output: {p}')


def reset_test_results(output_root: Path, selected_constants: tuple[str, ...], digits: int) -> None:
    """Explicit rerunnable TEST-only reset of exact output names, never production files.

    Leaves all historical logs and failed calculation work directories intact.
    Production code never calls this routine.
    """
    require(output_root == G / 'large_artifacts' / 'test_only',
            'REFUSE test reset outside the exact test-only root')
    require(digits == TEST_DIGITS, 'REFUSE test reset at production precision')
    for folder in ('digits', 'staging'):
        safe_regular(output_root / folder, must_exist=False)
    planned = []
    for const in selected_constants:
        require(const in CONSTANTS, f'Unexpected test constant: {const}')
        name = f'digits_{STEMS[const]}_{digits}.packed.bin'
        for folder in ('digits', 'staging'):
            path = output_root / folder / name
            planned.extend((path, Path(str(path) + '.wsl-receipt.json')))
    # Validate the entire set before removing any file.
    for path in planned:
        if path.exists() or path.is_symlink():
            require(proper_file(path), f'Unsafe existing test-only output: {path}')
    for path in planned:
        if path.exists():
            path.unlink()
            print(f'TEST-ONLY RESET removed previous file: {path}', flush=True)


def run_one(constant: str, mode: str, digits: int, output_root: Path) -> dict:
    attempt = f'{constant}_{digits}_{stamp()}_{uuid.uuid4().hex[:8]}'
    work = T / 'work' / attempt
    swap = work / 'swap'
    archived = output_root / 'logs' / attempt
    archived.mkdir(parents=True, exist_ok=False)
    swap.mkdir(parents=True, exist_ok=False)
    logfile_path = archived / 'run.log'
    data = {'constant':constant, 'digits':digits, 'attempt':attempt,
            'work_path':str(work), 'archive_path':str(archived), 'mode':mode,
            'result':'FAILED_OR_INCOMPLETE'}
    def persist():
        p = archived / 'status.json'
        with p.open('w', encoding='utf-8') as f:
            json.dump(data, f, indent=2); f.write('\n')
    persist()
    with logfile_path.open('x', encoding='utf-8', buffering=1) as logfile:
        emit('='*67, logfile)
        emit(f'BEGIN {constant.upper()} {digits:,} digits ({mode.upper()})', logfile)
        emit(f'WORK {work}\nLOG {logfile_path}', logfile)
        cmd = [str(YCRUNCHER), 'custom', constant, f'-dec:{digits-1}',
               '-hex:0', '-od:1', '-compress:0', '-verify:1',
               '-mode:swap', f'-TD:{THREADS}', '-PF:taskqueue', f'-M:{MEMORY}',
               '-swap:raid0', str(swap)]
        try:
            code = run_stream(cmd, work, logfile, f'y-cruncher {constant}')
            require(code == 0, f'y-cruncher exit code {code}')
            require(not re.search(r'Exception Encountered|Unable to rename file',
                                  logfile_path.read_text(encoding='utf-8', errors='replace'), re.I),
                    'y-cruncher log contains an exception')
            txts = [p for p in work.iterdir() if p.is_file() and p.suffix.lower() == '.txt']
            decimal = [p for p in txts if ' - Dec - ' in p.name]
            reports = [p for p in txts if p not in decimal]
            require(len(decimal) == 1 and len(reports) == 1,
                    'Expected exactly one decimal text file and one validation report; '\
                    f'found {[p.name for p in txts]}')
            src, report = decimal[0], reports[0]
            require(proper_file(src), f'Unsafe decimal source: {src}')
            validate_report(report, constant, digits)
            emit(f'YC_VERIFICATION_PASS SOURCE={src} REPORT={report}', logfile)
            new_file_copy(report, archived / report.name)
            data['ycruncher_report'] = str(archived / report.name)
            data['source_text'] = str(src)
            persist()
            name = (f'digits_{STEMS[constant]}_{digits}.packed.bin'
                    if mode == 'test' else f'digits_{STEMS[constant]}_10_to_10.packed.bin')
            staged = output_root / 'staging' / name
            final = output_root / 'digits' / name
            stage_receipt = Path(str(staged) + '.wsl-receipt.json')
            final_receipt = Path(str(final) + '.wsl-receipt.json')
            for p in (staged, final, stage_receipt, final_receipt):
                require(not p.exists() and not p.is_symlink(), f'Destination exists: {p}')
            convert_cmd = [sys.executable, str(CONVERTER),
                           '--constant', constant, '--digits', str(digits),
                           '--source-root', str(T / 'work'), '--input', str(src),
                           '--report', str(report), '--output-root', str(output_root),
                           '--output', str(staged), '--keep-text', '--run']
            if digits >= 1_000_000_000:
                convert_cmd.extend(['--ack-large', str(digits)])
            conv_code = run_stream(convert_cmd, work, logfile, f'conversion {constant}')
            require(conv_code == 0, f'Packed conversion failed with exit {conv_code}')
            require(proper_file(staged) and proper_file(stage_receipt),
                    'Staged binary/receipt missing')
            receipt = json.loads(stage_receipt.read_text(encoding='utf-8'))
            expected = receipt.get('binary_sha256_streamed')
            require(receipt.get('format') == FORMAT and receipt.get('format_version') == 1
                    and receipt.get('constant') == constant
                    and receipt.get('digits_including_integer') == digits
                    and receipt.get('packed_bytes') == packed_bytes(digits)
                    and receipt.get('binary_name') == name
                    and receipt.get('report_sha256') == hashlib.sha256(report.read_bytes()).hexdigest()
                    and receipt.get('scope') == 'PACKED_STAGING_ONLY_NO_LEGACY_REGISTRY'
                    and isinstance(expected, str) and bool(re.fullmatch('[0-9a-f]{64}', expected)),
                    'Receipt identity/evidence mismatch')
            emit('BEGIN INDEPENDENT COMPLETE-FILE SHA256 READBACK', logfile)
            actual, size = hash_file(staged)
            require(size == packed_bytes(digits), f'Packed size mismatch: {size}')
            require(actual == expected, f'Full-file SHA256 differs from streamed digest: {actual} != {expected}')
            emit(f'FULL_FILE_SHA256_PASS {actual} size={size}', logfile)
            require(not final.exists() and not final_receipt.exists(), 'Final destination already exists')
            # NTFS same-volume hardlinks: create-only; preserve staged file until both verified.
            os.link(staged, final)
            os.link(stage_receipt, final_receipt)
            require(os.path.samefile(staged, final) and os.path.samefile(stage_receipt, final_receipt)
                    and final.stat().st_size == size,
                    'Final publication hard-link check failed; NO CLEANUP')
            data.update({'final_binary':str(final), 'final_receipt':str(final_receipt),
                         'packed_bytes':size, 'sha256':actual,
                         'verification':'INDEPENDENT_FULL_FILE_SHA256_PASS',
                         'result':'PUBLISHED_VERIFIED_PENDING_CLEANUP'})
            persist()
            emit(f'PUBLISHED {final}', logfile)
            # No destructive operations before full verification + complete publication.
            staged.unlink()
            stage_receipt.unlink()
            src.unlink()
            # Delete only this attempt's own swap directory; report is archived on G:.
            require(swap.is_dir() and not swap.is_symlink() and work.parent == T / 'work',
                    'Unexpected swap directory; cleanup refused')
            shutil.rmtree(swap)
            data.update({'result':'COMPLETE', 'cleanup':'decimal_source_and_swap_removed',
                         'finished_utc':datetime.now(timezone.utc).isoformat()})
            persist()
            emit(f'COMPLETE {constant.upper()} sha256={actual}\nBIN {final}\nRECEIPT {final_receipt}\nREPORT {archived / report.name}\nLOG {logfile_path}\nSTATUS {archived / "status.json"}', logfile)
            return data
        except BaseException as exc:
            emit('STOP (NO AUTOMATIC RETRY): ' + repr(exc), logfile)
            data['error'] = repr(exc)
            persist()
            raise


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--mode', choices=('test', 'production'), required=True)
    parser.add_argument('--only-test-constant', choices=CONSTANTS, default=None,
                        help='TEST MODE ONLY: run just the named constant')
    parser.add_argument('--confirm-production-digits', type=int, default=None)
    args = parser.parse_args()
    mode = args.mode
    if mode == 'production' and args.only_test_constant is not None:
        print('STOP: --only-test-constant is forbidden in production', file=sys.stderr)
        return 2
    selected = (args.only_test_constant,) if args.only_test_constant else CONSTANTS
    digits = TEST_DIGITS if mode == 'test' else PRODUCTION_DIGITS
    output_root = G / 'large_artifacts' / ('test_only' if mode == 'test' else '')
    if mode == 'production' and args.confirm_production_digits != PRODUCTION_DIGITS:
        print('STOP: production requires --confirm-production-digits 10000000000', file=sys.stderr)
        return 2
    if mode == 'test' and args.confirm_production_digits is not None:
        print('STOP: confirmation is not accepted in test mode', file=sys.stderr)
        return 2
    try:
        for sub in ('staging', 'digits', 'logs'):
            (output_root / sub).mkdir(parents=True, exist_ok=True)
        preflight(mode, digits, output_root, selected)
        if mode == 'test':
            print('TEST-ONLY RE-RUN: replacing previous named test .bin/receipt files; old logs retained', flush=True)
            reset_test_results(output_root, selected, digits)
        print(f'OUTLANDISH NATIVE WINDOWS {mode.upper()} — TWO CONSTANTS, {digits:,} digits each', flush=True)
        print(f'G output: {output_root}\nT scratch: {T / "work"}', flush=True)
        results = []
        for constant in selected:
            # Recheck the destination of the next constant before touching it.
            results.append(run_one(constant, mode, digits, output_root))
        print('\n' + '='*72)
        print('BOTH CONSTANTS VERIFIED AND PUBLISHED — SUCCESS' if len(selected) == 2
              else f'{selected[0].upper()} VERIFIED AND PUBLISHED — TEST SUCCESS')
        for r in results:
            print(f"\n{r['constant'].upper()} : {r['packed_bytes']:,} bytes")
            print('BIN:     ' + r['final_binary'])
            print('RECEIPT: ' + r['final_receipt'])
            print('REPORT:  ' + r['ycruncher_report'])
            print('LOGS:    ' + str(Path(r['archive_path']) / 'run.log'))
            print('SHA256:  ' + r['sha256'])
        print('\nCopy the production BIN, receipt, report and logs manually to the Ryzen;')
        print('verify destination hashes after copying. Do not confuse test_only with production.')
        return 0
    except (Stop, OSError, ValueError, RuntimeError, subprocess.SubprocessError) as exc:
        print(f'\nPIPELINE STOP — {exc}', file=sys.stderr, flush=True)
        print('No automatic retry. Inspect preserved attempt log and T: work directory.',
              file=sys.stderr, flush=True)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
