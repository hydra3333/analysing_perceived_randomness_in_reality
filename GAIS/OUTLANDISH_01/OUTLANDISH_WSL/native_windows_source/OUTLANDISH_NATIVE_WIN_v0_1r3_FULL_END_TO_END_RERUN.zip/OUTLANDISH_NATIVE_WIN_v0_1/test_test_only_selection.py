#!/usr/bin/env python3
"""Check test-only selective rerun cannot modify production scheduling."""
import contextlib
import io
import sys
import tempfile
from pathlib import Path
import outlandish_windows_production as p

with tempfile.TemporaryDirectory() as temp:
    root=Path(temp)
    p.G=root/'G'
    p.T=root/'T'
    calls=[]
    p.preflight=lambda mode,digits,output_root,selected: calls.append(('preflight',mode,digits,selected))
    def fake_run(constant,mode,digits,output_root):
        calls.append(('run',constant,mode,digits))
        return {'constant':constant,'packed_bytes':500_000,
                'final_binary':'binary','final_receipt':'receipt',
                'ycruncher_report':'report','archive_path':str(root),'sha256':'0'*64}
    p.run_one=fake_run
    original_argv=sys.argv
    try:
        sys.argv=['prod.py','--mode','test','--only-test-constant','lemniscate']
        with contextlib.redirect_stdout(io.StringIO()):
            assert p.main()==0
        assert calls==[
            ('preflight','test',1_000_000,('lemniscate',)),
            ('run','lemniscate','test',1_000_000)
        ],calls
        calls.clear()
        sys.argv=['prod.py','--mode','production','--confirm-production-digits','10000000000','--only-test-constant','lemniscate']
        with contextlib.redirect_stderr(io.StringIO()):
            assert p.main()==2
        assert not calls
    finally:
        sys.argv=original_argv
print('TEST_ONLY_SELECTION_REGRESSION_PASS')
