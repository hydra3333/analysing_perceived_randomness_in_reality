#!/usr/bin/env python3
"""Portable synthetic two-constant end-to-end orchestration test.
No Windows y-cruncher is involved; this checks packaging, verification, hashes, publication,
and post-verification cleanup. Actual Windows test remains mandatory.
"""
from pathlib import Path
import importlib.util
import os
import tempfile
import json
import sys
import wsl_format

spec=importlib.util.spec_from_file_location('ctl',Path(__file__).with_name('outlandish_windows_production.py'))
ctl=importlib.util.module_from_spec(spec)
spec.loader.exec_module(ctl)

with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    ctl.G=root/'G'
    ctl.T=root/'T'
    ctl.YCRUNCHER=ctl.G/'tools'/'mock_ycruncher'
    ctl.CONVERTER=Path(__file__).with_name('wsl_convert.py')
    (ctl.G/'tools').mkdir(parents=True)
    (ctl.G/'large_artifacts'/'test_only'/'staging').mkdir(parents=True)
    (ctl.G/'large_artifacts'/'test_only'/'digits').mkdir(parents=True)
    (ctl.G/'large_artifacts'/'test_only'/'logs').mkdir(parents=True)
    (ctl.T/'work').mkdir(parents=True)
    fake=f'''#!{sys.executable}\nimport sys\nfrom pathlib import Path\nconst=sys.argv[2]\nN=int(next(x.split(':')[1] for x in sys.argv if x.startswith('-dec:')))+1\nfrom pathlib import Path\nwork=Path.cwd()\npre={{'gamma':{repr(wsl_format.PREFIXES['gamma'])},'lemniscate':{repr(wsl_format.FULL_LEMNISCATE)}}}[const]\nassert len(pre)==32\nname='Euler-Mascheroni Constant' if const=='gamma' else 'Lemniscate Constant'\nraw=pre+b'0'*(N-len(pre))\n(work/(name+' - Dec - Synthetic.txt')).write_bytes(raw[:1]+b'.'+raw[1:])\n(work/(name+' - Synthetic Report.txt')).write_text('Constant: '+name+'\\nDecimal Digits: '+f'{{N-1:,}}'+'\\nVerifying Base Conversion:\\nVerifying Decimal Output:\\nSpot Check: Good through 750000\\n')\nprint('Fake verified ycruncher output for isolated integration test')\n'''
    ctl.YCRUNCHER.write_text(fake)
    ctl.YCRUNCHER.chmod(0o755)
    out=ctl.G/'large_artifacts'/'test_only'
    a=ctl.run_one('gamma','test',1_000_000,out)
    b=ctl.run_one('lemniscate','test',1_000_000,out)
    for entry in (a,b):
        assert entry['result']=='COMPLETE'
        assert Path(entry['final_binary']).stat().st_size==500_000
        assert Path(entry['final_receipt']).exists()
        assert not Path(entry['source_text']).exists()
        assert not (Path(entry['work_path'])/'swap').exists()
        assert ctl.hash_file(Path(entry['final_binary']))[0]==entry['sha256']
    # Full test-only rerun: replace published test outputs and perform BOTH again.
    gamma_path=Path(a['final_binary'])
    lemni_path=Path(b['final_binary'])
    gamma_hash=a['sha256']
    lemni_hash=b['sha256']
    ctl.reset_test_results(out, ctl.CONSTANTS, ctl.TEST_DIGITS)
    assert not gamma_path.exists() and not lemni_path.exists()
    a2=ctl.run_one('gamma','test',1_000_000,out)
    b2=ctl.run_one('lemniscate','test',1_000_000,out)
    assert a2['sha256']==gamma_hash and b2['sha256']==lemni_hash
    assert Path(a2['final_binary']).is_file() and Path(b2['final_binary']).is_file()
    assert not Path(a2['source_text']).exists() and not Path(b2['source_text']).exists()
    print('INTEGRATION_TEST_PASS_TWO_CONSTANTS_AND_COMPLETE_RERUN')
