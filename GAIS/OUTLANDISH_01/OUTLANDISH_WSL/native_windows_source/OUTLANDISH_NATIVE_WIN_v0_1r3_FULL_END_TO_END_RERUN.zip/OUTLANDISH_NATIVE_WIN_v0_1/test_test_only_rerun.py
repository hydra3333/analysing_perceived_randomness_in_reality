#!/usr/bin/env python3
"""Regression for owner-approved overwrite of TEST-ONLY artifacts, never production."""
from pathlib import Path
import tempfile
import outlandish_windows_production as p

with tempfile.TemporaryDirectory() as td:
    root=Path(td)
    original_g=p.G
    try:
        p.G=root/'G'
        base=p.G/'large_artifacts'
        test=base/'test_only'
        for sub in ('staging','digits'):
            (test/sub).mkdir(parents=True)
            (base/sub).mkdir(parents=True)
        planned=[]
        for const in p.CONSTANTS:
            name=f'digits_{p.STEMS[const]}_{p.TEST_DIGITS}.packed.bin'
            for sub in ('staging','digits'):
                b=test/sub/name
                r=Path(str(b)+'.wsl-receipt.json')
                b.write_bytes(b'old-test-binary')
                r.write_text('old-test-receipt')
                planned.extend((b,r))
        prod_binary=base/'digits'/'digits_gamma_10_to_10.packed.bin'
        prod_binary.write_bytes(b'KEEP PRODUCTION!')
        report=test/'logs'/'oldrun.log'
        report.parent.mkdir(parents=True)
        report.write_text('old diagnostic log')
        # Wrong root must never be allowed to reset output.
        try:
            p.reset_test_results(base,p.CONSTANTS,p.TEST_DIGITS)
        except p.Stop:
            pass
        else:
            raise AssertionError('Must refuse test reset under production root')
        assert all(f.exists() for f in planned)
        p.reset_test_results(test,p.CONSTANTS,p.TEST_DIGITS)
        assert all(not f.exists() for f in planned)
        assert prod_binary.read_bytes()==b'KEEP PRODUCTION!'
        assert report.read_text()=='old diagnostic log'
        p.reset_test_results(test,p.CONSTANTS,p.TEST_DIGITS)  # re-runnable
        assert prod_binary.read_bytes()==b'KEEP PRODUCTION!'
        print('TEST_ONLY_RERUN_RESET_PASS; PRODUCTION_UNCHANGED')
    finally:
        p.G=original_g
