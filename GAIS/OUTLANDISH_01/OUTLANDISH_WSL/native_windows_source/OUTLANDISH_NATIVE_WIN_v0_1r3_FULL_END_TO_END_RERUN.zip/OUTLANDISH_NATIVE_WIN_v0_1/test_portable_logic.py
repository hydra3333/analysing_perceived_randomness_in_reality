#!/usr/bin/env python3
"""Portable self-tests for reused converter + receipt. No Windows y-cruncher required."""
from pathlib import Path
import tempfile, hashlib, json
from argparse import Namespace
import wsl_convert
from wsl_format import PREFIXES, FULL_LEMNISCATE, FORMAT, packed_bytes


def test_const(const):
    with tempfile.TemporaryDirectory() as d:
        root=Path(d)
        source=root/'work'
        outroot=root/'output'
        source.mkdir()
        (outroot/'staging').mkdir(parents=True)
        first = FULL_LEMNISCATE if const == 'lemniscate' else PREFIXES[const]
        digits=(first + b'0'*32)
        assert len(digits)==64
        textfile=source/'Constant - Dec - SAMPLE.txt'
        textfile.write_bytes(digits[:1]+b'.'+digits[1:])
        report=source/'Constant - SAMPLE.txt'
        label={'gamma':'Euler-Mascheroni Constant','lemniscate':'Lemniscate Constant'}[const]
        report.write_text(f'''Constant: {label}\nDecimal Digits: 63\nVerifying Base Conversion:\nVerifying Decimal Output:\nSpot Check: Good through 50\n''')
        dest=outroot/'staging'/f'digits_{const}_64.packed.bin'
        a=Namespace(source_root=source,output_root=outroot,input=textfile,report=report,
                    output=dest,constant=const,digits=64,run=True,keep_text=True,ack_large=None)
        record=wsl_convert._parse_and_run(a)
        assert record['format']==FORMAT
        assert dest.stat().st_size==packed_bytes(64)
        assert dest.read_bytes().hex().startswith(PREFIXES[const].decode()[:32])
        assert hashlib.sha256(dest.read_bytes()).hexdigest()==record['binary_sha256_streamed']
        assert textfile.exists()
        assert json.loads(Path(str(dest)+'.wsl-receipt.json').read_text())['constant']==const
        print(const,'PACKED_TEST_PASS')

if __name__=='__main__':
    test_const('gamma')
    test_const('lemniscate')
    print('PORTABLE_LOGIC_TESTS_PASS')
