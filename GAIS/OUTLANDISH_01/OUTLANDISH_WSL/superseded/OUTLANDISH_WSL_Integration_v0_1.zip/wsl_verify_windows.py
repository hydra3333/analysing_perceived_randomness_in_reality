#!/usr/bin/env python3
"""Read-only Windows verification of a WSL-staged numeric-byte OUTLANDISH file.

Reuses the established source's independent verifier; does not load, modify,
or promote the live registry. Optional --reference compares the entire shorter
of candidate and reference streams. Registration remains a separate owner step.
"""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

# Repo tree: GAIS/OUTLANDISH_01/OUTLANDISH_WSL/<this script>
PROJECT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(PROJECT))
from outlandish_big_constants import PREFIXES, verify  # noqa: E402

CHUNK = 4 * 1024 * 1024


def check_regular(path: Path) -> Path:
    p = path.absolute()
    if not p.is_file() or p.is_symlink() or (getattr(p, 'is_junction', lambda: False)()):
        raise ValueError(f'not an ordinary file: {p}')
    for parent in p.parents:
        if parent.is_symlink() or getattr(parent, 'is_junction', lambda: False)():
            raise ValueError(f'unsafe path ancestor: {parent}')
    return p


def compare_prefix(a: Path, b: Path) -> int:
    if a == b:
        raise ValueError('reference must not be the candidate')
    n = min(a.stat().st_size, b.stat().st_size)
    checked = 0
    with a.open('rb') as fa, b.open('rb') as fb:
        while checked < n:
            qty = min(CHUNK, n - checked)
            x = fa.read(qty)
            y = fb.read(qty)
            if x != y or len(x) != qty:
                raise ValueError(f'candidate/reference prefix differs near offset {checked:,}')
            checked += qty
    return checked


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--constant', choices=tuple(PREFIXES), required=True)
    p.add_argument('--digits', type=int, required=True)
    p.add_argument('--input', type=Path, required=True)
    p.add_argument('--reference', type=Path, help='trusted existing numeric-byte file; read-only')
    p.add_argument('--receipt', type=Path, help='defaults to <input>.wsl-receipt.json')
    p.add_argument('--progress-seconds', type=float, default=5.0)
    args = p.parse_args()
    try:
        if args.digits < 32:
            raise ValueError('expected at least 32 digits')
        inp = check_regular(args.input)
        receipt = check_regular(args.receipt or Path(str(inp) + '.wsl-receipt.json'))
        data = json.loads(receipt.read_text(encoding='utf-8'))
        if data.get('scope') != 'STAGING_ONLY_NO_REGISTRY_ACTION':
            raise ValueError('not a WSL staging receipt')
        if data.get('constant') != args.constant or data.get('digits_including_integer') != args.digits:
            raise ValueError('receipt identity mismatch')
        claimed = data.get('binary_sha256', '')
        if not isinstance(claimed, str) or len(claimed) != 64:
            raise ValueError('invalid receipt SHA-256')
        print(f'VERIFY STAGED FILE (READ-ONLY): {inp}', flush=True)
        import argparse as _argparse
        digest = verify(_argparse.Namespace(input_file=inp, constant=args.constant,
                        digits=args.digits, reference=None,
                        progress_seconds=args.progress_seconds))
        if digest != claimed:
            raise ValueError('Windows independent digest differs from WSL receipt')
        if args.reference:
            ref = check_regular(args.reference)
            prefix_bytes = compare_prefix(inp, ref)
            print(f'REFERENCE PREFIX PASS: {prefix_bytes:,} numeric bytes equal: {ref}', flush=True)
        print(f'WSL -> WINDOWS REHEARSAL PASS: {args.constant} {args.digits:,} bytes; {digest}', flush=True)
        print('NO REGISTRATION, NO DELETION, NO PRODUCTION TOML UPDATE.', flush=True)
    except (OSError, RuntimeError, ValueError, json.JSONDecodeError) as exc:
        print(f'WINDOWS VERIFY STOP: {exc}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
