# OUTLANDISH_WSL — isolated generator, Linux conversion and Windows verification

**Candidate:** v0.1, 2026-11-07. **Status:** Tested against synthetic files in a Linux container; **not yet exercised on the owner's actual Debian or Windows installations**. No production 10^10 run or registry promotion is authorised by this package.

## Operating principle

* New code and documentation are Git-managed on E: in `GAIS/OUTLANDISH_01/OUTLANDISH_WSL`.
* Linux static y-cruncher v0.8.7 Build 9547 runs inside Debian/WSL2, with its large text/swap files on ext4 in the T:-backed VHDX.
* `wsl_convert.py` (Python 3, **standard library only** for five constants) converts the native ext4 text to numeric-byte `.bin` **directly under the explicitly selected Windows staging root**, via `/mnt/t` for rehearsal or `/mnt/g` after review. No full text copy to NTFS, and no second complete binary on ext4. For `lemniscate` (full perimeter -> half perimeter), NumPy is optional for small cases, but *required by this candidate for >=1e9* because pure-Python digit-by-digit division would be prohibitively slow.
* Before deleting source text, the converter checks y-cruncher evidence (`Verify Output: Enabled`, successful spot check, constant, digit count), validates each input digit and a known constant prefix, flushes and fsyncs the binary, **rereads the entire binary**, publishes a create-only `.bin` filename, rereads the published `.bin` and records a durable JSON receipt. **Only then** does it delete the exact source text. On failed conversion or verification, source text remains. The report and small logs are never deleted.
* `wsl_verify_windows.py` independently reads the staged `.bin` on Windows using the existing `outlandish_big_constants.verify()` implementation, matches its SHA-256 to the Linux receipt and optionally compares every byte of the relevant existing reference prefix. It does not register, retire, or modify TOML.
* Existing production `outlandish_artifacts.py register` remains the **only** promotion mechanism, after a separately reviewed and owner-authorised step. `delete_superseded=true` on production may automatically delete an old active binary on promotion; this package makes **no** such calls.

**No production TOML is copied or edited by this package.** A second mutable registry would duplicate authority and invite errors. All paths and identity values are explicit command-line arguments for v0.1; a configuration template can be added later after the safe rehearsal if it materially simplifies operation.

## Files

* `wsl_generate.sh` — preview by default; native y-cruncher CLI wrapper, fixed `-verify:1` and conservative default `-TD:1 -PF:none`, swap cap `-M:4g`, unique ext4 attempt and swap directory. The memory setting is **proposed**, not proven safe/optimal for 10^10. Does not convert or delete text.
* `wsl_convert.py` — preview by default; strict streaming converter to a single specified T: or G: staging root; delete text *only after successful multi-pass verification*, unless `--keep-text` is supplied.
* `wsl_verify_windows.py` — Windows read-only receipt, numeric-byte, digest, and optional reference-prefix verifier.
* `test_wsl_convert.py` — synthetic six-constant and failure/refusal tests.
* `RESOURCE_ESTIMATES.md` — exact file sizes, observed 10^9 timings and deliberately labelled uncalibrated compute-only extrapolations.

## Initial 100-million-digit rehearsal — on T:, without deleting the existing sample

In **Debian**, first establish Python 3:

```bash
python3 --version
```

If missing, install just the Debian interpreter (`sudo apt update` then `sudo apt install -y python3-minimal`). No pip, compiler or NumPy is needed for the φ rehearsal.

Set the paths in the Debian shell:

```bash
SRC=/mnt/e/SOFTWARE-Win11/powerball/analysing_perceived_randomness_in_reality/GAIS/OUTLANDISH_01/OUTLANDISH_WSL
TEST=/mnt/t/OUTLANDISH_WSL/rehearsal_artifacts
mkdir -p "$TEST/staging"
```

**First run the preview ONLY**. Copy the following as one multiline command:

```bash
python3 "$SRC/wsl_convert.py" \
  --constant phi --digits 100000000 \
  --source-root /home/u/outlandish-test \
  --input '/home/u/outlandish-test/phi_100m_swap/Golden Ratio - Dec - Newton.txt' \
  --report '/home/u/outlandish-test/phi_100m_swap/Golden Ratio - 20261107-172852.txt' \
  --output-root "$TEST" \
  --output "$TEST/staging/digits_golden_ratio_10_to_8.bin" \
  --keep-text
```

After reviewing the preview, explicitly rerun that **same command with `--run` added**. `--keep-text` is intentional for this first rehearsal, to preserve the existing successful 100m sample. The converter will create exactly one `.bin` and its small `.wsl-receipt.json`, with no registry change.

In **Windows CMD**, use the existing normal Windows Python/venv to verify the staged file (read-only):

```bat
python "E:\SOFTWARE-Win11\powerball\analysing_perceived_randomness_in_reality\GAIS\OUTLANDISH_01\OUTLANDISH_WSL\wsl_verify_windows.py" --constant phi --digits 100000000 --input "T:\OUTLANDISH_WSL\rehearsal_artifacts\staging\digits_golden_ratio_10_to_8.bin" --reference "G:\OUTLANDISH_01\large_artifacts\digits\digits_golden_ratio_10_to_9.bin"
```

This independent Windows verification rereads the **complete 100m binary**, verifies the receipt digest and compares all 100m bytes to the prefix of the verified production 1-billion-digit φ file. The production file is opened read-only; the script does not register anything.

**If the hard-link publication step fails on `/mnt/t` or `/mnt/g` (DrvFS/NTFS filesystem support), stop and report the exact error.** Do not replace it with an overwrite-capable move or bypass the receipt/safety checks. That bridge is intentionally being tested in the 100m rehearsal.

## Generation preview (no run)

From Debian, while in the E: WSL source folder:

```bash
bash ./wsl_generate.sh --constant phi --digits 100000000
```

This **prints** the full configuration but does not create files or launch y-cruncher. To start generation would require an additional `--run` flag, and a run at/above 1 billion digits additionally requires `--ack-large-run N` with the exact digit count. For 10^10 and 10^11, first establish actual memory/disk/resource limits and obtain explicit owner approval. **Do not paste a large executable launch command for resource estimation.**

On an actual new generation, the runner keeps the text until a separate successful converter invocation. With the converter's normal default (omitting `--keep-text`), the text is deleted after the conversion/output reread/receipt checks; the small y-cruncher report and run log remain.

## Staging to G: later, after review

When a larger result is authorised, Linux `--output-root` will be the **existing G: artifact root** as seen through `/mnt/g/OUTLANDISH_01/large_artifacts`, with output in its `staging/` subdirectory, create-only. This is **not** a new registered/active file. The Linux binary SHA comes from the receipt; Windows must independently read it before any promotion. Production `outlandish_artifacts.py register` requires the correct basename, full SHA, content checks, full previous prefix check, and separate `--apply --confirm-idle`. Production retention can remove the prior binary, so back up/review retention deliberately before registration.

The safest initial G: production plan is **not** included as an automated button in this candidate. After the T: rehearsal, assess Windows filesystem publication semantics, timing, failure cleanup, exact binary filename, audit behavior and source deletion before allowing a 10^10 run.

## Technical notes and limitations

* A source file must be ordinary plaintext in the explicit source root; the report must be an ordinary small file **in the same attempt directory**. Source must include one decimal point immediately after the integer digit and no headers. Whitespace is allowed. For the lemniscate, the y-cruncher full-perimeter prefix must match before exact streaming division by two.
* The converter compares the known 32-digit prefix and binary digit range but **does not independently mathematically calculate all N digits**. y-cruncher's own output verification is therefore enabled and its report checked. The Windows pass detects transport/conversion corruption, not a shared algorithmic error in y-cruncher.
* Full output binary is read twice on Debian (pre/post-publication) plus once on Windows. These extra sequential reads trade time for reliable deletion and registration controls; they do **not** create an extra large binary copy.
* Files/receipt created by an interrupted operation may need manual investigation; there is no automated destructive retry. No generated data or mutable registry should be committed to Git. Git ignore rules for the WSL source folder should prohibit all *.bin, *.part, large text, logs, JSON receipts, and Python caches where appropriate.
* This candidate was tested on synthetic data in a Linux container; owner-specific WSL/DrvFS behavior remains **unverified**. The first real 100m rehearsal is the next test, NOT a 10^10 generation.
