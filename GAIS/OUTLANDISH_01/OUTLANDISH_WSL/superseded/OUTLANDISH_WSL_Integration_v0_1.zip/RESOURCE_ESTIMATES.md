# OUTLANDISH_WSL: output sizes and tentative timing models

**Date:** 2026-11-07. **Status:** Projections only; no 10^10/10^11 production run yet. These figures are NOT execution-time predictions or deadlines.

## Exact output sizes (per constant)

| Digits including integer | Final numeric-byte binary | Decimal text (without optional formatting) | Six final binaries |
|---|---:|---:|---:|
| 1,000,000,000 | 1,000,000,000 bytes (0.9313 GiB) | 1,000,000,001 bytes with decimal point | 6,000,000,000 bytes (5.59 GiB) |
| 10,000,000,000 | 10,000,000,000 bytes (9.3132 GiB) | 10,000,000,001 bytes | 60,000,000,000 bytes (55.88 GiB) |
| 100,000,000,000 | 100,000,000,000 bytes (93.1323 GiB) | 100,000,000,001 bytes | 600,000,000,000 bytes (558.79 GiB) |

These are **exact numeric-byte lengths** and the observed plain y-cruncher text formatting with one decimal point, assuming no separators. Actual y-cruncher **resource estimates** include transient working/swap files and may show a larger output allowance than this exact file length. Only one constant should be attempted at a time; text is deleted only after validated conversion and receipt; a registered old binary might remain pending retirement.

## Existing observed generator runtimes at 10^9

The table below records *owner-reported, approximate native Windows RAM-mode* y-cruncher generator observations using differing actual settings. They do not include full scans, WSL/NTFS conversion, cross-system verification, or registry work. `Lemniscate` observed only as "minutes", not an exact numerical time.

| Constant | Approximate observed 10^9 generation |
|---|---:|
| φ / golden ratio | 15 seconds |
| e | 44 seconds |
| π | 71 seconds |
| ln(2) | 180 seconds (3 minutes) |
| γ / Euler–Mascheroni | 2,447 seconds (40.8 minutes) |
| Lemniscate full-perimeter generator (normalized later to half) | Minutes; exact observed time not available |

Under Debian/WSL2, **φ** has been measured at 100,000 digits RAM/0.086s; 1m swap/1.727s; 10m swap/6.982s; and 100m swap/50.108s. The 100m swap run used `-M:256m -TD:1 -PF:none`, with output verification. These do **not** calibrate the performance of disk-backed 10^10 work on T:'s physical HDD.

## Explicitly speculative compute-only scaling illustration

For a *calculator* illustration (not a wall-time forecast), suppose computational cost scaled with `N × (ln N)^2` across sizes. This gives factors **12.35** (10^9 to 10^10) and **149.38** (10^9 to 10^11). Applying those artificial factors to the observed native-Windows 10^9 timings produces:

| Constant | 10^9 observed (Windows RAM) | 10^10 compute-only illustration | 10^11 compute-only illustration |
|---|---:|---:|---:|
| φ | ~15 s | ~3.1 min | ~37 min |
| e | ~44 s | ~9.1 min | ~1.83 h |
| π | ~71 s | ~14.6 min | ~2.95 h |
| ln(2) | ~180 s | ~37 min | ~7.47 h |
| γ | ~2,447 s | ~8.4 h | ~4.23 days |
| Lemniscate | "minutes" | **Not quantifiable** | **Not quantifiable** |

**Warning: none of these illustrative compute-only values is a realistic WSL2 HDD-backed expected wall time.** The simplifying model ignores algorithm/FFT complexity transitions, WSL memory cap, spill/seek/write amplification, multithreading changes, y-cruncher output verification, logging, transfer and conversion. In particular, WSL2 100m φ swap/50s versus native Windows 1b φ RAM/~15s already demonstrates that configurations cannot be casually scaled together. Actual 10^10/10^11 wall time could be substantially longer and is not reliably bounded from the current evidence; some attempts may prove impractical.

## Additional disk/memory evidence

At **10^10** φ in the Linux interactive *resource estimator only*, y-cruncher displayed RAM-only **41.0 GiB**; in disk-swap mode with the then-selected 14.1 GiB total-memory allocation it displayed about **37.0 GiB logical temporary disk** plus **17.0 GiB output**, and checkpoint size ~21.3 GiB. These estimates were **not** measured disk traffic or a validated 4 GiB memory cap. The 4 GiB total-memory target is proposed, not yet proven for 10^10. For 10^11 all six constants, proper far-memory and intermediate-file estimates are **still unavailable**. The WSL ext4 virtual capacity is ~1 TB and T: physical free space was ~2.9 TB; check *both* before large runs.

## Next measurement plan

After the 100m binary conversion and Windows read-only verification rehearsal passes, benchmark controlled **10^9 φ** swap under proposed 4g/TD1 settings only with owner approval, capture generation phase, conversion phase, G: write throughput, Windows reread and full-prefix-check elapsed time, plus peak actual swap and storage use. Repeat other constants selectively. Use these to derive empirically grounded 10^10 ranges before attempting them; only then consider 10^11. Include observed `.bin` sizes and hashes in each receipt. Keep `-verify:1` and conservative threading initially, and never add automatic large-run scheduling on the basis of speculative tables.
