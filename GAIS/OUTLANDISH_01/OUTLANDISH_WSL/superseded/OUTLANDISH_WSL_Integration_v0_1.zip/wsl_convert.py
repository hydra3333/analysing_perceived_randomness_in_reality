#!/usr/bin/env python3
"""WSL-only strict decimal-text -> OUTLANDISH numeric-byte staging converter.

Read an already-completed y-cruncher plain-text file on native Linux ext4 and
write an independently re-read/verified .bin into explicitly scoped staging
on T: (rehearsal) or G: (after review). Never touches the Windows registry.
Requires Python >=3.10 standard library; NumPy is OPTIONAL for lemniscate.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import sys
import time
import uuid

CHUNK = 4 * 1024 * 1024
WHITESPACE = b' \t\r\n'
NUMERIC = bytes((i - 48 if 48 <= i <= 57 else 255) for i in range(256))
PREFIXES = {
    'pi': b'31415926535897932384626433832795',
    'phi': b'16180339887498948482045868343656',
    'e': b'27182818284590452353602874713526',
    'log2': b'06931471805599453094172321214581',
    'gamma': b'05772156649015328606065120900824',
    'lemniscate': b'26220575542921198104648395898911',
}
LEMNISCATE_SOURCE = bytes(i - 48 for i in b'52441151085842396209296791797822')
STEMS = {'pi': 'pi', 'phi': 'golden_ratio', 'e': 'e', 'log2': 'log2',
         'gamma': 'gamma', 'lemniscate': 'lemniscate'}
REPORT_NAMES = {'pi': 'Pi', 'phi': 'Golden Ratio', 'e': 'e',
                'log2': 'Log(2)', 'gamma': 'Euler-Mascheroni Constant',
                'lemniscate': 'Lemniscate'}


def ordinary(path: Path, *, kind: str) -> Path:
    """Reject symlinks in existing ancestors, including leaf, before use."""
    p = Path(os.path.abspath(path))
    for node in (p, *p.parents):
        if node.is_symlink():
            raise ValueError(f'{kind} has symlink ancestor: {node}')
    if kind == 'input' and (not p.is_file() or not p.stat().st_nlink >= 1):
        raise ValueError(f'input not regular: {p}')
    return p


def inside(child: Path, root: Path, *, strict: bool = True) -> bool:
    try:
        rel = child.relative_to(root)
        return bool(rel.parts) if strict else True
    except ValueError:
        return False


def validate_report(report: Path, constant: str, digits: int) -> dict:
    if not report.is_file() or report.is_symlink() or report.stat().st_size > 256_000:
        raise ValueError('missing/non-ordinary/oversized y-cruncher validation report')
    body = report.read_text(encoding='utf-8', errors='replace')
    if not re.search(r'Verify Output:\s*Enabled', body):
        raise ValueError('report does not show Verify Output: Enabled')
    if not re.search(r'Spot Check:\s*Good through', body):
        raise ValueError('report does not show a successful spot check')
    if not re.search(r'Decimal Digits:\s*' + re.escape(f'{digits - 1:,}') + r'\b', body):
        raise ValueError('report decimal digit count does not match')
    # The report is evidence, not a cryptographic authenticity guarantee.
    if not re.search(r'Constant:\s*' + re.escape(REPORT_NAMES[constant]) + r'\s*$', body, re.M | re.I):
        raise ValueError('report constant does not match')
    return {'report_file': report.name, 'report_sha256': hashlib.sha256(report.read_bytes()).hexdigest(),
            'ycruncher_verify_output': True, 'spot_check_reported': True}


def halve(digits: bytes, carry: int, np_module) -> tuple[bytes, int]:
    if np_module is not None:
        ar = np_module.frombuffer(digits, dtype=np_module.uint8)
        out = ar >> 1
        out[0] += 5 * carry
        if len(ar) > 1:
            out[1:] += 5 * (ar[:-1] & 1)
        return out.tobytes(), int(ar[-1] & 1)
    out = bytearray(len(digits))
    for index, val in enumerate(digits):
        out[index] = (10 * carry + val) // 2
        carry = val & 1
    return bytes(out), carry


def convert(args) -> dict:
    source_root = ordinary(args.source_root, kind='source root')
    output_root = ordinary(args.output_root, kind='output root')
    inp = ordinary(args.input, kind='input')
    report = ordinary(args.report, kind='report') if args.report else None
    output = ordinary(args.output, kind='output')
    if not source_root.is_dir() or not output_root.is_dir():
        raise ValueError('source-root and output-root must be existing directories')
    if not inside(inp, source_root) or not inside(output, output_root):
        raise ValueError('input/output must be strictly within their respective roots')
    if not inp.name.endswith('.txt') or not output.name.endswith('.bin'):
        raise ValueError('source must be .txt and destination must be .bin')
    if report and (not inside(report, source_root) or report.parent != inp.parent):
        raise ValueError('report must be in the same source attempt directory')
    if output.exists() or output.is_symlink():
        raise FileExistsError(f'refusing to replace output: {output}')
    receipt_path = output.with_name(output.name + '.wsl-receipt.json')
    if receipt_path.exists() or receipt_path.is_symlink():
        raise FileExistsError('receipt already exists; refusing to replace')
    if args.digits < 32:
        raise ValueError('digits must be >= 32')
    if args.delete_text and report is None:
        raise ValueError('automatic source deletion requires --report with y-cruncher validation evidence')
    report_info = validate_report(report, args.constant, args.digits) if report else {}
    if not args.run:
        print(f'PREVIEW constant={args.constant} digits={args.digits:,}')
        print(f'READ {inp}; report={report}')
        print(f'CREATE {output}; receipt={receipt_path}')
        print('TEXT CLEANUP: ' + ('after successful re-read verification & receipt' if args.delete_text else 'KEEP'))
        print('No output created, no input read in full, no files deleted.')
        return {}
    if args.digits >= 1_000_000_000 and not args.confirm_large:
        raise ValueError('for >=1e9 digits, explicitly add --confirm-large after preview/review')
    if output.parent != output_root / 'staging':
        raise ValueError('output must be immediately below output-root/staging (pre-existing)')
    if not output.parent.is_dir() or output.parent.is_symlink():
        raise ValueError('staging folder missing/unsafe')
    if not output.name.startswith('digits_' + STEMS[args.constant] + '_'):
        raise ValueError('filename must follow digits_<constant>_*.bin convention')
    if shutil.disk_usage(output.parent).free < args.digits + 16 * 1024 * 1024:
        raise ValueError('insufficient destination free space')
    known = bytes(x - 48 for x in PREFIXES[args.constant])
    np_module = None
    if args.constant == 'lemniscate':
        try:
            import numpy as np_module
        except ImportError:
            if args.digits >= 1_000_000_000:
                raise ValueError('lemniscate >=1e9 needs optional NumPy for practical speed')
    temporary = output.with_name('.' + output.name + '.' + uuid.uuid4().hex + '.part')
    start = time.perf_counter()
    in_sha = hashlib.sha256()
    out_sha = hashlib.sha256()
    raw_size = total = dots = carry = 0
    published = False
    receipt_published = False
    try:
        with inp.open('rb') as src, temporary.open('xb') as dst:
            while chunk := src.read(CHUNK):
                in_sha.update(chunk)
                raw_size += len(chunk)
                if b'.' in chunk:
                    count = chunk.count(b'.')
                    if dots or count != 1:
                        raise ValueError('more than one decimal point')
                    before = chunk[:chunk.index(b'.')].translate(None, WHITESPACE)
                    if total + len(before) != 1:
                        raise ValueError('decimal point must follow the integer digit')
                    dots = 1
                translated = chunk.translate(None, WHITESPACE + b'.').translate(NUMERIC)
                if b'\xff' in translated:
                    raise ValueError('non-digit/header/metadata in source text')
                if args.constant == 'lemniscate':
                    if total < len(LEMNISCATE_SOURCE):
                        n = min(len(translated), len(LEMNISCATE_SOURCE) - total)
                        if translated[:n] != LEMNISCATE_SOURCE[total:total+n]:
                            raise ValueError('lemniscate source is not the full perimeter')
                    translated, carry = halve(translated, carry, np_module)
                if total < len(known):
                    n = min(len(translated), len(known) - total)
                    if translated[:n] != known[total:total+n]:
                        raise ValueError('known constant prefix mismatch')
                total += len(translated)
                if total > args.digits:
                    raise ValueError('source exceeds requested digit count')
                dst.write(translated)
                out_sha.update(translated)
            if not dots:
                raise ValueError('decimal point missing')
            if total != args.digits:
                raise ValueError(f'wrong digit count: {total} instead of {args.digits}')
            dst.flush()
            os.fsync(dst.fileno())
        reread_sha = hashlib.sha256()
        verified = 0
        with temporary.open('rb') as src:
            while chunk := src.read(CHUNK):
                if max(chunk, default=0) > 9:
                    raise ValueError('invalid numeric byte on verification reread')
                if verified < len(known):
                    n = min(len(chunk), len(known) - verified)
                    if chunk[:n] != known[verified:verified+n]:
                        raise ValueError('reread known prefix mismatch')
                reread_sha.update(chunk)
                verified += len(chunk)
        if verified != args.digits or reread_sha.hexdigest() != out_sha.hexdigest():
            raise ValueError('post-conversion binary reread/length/SHA mismatch')
        # A create-only hard link publishes a completed file without overwriting
        # another file if the Windows filesystem supports hardlinks through DrvFS.
        os.link(temporary, output)
        published = True
        if output.stat().st_size != args.digits:
            raise ValueError('published file size changed')
        with output.open('rb') as pub:
            published_hash = hashlib.sha256()
            while chunk := pub.read(CHUNK):
                published_hash.update(chunk)
        if published_hash.hexdigest() != out_sha.hexdigest():
            raise ValueError('published file digest differs')
        record = {
            'format': 'OUTLANDISH_01_numeric_digit_0_to_9_one_byte',
            'constant': args.constant, 'digits_including_integer': args.digits,
            'binary': str(output), 'binary_sha256': out_sha.hexdigest(),
            'source_text': str(inp), 'source_text_bytes': raw_size,
            'source_text_sha256': in_sha.hexdigest(),
            'text_cleanup_requested': bool(args.delete_text),
            'conversion_seconds': round(time.perf_counter() - start, 3),
            'verified_utc': datetime.now(timezone.utc).isoformat(),
            'scope': 'STAGING_ONLY_NO_REGISTRY_ACTION', **report_info,
        }
        # Create-only, durable receipt before deleting source. If this fails,
        # the text is preserved and the candidate is left for inspection.
        with receipt_path.open('x', encoding='utf-8') as receipt:
            json.dump(record, receipt, indent=2)
            receipt.write('\n')
            receipt.flush()
            os.fsync(receipt.fileno())
        receipt_published = True
        if args.delete_text:
            # No wildcards; delete only the exact input file inside source-root.
            inp.unlink()
            print(f'TEXT REMOVED after verified binary/receipt: {inp}', flush=True)
        print(f'STAGING CONVERSION PASS: {args.constant} {total:,} digits', flush=True)
        print(f'OUTPUT {output}; SHA-256 {out_sha.hexdigest()}', flush=True)
        print(f'RECEIPT {receipt_path}', flush=True)
        print(f'CONVERT + RE-READ + PUBLISH seconds: {time.perf_counter()-start:.3f}', flush=True)
        return record
    finally:
        if temporary.exists():
            temporary.unlink()
        if published and not receipt_published:
            print('NOTICE: candidate published but receipt not confirmed; source retained; inspect manually.', file=sys.stderr)


def main() -> int:
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('--constant', choices=tuple(PREFIXES), required=True)
    p.add_argument('--digits', type=int, required=True, help='including the integer digit')
    p.add_argument('--input', type=Path, required=True, help='native ext4 y-cruncher plaintext')
    p.add_argument('--report', type=Path, help='matching small y-cruncher verification report')
    p.add_argument('--source-root', type=Path, required=True, help='pre-existing allowed source parent')
    p.add_argument('--output-root', type=Path, required=True, help='pre-existing T: rehearsal or G: artifact root')
    p.add_argument('--output', type=Path, required=True, help='create-only .bin under output-root/staging')
    p.add_argument('--run', action='store_true', help='without this, print a preview only')
    p.add_argument('--confirm-large', action='store_true', help='required for >=1e9 digits')
    g = p.add_mutually_exclusive_group()
    g.add_argument('--keep-text', dest='delete_text', action='store_false')
    g.add_argument('--delete-text-after-verified', dest='delete_text', action='store_true')
    p.set_defaults(delete_text=True)
    args = p.parse_args()
    try:
        convert(args)
    except (OSError, ValueError, RuntimeError) as exc:
        print(f'WSL CONVERSION STOP: {exc}', file=sys.stderr)
        return 2
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
