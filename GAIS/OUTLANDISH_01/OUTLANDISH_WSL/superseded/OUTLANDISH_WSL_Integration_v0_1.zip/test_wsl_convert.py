#!/usr/bin/env python3
"""Synthetic-only WSL converter and read-only Windows verifier tests."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

import wsl_convert as wc

SCRIPT = Path(__file__).with_name('wsl_convert.py')


class ConverterTests(unittest.TestCase):
    def setUp(self):
        self.tmp = tempfile.TemporaryDirectory()
        self.addCleanup(self.tmp.cleanup)
        self.root = Path(self.tmp.name)
        self.source = self.root / 'linux'
        self.attempt = self.source / 'attempt'
        self.attempt.mkdir(parents=True)
        self.outroot = self.root / 't_rehearsal'
        (self.outroot / 'staging').mkdir(parents=True)

    def payload(self, constant='phi', digits=64, invalid_report=False):
        prefix = b'52441151085842396209296791797822' if constant == 'lemniscate' else wc.PREFIXES[constant]
        content = prefix + b'0' * (digits - len(prefix))
        f = self.attempt / 'constant.txt'
        f.write_bytes(content[:1] + b'.' + content[1:])
        name = wc.REPORT_NAMES[constant]
        r = self.attempt / 'validated.txt'
        r.write_text(f'Constant: {name}\nDecimal Digits: {digits - 1:,}\nVerify Output: Enabled\n'
                     + ('Spot Check: BAD\n' if invalid_report else 'Spot Check: Good through 32\n'), encoding='utf-8')
        dest = self.outroot / 'staging' / f'digits_{wc.STEMS[constant]}_10_to_test.bin'
        cmd = [sys.executable, str(SCRIPT), '--constant', constant, '--digits', str(digits),
               '--input', str(f), '--source-root', str(self.source),
               '--output-root', str(self.outroot), '--output', str(dest),
               '--report', str(r), '--run']
        return cmd, f, dest

    def run_script(self, cmd, rc=0):
        r = subprocess.run(cmd, capture_output=True, text=True)
        self.assertEqual(r.returncode, rc, r.stdout + '\n' + r.stderr)
        return r

    def test_six_constants_stream_and_delete(self):
        for const in wc.PREFIXES:
            with self.subTest(constant=const):
                cmd, f, out = self.payload(constant=const)
                self.run_script(cmd)
                self.assertFalse(f.exists())
                self.assertEqual(out.stat().st_size, 64)
                self.assertEqual(out.read_bytes()[:32], bytes(i - 48 for i in wc.PREFIXES[const]))
                receipt = json.loads(Path(str(out) + '.wsl-receipt.json').read_text())
                self.assertTrue(receipt['text_cleanup_requested'])
                self.assertEqual(receipt['scope'], 'STAGING_ONLY_NO_REGISTRY_ACTION')

    def test_preview_no_side_effects(self):
        cmd, f, out = self.payload()
        cmd.remove('--run')
        self.run_script(cmd)
        self.assertTrue(f.exists()); self.assertFalse(out.exists())

    def test_keep_text_rehearsal(self):
        cmd, f, out = self.payload()
        self.run_script(cmd + ['--keep-text'])
        self.assertTrue(f.exists()); self.assertTrue(out.exists())

    def test_invalid_source_retains_text_and_no_output(self):
        cmd, f, out = self.payload()
        f.write_bytes(b'1.' + b'X' * 63)
        self.run_script(cmd, rc=2)
        self.assertTrue(f.exists()); self.assertFalse(out.exists())
        self.assertFalse(Path(str(out)+'.wsl-receipt.json').exists())

    def test_invalid_report_retains_text(self):
        cmd, f, out = self.payload(invalid_report=True)
        self.run_script(cmd, rc=2)
        self.assertTrue(f.exists()); self.assertFalse(out.exists())

    def test_wrong_length_retains_text(self):
        cmd, f, out = self.payload()
        f.write_bytes(f.read_bytes()[:-2])
        self.run_script(cmd, rc=2)
        self.assertTrue(f.exists()); self.assertFalse(out.exists())

    def test_output_collision_retains_original(self):
        cmd, f, out = self.payload()
        out.write_bytes(b'old')
        self.run_script(cmd, rc=2)
        self.assertEqual(out.read_bytes(), b'old'); self.assertTrue(f.exists())

    def test_output_path_escape_refused(self):
        cmd, f, out = self.payload()
        cmd[cmd.index('--output') + 1] = str(self.root / 'outside.bin')
        self.run_script(cmd, rc=2)
        self.assertTrue(f.exists()); self.assertFalse((self.root / 'outside.bin').exists())

    def test_source_symlink_refused(self):
        cmd, f, out = self.payload()
        link = self.attempt / 'link.txt'
        try: link.symlink_to(f)
        except (OSError, NotImplementedError): self.skipTest('symlink privilege unavailable')
        cmd[cmd.index('--input') + 1] = str(link)
        self.run_script(cmd, rc=2)
        self.assertTrue(f.exists()); self.assertFalse(out.exists())

    def test_windows_verifier_reads_receipt_no_write(self):
        cmd, f, out = self.payload()
        self.run_script(cmd + ['--keep-text'])
        with tempfile.TemporaryDirectory() as target:
            project = Path(target)
            source_modules = Path(os.environ.get('OUTLANDISH_TEST_PARENT', Path(__file__).resolve().parent.parent))
            if not source_modules.is_dir():
                self.skipTest('standalone test requires repository copy')
            for name in ('outlandish_big_constants.py', 'outlandish_artifacts.py', 'outlandish_config.py'):
                shutil.copyfile(source_modules / name, project / name)
            sub = project / 'OUTLANDISH_WSL'
            sub.mkdir()
            shutil.copyfile(Path(__file__).with_name('wsl_verify_windows.py'), sub / 'wsl_verify_windows.py')
            ref = self.root / 'reference.bin'
            ref.write_bytes(out.read_bytes() + b'1'*20)
            args = [sys.executable, str(sub / 'wsl_verify_windows.py'), '--constant', 'phi',
                    '--digits', '64', '--input', str(out), '--reference', str(ref)]
            p = subprocess.run(args, capture_output=True, text=True)
            self.assertEqual(p.returncode, 0, p.stdout + '\n' + p.stderr)
            self.assertIn('NO REGISTRATION', p.stdout)


if __name__ == '__main__':
    unittest.main(verbosity=2)
