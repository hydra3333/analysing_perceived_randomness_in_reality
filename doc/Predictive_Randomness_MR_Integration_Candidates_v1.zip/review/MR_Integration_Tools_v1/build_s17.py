"""Extract ratified MR proposal v0.5 text into a raw R3 section 17 (headings shifted,
numbers prefixed with 17.). Cross-references are then edited by hand and listed in
the evidence note. Usage: python -I build_s17.py MR_v0_5.md out.md"""
import re, sys

src, out = sys.argv[1], sys.argv[2]
L = open(src, encoding="utf-8").read().split("\n")   # L[i] = line i+1

def rng(a, b):
    """1-based inclusive line range."""
    return L[a - 1:b]

def shift(lines):
    res = []
    for s in lines:
        m = re.match(r"^(#{2,3}) (.*)$", s)
        if m:
            hashes, title = m.groups()
            # numbered headings: "0. Scope", "3.4 Track", "5A. N1", "3.7A Fixed"
            t2 = re.sub(r"^(\d+[A-Z]?(?:\.\d+[A-Z]?)?)\.? ", lambda k: "17." + k.group(1) + " ", title)
            s = "#" + hashes + " " + t2
        # bold paragraph labels "**7.5 Side..." / "**18.1 Feasibility.**"
        s = re.sub(r"^\*\*(\d+\.\d+) ", lambda k: "**17." + k.group(1) + " ", s)
        res.append(s)
    return [x for x in res if x != "---"]

parts = []
parts += shift(rng(85, 99))      # 0
parts += shift(rng(102, 119))    # 1
parts += shift(rng(121, 149))    # 2 MRD table
parts += shift(rng(152, 159))    # 3, 3.1
parts += ["#### 17.3.2 Numbering conventions", "", "@@POINTER-3.2@@", ""]
parts += shift(rng(175, 307))    # 3.3 .. 3.9
parts += shift(rng(309, 400))    # 4
parts += shift(rng(402, 491))    # 5, 5A, 5B
parts += shift(rng(493, 787))    # 6
parts += ["### 17.7 In-sample diagnostic mode (IS)", "", "@@POINTER-7@@", ""]
parts += shift(rng(819, 857))    # 7.5
parts += ["### 17.8 Supplementary-number rule (MRD-03)", "", "@@POINTER-8@@", ""]
parts += shift(rng(875, 889))    # 9
parts += shift(rng(891, 925))    # 10
parts += shift(rng(927, 937))    # 11
parts += ["### 17.12 Execution model (independent of production; MRD-13)", "", "@@POINTER-12@@", ""]
parts += shift(rng(944, 945))    # 12 evaluator + dependency bullets
parts += shift(rng(949, 958))    # 13 phasing table
parts += ["@@POINTER-13@@", ""]
parts += shift(rng(986, 1016))   # 14
parts += shift(rng(1036, 1052))  # 16
parts += ["### 17.17 Traceability to the owner's starter text", ""]
parts += shift(rng(1058, 1077))  # 17.1 table only
parts += [""]
parts += shift(rng(1135, 1192))  # 18 (without end marker)
open(out, "w", encoding="utf-8", newline="\n").write("\n".join(parts) + "\n")
