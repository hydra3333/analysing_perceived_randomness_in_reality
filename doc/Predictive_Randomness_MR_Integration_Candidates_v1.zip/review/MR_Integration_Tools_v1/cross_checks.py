"""Cross-document checks over the draft editions.
Usage: python -I cross_checks.py DRAFT_DIR"""
import re, sys, os, hashlib
D = sys.argv[1]
F = {"R3": "Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md",
     "R2": "Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md",
     "Architecture": "Predictive_Randomness_Software_Architecture_Discussion_v0_8.md",
     "Proposal": "Predictive_Randomness_Research_Project_Proposal_v0_6.md"}
T = {k: open(os.path.join(D, v), encoding="utf-8").read() for k, v in F.items()}
ok = True
def say(flag, msg):
    global ok; ok &= flag; print(("PASS " if flag else "FAIL ") + msg)

# 1 shared paragraph identical in all four copies
paras = [l for k in ("R2", "Proposal", "Architecture") for l in T[k].split("\n") if l.startswith("**Current development data (25 October 2026")]
say(len(paras) == 4 and len(set(paras)) == 1, f"'Current development data' paragraph: {len(paras)} copies, {len(set(paras))} distinct text(s), sha256 {hashlib.sha256(paras[0].encode()).hexdigest()[:16]}")

# 2 stale supplementary wording gone
for k, t in T.items():
    for pat in ["provenance only and never become scientific inputs", "excluded from views and scoring", "supplemental science", "structural checks only."]:
        hits = [l[:90] for l in t.split("\n") if pat in l and "Earlier ratified text" not in l]
        say(not hits, f"{k}: no unqualified '{pat}'" + (f" -> {hits}" if hits else ""))

# 3 cross-references resolve to headings or bold labels
def anchors(t):
    a = set()
    for l in t.split("\n"):
        m = re.match(r"^#{2,4} (\d+[A-Z]?(?:\.\d+[A-Z]?)*)\.? ", l) or re.match(r"^\*\*(\d+(?:\.\d+[A-Z]?)+)\.? ", l)
        if m: a.add(m.group(1).rstrip("."))
    return a
A = {k: anchors(t) for k, t in T.items()}
refpat = re.compile(r"\b(R3|R2|Architecture)(?: sections?)? (\d+[A-Z]?(?:\.\d+[A-Z]?)*)((?:(?:,| and|-) ?\d+[A-Z]?(?:\.\d+[A-Z]?)*)*)")
bad = []
for k, t in T.items():
    for m in refpat.finditer(t):
        doc = m.group(1); nums = [m.group(2)] + re.findall(r"\d+[A-Z]?(?:\.\d+[A-Z]?)*", m.group(3) or "")
        for n in nums:
            if n in A[doc] or (doc == "R3" and n == "17"): continue
            # only check references our integration introduced (17.x in R3; new R2/Architecture sections)
            if (doc == "R3" and n.startswith("17")) or (doc == "R2" and n in ("2.5", "3.6", "5.6", "6.2", "8.4", "8.4.1", "8.4.2", "8.4.3", "8.4.4")) \
               or (doc == "Architecture" and n in ("5A.4", "12.5", "20A")):
                bad.append((k, m.group(0)))
# bare 17.x references inside R3
for m in re.finditer(r"(?<![\d.])(17\.\d+[A-Z]?(?:\.\d+[A-Z]?)*)", T["R3"]):
    n = m.group(1).rstrip(".")
    if n not in A["R3"] and not re.fullmatch(r"17\.\d{3}", n): bad.append(("R3", n))
say(not bad, f"integration cross-references resolve ({len(A['R3'])} R3 / {len(A['R2'])} R2 / {len(A['Architecture'])} Architecture anchors)" + (f"; unresolved {sorted(set(bad))}" if bad else ""))
print("OVERALL", "PASS" if ok else "FAIL")
