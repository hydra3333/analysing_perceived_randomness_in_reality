"""Assemble RATIFICATION_REGISTER v0.4 (candidate) from ratified v0.3 and the four draft editions.
Hashes are computed from the draft files (UTF-8, LF), so rerun after every revision.
Usage: python -I assemble_reg.py REG_v0_3.md DRAFT_DIR out.md"""
import sys, hashlib, os
reg = open(sys.argv[1], encoding="utf-8").read(); D = sys.argv[2]
def h(name): return hashlib.sha256(open(os.path.join(D, name), "rb").read()).hexdigest()
def rep(text, old, new, label):
    c = text.count(old)
    if c != 1: sys.exit(f"{label}: expected 1 match, found {c}: {old[:80]!r}")
    return text.replace(old, new)
R3, R2 = "Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md", "Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md"
AR, PR = "Predictive_Randomness_Software_Architecture_Discussion_v0_8.md", "Predictive_Randomness_Research_Project_Proposal_v0_6.md"

new_section = f"""## Method ranking measures and integration editions (26 October 2026)

Two documents were owner-ratified on 26 October 2026 at commit `ac01678`. Their authoring-time headers ("RATIFICATION CANDIDATE" / "CANDIDATE ... awaits owner ratification") are historical; the ratification recorded here determines their status, and the files are never edited to change those headers.

| Document (path under `doc/`) | Authority and status | Git-content SHA-256 (UTF-8/LF) |
|---|---|---|
| `Predictive_Randomness_Method_Ranking_Measures_Proposal_v0_5.md` | OWNER-RATIFIED 26 Oct 2026. Its content is integrated into the four editions below; once they are ratified, the file is integrated history, kept unchanged. Versions v0.2-v0.4 are historical drafts. | `c6ca2cb2174ee2963a6fe33347820c80b92e6dd1eda518a1f0c8e3254d67ab19` |
| `HOLDOUT_EXPOSURE_RECORD_v0_2.md` | OWNER-RATIFIED 26 Oct 2026; factual, value-free record (6 items); supersedes v0.1 | `aec833fe031b6d1d73e6acbb81757b50b193425a6899c84d438431d9df4433e2` |
| `RATIFICATION_REGISTER_v0_3.md` | OWNER-RATIFIED 26 Oct 2026; superseded by this register when it is ratified | `99e75fbe1bc5cea34a7d2b1c456633815b88e340c4a05aab5fb671d624c7ec37` |

**Integration editions (RATIFICATION CANDIDATES, awaiting owner ratification).** Each is its ratified predecessor edited in place; every ratified ID and rule is kept, and the protected blocks are byte-identical.

| Candidate edition (path under `doc/`) | Ratified predecessor | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `{R3}` | R3 v0.4 | RATIFICATION CANDIDATE; adds section 17 (method ranking measures); `{h(R3)}` |
| `{R2}` | R2 v0.4 | RATIFICATION CANDIDATE; supplementary rule 2.5, numbering 3.6, stage-1 contract fields 5.6, in-sample mode 8.4; `{h(R2)}` |
| `{AR}` | Architecture v0.7 | RATIFICATION CANDIDATE; ranking tool launcher 5A.4, report tool / in-sample runs / N1 12.5; protected 5C unchanged; `{h(AR)}` |
| `{PR}` | Proposal v0.5 | RATIFICATION CANDIDATE; charter section 2.7; supplementary sentence in sections 0 and 3.1; `{h(PR)}` |

**On owner ratification:** the install package changes the four headers and this table's statuses to OWNER-RATIFIED and recomputes these hashes; Claude verifies the installed files against Git HEAD. R3 v0.4, R2 v0.4, Architecture v0.7 and Proposal v0.5 then become historical predecessors, with their hashes kept above. Unchanged: R1 v0.4, TIE_SHA256_V1 v0.2, P3 v0.2, the Windows POC Task Specification v0.2, the numerical reference v0.1, the E_1 legacy schema and goldens, the masters, the owner tools, the coordinator and Package 2 v0.11. Ratification grants no run, update, holdout, Mode H, FINAL, process termination or code acceptance.

**Continuity documents (commit `618fe48`, verified by Claude):** the current handovers are `HANDOVER/Claude_Reviewer_Handover_Predictive_Randomness_v10.md` and `HANDOVER/Predictive_Randomness_ChatGPT_Coder_Handover_v1_1r1.md`. Reviewer handovers v2-v9, coder handovers v1.0r1 and v1.1, and the ChatGPT handbacks are in `HANDOVER/superseded/`; the interim note is in `HANDOVER/`. They are continuity records, not normative.

"""

reg = rep(reg, "**Register version:** v0.3 OWNER-RATIFIED 26 October 2026, consolidated governing-document register; v0.2 OWNER-RATIFIED 24 October 2026.",
    "**Register version:** v0.4 RATIFICATION CANDIDATE (26 October 2026), adding the method-ranking integration; v0.3 OWNER-RATIFIED 26 October 2026; v0.2 OWNER-RATIFIED 24 October 2026.", "hdr")
reg = rep(reg, "The new consolidated governing editions below were owner-ratified 26 October 2026; only explicit OPEN/PROVISIONAL/RECOMMENDED subitems remain undecided.  \n",
    "The new consolidated governing editions below were owner-ratified 26 October 2026; only explicit OPEN/PROVISIONAL/RECOMMENDED subitems remain undecided. The v0.4 entries were cross-checked by Claude against GitHub HEAD `618fe48` (26 October 2026).  \n", "basis")
reg = rep(reg, "- The **current** governing set is consolidated Proposal v0.5,",
    "- **Until the v0.4 integration editions are ratified,** the v0.3 set below governs, together with the already ratified Method Ranking Measures Proposal v0.5 and exposure record v0.2; on ratification the current set becomes Proposal v0.6, R1 v0.4, R2 v0.5, R3 v0.5, Architecture v0.8, the Windows POC Task Specification v0.2, P3 v0.2, TIE_SHA256_V1 v0.2 and exposure record v0.2.\n- The v0.3 governing set is consolidated Proposal v0.5,", "interp")
reg = rep(reg, "\n## Interpretation and verification\n", "\n" + new_section + "## Interpretation and verification\n", "insert")
open(sys.argv[3], "w", encoding="utf-8", newline="\n").write(reg)
print("ok")
