# The one replacement applied identically to the four copies of the "Current development data" paragraph.
S_OLD = "Three supplementary Oz Lotto labels are provenance only and never become scientific inputs."
S_NEW = ("Three supplementary Oz Lotto labels are never method inputs; the evaluator alone may read a target "
         "draw's supplementaries, after the target is opened and its forecast frozen, solely to classify prize "
         "divisions (R2 section 2.5).")
