"""Assemble Proposal v0.6 from ratified Proposal v0.5.
Usage: python -I assemble_prop.py PROPOSAL_v0_5.md out.md"""
import sys
sys.path.insert(0, __file__.rsplit("/", 1)[0])
from common_supp import S_OLD, S_NEW
p = open(sys.argv[1], encoding="utf-8").read()
def rep(text, old, new, label, n=1):
    c = text.count(old)
    if c != n: sys.exit(f"{label}: expected {n} match(es), found {c}: {old[:80]!r}")
    return text.replace(old, new)

s27 = """### 2.7 Method rankings, in-sample diagnostics and "mark, never suppress" (DECIDED, 26 October 2026)

Owner-ratified in the Method Ranking Measures Proposal v0.5. The operative rules are in R3 section 17, R2 sections 2.5, 3.6, 5.6 and 8.4, and Architecture sections 5A.4 and 12.5.

- **Rankings are reports.** Methods may be ranked by measured success in league tables, separately for each game and independently of production runs (MRD-01, MRD-13). Rankings never alter a forecast, fit or FINAL batch, and no method reads them. Any rule that uses rankings to choose, weight or switch methods is itself a registered meta-method, tested like any other method (MRD-05; RK-1..RK-3).
- **In-sample diagnostics are allowed and labelled.** The owner knowingly accepts in-sample bias. In-sample results are shown beside walk-forward results, never ranked against them, and never counted as evidence of prediction (MRD-21, MRD-23; R2 section 8.4).
- **Mark, never suppress.** Every number the owner asks for is calculated and shown. Where a figure is not a calibrated probability, it carries a plain label saying so; it is never withheld for that reason (MRD-21).
- **Statistics is an instrument, not a gate.** Conventional statistics is used to tell kinds of pattern apart: a consequence of how the method works, an effect of fitting, chance or selection, or a pattern that persists on genuinely new draws (PO-1..PO-4; R3 section 17.3.9). It never decides which ideas, methods or measures may be investigated or reported.
- **Explanation-text rule.** Every measure, method, variant, status and mode is reported with its ID, name, one-line summary and a short explanation, so its meaning is never lost from a report. Generic terms such as "walk-forward" and "in-sample" are always printed with their exact meaning in this project (MRD-09, MRD-24).

"""

p = rep(p, "## Comprehensive project proposal \u2014 v0.5 consolidated, OWNER-RATIFIED (26 October 2026)\n",
    "## Comprehensive project proposal \u2014 v0.6 RATIFICATION CANDIDATE (26 October 2026)\n", "title")
p = rep(p, "**Edition status: OWNER-RATIFIED 26 October 2026 (consolidated v0.4 review baseline).** This edition supersedes Proposal v0.4.",
    "**Edition status: RATIFICATION CANDIDATE, awaiting owner ratification; until then Proposal v0.5 governs, except that the owner-ratified Method Ranking Measures Proposal v0.5 already governs its own subject.** Proposal v0.6 is Proposal v0.5 (OWNER-RATIFIED 26 October 2026, which superseded Proposal v0.4) plus that integration.", "status")
p = rep(p, S_OLD, S_NEW, "supp", n=2)
p = rep(p, "\n**Current execution boundary:**",
    "\n**Edition 0.6:** integrates the owner-ratified Method Ranking Measures Proposal v0.5 (26 October 2026): the supplementary-number sentence in sections 0 and 3.1, the new charter section 2.7, and pointer lines in 10.1 and 18 item 8. The protected E_1-E_6 definitions are unchanged; no other ratified text changes.\n\n**Current execution boundary:**", "0-note")
p = rep(p, "This distinction keeps the project radical in **what it is willing to test**, yet disciplined in **what it concludes**.\n\n",
    "This distinction keeps the project radical in **what it is willing to test**, yet disciplined in **what it concludes**.\n\n" + s27, "2.7")
p = rep(p, "It documents issues that a rigorous design will need to address.\n",
    "It documents issues that a rigorous design will need to address. The owner-ratified method ranking measures (league tables) are specified in R3 section 17; the charter principles behind them are in 2.7.\n", "10.1")
p = rep(p, "8. **Evaluation metrics:** Which performance measures become primary, secondary, and exploratory?\n",
    "8. **Evaluation metrics:** Which performance measures become primary, secondary, and exploratory? (Method ranking measures for league-table reports: R3 section 17, owner-ratified 26 October 2026.)\n", "18.8")
open(sys.argv[2], "w", encoding="utf-8", newline="\n").write(p)
print("ok", len(p.split("\n")), "lines")
