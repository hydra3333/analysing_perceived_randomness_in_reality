"""Generic mechanical check of a new edition against its ratified base.
Usage: python -I check_doc.py BASE NEW 'name|start_regex|end_regex' ...
Checks: LF only, UTF-8, single final newline, protected blocks byte-identical, list of changed
base lines, new/changed lines ASCII (unless verbatim from base), every base ID still present."""
import re, sys, hashlib, difflib
b = open(sys.argv[1], encoding="utf-8").read()
raw = open(sys.argv[2], "rb").read(); d = raw.decode("utf-8")
ok = True
def say(flag, msg):
    global ok; ok &= flag; print(("PASS " if flag else "FAIL ") + msg)
say(b"\r" not in raw, "LF only"); say(raw.endswith(b"\n") and not raw.endswith(b"\n\n"), "single final newline")
for spec in sys.argv[3:]:
    name, sp, ep = spec.split("@@")
    def blk(t):
        m = re.search(sp, t, re.M); n = re.search(ep, t[m.end():], re.M)
        return t[m.start(): m.end() + n.start()]
    x, y = blk(b), blk(d)
    say(x == y, f"protected {name} byte-identical ({len(x)} chars, sha256 {hashlib.sha256(x.encode()).hexdigest()[:16]})")
bl, dl = b.split("\n"), d.split("\n")
ops = difflib.SequenceMatcher(None, bl, dl, autojunk=False).get_opcodes()
removed = [bl[i] for o, i1, i2, j1, j2 in ops if o in ("replace", "delete") for i in range(i1, i2)]
added = [dl[j] for o, i1, i2, j1, j2 in ops if o in ("replace", "insert") for j in range(j1, j2)]
print(f"INFO {len(removed)} base line(s) changed/removed; {len(added)} line(s) added/changed")
for r in removed: print("     - " + r[:120])
bset = set(bl)
rem_pool = [r for r in removed]
def inserted_chars(s):
    best = max(rem_pool, key=lambda r: difflib.SequenceMatcher(None, r, s, autojunk=False).ratio(), default="")
    sm = difflib.SequenceMatcher(None, best, s, autojunk=False)
    if sm.ratio() < 0.5: return s
    return "".join(s[j1:j2] for o, i1, i2, j1, j2 in sm.get_opcodes() if o in ("replace", "insert"))
na = [s for s in added if s not in bset and any(ord(c) > 127 for c in inserted_chars(s))]
for s in na: print("     non-ASCII new line: " + s[:120])
say(not na, "all inserted text plain ASCII (character-level, against the edited base line)")
idpat = re.compile(r"\b(?:R3-[TD]\d+|R2-[CD]\d+[A-Z]?|MRD-\d+|MRT-\d+|MRO-\d+|RK-\d+|PO-\d+|ERR-R2-\d+|M-INV-\d+|[ITWAD]-\d+|O-\d+|E_\d+)\b")
missing = sorted(set(idpat.findall(b)) - set(idpat.findall(d)))
say(not missing, f"all {len(set(idpat.findall(b)))} base IDs still present" + (f"; missing {missing}" if missing else ""))
print("OVERALL", "PASS" if ok else "FAIL")
