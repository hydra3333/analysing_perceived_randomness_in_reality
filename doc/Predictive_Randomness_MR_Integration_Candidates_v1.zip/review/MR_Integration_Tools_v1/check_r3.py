"""Mechanical checks for R3 v0.5 against ratified R3 v0.4 and MR proposal v0.5.
Usage: python -I check_r3.py R3_v0_4.md R3_v0_5.md MR_v0_5.md"""
import re, sys, hashlib, difflib

b = open(sys.argv[1], encoding="utf-8").read()
d = open(sys.argv[2], encoding="utf-8").read()
mr = open(sys.argv[3], encoding="utf-8").read()
raw = open(sys.argv[2], "rb").read()
ok = True
def say(flag, msg):
    global ok
    ok &= flag
    print(("PASS " if flag else "FAIL ") + msg)

# 1 encoding / line endings
say(b"\r" not in raw, "no CR bytes (LF only)")
say(raw.endswith(b"\n") and not raw.endswith(b"\n\n"), "single final newline")
raw.decode("utf-8")
say(True, "valid UTF-8")

# 2 protected blocks: R3 0.4, 2.4, 3 (heading to next heading of same or higher level)
def block(text, start_pat, end_pat):
    m = re.search(start_pat, text, re.M); n = re.search(end_pat, text[m.end():], re.M)
    return text[m.start(): m.end() + n.start()]
for name, sp, ep in [("0.4", r"^### 0\.4 ", r"^(---|## |### )"),
                     ("2.4", r"^### 2\.4 ", r"^(## |### )"),
                     ("3",   r"^## 3\. ",   r"^## ")]:
    x, y = block(b, sp, ep), block(d, sp, ep)
    say(x == y, f"protected R3 {name} byte-identical ({len(x)} chars, sha256 {hashlib.sha256(x.encode()).hexdigest()[:16]})")

# 3 every ratified v0.4 line kept, except the listed edited lines
bl, dl = b.split("\n"), d.split("\n")
sm = difflib.SequenceMatcher(None, bl, dl, autojunk=False)
removed = [bl[i] for op, i1, i2, j1, j2 in sm.get_opcodes() if op in ("replace", "delete") for i in range(i1, i2)]
print(f"INFO {len(removed)} v0.4 line(s) changed or removed:")
for r in removed: print("     - " + r[:110])
added = [dl[j] for op, i1, i2, j1, j2 in sm.get_opcodes() if op in ("replace", "insert") for j in range(j1, j2)]
print(f"INFO {len(added)} line(s) added or changed in v0.5")

# 4 non-ASCII only in lines that already existed (verbatim) in v0.4
bset = set(bl)
nonascii_new = [s for s in added if any(ord(c) > 127 for c in s) and s not in bset]
for s in nonascii_new: print("     non-ASCII new line: " + s[:110])
expected = [s for s in nonascii_new if s.startswith("| R3-D21 |")]  # keeps the ratified curly quotes in column 2
say(len(nonascii_new) == len(expected), f"new/changed lines are ASCII (except R3-D21 row keeping its ratified quotes: {len(expected)})")

# 5 IDs
idpat = re.compile(r"\b(?:R3-[TD]\d+|MRD-\d+|MRT-\d+|MRO-\d+|RK-\d+|PO-\d+|MR\d+(?:-T|\.BOTTOM)?|PD\d|OD\d|ERR-R2-\d+|R2-[CD]\d+|M-INV-\d+|[ITWAD]-\d+|E_\d+|N1)\b")
for label, src in [("R3 v0.4", b), ("MR v0.5 (carried in R3)", mr)]:
    ids = set(idpat.findall(src)); missing = sorted(i for i in ids if i not in set(idpat.findall(d)))
    say(not missing, f"all {len(ids)} IDs of {label} present in v0.5" + (f"; missing {missing}" if missing else ""))

# 6 carried MR lines: every MR body line is in v0.5 verbatim, or is a known transformed/relocated line
dset = set(dl)
mrl = mr.split("\n")
absent = [(i + 1, s) for i, s in enumerate(mrl) if s.strip() and s.strip() != "---" and s not in dset]
print(f"INFO {len(absent)} MR v0.5 non-blank lines not verbatim in R3 v0.5 (headings renumbered, cross-references, relocated or history):")
for n, s in absent: print(f"     MR{n:>5}: {s[:105]}")
print("OVERALL", "PASS" if ok else "FAIL")
