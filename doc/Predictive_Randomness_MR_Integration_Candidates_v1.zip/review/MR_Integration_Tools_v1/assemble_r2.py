"""Assemble R2 v0.5 from ratified R2 v0.4 and MR proposal v0.5 (sections 3.2, 7.1-7.4, 8, 13 fields).
Every replacement must match exactly once. New text is plain ASCII.
Usage: python -I assemble_r2.py R2_v0_4.md MR_v0_5.md out.md"""
import sys
sys.path.insert(0, __file__.rsplit("/", 1)[0])
from common_supp import S_OLD, S_NEW

r2 = open(sys.argv[1], encoding="utf-8").read()
mr = open(sys.argv[2], encoding="utf-8").read().split("\n")
def lines(a, b): return [s for s in mr[a - 1:b] if s != "---"]
def rep(text, old, new, label):
    c = text.count(old)
    if c != 1: sys.exit(f"{label}: expected 1 match, found {c}: {old[:80]!r}")
    return text.replace(old, new)
def tr(block, pairs, label):
    t = "\n".join(block)
    for o, n in pairs: t = rep(t, o, n, label)
    return t.strip("\n")

# ---- MR 8 -> R2 2.5
s25 = "### 2.5 Oz Lotto supplementary numbers: evaluator-only scoring use (DECIDED, MRD-03)\n\n" \
      "Owner-ratified on 26 October 2026 in the Method Ranking Measures Proposal v0.5 (proposal section 8).\n\n" + \
      tr(lines(861, 871), [
        ("**Current ratified text:**", "**Earlier ratified text (replaced by this rule on 26 October 2026):**"),
        ("outside this proposal.", "outside this rule."),
      ], "2.5")
# ---- MR 3.2 -> R2 3.6
s36 = "### 3.6 Numbering conventions (DECIDED, MRD-11)\n\n" \
      "Owner-ratified on 26 October 2026 in the Method Ranking Measures Proposal v0.5 (proposal 3.2). They apply project-wide.\n\n" + \
      tr(lines(162, 173), [("N-1 inclusive (3.3).", "N-1 inclusive (R3 section 17.3.3).")], "3.6")
# ---- MR 13 stage-1 fields -> R2 5.6
s56 = "### 5.6 Method-generic contract fields before E_2 (stage 1) (DECIDED; Method Ranking Measures Proposal v0.5 section 13)\n\n" \
      "Owner-ratified on 26 October 2026. These fields belong to the E_2-readiness package, the method-generic contract that must replace the E_1-specific conventions before E_2 (Architecture section 20A), after Package 2 v0.11 is accepted. They are not part of v0.11, and P3 v0.2 is not edited. The owner ratifies the field schema first (R3 section 17.13, stage 1). Declaring a field or capability authorises nothing.\n\n" + \
      tr(lines(959, 982), [], "5.6")
# ---- MR 7.1-7.4 -> R2 8.4
s84 = "### 8.4 In-sample diagnostic mode (IS) (DECIDED; Method Ranking Measures Proposal v0.5 section 7)\n\n" \
      "Owner-ratified on 26 October 2026; proposal 7.1-7.4 are carried here as 8.4.1-8.4.4. The side-by-side display (proposal 7.5) is a reporting rule in R3 section 17.7.5. H(N), E(G) and the window [S, L] are defined in R3 sections 17.3.3 and 17.3.6.\n\n" + \
      tr(lines(791, 817), [
        ("**7.1 Purpose.**", "**8.4.1 Purpose.**"),
        ("**7.2 Procedure**", "**8.4.2 Procedure**"),
        ("against draw N (section 4).", "against draw N (R3 section 17.4)."),
        ("**7.3 Capability** (declared in the method-generic contract, section 13):", "**8.4.3 Capability** (declared in the method-generic contract, section 5.6):"),
        ("**7.4 Firewall and labelling:**", "**8.4.4 Firewall and labelling:**"),
        ("They are shown side by side (7.5).", "They are shown side by side (R3 section 17.7.5)."),
      ], "8.4")

# ---- edits to ratified R2 v0.4
r2 = rep(r2, "**Version:** 0.4 CONSOLIDATED, OWNER-RATIFIED 26 October 2026  \n",
    "**Version:** 0.5 RATIFICATION CANDIDATE (26 October 2026): R2 v0.4 plus the integration of the owner-ratified Method Ranking Measures Proposal v0.5. Predecessor: R2 v0.4 CONSOLIDATED, OWNER-RATIFIED 26 October 2026.  \n", "hdr")
r2 = rep(r2, "**Edition status: OWNER-RATIFIED 26 October 2026 (consolidated v0.4 review baseline).** Supersedes R2 v0.3",
    "**Edition status: RATIFICATION CANDIDATE, awaiting owner ratification; until then R2 v0.4 governs, except that the owner-ratified Method Ranking Measures Proposal v0.5 already governs its own subject.** R2 v0.4 (OWNER-RATIFIED 26 October 2026) superseded R2 v0.3", "status")
r2 = rep(r2, "there is no promotion by consolidation.\n",
    "there is no promotion by consolidation.\n\n"
    "Edition 0.5 integrates the owner-ratified Method Ranking Measures Proposal v0.5 (26 October 2026): I-01, the section 2 data paragraph and 2.1 (Oz Lotto supplementary numbers), new sections 2.5, 3.6, 5.6 and 8.4, and pointer lines in 2.4, 4.2, 6.2, 8.1 and 13.2. The protected method inventory (section 7) and 4.1 are unchanged; no other ratified text changes.\n", "0-note")
r2 = rep(r2, "with 7/47 main, with supplementary numbers excluded from views and scoring.",
    "with 7/47 main, with supplementary numbers excluded from every method view, fit, seed, digest and forecast; the evaluator alone may read a target draw's supplementaries to classify prize divisions (section 2.5).", "I-01")
r2 = rep(r2, S_OLD, S_NEW, "sec2-para")
r2 = rep(r2, "Oz Lotto supplementary labels remain structural checks only.",
    "Oz Lotto supplementary labels remain structural checks only for every method-facing reader and view; their only other use is the evaluator-only division scoring of section 2.5.", "2.1")
r2 = rep(r2, "and never scores or exposes benchmark predictions.\n",
    "and never scores or exposes benchmark predictions. In-sample diagnostic runs (section 8.4) use their own separate namespace, `IN_SAMPLE_DIAGNOSTIC`.\n\n" + s25 + "\n", "2.4+2.5")
r2 = rep(r2, "The builder may not interpret ordinary holdout rows as a default FINAL training exclusion once FINAL is separately authorised.\n",
    "The builder may not interpret ordinary holdout rows as a default FINAL training exclusion once FINAL is separately authorised.\n\n" + s36 + "\n", "3.6")
r2 = rep(r2, "R2 requires **type honesty**, not a single compulsory scoring convention.\n",
    "R2 requires **type honesty**, not a single compulsory scoring convention.\n- Per-channel probability capability (`main_probability_kind`, `powerball_probability_kind`) is declared under section 5.6, field 3, and is never inferred from arbitrary scores. The ranking measures MR6 and MR14 (R3 section 17.6) use it.\n", "4.2")
r2 = rep(r2, "it must never read/score outcome 1577.\n\n\n## 6. Method interface",
    "it must never read/score outcome 1577.\n\n" + s56 + "\n\n## 6. Method interface", "5.6")
r2 = rep(r2, "`resource_profile`, and `reason_for_any_blocker`.\n",
    "`resource_profile`, and `reason_for_any_blocker`. From the stage-1 contract (section 5.6, field 1), each entry also holds the method's name, one-line summary and short explanation, with per-version provenance; every report prints them (MRD-09; R3 section 17.10.3).\n", "6.2")
r2 = rep(r2, "| `BENCHMARK_SYNTHETIC` | Labelled synthetic fixture | Timing-only smoke/throughput measurement | **No scoring** | Only timing and technical diagnostics |\n",
    "| `BENCHMARK_SYNTHETIC` | Labelled synthetic fixture | Timing-only smoke/throughput measurement | **No scoring** | Only timing and technical diagnostics |\n"
    "| `IN_SAMPLE_DIAGNOSTIC` | One full fit on the eligible development draws E(G)..L of the declared window (section 8.4) | Diagnostic: how well a fitted method describes draws it has already seen | **Yes, by design:** the scored draws are part of the fit, so it is never a forecast | IS namespace only; labelled `IN_SAMPLE_DIAGNOSTIC`; never in the R3 ledger or allowlist |\n", "8.1")
r2 = rep(r2, "Exact evaluation and selection rules belong to R3.\n",
    "Exact evaluation and selection rules belong to R3.\n\n" + s84 + "\n", "8.4")
r2 = rep(r2, "without excluding demonstrable faults.\n\n### 13.3",
    "without excluding demonstrable faults.\n\nR3 section 17 (method ranking measures, owner-ratified 26 October 2026) settles part of this list for ranking reports only: the league-table measures, their significance labels and multiplicity rules. Everything else above remains for R3 as stated.\n\n### 13.3", "13.2")

open(sys.argv[3], "w", encoding="utf-8", newline="\n").write(r2)
print("ok", len(r2.split("\n")), "lines")
