"""Account for every non-blank line of MR proposal v0.5: where it is in the new editions.
Classes: VERBATIM (in R3 v0.5 as is), TRANSFORMED (renumbered heading or edited
cross-reference; transformed text found in R3 v0.5), RELOCATED-R2 / RELOCATED-ARCH
(must appear in those drafts; checked when given), HISTORY (not carried by owner
decision: header/changes, section 15, 17.2-17.4, end marker). Anything else = UNACCOUNTED.
Usage: python -I account_mr.py MR.md R3_v0_5.md s17_raw.md s17_x.md [R2_v0_5.md] [ARCH_v0_8.md]"""
import sys, re
mr = open(sys.argv[1], encoding="utf-8").read().split("\n")
r3 = set(open(sys.argv[2], encoding="utf-8").read().split("\n"))
raw = open(sys.argv[3], encoding="utf-8").read().split("\n")
xx = open(sys.argv[4], encoding="utf-8").read().split("\n")
r2 = set(open(sys.argv[5], encoding="utf-8").read().split("\n")) if len(sys.argv) > 5 else None
ar = set(open(sys.argv[6], encoding="utf-8").read().split("\n")) if len(sys.argv) > 6 else None

# same ranges as build_s17.py, giving MR line -> raw line (identical index in xx)
ranges = [(85, 99), (102, 119), (121, 149), (152, 159), None, (175, 307), (309, 400), (402, 491),
          (493, 787), None, (819, 857), None, (875, 889), (891, 925), (927, 937), None, (944, 945),
          (949, 958), None, (986, 1016), (1036, 1052), None, (1058, 1077), None, (1135, 1192)]
inserts = {4: 4, 9: 4, 11: 4, 15: 4, 18: 2, 21: 2, 23: 1}  # placeholder lines added by build_s17
m2raw, r = {}, 0
for k, rg in enumerate(ranges):
    if rg is None:
        r += inserts[k]; continue
    for i in range(rg[0], rg[1] + 1):
        if mr[i - 1] == "---": continue
        m2raw[i] = r; r += 1
HIST = [(1, 84), (1018, 1034), (1078, 1134), (1193, 1194)]
R2 = [(160, 174), (789, 818), (859, 873), (959, 984)]
AR = [(939, 943)]
inr = lambda n, L: any(a <= n <= b for a, b in L)
counts, bad = {}, []
for n, s in enumerate(mr, 1):
    if not s.strip() or s == "---": continue
    if s in r3: c = "VERBATIM"
    elif n in m2raw and xx[m2raw[n]] in r3: c = "TRANSFORMED"
    elif inr(n, HIST): c = "HISTORY"
    elif inr(n, R2): c = "RELOCATED-R2" + ("" if r2 is None else (" ok" if s in r2 else " MISSING"))
    elif inr(n, AR): c = "RELOCATED-ARCH" + ("" if ar is None else (" ok" if s in ar else " MISSING"))
    else: c = "UNACCOUNTED"
    counts[c] = counts.get(c, 0) + 1
    if c in ("UNACCOUNTED",) or c.endswith("MISSING") or (c == "TRANSFORMED" and "-v" in sys.argv):
        bad.append((n, c, s[:100]))
for k, v in sorted(counts.items()): print(f"{k:22} {v}")
for b in bad: print("  ", b)
