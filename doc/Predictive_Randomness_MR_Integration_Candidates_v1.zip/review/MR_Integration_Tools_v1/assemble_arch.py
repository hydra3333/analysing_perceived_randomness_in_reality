"""Assemble Architecture v0.8 from ratified v0.7 and MR proposal v0.5 section 12.
Usage: python -I assemble_arch.py ARCH_v0_7.md MR_v0_5.md out.md"""
import sys
sys.path.insert(0, __file__.rsplit("/", 1)[0])
from common_supp import S_OLD, S_NEW
a = open(sys.argv[1], encoding="utf-8").read()
mr = open(sys.argv[2], encoding="utf-8").read().split("\n")
def rep(text, old, new, label):
    c = text.count(old)
    if c != 1: sys.exit(f"{label}: expected 1 match, found {c}: {old[:80]!r}")
    return text.replace(old, new)

MR941, MR942, MR943 = mr[940], mr[941], mr[942]
assert MR941.startswith("- **WF rankings:**") and MR942.startswith("- **IS runs**") and MR943.startswith("- **Wrapper:**")

s5a4 = ("### 5A.4 `Run_Method_Rankings.bat`: method-ranking report tool launcher (DECIDED; Method Ranking Measures Proposal v0.5 section 12)\n\n"
        "Owner-ratified on 26 October 2026. The tool it launches is described in 12.5.\n\n" + MR943 + "\n")
s125 = ("### 12.5 Method-ranking report tool, in-sample runs and N1 (DECIDED; Method Ranking Measures Proposal v0.5 section 12)\n\n"
        "Owner-ratified on 26 October 2026 (MRD-13). The measures, reports and labels are specified in R3 section 17; ratification authorises no run.\n\n"
        + MR941 + "\n" + MR942 + "\n"
        "- **N1** (R3 section 17.5A) is an evaluator component inside the report tool. It runs no method code, and its replicates are calibration artefacts kept under the synthetic firewall.\n"
        "- The wrapper is in 5A.4. The evaluator rules (outcomes read only for opened targets that have frozen forecasts; supplementaries only under R2 section 2.5) and the dependency rule are in R3 section 17.12.\n")

a = rep(a, "**Version:** 0.7 CONSOLIDATED, OWNER-RATIFIED 26 October 2026  \n",
    "**Version:** 0.8 RATIFICATION CANDIDATE (26 October 2026): Architecture v0.7 plus the integration of the owner-ratified Method Ranking Measures Proposal v0.5. Predecessor: Architecture v0.7 CONSOLIDATED, OWNER-RATIFIED 26 October 2026.  \n", "hdr")
a = rep(a, "**Edition status: OWNER-RATIFIED 26 October 2026 (consolidated v0.4 review baseline).** Supersedes Architecture v0.6.",
    "**Edition status: RATIFICATION CANDIDATE, awaiting owner ratification; until then Architecture v0.7 governs, except that the owner-ratified Method Ranking Measures Proposal v0.5 already governs its own subject.** Architecture v0.7 (OWNER-RATIFIED 26 October 2026) superseded Architecture v0.6.", "status")
a = rep(a, "All three safety enable switches remain False, and an unresolved orphan blocks all games.\n",
    "All three safety enable switches remain False, and an unresolved orphan blocks all games.\n\n"
    "Edition 0.8 integrates the owner-ratified Method Ranking Measures Proposal v0.5 (26 October 2026): the supplementary-number sentences in section 0 and section 1 item 2, new 5A.4 and 12.5, and pointer lines in 0.2, 7.1 and 20A. The protected section 5C is byte-identical to v0.7; no other ratified text changes.\n", "0-note")
a = rep(a, S_OLD, S_NEW, "sec0-para")
a = rep(a, "| Architecture v0.7 consolidated OWNER-RATIFIED | Runtime and protected safety contracts; v0.6 historical |\n",
    "| Architecture v0.7 consolidated OWNER-RATIFIED | Runtime and protected safety contracts; v0.6 historical |\n"
    "| Architecture v0.8 (this edition) | RATIFICATION CANDIDATE: v0.7 plus the method-ranking integration; protected 5C unchanged |\n"
    "| Method Ranking Measures Proposal v0.5 | OWNER-RATIFIED 26 Oct 2026; carried in R3 section 17, R2 and this Architecture (5A.4, 12.5, 20A); the file is kept unchanged as history |\n", "0.2")
a = rep(a, "OZLOTTO from draw 1474 (7/47 MAIN), no earlier formats or Oz supplemental science; see R2 \u00a72.",
    "OZLOTTO from draw 1474 (7/47 MAIN), no earlier formats; Oz supplementaries are never method inputs and are read only by the evaluator for prize-division scoring (R2 section 2.5); see R2 \u00a72.", "1.2")
a = rep(a, "## 5A. Three operator-maintained Windows batch utilities\n", "## 5A. Operator-maintained Windows batch utilities\n", "5A-title")
a = rep(a, "- Batch CRLF, return codes, output pipes and process-tree termination must be tested on the user's actual Windows/venv installation.\n",
    "- Batch CRLF, return codes, output pipes and process-tree termination must be tested on the user's actual Windows/venv installation.\n\n" + s5a4, "5A.4")
a = rep(a, "--mode final | historical | benchmark-real | benchmark-synthetic | synthetic\n",
    "--mode final | historical | benchmark-real | benchmark-synthetic | synthetic | in-sample-diagnostic\n", "7.1")
a = rep(a, "requires a separately declared, pre-target, method/ensemble version and governance decision.\n",
    "requires a separately declared, pre-target, method/ensemble version and governance decision.\n\n" + s125, "12.5")
a = rep(a, "No run authorisation follows from this statement.\n",
    "No run authorisation follows from this statement.\n\n"
    "**Stage-1 contract fields (DECIDED; Method Ranking Measures Proposal v0.5):** the method-generic contract carries the stage-1 fields and the acceptance list before E_2 in R2 section 5.6; the owner ratifies the field schema first (R3 section 17.13). They are not part of Package 2 v0.11, and P3 v0.2 is not edited.\n", "20A")
open(sys.argv[3], "w", encoding="utf-8", newline="\n").write(a)
print("ok", len(a.split("\n")), "lines")
