# E_1 first real historical development run - procedure v0.1 (REVIEW ONLY)

**Status:** NOT AUTHORIZED. For Claude's independent review and subsequent explicit project-owner go-ahead. This is **not** a permission to use real data now, unseal holdout, create FINAL forecasts, or enable termination.

## Exact identities and boundaries

| Property | Required value |
|---|---|
| Accepted synthetic-run Git baseline | `5c94ccf3e84cbf696bfdb3c512985dfc6665477e` (operator-reported clean; verified public commit) |
| Baseline E_001 source SHA-256 (review-package copy) | `3a5e1585e6b6da0bd363c4a10d759ae35100bc73134eb33d1b12d05eff476959` |
| **First historical target** | `1577` (one target only) |
| Strict permitted training view | unordered U columns; draws **1144 through 1576 inclusive** (433 draws) |
| Source | `source_data/australian_powerball_history_20261021.csv` (the approved unordered, not drawn-order, source) |
| Owner-reported source SHA-256 | `6dc91efe2f5d3993c9c7247d979a16ad2a5082a4eaa364fad3d6ef9f31ebb1d7` |
| Source hash role | source/audit provenance only, **never** an input to training view, seed or forecast |
| Method and variant | `E_1` / `FULL_HISTORY_RAW_COUNTS_V1` |
| Tie contract | ratified `TIE_SHA256_V1` 4-byte unsigned little-endian lengths + UTF-8 |
| Mode | `REAL_HISTORICAL_DEVELOPMENT`; standalone via existing `Run_Experiment.bat` only |
| Local result directory | `transitory_data/p3_standalone_runs/e1-<generated-run-id-suffix>/` (git-ignored) |
| Non-authorised | 1578-1587 holdout, weekly FINAL publication, coordinator scheduling/termination, Ctrl+C/timeout/destructive tests, 1145..1577 full batch |

**Pre-authorisation:** Claude must accept (a) the attached actual Windows synthetic evidence, (b) source/scope, and (c) the exact one-line gate patch. The owner must then **separately and explicitly authorise** this first real run and the corresponding one-line enable change. The previously ratified D3 permits parallel standalone historical development in principle but does not waive this per-run gate.

## Operator preparation - do not execute until all authorisations exist

1. Confirm Windows root and `git status --short` clean. Record new HEAD after the separately approved gate commit. Source baseline must be the reviewed `5c94ccf3...` or a later **identified, reviewed** descendant; never silently apply to unrelated changes.
2. Confirm exact `src/methods/E_001_Historical_Appearance_Frequency.py` content and disabled baseline gate (`ENABLE_REAL_HISTORICAL_DEVELOPMENT = False`). The supplied patch changes this one line to `True` and nothing else. Expected SHA-256 of enabled file if ONLY this exact review-copy changes: `9ce866e44c7e8e13a3c245a7fa800d1c2a8d6c6b7ca311e4c9f8ec0fbe309a45`. A different baseline requires review before using the expected enabled hash.
3. Before enabling or running, verify source snapshot exists and its `certutil -hashfile source_data\australian_powerball_history_20261021.csv SHA256` is exactly `6dc91efe...ebb1d7`. Abort on any mismatch. Do not print/analyse holdout outcomes. The loader itself reads only the permitted prefix, not the whole-source hash.
4. Confirm no marker entry exists at `transitory_data\poc_runs\UNRESOLVED_ORPHAN.json` (including any directory or symlink). If any entry is present or uncertain, **SAFETY STOP**. Do not remove it as a shortcut.
5. **After the owner authorises it**, apply the separately reviewed one-line change, inspect `git diff --check` and `git diff` for exactly that change, commit it as its own commit and push. Record the commit SHA and ensure clean tree. Do not change `Run_Experiment.bat`, wrapper controls, coordinator, venv or termination switch. Never activate via environment-variable or command-line override.
6. The existing synthetic unittest `test_real_mode_is_code_blocked_before_any_source_read` is written for gate=False; a gate=True commit makes its prior refusal assertion invalid. Do not assert a full 12/12 PASS against that unchanged test after enabling. Claude should decide the correct post-gate test-policy update separately (no clandestine extra code edit in the one-line activation commit).

## First authorised execution (ONLY AFTER written owner authorisation)

From ordinary Windows CMD, repository root:

```bat
.venv\Scripts\python.exe -c "import os,sys; p=r'transitory_data\poc_runs\UNRESOLVED_ORPHAN.json'; blocked=os.path.lexists(p); print('SAFETY STOP: ORPHAN MARKER EXISTS' if blocked else 'NO ORPHAN MARKER'); sys.exit(2 if blocked else 0)"
echo MARKER_CHECK_RC=%ERRORLEVEL%
certutil -hashfile source_data\australian_powerball_history_20261021.csv SHA256
findstr /C:"ENABLE_REAL_HISTORICAL_DEVELOPMENT = True" src\methods\E_001_Historical_Appearance_Frequency.py
```

Stop unless the marker is absent, source hash matches the full SHA specified above, and reviewed gate commit is verified. Then:

```bat
Run_Experiment.bat E_001_Historical_Appearance_Frequency.py --mode historical-development --target 1577 --source ..\..\source_data\australian_powerball_history_20261021.csv
echo RC=%ERRORLEVEL%
```

Expected if successful: `RC=0`, a new `e1-...` run ID, status `ENGINEERING_POC_STATUS_V1` with real PID, process creation time, actual `sys_prefix`, terminal elapsed/CPU/labelled peak memory, and `SUCCESS`; manifest `PASS`, both hashes bound, `orphan_suspected=false`, `marker_write_failed=false`, `external_exit_code_verified=false` (self-reported standalone). Report/output is a **historical development forecast for 1577**, not a FINAL forecast. The target draw 1577 is never included in its training prefix. No post-hoc comparison/scoring is included in this first run; develop walk-forward/scorer separately.

After execution: re-check marker; save exact run ID, full console transcript, `status.json`, `standalone_manifest.json`, canonical-result hash, source SHA-256, new commit SHA, RC. Verify consumer refuses FAIL/orphan and mismatched hashes **before opening results**. No additional real targets until reviewed evidence and separate next-step authorisation.

## Reviewer-specific questions

1. Does the accepted standalone self-report exception apply to this one target, with independently observed operator `RC=0`, pending future coordinator `exit_receipt.json`?
2. Is single-target 1577 and U-view 1144..1576 the proper first real-development scope and still holdout-sealed?
3. Is one-line gate diff sufficient on current identified Git baseline? Is additional supervised Windows preparation required before the owner go-ahead?
4. How should the disabled-real test be treated once the gate becomes True while preserving the separately reviewed one-line activation commitment?
