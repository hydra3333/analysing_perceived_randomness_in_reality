# Consolidated documentation full-review instructions — NOT RATIFIED

This package consolidates the Proposal, R2 (including ERR-R2-01–06), R3, Architecture and P3 task plan into self-contained numbered sections and preserves R1 and the TIE note unchanged. Superseded provisions are described solely as history in final appendices. The existing ratified files have not been modified.

**Review gate:** this is a newly rewritten candidate requiring Claude to read each document fully, verify every requirement source mapping and any remaining stale prose. Check `review_evidence/POTENTIALLY_SUPERSEDED_PHRASES.json`: occurrences inside historical prose or appendices may be appropriate, but any current contradictory requirement is a BLOCKER for ratification.

**Source hierarchy:** current owner decisions Oct 25; earlier ratified Proposal v0.4, R2 v0.3 + erratum v0.3 (ERR-R2-01..05; ERR-R2-02 remains provisional), R3 v0.3, Architecture v0.6, P3 v0.1, R1 v0.4, TIE note v0.2. Newly proposed ERR-R2-06 merged for consideration but not yet ratified. No new design approval implied. `REQUIREMENT_DISPOSITION_MATRIX.csv` maps all document headings and ERR-R2 IDs; reviewer must check row content and semantic dependencies in addition to hashes.

**Protected blocks:** `VERBATIM_BLOCK_SHA256.json` lists old/new hashes of safety and method-math blocks. A passing hash is necessary but does not prove requirements around them retained meaning.

**Important:** the P3 task specification is a clean rewrite because its old scraping and Oz first-seal plan became obsolete after the owner-run master INIT. Inspect its mapping carefully. The register is a review-only candidate and must be populated with exact final installed-file hashes after owner ratification.

**NO RUN AUTHORITY:** no Windows runs, scraping, results-master update, holdout/Mode H, FINAL, scientific coordinated run, process termination or safety-switch changes.

**Claude's requested outcome:** BLOCKER / CORRECTION / OPTIONAL with precise replacement text and evidence, checking both full source-to-target map and current scientific/process-safety semantics. The old v0.3 ratification packet must not be installed if a new consolidated edition is chosen.
