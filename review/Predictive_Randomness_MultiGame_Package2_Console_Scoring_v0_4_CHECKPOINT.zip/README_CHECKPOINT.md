# Multi-Game Package 2 -- Console + Scoring Checkpoint v0.4

**STATUS: INTERMEDIATE ENGINEERING CHECKPOINT ONLY. DO NOT INSTALL AS A COMPLETE PACKAGE 2 RELEASE.**

This is a **delta** relative to the owner's two retained checkpoints:
1. `Predictive_Randomness_MultiGame_Package2_Foundation_v0_1_CHECKPOINT.zip`
2. `Predictive_Randomness_MultiGame_Package2_Source_Provenance_v0_3_CHECKPOINT.zip`

Authoritative ratified documentation base: commit `057fd8c618c00d162324149e949fc71ab72ca3ce`.
Owner has NOT authorised live Oz collection/holdout access, Oz science, FINAL,
process termination or P2 coordinator changes. The code remains OFFLINE only.

## Delta files

* `multigame_console_protocol_v1.py`: four BEGIN/RESULT/DIGEST/FINISH records,
  identity/digest/byte checks; stringent ordering/uniqueness; explicit FAILED
  parsing. Does not change P2 coordinator, which still cannot run E methods.
* `multigame_synthetic_scorer_v1.py`: barrel-aware synthetic-only evaluator.
  Calls the existing `verify_synthetic_and_consume()` (orphan, status, manifest,
  hash firewall) BEFORE invoking a caller-supplied synthetic outcome callback.
  Computes TOP/WORST overlaps and means of **native-score tie mid-ranks**;
  no invented Oz Powerball barrel, no pooling.
* `test_multigame_console_and_synthetic_scorer_v0_4.py`: seven offline tests.
* `test_multigame_powerball_1577_regression_v0_4.py`: one authoritative
  1577 forecast regression. It invokes the existing strict prefix-only reader,
  reading **draws 1144..1576 only** and verifying the frozen result hash and
  the new pure tie ranking. Does NOT read 1577, 1578..1587 or later rows.
  It intentionally does NOT relabel actual data as a synthetic fixture.

## Linux rehearsal (not a Windows acceptance claim)

`python -m unittest discover -s tests -p 'test_multigame_*.py' -v`: **50 / 50 PASS**.
`python -m unittest discover -s tests -p 'test_p3_e1_standalone_v0_1.py' -v`: **13 / 13 PASS**.

The 1577 frozen checks match:
- training digest `d47fbbd6e60e6abc429fb74f47d8bbeafc6560152c2ecddb3b75d79932df4339`
- canonical forecast digest `7f1130872b3afaa222ff4e8c2396cd2c2872583544dfa6b31cc5a07cd067164e`
- TOP MAIN `[9,17,7,11,18,30,12]`, PB `2`;
  WORST MAIN `[31,13,8,29,26,33,35]`, PB `12`.

## Outstanding before consolidated Claude code review / Windows acceptance

1. **Coordinator-owned exit receipt is NOT implemented.** The method cannot
   self-certify exit or process ancestry, and merely validating an untrusted
   receipt file would be insufficient. Requires design and independent review.
2. The method-generic console protocol is an **offline producer/validator**;
   not wired into the coordinator, worker scheduler, E_001 or executable.
   Must test real coordinator parsing/failure cases without relaxing any
   process-safety, unresolved-orphan or failed-group-result firewall gates.
3. Synthetic-only scorer is not an evaluation runner, FINAL scorer or
   walk-forward. No future outcome retrieval permitted. The Powerball
   walk-forward window remains owner-unratified.
4. Actual Lotterywest network acquisition and Run_Scraper.bat remain disabled;
   first real Oz scrape requires separate Package 3 approval.
5. Comprehensive diff/ownership comparison against newest Git HEAD,
   Claude independent code review and owner Windows tests still required.

This delta does not modify any ratified E_1 runner, P2 coordinator, source CSV,
network scraper or process termination switch.
