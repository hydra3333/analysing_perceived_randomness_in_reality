# DOC-2 - register v0.7 (E2R-1 ratification and the 28 October decisions) - handback for review

| Field | Value |
|---|---|
| Item | DOC-2: register v0.7, recording the E2R-1 specification's ratification, owner decisions D-1..D-11, process decisions, and the DOC-1 and snapshot commits |
| Author / reviewer | Claude / ChatGPT reviewer chat |
| Base commit | `38fc60e` (GitHub `main`) |
| Input | register v0.6 Git blob `5e677dce3f2ae01cd7a3f6cc1ff408c8e32e268150fe0c956e42bf703a9b074c` |
| Scope | One register edition. No code and no other document. The E2R-1 specification is installed unchanged (`0a73c92d...a954`) with it later. |
| Risk tier | HIGH (the register) |
| Owner gate | The owner ratifies register v0.7 and confirms the E2R-1 ratification date; then installs both in one commit |
| Evidence state | IMPLEMENTED (draft); mechanically checked; not yet REVIEWED |

**Date:** 28 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears in or was used for this file.

| File | SHA-256 |
|---|---|
| `RATIFICATION_REGISTER_v0_7.md` (UTF-8, LF, as its lineage) | `92e73afba1f7cdb55f38959df67c01d5312f4bc4d50ab3fce6ab1b26f89ce4b1` |
| `evidence/register_v0_6_to_v0_7.diff` | `7e00bc93cd64273ec37d91ce82abac6967d056858bbd93758e20b789ba57cd10` |
| `tools/make_register_v07.py` (5 counted replacements; refuses any other input) | `b6d12df96d79cdc4c2ee832cbd020585ed01bfd6083f6224d79166787f0e9457` |

## What changes

- **Four existing lines change:**
  - the version line, set to RATIFICATION CANDIDATE;
  - the basis line, which gains the v0.7 cross-check against `38fc60e`;
  - the v0.6 "Oversight instruction status" paragraph, now labelled as superseded;
  - the register v0.5 row, which now reads "superseded by register v0.6" rather than "by this register".
- **One new section, "E2R-1 specification and owner decisions of 28 October 2026"**, recording:
  - the DOC-1 install at `be18548`;
  - the E2R-1 ratification, with its full review history;
  - D-1..D-11;
  - the process decisions: oversight extended to six reviews with reporting by exception; one review for handovers; the Git-history plan;
  - the snapshot commits `319fd11` and `38fc60e`;
  - four out-of-date statements (Architecture "one standalone .py per method"; R2 5.6 and R3 17.13 "ratify first"; three H-1 v1r2 items; the v0.6 oversight paragraph).
- Everything else is byte-identical. The 28 non-ASCII characters of v0.6 are unchanged.

## Mechanical checks

- Every 64-character hash in a new line matches a file at `38fc60e`. The one exception is the specification itself (`0a73c92d...`), which is installed with this register.
- Every commit ID cited resolves.
- Placeholders finalised after review and ratification:
  - `[E2R-DATE]`: the owner's E2R-1 ratification date;
  - "RATIFICATION CANDIDATE": changed to OWNER-RATIFIED with the date.

## Please check

- **Whether the process decisions are recorded at the right level.** In particular: the oversight extension to six reviews; your RD-13/17/21 counting of the E2R rechecks as review 4; and reporting by exception.
- **Whether the out-of-date list is complete.** In particular, whether anything in R2 6.2 (registry fields) needs a line now that registry status lives in `REGISTRY_ENTRY_V1` under E2R-1. Claude's view: no, because E2R-1 implements R2 6.2 rather than contradicting it.
- **The E2R-1 paragraph's statement of what ratification does and does not authorise.**

*End of handback.*
