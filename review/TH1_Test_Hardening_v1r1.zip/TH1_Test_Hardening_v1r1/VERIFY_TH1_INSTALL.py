#!/usr/bin/env python3
"""Read-only installation verifier for TH-1 r1 (offline test hardening P2-R1-O1, P2-R1-O3, link-test portability).

Claude, 27 October 2026. Standard library only; does not import project code, run tests, change
files or touch Git state (every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0).
Phases:
  pre        clean tree; HEAD descends from the base commit; the two modified files still have
             their base bytes; the three new paths are absent; guarded files unchanged.
  post       after copying the overlay: exactly the 5 expected paths changed, all with the
             expected bytes (CRLF tolerated in the working copy; Git stores LF).
  committed  after the commit: clean tree; the last commit changed exactly those 4 paths
             (3 added, 2 modified), all with the expected Git blobs.
Usage: python VERIFY_TH1_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

BASE = '997ed46081695c0be68fd5b5db2efa95ce838a8b'
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')
NEW = {
    'tests/test_p2_r1_t05_hardening_v1.py': '7e68542d5f464c910f7c94eccd9aae57089170846fb7224a4727814b88b25278',
    'tests/fixtures/coordinator_v0_6_baseline/Powerball_Experiment_Coordinator_v0_6.py.txt': '2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b',
    'review/Claude_Verification_Transition_Commit_d36735d_v1.md': 'c76b3bb305fca61bec0b791e6d792bc5b33f46529df0222498cbc5669a9343a0',
}
MODIFIED = {  # path: (base blob SHA-256, new SHA-256)
    'tests/test_multigame_v011_static_and_timing.py': (
        '578f6206cfc72347871da7d48eb310d48b4d6bbd45d477fb1b9f016b15811bd4',
        '8e606e965f748cb7b48f3ba8f76b29dfecf71552f59c4b3292cc76f42ab43696'),
    'tests/test_multigame_v011_reader_contracts.py': (
        'd3d3b516a3f9140ef597015e6e3e3df6eb332a1f8610661a9d7a08bb2ae5b8a4',
        'a0460c49ac5d193871dd35f02ba532271e9c943185b8a9b759f0ee5b4a0da2dc'),
}
GUARDED = {  # must stay byte-identical in Git
    'src/Powerball_Experiment_Coordinator.py': 'bc8380b5f20a704c0f47d5f76eeb86156237142b5639e5b9770b8314db3bb822',
    'src/methods/_common/game_draws_reader_v1.py': 'e06e0cca7edc298aadf5298ae860d6093467f6460fcbf9839928b1e4fdb342b5',
    'doc/RATIFICATION_REGISTER_v0_5.md': '551c1b42e99b58ad313dabe7d533e5650db83edce58e04f954b2f616c77afb3f',
}
HERE = Path(__file__).resolve().parent


def sha(b):
    return hashlib.sha256(b).hexdigest()


def git(repo, *args):
    r = subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    a = ap.parse_args()
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    expected = dict(NEW, **{p: v[1] for p, v in MODIFIED.items()})
    for p, h in expected.items():  # the package itself must be intact
        need(sha((HERE / 'repo_overlay' / p).read_bytes()) == h, f'package file damaged: {p}')
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = subprocess.run(['git', '--no-optional-locks', '-C', str(repo), 'merge-base', '--is-ancestor', BASE, 'HEAD'],
                         env=GIT_ENV)
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    for p, h in GUARDED.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'guarded file changed in Git: {p}')
    print(f'{len(GUARDED)} guarded files unchanged in Git HEAD')
    status = git(repo, 'status', '--porcelain', '--untracked-files=all').decode(errors='replace')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        for p, (old, _) in MODIFIED.items():
            need(sha(git(repo, 'show', f'HEAD:{p}')) == old, f'file to be replaced is not at its base bytes: {p}')
        for p in NEW:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP')
        print('PRE PASS: clean tree; 2 files at their base bytes; 3 new paths absent. Nothing was changed.')
        return

    if a.phase == 'post':
        changed = {line[3:].strip().strip('"').replace('\\', '/') for line in status.splitlines()}
        need(changed == set(expected), 'unexpected changed paths: ' + ', '.join(sorted(changed ^ set(expected))))
        for p, h in expected.items():
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(f.read_bytes().replace(b'\r\n', b'\n')) == h, f'wrong bytes: {p}')
        print('POST PASS: exactly the 5 expected paths changed, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    for p, h in expected.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    names = git(repo, 'diff', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    want = dict({p: 'A' for p in NEW}, **{p: 'M' for p in MODIFIED})
    need(got == want, 'the last commit did not change exactly the expected paths: ' + repr(sorted(got.items())))
    print('COMMITTED PASS: the last commit added 3 files and modified 2; all 5 Git blobs match.')


if __name__ == '__main__':
    try:
        main()
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        sys.exit(2)
