# E2R-1 - E_2-readiness specification v0.3r1 - handback for focused recheck

**Work-item card**

| Field | Value |
|---|---|
| Item | E2R-1: the stage-1 contract-field schema and acceptance list before E_2 |
| Author chat | Claude (primary designer and coder) |
| Reviewer chat | ChatGPT reviewer chat (H-2 v1r3) |
| Base commit | `be185485693f29cf9ab28292dc6eebad00bbc32c` |
| Inputs | v0.2 `4254128d20a3f9fa3a7d65658bcca99e8f72045145b1514d570b3c4f21ebc4a4`; review `E2R_R3_Review_Commit_Independent.md` `17087f5715bc3cfe49a2120fd25d1cdb626c6d9c480d53b5f3bb73559e93b2b2` |
| Scope | One specification document. No code, no change to any ratified document. |
| Risk tier | HIGH. The review assigned RECHECK to B01-B03, C01-C04, ADD-C06..C10 |
| Owner gate | The owner ratifies after the recheck. OPEN-4 is already decided (D-8) |
| Evidence state | IMPLEMENTED (draft); mechanically checked; not yet REVIEWED |

**Date:** 28 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears in or was used for this document.

## Contents

| File | SHA-256 |
|---|---|
| `Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r1.md` (ASCII, LF) | `7211f4c9d6f8e51a83629e68d03c9fe2d7593acca11a1b904ec75123dde5dbd0` |
| `evidence/spec_v0_2_to_v0_3r1.diff` (exact diff from v0.2) | `04b45be7850ec66d91059119120dd88bcad863f05d2d9108885d5a132782b782` |

v0.3r1 is v0.3 (never sent for review) plus the owner's decision D-8 on OPEN-4. v0.3 was written as a full revision rather than by counted replacements, because the blockers changed several tables together. The exact diff above is the complete record of the change. Spec Appendix A maps all 16 findings to their resolutions.

## What changed, in brief

- **B01:**
  - each barrel declares `ranking_kind`: scored, order-only or none;
  - a table of legal TOP/WORST combinations, including set-only and diagnostic-only;
  - `ranked_groups` as one weak order for both scored and order-only rankings, with ranking fields that exist only where a ranking does;
  - a new C2 `METHOD_DIAGNOSTIC_V1` record, kept but never scored or treated as evidence;
  - a non-normative `MethodOutput` sketch (O01).
- **B02:** C1 is pre-target only. In-sample is reserved, with the requirements for its future schema, and the mode table is split into what stage 1 can produce and what is reserved.
- **B03:** the freeze receipt has no scoring field, and scoring status is derived by a join. A new `RUN_TERMINAL_RECORD_V1` covers every run; a failed run never gets a freeze receipt.
- **C01:** `fit_seed_policy_id` is reserved, the formula is deferred with explicit requirements, and no stochastic declaration can be SUPPORTED in stage 1.
- **C02-C05:** adopted as worded, or with small adjustments shown in Appendix A.
- **ADD-C06..C10:** a new section 12A records the owner's source-tree and release decisions D-4..D-7, with:
  - the revision rule for shared helpers, with a two-method example;
  - the method-ID and folder-locator mapping;
  - commit-free, hash-free retirement and its limits;
  - the AND gate and safe release sequence;
  - the three checkpoints;
  - NAMES-1 requirements, recorded here and proved in that package.
- **Tests:** E2R-T13..T16 added, numbered as the reviewer proposed for T13..T15. T16 covers receipts and terminal records.

## Oversight (owner instruction; review 4 of 6)

The review settled eight items as REVIEWER-DECIDED: E2R-RD-01..04 (tier, typed union, RECHECK rule, REC01 non-blocking) and E2R-RD-05..08 (accepting the owner's withdrawal of hashing, the commit-free archives, the AND gate, and NAMES-1 sequencing). Claude found **no departure** from the ratified rules. RD-05..08 confirm owner decisions already relayed, which is within the 23 October latitude.

## Points Claude would like the recheck to look at

- **E2R-R15A** (the channel combination table) and **E2R-R27/R28** (`ranked_groups` and the tie rule for order-only `GROUPED` rankings): are they complete and consistent?
- **E2R-R38:** a refused dispatch gets no terminal record because no run started. Is that the right boundary with Package 2's existing status records?
- **D-2:** applying `NOT_EVIDENCE` to diagnostic records is Claude's recommendation, not an owner decision.
- **D-8** (your REC01): the owner chose both an "as published" prospective view, with the revision per draw, and a separate "current methods" single-revision view (E2R-R40B). Please check that totals over the "as published" view are labelled correctly.

*End of handback.*
