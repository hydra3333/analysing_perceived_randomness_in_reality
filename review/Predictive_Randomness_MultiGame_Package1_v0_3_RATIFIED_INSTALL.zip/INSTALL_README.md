# Multi-Game Package 1 — owner-ratified installation

**Owner approval:** 24 October 2026, following Claude's no-blockers review and six accepted corrections.
**Final clarification:** historical-development/backtesting target ceilings apply ONLY to retrospective development. They do not cap later prospective FINAL prediction, ordinary operation, eligible weekly retraining, or maintenance. Those modes remain subject to separate authorisation, N−1, forecast freezing, and holdout protections.

## Scope

The repository-relative `repo_overlay/doc/` folder contains seven ratified Markdown documents. Extract only that folder's contents to your repository's `doc/` (preserving subdirectories). Do not extract diffs or manifests into the repository. Preserve historical versions.

- Proposal v0.4; R2 erratum record v0.3 (ERR-R2-05); R3 v0.3; Architecture v0.6; new Multi-Game P3 Task Spec v0.1; shared TIE contract note v0.2; first committed ratification register v0.2.
- All file hashes are calculated from UTF-8 LF **content**, as stored in Git. Windows checkout may use CRLF; Git blob hashes can be verified with `git show`.
- The ratification register lists the final hashes of the other six documents. The register's own hash is in `SHA256_MANIFEST.txt`, avoiding a circular self-reference.

## Suggested Windows CMD verification and commit

Before extraction: `git status --short`; `git rev-parse HEAD`. Untracked review or backup files should not be staged.
After extracting only the repository overlay:

```bat
git status --short
git diff --check
git add doc\Predictive_Randomness_Research_Project_Proposal_v0_4.md
git add doc\Predictive_Randomness_R2_v0_3_Erratum_Record_v0_3.md
git add doc\Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_3.md
git add doc\Predictive_Randomness_Software_Architecture_Discussion_v0_6.md
git add doc\Predictive_Randomness_MultiGame_Infrastructure_P3_Task_Specification_v0_1.md
git add doc\contracts\TIE_SHA256_V1_Ratified_Encoding_v0_2.md
git add doc\RATIFICATION_REGISTER_v0_2.md
git diff --cached --check
git diff --cached --stat
```

Inspect the staged paths; if they are ONLY those seven, then:

```bat
git commit -m "Ratify multi-game scope and infrastructure specifications"
git push origin main
git rev-parse HEAD
git status --short
```

**Safety:** ratification and installation authorise NO coding, scraper invocation, structural audit, experiments, holdout opening, FINAL publication, or process termination. Package 2 (code) and Package 3 (first Oz data scrape) remain separate owner-controlled gates. Development remains PAUSED.
