# Predictive Randomness — Package 2 v0.11 REVIEW CANDIDATE

**Prepared:** 2026-10-26, ChatGPT primary coder, for independent Claude review and owner ratification.  
**Base:** owner-verified clean `main` `618fe48c48ada46bcf60c80bbd291acc216d7e3b`.  
**Review precursor:** `review/Predictive_Randomness_MultiGame_Package2_v0_10r1_OWNER_VIEW_DECISIONS_CLAUDE_REVIEW.zip`, SHA-256 `f1db9629f4735f25de357a991a98748abffe0f53ed58efb03e11991b972cf45b`.  
**Authorities:** ratified P3 task v0.2; Proposal v0.5, R2 v0.4, R3 v0.4, Architecture v0.7, Register v0.3; Claude `Claude_Review_Package2_v0_10_r1_and_Direction_v3.md`. MR v0.5 and exposure v0.2 are ratified, pending integration, but **outside v0.11 coding**. All governing documents are unmodified.

**THIS IS NOT AN INSTALLATION, SCIENTIFIC APPROVAL, OR EXECUTION AUTHORISATION.**

## How Claude should review

1. Inspect this ZIP as *data*. Verify its own SHA-256 and `SHA256_MANIFEST.json` file identities, and separately verify the base clean HEAD. Never run the historical GAIS Selenium code or the retired ChatGPT acquisition overlay.
2. Make a **scratch copy** of the verified baseline `618fe48`. Apply `repo_overlay/` to that *scratch* tree only, using the `RETIRED_CANDIDATE_ONLY.txt` inventory to omit obsolete, **previously uninstalled** v0.9/v0.10 candidate sources. Nothing in the working Git checkout needs editing before owner ratification.
3. See `evidence/COORDINATOR_V06_TO_V011_EXACT.diff` and `...AST_AND_RECONSTRUCTION.json`: exact mechanically applied patch and byte equality; 11/11 protected functions AST unchanged. Review nonprotected coordinator edits independently; AST equality alone does **not** prove safety.
4. Review findings in `C1_C6_CLOSURE_AND_REVIEW_REQUEST.md`. Pay particular attention to the `load_pinned_draw_view` master/ledger/INIT chain, the frozen E_1 date-free compatibility, and the fact that a whole-master SHA is **not** an input to N−1 predictor digests.
5. Offline test evidence is **Linux 3.13.5 / NumPy 2.3.5**, not the owner's Windows Python 3.14 environment. Selected 56 offline tests passed. The file `tests/test_multigame_windows_lifecycle_review_v0_9.py` is included solely for eventual review; it was **not executed**. The legacy POC Windows safety/lifecycle/destructive acceptance gates remain **NOT TESTED**.

## Exact package boundaries

- The `repo_overlay/` folder contains only the Package 2 review overlay and one historical `requirements.txt` clarification; not the full repository. No source masters, no quarantined results, no source ledger bytes, no historical private saved pages, no actual run outputs, and no `.venv` are shipped.
- `RETIRED_CANDIDATE_ONLY.txt` is the sorted authoritative review inventory. These **21 entries were not in verified HEAD**, so they are retired from *candidate overlays*, not instructions to delete tracked baseline history.
- `source_data/<GAME>_results_master.csv`, ledgers and INIT records remain exclusively owner-maintained. SHA identities only are in `evidence/BASELINE_MASTER_PROVENANCE_NO_OUTCOMES.json`. No master update, fetch, saved-page parser, scraper or dependency installation occurred.
- `src/methods/E_001_Historical_Appearance_Frequency.py`, `_common/e1_training_view_v0_1.py`, accepted owner tools and Windows wrappers are **unchanged** from committed `618fe48`. The E_1 1577 result is a **forecast-only regression** on draws 1144–1576; **not** 1577 evaluation or Mode H access. The existing accepted E_1 standalone is grandfathered for its legacy source/path references. New method implementations must not import the common master loader.
- The uninstalled review-only synthetic contracts remain synthetic; `_COORDINATED_SCIENCE_ALLOWLIST` is empty. No E_2 contract/readiness fields, scientific ranking code, Mode H, FINAL, prospective scoring or IS engine have been added.
- `Run_Scraper.bat` is NOT part of this candidate. The one authorised results/master tooling route is the already-committed owner-maintained `Run_Results_Updater.bat`, `src/results_master_v0_1.py` and `src/two_site_results_check_v0_7.py`; none was invoked.
- Windows timeouts in `terminate_owned_tree` (`3.0` and `3`) were deliberately retained verbatim to preserve the AST-protected safety contract.

## Permitted offline review commands (on a separate scratch tree only)

Using an existing environment with `numpy` and `psutil`; **do not run the dependency installer to prepare for review**:

```text
python -m unittest -v tests.test_multigame_v011_reader_contracts tests.test_multigame_v011_static_and_timing tests.test_multigame_launch_and_manifest_v0_8 tests.test_multigame_exit_receipt_v0_8 tests.test_multigame_science_allowlist_v0_8 tests.test_multigame_console_and_synthetic_scorer_v0_4
```

Set the scratch `src`, `src/methods`, and `tests` folders on the Python module search path as appropriate. The above suite is offline. **Not included:** real scientific experiment execution, master update, Windows P1/P2 tests, Windows lifecycle or destructive tests, holdout, Mode H, FINAL, dependencies installer. Those require new owner authorisation after independent review. The global orphan-marker state is ephemeral; the owner's `False` report on 26 Oct is **not** permission to launch.

## Review outcomes and authority

- `DECIDED`: Scope exactly C1–C6 / P3 v0.2. Three switches remain false and scientific allowlist empty. Process-safety policies remain unchanged. MR integration is handled by a separate ChatGPT discussion, not this package.
- `RECOMMENDED`: Independent Claude source/test review of N−1 ownership and master pinning, fingerprint/repro checks on Windows only when separately authorised, and careful inspection of any `WINDOWS_NOT_EXECUTED` evidence.
- `OPEN / not claimed`: Windows runtime acceptance, dependency drift requalification, full future Mode H rules, walk-forward target preregistration, retired v0.10 API acceptance (explicitly obsolete), and the optional historical source `06f6e0f` cross-check in an actual Git checkout; the v0.11 prebuild golden uses the accepted pinned master already available at HEAD.

The owner, not this ZIP, decides installation, Windows runs and later gates.
