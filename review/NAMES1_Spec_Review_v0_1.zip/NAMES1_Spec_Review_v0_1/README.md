# NAMES-1 - one-off rename specification v0.1 - handback for R-3 design review

| Field | Value |
|---|---|
| Item | NAMES-1: rename existing versioned file names to stable names (E2R-1 v0.3r3, 12A.1, 12A.4, 12A.5; owner decisions D-4, D-7) |
| Author / reviewer | Claude / ChatGPT reviewer chat |
| Base commit | `38fc60e03ea0766f72476cbab7c0e1eb5bd59d07` |
| Scope | One design document plus design evidence. No source change. |
| Risk tier | HIGH (it changes the reader's and the coordinator's import lines: RECHECK) |
| Owner gate | The owner decides OPEN-N1..N3 and ratifies; the code package then needs explicit owner execution authorisation |
| Evidence state | IMPLEMENTED (draft); author-side trial in a disposable copy; not yet REVIEWED |

**Date:** 28 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears here. The trial ran only the accepted offline suite, in a disposable copy.

| File | SHA-256 |
|---|---|
| `Predictive_Randomness_NAMES1_Rename_Specification_v0_1.md` (ASCII, LF) | `88379b2800f0b660242ece361178eff7c0a2ebc70c68a83916cb187d1fa9dce5` |
| `evidence/rename_map.py` (the 27-file map) | `8a361e93691a2afe0ca2dbd670bcc327d4d624c4fe846933da7d83115a6793ae` |
| `evidence/apply_trial.py` (applies the map to a disposable tree) | `82aecd26b05d295113e0348f58d788bda9efcb8eedf6bbdcb4fd0dd3140eb790` |
| `evidence/inventory.py` and `evidence/inventory_38fc60e.txt` (import graph, string references, .bat references) | `691d4ce2...cf01`, `539ade81...cceb` |
| `evidence/substitution_sites.txt` (every changed line, per file) | `24cd8f62397a481d3226e599d1970c5ff9e936d8d8a42487ddeba9d4005d8982` |
| `evidence/baseline_suite_output.txt`, `evidence/trial_suite_output.txt` (79 tests each: the 60-test suite plus the two other current test modules) | `f26702b5...0a3f`, `ef2b330e...549e` |

## Where Claude would look hardest

- **N1-R05** (no per-method folders and no move of E_1 in NAMES-1). It refines D-4 because of the Option F wrapper's bare-file-name rule and the shared reader's import from E_1's module. Is the proposed reading of D-4 sound?
- **Substitutions inside negative checks** (section 6). They become broader, never narrower. Please confirm.
- **N1-T03** (AST equality with names and string constants substituted). Is it a sufficient complement to the substitution-equality proof (N1-T02)?
- **The out-of-scope list (OPEN-N2).** Is anything missing?

The author-side trial is design evidence, not the package. The package will be built from the ratified map, with explicit `git mv` commands, an overlay, a verifier, and the N1-T01..T10 evidence.

*End of handback.*
