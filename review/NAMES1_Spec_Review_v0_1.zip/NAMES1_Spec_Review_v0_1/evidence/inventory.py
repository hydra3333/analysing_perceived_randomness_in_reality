"""NAMES-1 inventory (read-only). Usage: python3 -I inventory.py REPO_TREE"""
import ast, re, sys
from pathlib import Path
root = Path(sys.argv[1])
py = sorted(p for p in root.rglob('*.py') if not any(x in p.parts for x in ('.git',)))
mods = {}
for p in py:
    rel = p.relative_to(root).as_posix()
    mods[rel] = p
print('== imports (module -> imported names) ==')
for rel, p in mods.items():
    try:
        tree = ast.parse(p.read_text(encoding='utf-8', errors='replace'))
    except SyntaxError as e:
        print(rel, 'SYNTAX', e); continue
    imps = set()
    for n in ast.walk(tree):
        if isinstance(n, ast.Import):
            imps |= {a.name for a in n.names}
        elif isinstance(n, ast.ImportFrom) and n.module:
            imps.add(('.' * n.level) + n.module)
    local = sorted(i for i in imps if re.search(r'(_common|coordinator_private|_v\d|e1_|multigame|game_|experiment_|project_paths|runtime_env|Powerball_Experiment|two_site|results_master|E_001|POC_)', i))
    if local:
        print(rel, '->', ', '.join(local))
print('\n== string references to versioned names / paths ==')
pat = re.compile(r"[\"'][^\"'\n]*(?:_v\d+(?:_\d+)?(?:\.py)?|E_001_[A-Za-z_]+|POC_[A-Za-z_]+|_common/|coordinator_private)[^\"'\n]*[\"']")
for rel, p in mods.items():
    txt = p.read_text(encoding='utf-8', errors='replace')
    hits = sorted(set(m.group(0) for m in pat.finditer(txt)))
    hits = [h for h in hits if not re.fullmatch(r"[\"'][A-Z0-9_]+_V\d+[A-Z0-9_]*[\"']", h, re.I) or '.py' in h or '/' in h]
    if hits:
        print(rel, '::', ' | '.join(h[:90] for h in hits[:25]))
print('\n== .bat references ==')
for p in sorted(root.glob('*.bat')):
    txt = p.read_text(encoding='utf-8', errors='replace')
    hits = sorted(set(re.findall(r'[A-Za-z0-9_\\/.-]*\.py', txt)))
    print(p.name, '::', ', '.join(hits))
