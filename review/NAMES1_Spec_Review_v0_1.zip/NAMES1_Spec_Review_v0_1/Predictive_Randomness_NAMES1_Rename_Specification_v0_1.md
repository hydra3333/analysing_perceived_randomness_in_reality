# Predictive Randomness - NAMES-1 one-off rename specification, v0.1

**Document:** the design for NAMES-1, the one-off rename of existing versioned file names to stable names (E2R-1 specification v0.3r3, sections 12A.1, 12A.4 and 12A.5; owner decisions D-4 and D-7, 28 October 2026).
**Version:** v0.1 DRAFT for independent design review (R-3), 28 October 2026 (Adelaide, UTC+10:30).
**Author:** Claude (primary designer and coder). **Independent reviewer:** the ChatGPT reviewer chat. **Ratifier:** the project owner.
**Status:** DRAFT. A design only. It authorises no rename, no source change and no run. The NAMES-1 code package follows only after this design is reviewed and ratified and the owner authorises execution.
**Base:** repository commit `38fc60e03ea0766f72476cbab7c0e1eb5bd59d07`.
**Risk tier:** HIGH. NAMES-1 changes import lines in the reader and the coordinator (always-review subjects), so the package always gets RECHECK.
**Holdout statement:** no draw outcome appears here. Design evidence used only the accepted offline suite in a disposable copy.

**Tags.** **DECIDED** cites an owner decision or ratified text; **RECOMMENDED** is a design choice proposed for ratification; **OPEN** is a decision for the owner, with a recommendation. Requirement IDs are `N1-Rnn`; tests are `N1-Tnn`.

---

## 1. Purpose in plain English

Many current files carry a version in their name: `game_draws_reader_v1.py`, `e1_historical_appearance_frequency_v0_3.py`, `test_multigame_exit_receipt_v0_8.py` and so on. The number is a development draft or interface number, not a method revision. Under the owner's new rule that `src/` holds current code only with stable names (D-4), these names mislead. NAMES-1 renames them once, updates every reference, and changes nothing else, with proof.

## 2. Principles

- **N1-R01 (DECIDED; E2R-R60, D-7).** NAMES-1 changes file names and the references to them, and nothing else. Every edited file equals its predecessor with exactly the listed whole-word name substitutions (section 5). No behaviour, schema, identity, test logic, golden or safety rule changes.
- **N1-R02 (DECIDED; E2R-R60).** The eleven protected coordinator functions stay AST-identical to v0.6. The two coordinator edit sites (three lines) are in `coordinator_main` and at module level, outside the protected functions.
- **N1-R03 (DECIDED; E2R-R14A, E2R-R60).** E_1 keeps revision 1. NAMES-1 records that decision explicitly, on the strength of the substitution-equality proof (section 5), not on unchanged goldens alone. The exception is scoped to NAMES-1.
- **N1-R04 (DECIDED; delivery method, register v0.6).** Delivery is by whole files, with explicit renames. The owner runs a listed `git mv` for each rename, then copies an overlay of the edited contents. The read-only verifier proves that each old path is gone, each new path has the expected bytes, and nothing else changed. There are no hand edits.

## 3. What is renamed (RECOMMENDED scope)

Eighteen runtime modules and nine current test modules: 27 files. Folders do not change.

| Old path | New path |
|---|---|
| `src/methods/_common/e1_common_reader_bridge_v1.py` | `src/methods/_common/e1_common_reader_bridge.py` |
| `src/methods/_common/e1_historical_appearance_frequency_v0_3.py` | `src/methods/_common/e1_historical_appearance_frequency.py` |
| `src/methods/_common/e1_standalone_contract_v0_1.py` | `src/methods/_common/e1_standalone_contract.py` |
| `src/methods/_common/e1_training_view_v0_1.py` | `src/methods/_common/e1_training_view.py` |
| `src/methods/_common/game_draws_reader_v1.py` | `src/methods/_common/game_draws_reader.py` |
| `src/methods/_common/game_profiles_v1.py` | `src/methods/_common/game_profiles.py` |
| `src/methods/_common/multigame_ancestry_release_v1.py` | `src/methods/_common/multigame_ancestry_release.py` |
| `src/methods/_common/multigame_console_protocol_v1.py` | `src/methods/_common/multigame_console_protocol.py` |
| `src/methods/_common/multigame_coordinated_manifest_v1.py` | `src/methods/_common/multigame_coordinated_manifest.py` |
| `src/methods/_common/multigame_e1_v1.py` | `src/methods/_common/multigame_e1.py` |
| `src/methods/_common/multigame_method_registry_v1.py` | `src/methods/_common/multigame_method_registry.py` |
| `src/methods/_common/multigame_result_registry_v1.py` | `src/methods/_common/multigame_result_registry.py` |
| `src/methods/_common/multigame_standalone_contract_v1.py` | `src/methods/_common/multigame_standalone_contract.py` |
| `src/methods/_common/multigame_synthetic_scorer_v1.py` | `src/methods/_common/multigame_synthetic_scorer.py` |
| `src/methods/_common/multigame_worker_launch_handshake_v1.py` | `src/methods/_common/multigame_worker_launch_handshake.py` |
| `src/coordinator_private/multigame_coordinator_exit_receipt_v2.py` | `src/coordinator_private/multigame_coordinator_exit_receipt.py` |
| `src/coordinator_private/multigame_launch_spec_v1.py` | `src/coordinator_private/multigame_launch_spec.py` |
| `src/coordinator_private/multigame_windows_lifecycle_v1.py` | `src/coordinator_private/multigame_windows_lifecycle.py` |
| `tests/test_multigame_console_and_synthetic_scorer_v0_4.py` | `tests/test_multigame_console_and_synthetic_scorer.py` |
| `tests/test_multigame_exit_receipt_v0_8.py` | `tests/test_multigame_exit_receipt.py` |
| `tests/test_multigame_launch_and_manifest_v0_8.py` | `tests/test_multigame_launch_and_manifest.py` |
| `tests/test_multigame_science_allowlist_v0_8.py` | `tests/test_multigame_science_allowlist.py` |
| `tests/test_multigame_v011_reader_contracts.py` | `tests/test_multigame_reader_contracts.py` |
| `tests/test_multigame_v011_static_and_timing.py` | `tests/test_multigame_static_and_timing.py` |
| `tests/test_multigame_windows_lifecycle_review_v0_9.py` | `tests/test_multigame_windows_lifecycle_review.py` |
| `tests/test_p2_r1_t05_hardening_v1.py` | `tests/test_t05_hardening.py` |
| `tests/test_p3_e1_standalone_v0_1.py` | `tests/test_e1_standalone.py` |

**Kept exactly as they are, because their version is a real identity, not a file-naming habit:**
- every schema, variant, profile and tie identifier inside the code (for example `MULTIGAME_E1_FORECAST_V1_REVIEW`, `FULL_HISTORY_RAW_COUNTS_V1`, `POWERBALL_PROFILE_V1`, `TIE_SHA256_V1`). These are record identities, and renaming them would change hashes;
- the frozen fixtures `tests/p3_e1_synthetic_v0_3.json` (the goldens' fixture) and `tests/fixtures/coordinator_v0_6_baseline/Powerball_Experiment_Coordinator_v0_6.py.txt` (the committed v0.6 coordinator; the AST anchor);
- the negative checks that forbid retired module names (`_common.lotterywest_api_client_v1`, `_common.multigame_results_build_v1`, `_common.multigame_offline_source_pipeline_v1`, `_common/multigame_coordinator_exit_receipt_v1.py`). These are not in the map and are untouched.

## 4. What NAMES-1 does not do

- **N1-R05 (RECOMMENDED; refines D-4 for owner confirmation, OPEN-N1).** NAMES-1 does **not** create per-method folders or move E_1's code. The reasons:
  1. The ratified Option F wrapper `Run_Experiment.bat` accepts only a bare file name directly in `src\methods` and runs from that folder. Moving `E_001_Historical_Appearance_Frequency.py` would mean changing the wrapper, which is provisional under ERR-R2-02 and tied to owner Windows gates.
  2. Architecture's own layout is `src/methods/E_###_name.py`.
  3. The shared reader imports `canonical_bytes` from E_1's module, so moving that module into an E_1 folder would make shared code depend on a method folder. Separating the shared encoding out is a code change, not a rename.

  Recommended reading of D-4, then: each method's **entry file** stays at `src/methods/E_<nnn>_<Name>.py`, and its **folder** `src/methods/E_<nnn>/` holds its method-specific modules and its `IN_DEVELOPMENT.txt` flag. Folders are created when a method's code first arrives (E_2 first). E_1's modules stay in `_common` under stable names, until a separate, reviewed E_1 package moves them, if the owner wants that.
- **Out of scope (OPEN-N2), listed so nothing is forgotten:**
  - the **owner's data tools**: `src/results_master_v0_1.py` (run by `Run_Results_Updater.bat`), `src/two_site_results_check_v0_2.py` .. `_v0_7.py` (v0_7 current, v0_2..v0_6 superseded), and `src/scrape_australian_powerball_history_from_2018_04_19_v0_3.py` (an old tool). H-1 says Claude does not rewrite or invoke them, and they touch data acquisition;
  - the **legacy one-off test scripts**: `tests/p0_static_checks.py`, the `tests/p1p2_*` scripts (including the `_v0_3` .. `_v0_6` interlock scripts), `tests/windows_architecture_poc_suite.py` and `tests/prepare_p3_e1_synthetic_csv_v0_1.py`;
  - the POC probe workers, which have no version in their names;
  - everything under `review/` (history; its old kit scripts will no longer import against the new names, which is acceptable for history).

## 5. Proof plan (E2R-R60; reviewer's ADD-C07)

| Test | What it proves |
|---|---|
| N1-T01 | The path map is complete. A static scan of every `.py` file under `src/` and `tests/` finds no remaining reference to any old name in the map. |
| N1-T02 | **Substitution equality**, file by file. Each edited file equals its predecessor with exactly the map's whole-word substitutions applied. Each pure rename is byte-identical to its predecessor. Each substitution site is listed for review (`substitution_sites.txt`). |
| N1-T03 | **AST equality.** For every edited module, the predecessor's AST with the map applied to import names and to string constants equal to an old name equals the new AST. |
| N1-T04 | The eleven protected coordinator function ASTs are unchanged: the existing no-skip TH-1 test, against the v0.6 fixture. |
| N1-T05 | Import origin. Each new module imports from its new path (`__file__`, `__name__`), and importing an old name fails. The coordinator's exit-receipt issuer check (lines 1103-1105) resolves to the renamed file. |
| N1-T06 | Wrappers and launch. No `.bat` file changes, and the verifier guards that. The standalone E_1 contract test and the synthetic worker tests pass under the new names. |
| N1-T07 | The E_1 legacy goldens, the prefix-only and view regressions and T-05: the full offline suite under its new module names. |
| N1-T08 | The three switches are still False and the allowlist is still empty (existing tests, plus a verifier guard). |
| N1-T09 | **Windows.** The owner runs the renamed suite on Windows, Python 3.14. Expected: 60 OK, with the same 2 symlink skips as today. |
| N1-T10 | **Rollback.** A single owner `git revert` of the NAMES-1 commit restores every old path. Tested in a disposable clone. |

**The new standard offline suite command:**
`PYTHONPATH=src:src/methods:tests python -m unittest tests.test_multigame_reader_contracts tests.test_multigame_static_and_timing tests.test_multigame_launch_and_manifest tests.test_multigame_exit_receipt tests.test_multigame_science_allowlist tests.test_multigame_console_and_synthetic_scorer tests.test_t05_hardening`

On Windows CMD: `set PYTHONPATH=src;src\methods;tests`, then the same `python -m unittest ...` line, then `set PYTHONPATH=`.

## 6. Design evidence (author-side trial; not the package)

The map was applied to a disposable copy of `38fc60e` by `apply_trial.py`:
- **The change:** 27 files renamed; 94 whole-word substitutions in 27 files.
- **Standard suite:** under the new names, **60 tests OK** on Linux (Python 3.13.17, NumPy 2.5.3), the same as before.
- **The other two current tests** (`test_e1_standalone`, `test_multigame_windows_lifecycle_review`): **19 OK**, identical before and after.
- **Leftover versioned names:** none in `src/` or `tests/`, other than the out-of-scope owner tools and the kept identities of section 3.
- **Review targets:** every substitution site is listed in `substitution_sites.txt`.
- **Negative checks:** a few substitutions fall inside negative checks, such as `assertNotIn('game_draws_reader', ...)`. The new substring is broader than the old one, so these checks become slightly stricter, never weaker.

## 7. Records that go out of date

- The H-1 v1r2 module map (section 7.1) and suite command.
- R2, R3 and Architecture mentions of the old file names.
- The TH-1 records, which name the old test modules.

The register edition installed with NAMES-1 lists these; the next H-1 revision folds them in. Historical records are never edited.

## 8. Decisions for the owner

**OPEN-N1 - Per-method folders: is the reading in N1-R05 what you meant by D-4?**
- **The reading:** entry files stay directly in `src/methods/` as the wrapper requires; each method's folder holds its own modules and its flag; folders are created when a method's code arrives.
- **Recommendation: yes.** It avoids touching the safety-reviewed launch wrapper and keeps NAMES-1 a pure rename.

**OPEN-N2 - Owner tools and legacy test scripts: in NAMES-1 or later?**
- **Recommendation: later, as a separate small tidy-up package.** It would rename `results_master` and the current `two_site_results_check` with your `Run_Results_Updater.bat`, archive the superseded `two_site_results_check_v0_2..v0_6`, the old scraper and the legacy test scripts, and you would check those tools on Windows. Keeping that apart keeps NAMES-1 small and avoids touching data-acquisition code.

**OPEN-N3 - Test file names.**
- **Recommendation:** use the stable names in section 3. In particular, `test_multigame_v011_reader_contracts` becomes `test_multigame_reader_contracts`, and `test_p2_r1_t05_hardening_v1` becomes `test_t05_hardening`.

*End of NAMES-1 specification draft v0.1.*
