# Predictive Randomness — Ratification Register

**Register version:** v0.2 — 24 October 2026 REVIEW CANDIDATE; the v0.1 owner-ratification records are historical.  
**Basis:** historical owner ratifications recorded in v0.1; Claude independent multi-game review v3 reports GitHub HEAD `34b23ad5bfb07f0a45c1bbba329396e8d9235dd4` (not independently fetched as binary source for this candidate). New multi-game documents below are drafts, not approved.  
**Authority:** This register records approvals; it does **not** independently ratify any document, authorise an experiment, or supersede an operative specification. If a historic document still says “draft”, “review candidate” or “not ratified”, its status at the time of drafting is historical. The later owner approval recorded here determines its current status.

## Current and historical ratification identities

SHA-256 below is computed from **UTF-8 Git-stored file content with LF line endings** (the canonical content represented by the source GitHub ZIP and ratified install artifacts), *not* from a Windows working copy whose checkout may have CRLF endings. The Architecture v0.5 hash represents the **proposed one-line heading correction** in this housekeeping package, and should be verified after commit. Hashes are immutable document-content identities, not Git commit IDs.

| Document (under `doc/`) | Authority and status | Owner approval date | Superseded by / qualifier | Git-content SHA-256 |
|---|---|---|---|---|
| `Predictive_Randomness_Research_Project_Proposal_v0_3.md` | Current — OWNER-RATIFIED | 21 Oct 2026 | — | `04e061d13b69e49c0dc227b7093570e96598d4c416952ac6092af4d3d14d4b64` |
| `Predictive_Randomness_Experimental_Methods_Research_R1_v0_4.md` | Current — OWNER-RATIFIED | 21 Oct 2026 | — | `19809ae8a1aca716c6c6a4de71a37b705129304894a2b382036d51b76575b99f` |
| `Predictive_Randomness_Experimental_Method_Specifications_R2_v0_3.md` | Current — OWNER-RATIFIED | 22 Oct 2026 | — (R2 approved erratum v0.2 also applies) | `7ec4bad9ab00a619a42cedc4abbe4bec393589563d3bc3061ab4737525259d71` |
| `Predictive_Randomness_R2_v0_3_Approved_Erratum_v0_2.md` | Current — OWNER-APPROVED narrow erratum | 22 Oct 2026 | — (ERR-R2-02 remains provisional pending P2) | `a08b4e7620be8cb32142b23146c5f82c415a50e56cba0b2ea3bed6e1a4b80d5e` |
| `Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_2.md` | Current — OWNER-RATIFIED | By 23 Oct 2026; precise date not independently established | — | `dd0b5243ad8f93a0de7c502e2e6ce54a99c5e427063ce7b3e49313fb18975800` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_4.md` | Historical — previously OWNER-RATIFIED | 23 Oct 2026 | Architecture v0.5 | `7526e381be93caa68ce8f8a6b90f135748925f1c0b080e171e1ef18cd771f257` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_5.md` | Current — OWNER-RATIFIED | 23 Oct 2026 | — | `2d57f59afbd152ae80720e117dab5b9749ab3a611bf32ab1b14d3ed1be478acd` |
| `Predictive_Randomness_Windows_POC_Implementation_Task_Specification_v0_1.md` | Historical — OWNER-RATIFIED for P0–P2 | By 23 Oct 2026; precise date not independently established | Windows POC Task Spec v0.2 | `deeae27f846061d51555c3d89a77c8199941b74456520a98aa6501c504b85e5e` |
| `Predictive_Randomness_Windows_POC_Implementation_Task_Specification_v0_2.md` | Current — OWNER-RATIFIED | 23 Oct 2026 | — | `ca5e89dde7e9927974e759f1df115eefca03144de45e073c240aa9e13f24ebf1` |
| `HANDOVER/Predictive_Randomness_ChatGPT_Continuation_Handback_v0_2.md` | Historical — OWNER-RATIFIED | By 23 Oct 2026; precise date not independently established | Handback v0.4 | `53b33b6ddec5b874725b195d4c45e3295351915a6e8331e2d2eb56d4b8a28140` |
| `HANDOVER/Predictive_Randomness_ChatGPT_Continuation_Handback_v0_4.md` | Current — OWNER-RATIFIED | 23 Oct 2026 | — | `5093e446fb14bc281fecea1e722ee2bea366614dac9fb5192e36b96b63e603db` |

## Pending multi-game document candidates — no approval implied

| Proposed document | Authority today | If approved, replaces/qualifies |
|---|---|---|
| `Predictive_Randomness_Research_Project_Proposal_v0_4_REVIEW_CANDIDATE.md` | NOT RATIFIED | Proposal v0.3 charter scope only; existing research philosophy retained |
| `Predictive_Randomness_R2_v0_3_Erratum_Record_v0_3_REVIEW_CANDIDATE.md` | New ERR-R2-05 NOT APPROVED; prior ERR-R2-01..04 remain as approved in v0.2 | R2 v0.3 game-scoped interpretation; erratum v0.2 still governs until ratification |
| `Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_3_REVIEW_CANDIDATE.md` | NOT RATIFIED | R3 v0.2 only after approval |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_6_REVIEW_CANDIDATE.md` | NOT RATIFIED | Self-contained successor to v0.5 if approved |
| `Predictive_Randomness_MultiGame_Infrastructure_P3_Task_Specification_v0_1_REVIEW_CANDIDATE.md` | NOT RATIFIED | New workstream; POC task v0.2 remains separate |
| `contracts/TIE_SHA256_V1_Ratified_Encoding_v0_2_REVIEW_CANDIDATE.md` | Clarification NOT RATIFIED; D2 unchanged | Adds game applicability, does not change byte encoding |

**Ratification order proposed:** charter scope first; R2/R3 scientific changes next; Architecture v0.6 and new task specification afterward, with the contract note/register adopted as supporting records. Fill in approval dates and content hashes **only after actual owner approvals and commits**. No candidate filename is an approved authority.


## Interpretation and verification

- The **current** governing set is Proposal v0.3, R1 v0.4, R2 v0.3 as modified by its approved erratum v0.2, R3 v0.2, Architecture v0.5, and Windows POC Task Specification v0.2. ChatGPT Handback v0.4 records continuity, not a replacement for these specifications.
- ERR-R2-02 / Option F is **provisional for production** pending the P2 test evidence and owner disposition, even though the Architecture and POC Task Specification are ratified.
- The **failed/orphan-group result firewall** is OWNER-RATIFIED on 23 October 2026. Never consume downstream results from failed or orphan-suspected groups, even when a canonical result file exists.
- **Later owner report (23 October 2026):** the reviewed, incident-specific orphan-clearance utility completed `CHECK PASS` and `MANUAL CLEARANCE PASS`, preserving the archived FAILED evidence and writing a clearance record; a subsequent one-worker P2 canonical fixture passed and left no marker. The repository is not itself live-state proof; always recheck the current global marker before any future launch. These observations do not close P2 or authorise destructive tests.
- This register does not authorise process termination, destructive testing, holdout unsealing, Oz Lotto scraping or Oz science. Previously authorised Powerball E_1 historical development and the verified draw-1577 run are historical facts, not permission for new Oz runs. The current multi-game development pause remains binding.
- To verify a Git-stored file hash on Windows CMD after committing, substitute the path and run: `git show HEAD:doc/EXAMPLE.md | python -c "import sys,hashlib;print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())"`. Git may normalise checkout line endings; `certutil -hashfile` on a CRLF working file can legitimately differ.
- Where an exact historic ratification day is not independently substantiated, the register says so rather than assigning a date without evidence. Improve those entries only when a documentary decision record supports the update.

## Change discipline

This v0.1 register and the single-line correction to Architecture v0.5 are administrative housekeeping. They do not alter technical policy, scientific method contracts, executable code, or experiment evidence. Preserve earlier document versions. Future substantive changes still follow ChatGPT draft → Claude review at the required gates → owner ratification.
