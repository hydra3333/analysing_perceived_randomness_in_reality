# Independent Claude review request — Multi-Game Package 1 v0.1

**24 October 2026. Review only.** The owner approved ChatGPT **drafting** this documentation package but **has not ratified** any of these multi-game specifications or resumed coding, scraping or experiments. Development remains PAUSED until explicit owner approval. Do **not** interpret review acceptance as permission to install or execute.

## Review basis

- Governing ratified: Project Proposal v0.3, R1 v0.4, R2 v0.3 with OWNER-APPROVED erratum v0.2 (ERR-R2-02 still conditional), R3 v0.2, Architecture v0.5, POC Task Spec v0.2, ratified failed/orphan-result firewall, D2 `TIE_SHA256_V1` little-endian encoding.
- Independent review used: `Claude_Review_MultiGame_Architecture_v3.md` (SHA-256 `1efdaf0a41ada2d1e382c0dccbb9e39a1d1c595f166e00f81f1b5ae434b17747`), **superseding v1/v2**. Its source HEAD observation was `34b23ad5bfb07f0a45c1bbba329396e8d9235dd4`.
- Baseline documents were recreated from the repository ZIP the owner uploaded and the previously owner-ratified document installation/housekeeping ZIPs; **ChatGPT has not claimed byte-by-byte verification against HEAD 34b23ad5 for every file.** Each source LF-normalised hash is in `SOURCE_AND_CANDIDATE_SHA256.json`; please check it against pristine current Git files before approving. `diffs/` contains exact `LF`-normalised unified comparisons.
- No code, dataset, holdout or live process/marker files are in this package. This is the **first stop/go package, documents only**.

## Candidate contents

1. Proposal v0.4, full charter with new §0A scope; historic text retained and marked as Powerball-specific where necessary.
2. R2 v0.3 erratum record v0.3, preserving earlier approved sections and adding **ERR-R2-05 NOT APPROVED**. R2 v0.3 itself stays intact.
3. R3 v0.3, full document with new multi-game §0A, still unratified.
4. Architecture v0.6, full self-contained document with proposed §0A and old ratified v0.5 safety provisions retained. No separate erratum.
5. New P3 multi-game infrastructure task spec v0.1 (three stop/go packages).
6. Shared TIE_SHA256_V1 applicability note v0.2, no byte encoding changes.
7. Ratification register v0.2 candidate, listing current owners' approvals separately from proposed versions.

## Required independent checks

- **Charter authority:** Is adding OZLOTTO properly labelled an owner-reserved scope amendment? Is v0.3's philosophy, permanent method retention and no automatic probability veto unchanged? Are supplemental numbers excluded scientifically but archived raw?
- **Scientific identity:** Do dates/source provenance and game/profile versions enter *only the appropriate permitted views*? Does existing Powerball E_1 training view and `TIE_SHA256_V1` tie tuple remain byte-identical? Check the v0.3 synthetic vector (`df21871f`, `7ce5ab1b`, `7b43d659`) and real target 1577 (`d47fbbd6`, `7f113087`), including exact rankings.
- **Holdout/firewall:** Is Oz first-snapshot 10-highest **rule** fixed before scraping, with bounded all-row structural audit not releasing held-out ball values? Does the method reader remain prefix-only (no target-row N)? Is existing Powerball 1578–1587 still protected? Are failed/orphan runs always refused, even with a result file?
- **Dates:** Derived weekly dates based on profile constants; source dates validation in every snapshot, field-only error reporting; date-dependent E_14/E_54 stop on mismatch, no automatic disqualification of unrelated U-only science; correct digest mapping and no user-supplied date/7-day parameters.
- **Result/score semantics:** One barrel vs two; Powerball channel absent on Oz, no fake zero; qualified game/draw identity everywhere, legacy compatibility only via a versioned reader; per-game reference figures, freeze and score tracks not pooled.
- **Process safety:** Existing v0.5 §5C, no-status/no-kill, root/ancestry/ctime, global marker, no taskkill, no process-name proof, no termination switch enablement, coordinated exit receipt and handshake unchanged.
- **Scraper/order:** Separate scrapers; `Run_Scraper.bat <game>` scoped to existing venv rules, immutable two-file Oz snapshot, no automatic adoption; operator-era evidence and exact held-out draw boundary remain OPEN until approved first scrape.
- **Coverage:** Have we missed any hard-coded Powerball numerical/structural assumption that must be addressed *before* implementing E_2–E_6? Are three stop/go packages minimal and independently gated?
- **Administrative:** Do old status paragraphs in preserved ratified-doc history inadvertently appear current? Is the R2 erratum v0.3 approach appropriate compared with an R2 v0.4 full revision? Verify all DECIDED/RECOMMENDED/OPEN classifications and avoid speculative source claims.

## Explicit questions / choices for owner ratification (not answers)

- Ratify the scope amendment, Oz current-era winning-only policy, and first-snapshot-ten-highest holdout rule?
- Ratify pair `(game_id, draw_number)`, profile-driven U/X views, derived-weekly-date rule and date-dependent STOP behaviour?
- Ratify per-game scoring, score non-pooling and freeze identities?
- Accept R2 **erratum v0.3** (proposed) versus a full ratified R2 v0.4 revision?
- Ratify self-contained Architecture v0.6, new infrastructure task plan and tie-note applicability? (These do not authorise code.)

**Please return:** blocker / correction / safe-to-defer findings, evidence with line references, owner decisions requiring ratification, and a short paste-ready summary. Do not request destructive tests, run Oz data, unseal holdouts or alter the repo. The owner will decide whether to ratify or request revisions. No further exploration needed unless a substantive issue is found.
