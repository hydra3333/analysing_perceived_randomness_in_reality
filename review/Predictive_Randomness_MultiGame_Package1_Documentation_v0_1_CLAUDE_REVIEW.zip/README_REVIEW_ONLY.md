# Multi-Game Architecture — Package 1 (DOCUMENTS ONLY) v0.1

**Prepared:** 24 October 2026 (Adelaide)  
**Status:** **REVIEW CANDIDATE / NOT RATIFIED**  
**Provenance:** owner approved *drafting* this package, not installation, code modification, scraping, P3 resumption or Oz Lotto science. The global development pause continues.  
**Reviewer basis:** Claude Multi-Game Architecture review **v3** only (v1/v2 superseded); SHA-256 `1efdaf0a41ada2d1e382c0dccbb9e39a1d1c595f166e00f81f1b5ae434b17747`.

## Contents

- `repo_overlay/doc/`: seven versioned Markdown candidates. **Do not install/commit as ratified documents.** Their candidate filename markers are intentional.
- `diffs/`: six LF-normalised unified diffs against the historical governing documents. The new task spec is a new file and has no predecessor diff.
- `SOURCE_AND_CANDIDATE_SHA256.json`: exact SHA-256 for LF-normalised source document text and the candidate files' exact UTF-8 LF bytes.
- `CLAUDE_REVIEW_REQUEST.md`: consolidated independent review instructions and owner decisions.
- `PACKAGE_SHA256.txt`: hashes for all review package members excluding itself.

## Baseline and limitations

The source texts were obtained from the owner's uploaded repository ZIP, together with the earlier owner-ratified document installation and ratification-register housekeeping packages. The resulting LF-normalised baselines have hashes recorded in the manifest. The observed public GitHub HEAD in Claude v3 was `34b23ad5bfb07f0a45c1bbba329396e8d9235dd4`; the authoring environment could read the public architecture page but could not clone this HEAD, and **does not claim that every current file is independently verified byte-identical to the local source snapshot**. Claude should reconcile each base hash with pristine HEAD before accepting the diffs. Do not force-install a candidate onto a different source revision.

The ratified Architecture v0.5 safety §§5C.2–5C.3, R2 historic approved errata, and R3 evaluation mathematics were copied without changing their operative text, except for the explicitly disclosed metadata status/title changes and proposed §0A additions. Historic draft-status lines elsewhere in these complete documents describe older drafting and should be read through the new review-candidate prefaces; they are not newly ratified claims.

## Classification

**OWNER ALREADY RATIFIED (preserved):** Powerball-era rules; E_1 identity and D2 little-endian tie bytes; global orphan safety; no-status/no-kill; failed/orphan result firewall; scientific method retention; immutable prospective evidence and N−1; R2 operational decisions including conditional Option F.

**OWNER DIRECTION, NOT YET RATIFIED AS MULTI-GAME SPECS:** explore both games now, no supplementaries in Oz science, compound draw identity, derived-weekly-date semantics, and no complicated Task Manager rename requirement. Their binding form is **RECOMMENDED** for owner approval within the candidate charter/R2/R3/Architecture amendments.

**CHATGPT DRAFTING CHOICES (DECIDED only within document preparation):** a frozen Python profile module, prefixes and directory segments, method-generic common runtime, no generalised any-game engine, bounded structural auditor shape, distinct source/snapshot files, advisory resource warning. All require normal scientific/safety review before consequential implementation.

**OPEN:** operator confirmation of Oz draw 1474, first approved snapshot/holdout number range/hash, nominal local draw/closing times and DST-aware UTC rules, E_54 external-data availability, final schema field names, start of Oz science/FINAL, E_63 registration, and separate P2 process-termination authorisation.

## Recommended order after review

1. Owner ratifies charter Proposal v0.4 **first**, then the R2/R3 changes, then self-contained Architecture v0.6/new task specification and supporting notes. Update register **after**, with exact final Git hashes and approval dates. Do not mark these candidate files RATIFIED in advance.
2. Owner **separately authorises** Package 2 shared-code implementation only after documents approved; Claude reviews; Windows synthetic tests.
3. Owner separately permits one Oz Lotto scrape and bounded validation; record the sealed holdout and STOP. No Oz science until further authorisation.
4. Owner explicitly resumes the previously paused Powerball scoring/walk-forward and E_2–E_6 development under the ratified shared contracts.

**No executable scripts or data outcomes are provided.**
