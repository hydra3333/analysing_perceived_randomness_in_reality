# Request for Claude independent re-review — Documentation Recovery package v0.2

Baseline: GitHub HEAD `5eea9bd92645aed0574037b23099839eb846f64e` (Claude-confirmed), with local ZIP used for comparison. All candidates NOT RATIFIED.

**Review priority:** Architecture v0.5 and Task Spec v0.2, especially former B1/B2 and corrections C1–C3; independently validate original-to-candidate exact diffs and SHA-256 manifest. Verify that the architecture is ONE self-contained document, the separate erratum is absent, and old taskkill/fallback and diagnostic cleanup wording no longer grants termination authority. Check 5C.2's complete trigger including zero captured descendants with an alive/unknown run-matched status PID; stuck pipes; any unconfirmed stop; status block-only. Confirm review-only status and no safety-switch change.

**Authority distinctions:** strict no-status/no-kill and durable manual orphan interlock OWNER-RATIFIED; status PID block-only DECIDED within that policy; early STARTED status DECIDED implementation guidance, not owner ratification; FAIL/orphan group result-consumption exclusion is **NEW RECOMMENDED**, awaiting owner decision. Does any statement silently upgrade its authority?

Handback v0.4 carries Claude correction C4 (future handback v0.5) and current state. It can be ratified independently once reviewed. Do not treat owner-reported Windows tests as independently inspected, or imply the live marker cleared.

Please report BLOCKERS / NON-BLOCKERS, cite file and line, and provide a short paste-ready feedback block. Do not approve clearance, process killing, destructive tests or P3.
