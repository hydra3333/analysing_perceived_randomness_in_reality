# Installation / authority notes — v0.2 REVIEW ONLY

- None of these documents has been owner-ratified. Do not install as authoritative. Previous ratified Architecture v0.4 continues to govern.
- Architecture v0.5 is standalone. The earlier proposed separate v0.5 safety erratum is WITHDRAWN and NOT included. The new v0.5 contains the substantive policy in section 5C.2 and the acceptance constraints in 5C.3.
- No coordinator or batch files were modified. No marker or archive was changed. Coordinator termination switch remains False.
- Real unresolved-orphan marker remains ACTIVE as of owner local observation at 23 Oct 2026 21:18 Adelaide. No tests/launches until reviewed manual clearance.
- `RECOMMENDED`: owner must decide whether FAIL/orphan-suspected groups' late results are excluded from downstream consumption. That is new policy, not already ratified.
- Claimed Git HEAD 5eea9bd is Claude-verified on GitHub, not proof of current local working-tree state.
- The tracked worker stdout `.log` omission and doc housekeeping are separately pending; this review package does not perform Git operations.
