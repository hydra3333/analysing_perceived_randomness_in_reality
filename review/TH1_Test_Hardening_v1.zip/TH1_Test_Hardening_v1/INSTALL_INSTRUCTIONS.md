# TH-1 - installation (only after the ChatGPT reviewer's PASS and the owner's acceptance)

Windows CMD, repository root. `git status --short` must print nothing first. Save this ZIP to `E:\TEMP` and extract it there (`tar -xf "E:\TEMP\TH1_Test_Hardening_v1.zip" -C E:\TEMP`), which creates `E:\TEMP\TH1_Test_Hardening_v1\`.

```bat
python "E:\TEMP\TH1_Test_Hardening_v1\VERIFY_TH1_INSTALL.py" --repo . --phase pre
xcopy "E:\TEMP\TH1_Test_Hardening_v1\repo_overlay\*" . /E /Y
python "E:\TEMP\TH1_Test_Hardening_v1\VERIFY_TH1_INSTALL.py" --repo . --phase post
call "E:\TEMP\TH1_Test_Hardening_v1\STAGE_EXACT_FILES.cmd"
git diff --cached --name-status
```

Expected: `PRE PASS`; `4 File(s) copied` (one replaces `tests\test_multigame_v011_static_and_timing.py`, as intended); `POST PASS`; three lines starting with `A` and one with `M`.

Optional, owner-run, offline (reads only the accepted development masters and synthetic fixtures; no Windows process, network or holdout action):

```bat
set PYTHONPATH=src;src\methods;tests
python -m unittest tests.test_multigame_v011_reader_contracts tests.test_multigame_v011_static_and_timing tests.test_multigame_launch_and_manifest_v0_8 tests.test_multigame_exit_receipt_v0_8 tests.test_multigame_science_allowlist_v0_8 tests.test_multigame_console_and_synthetic_scorer_v0_4 tests.test_p2_r1_t05_hardening_v1
set PYTHONPATH=
```

Expected: `Ran 59 tests ... OK` with no skips. Then commit, push and verify:

```bat
git commit -m "TH-1: offline test hardening (P2-R1-O1 T-05 intermediate targets; P2-R1-O3 no-skip v0.6 AST check)"
git push
python "E:\TEMP\TH1_Test_Hardening_v1\VERIFY_TH1_INSTALL.py" --repo . --phase committed
git rev-parse HEAD
```

Expected: `COMMITTED PASS`. Send Claude the commit ID (and the suite output if you ran it). If anything prints `STOP`, stop and send Claude the output.
