@echo off
setlocal
rem OPTIONAL owner-run staging of exactly the 4 TH-1 paths. No commit, push or deletion.
git add -- ^
  "review\Claude_Verification_Transition_Commit_d36735d_v1.md" ^
  "tests\fixtures\coordinator_v0_6_baseline\Powerball_Experiment_Coordinator_v0_6.py.txt" ^
  "tests\test_multigame_v011_static_and_timing.py" ^
  "tests\test_p2_r1_t05_hardening_v1.py"
if errorlevel 1 (echo STAGING FAILED & exit /b 1)
git status --short
endlocal
