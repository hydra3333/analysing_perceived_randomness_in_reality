"""Spec v0.1 -> v0.2: record the owner's decisions on OPEN-1..3 (28 Oct 2026). Counted edits."""
import hashlib, sys
src, out = sys.argv[1], sys.argv[2]
t = open(src, encoding='ascii').read()
assert hashlib.sha256(t.encode()).hexdigest() == '3f956a8bb90236688acb3a130c9a970d1bcce523f2870a7df900aa9590ffdf6c'
SEC14 = t[t.index('## 14. Decisions for the owner'):t.index('*Document references:')]
NEW14 = """## 14. Owner decisions recorded, and what remains for ratification

**Owner decisions, 28 October 2026** (made on Claude's recommendations, before review):
- **D-1 (was OPEN-1):** `track_id` does **not** include the method revision. A track continues across revisions, and every record carries `method_revision` (E2R-R40, E2R-R40A).
- **D-2 (was OPEN-2):** synthetic and benchmark records get the evidence tier **`NOT_EVIDENCE`**. It is never shown in a league table (section 9).
- **D-3 (was OPEN-3):** the method name, one-liner and short explanation are written for **E_1 and E_2** in the E_2-readiness code package. Each later method's texts are written with its own specification (E2R-R21A).

**RECOMMENDED** for ratification with the document, unless the reviewer or owner objects:
- **Structure:** the five record families and their digest links (E2R-R08), and the method-computes / contract-assembles split (E2R-R07).
- **Encoding:** the canonical encoding, the float and negative-zero rules and schema naming (E2R-R10..R15).
- **Records:** the field tables of sections 5, 7, 8 and 10.
- **Vocabulary:** the five-field mode vocabulary and its legal-combination table (section 9).
- **Seeds:** the seed derivation (7.6), coded only with the first stochastic method.
- **Versioning:** the migration rule (section 12).
- **Tests:** the test list (section 13).

**OPEN:** none at this draft. The reviewer may raise new questions for the owner.

"""
EDITS = [
    ('# Predictive Randomness - E_2-readiness method-generic contract specification, v0.1\n',
     '# Predictive Randomness - E_2-readiness method-generic contract specification, v0.2\n'),
    ('**Version:** v0.1 DRAFT for independent design review (R-3), 28 October 2026 (Adelaide, UTC+10:30).',
     '**Version:** v0.2 DRAFT for independent design review (R-3), 28 October 2026 (Adelaide, UTC+10:30). v0.2 records the owner\'s decisions of 28 October 2026 on the three questions v0.1 left open (section 14), adds the revision-selection rule E2R-R40A that the owner\'s question prompted, and changes nothing else. v0.1 was not reviewed.'),
    ('- **DECIDED**, citing the owner-ratified source it restates;',
     '- **DECIDED**, citing the owner-ratified source it restates, or the owner decision of 28 October 2026 recorded in section 14;'),
    ('- **OPEN**, a decision for the owner, with a recommendation (section 14).',
     '- **OPEN**, a decision for the owner, with a recommendation (section 14; none remain at v0.2).'),
    ('- **E2R-R21 (RECOMMENDED).**',
     '- **E2R-R21A (DECIDED; owner decision D-3, 28 October 2026).** `method_name`, `one_liner` and `short_explanation` are written, in plain English, for E_1 and E_2 in the E_2-readiness code package. For E_3..E_62 they are written with each method\'s own specification. Until then, those declarations carry the exact R1/R2 name, and their one-liner and explanation say plainly that the method is not yet specified. Every text is reviewed with the package that introduces it.\n- **E2R-R21 (RECOMMENDED).**'),
    ('- **E2R-R40 (RECOMMENDED).** `track_id` is the text `GAME:METHOD:VARIANT:READOUT:MODE`, for example `POWERBALL:E_2:EXAMPLE_VARIANT:TOP:WF`. `method_revision` is carried in every record, but is not part of `track_id` (OPEN-1). Reports never pool different revisions in one series without a disclosed policy (R3 3.5).\n',
     '- **E2R-R40 (RECOMMENDED format; DECIDED content, owner decision D-1).** `track_id` is the text `GAME:METHOD:VARIANT:READOUT:MODE`, for example `POWERBALL:E_2:EXAMPLE_VARIANT:TOP:WF`. `method_revision` is carried in every record, but is not part of `track_id`. Reports never pool different revisions in one series without a disclosed policy (R3 3.5).\n'
     '- **E2R-R40A (DECIDED principle, owner decision D-1 and the owner\'s question of 28 October 2026; RECOMMENDED wording).** Which revision a report uses:\n'
     '  - A track continues across revisions. Each report or table uses **one declared revision per track** and states it. The default is the latest revision whose method specification is ratified and whose implementation is accepted.\n'
     '  - Records of other revisions are kept. They are never silently mixed in, and appear only when a report explicitly asks for a labelled side-by-side comparison.\n'
     '  - Re-running a revision on past draws adds new records for the same targets. It never modifies or replaces earlier records (R2 8.2A, T-36).\n'
     '  - Prospective records (published before the draw) of every revision are permanent. A later revision re-run over those draws is labelled retrospective development walk-forward, never prospective (R3 17.3.5, 17.3.9).\n'
     '  - Why superseded results are kept: prospective forecasts cannot be recreated; comparing revisions on the same development draws shows how much of an apparent gain could be tuning to known results (pattern origin PO-3, R3 17.3.9 and 6.2); and the record is never made to look tidier than it was (mark, never suppress).\n'),
    ('| R3 17.3.9, plus `NOT_EVIDENCE` for synthetic and benchmark records (OPEN-2) |',
     '| R3 17.3.9, plus `NOT_EVIDENCE` for synthetic and benchmark records (owner decision D-2, 28 October 2026) |'),
    (SEC14, NEW14),
    ('*End of specification draft v0.1.*', '*End of specification draft v0.2.*'),
]
for old, new in EDITS:
    assert t.count(old) == 1, old[:70]
    t = t.replace(old, new)
assert all(ord(c) < 128 for c in t)
open(out, 'w', encoding='ascii', newline='\n').write(t)
print(hashlib.sha256(t.encode()).hexdigest())
