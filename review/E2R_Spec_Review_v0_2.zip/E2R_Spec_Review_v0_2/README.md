# E2R-1 - E_2-readiness method-generic contract specification v0.2 - handback for design review

**Work-item card**

| Field | Value |
|---|---|
| Item | E2R-1: the stage-1 contract-field schema and acceptance list before E_2 (R2 v0.5 section 5.6; R3 v0.5 section 17.13 stage 1; Architecture v0.8 section 20A) |
| Author chat | Claude (primary designer and coder) |
| Reviewer chat | ChatGPT reviewer chat (H-2 v1r3): R-3 design-stage review; a competing design is welcome |
| Base commit | `be185485693f29cf9ab28292dc6eebad00bbc32c` |
| Inputs | R2 v0.5 `2c67db8f...9a3e`; R3 v0.5 `53e30a3e...57b6`; Architecture v0.8 `32cf157d...52ec`; TIE v0.2 `045b784d...65a0b6`; register v0.6 `5e677dce...074c`; the Package 2 code at `be18548` (registry, result registry, standalone contract, reader) |
| Scope | One new specification document. No code, no change to any ratified document. |
| Risk tier | HIGH (normative text; it governs reader-adjacent, tie, seed and TOP/WORST contracts) |
| Owner gate | The owner asked for this specification on 28 October 2026 ("please continue"). The owner decides OPEN-1..3 and ratifies before any code. |
| Evidence state | IMPLEMENTED (draft); checked against the sources; not yet REVIEWED. v0.2 supersedes v0.1, which was never sent for review. |

**Date:** 28 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears in or was used for this document.

## Contents

| File | SHA-256 |
|---|---|
| `Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_2.md` (ASCII, LF; proposed path `doc/`) | `4254128d20a3f9fa3a7d65658bcca99e8f72045145b1514d570b3c4f21ebc4a4` |
| `evidence/spec_v0_1_to_v0_2.diff` (the only changes from the unreviewed v0.1 `3f956a8b...df6c`) | `6311672cb733f0fd7f01c62602ce3f85d7f3dbb34e4e838640e252a308a1ac52` |
| `evidence/make_v02.py` (counted edits that build v0.2 from v0.1) | `e9cb5ea50855ba5deda305e9028cf5a29b1415b81e76016f1f443aa83490dc53` |

## What the document does, in five lines

1. It splits everything into five records: a static **declaration**, an orchestration **run request**, the method's **forecast record**, the orchestration **freeze receipt**, and a scorer-only **post-outcome record**. Only the forecast record and a frozen task object are method-facing, and the master hash lives only in the run request and receipt (B1).
2. The method returns only numbers. The shared contract module adds every identity field and validates the record before freezing it.
3. It fixes the shape and numeric rules: full permutations, recomputed TIE_SHA256_V1 order, TOP as the first k, WORST as the reversal, the probability kinds, finite float64 only, and no negative zero.
4. It separates five fields: run mode, product kind, execution path, evidence tier and score status. A legal-combination table makes the mode firewall checkable.
5. It maps each of the nine ratified acceptance items to tests E2R-T01..T12, and states a versioning and migration rule that leaves every E_1 golden untouched.

## Where to look hardest (Claude's own list)

- **E2R-R07** (method computes, contract assembles). Is that split right for joint-set (`MAP_SET`) and diagnostic methods?
- **7.2 `ranking_digest` and `tie_identity`.** R2 5.6 field 2 says "the TIE_SHA256_V1 identity and digest" without defining the digest. This is Claude's reading.
- **Section 9.** It reconciles four existing vocabularies (Package 2, E_1, R2 8.1, R3) into five fields. Check the legal-combination table, including the owner-chosen `NOT_EVIDENCE` tier (D-2).
- **E2R-R40A.** This is the new revision-selection rule. Is the default revision well defined, and are prospective records fully protected?
- **7.6 fit seed identity.** This is an always-review subject. The tuple follows R2 9.2, but is defined now and coded only with the first stochastic method.
- **E2R-R25.** The design keeps the reader file unchanged by wrapping its existing generic digest. Is that sufficient?
- **E2R-R33.** It requires finite scores and no sentinels. E_2's "never seen" labels (R2 7.1) must then be handled by E_2's own specification.

## DECIDED / RECOMMENDED / OPEN

- **DECIDED:** every requirement tagged DECIDED cites its ratified source. The owner also decided, on 28 October 2026 and on Claude's recommendations, the three questions v0.1 had left open (spec section 14):
  - **D-1:** `track_id` excludes the revision. A new rule, E2R-R40A, says which revision a report uses and why superseded results are kept. It was prompted by the owner's question about re-running past draws.
  - **D-2:** a `NOT_EVIDENCE` tier for synthetic and benchmark records.
  - **D-3:** method texts for E_1 and E_2 in the code package, and later methods' texts with their own specifications (E2R-R21A).
- **RECOMMENDED:** the structure, encoding, field tables, vocabulary table, seed rule, migration rule and test list (section 14).
- **OPEN:** none. The reviewer may raise new questions for the owner, including on D-1..D-3 (RECONSIDER).

## Not done

- No code. The code package follows ratification (agreed roles position section 10, item 2). Its tests use synthetic fixtures and the development prefix only.
- E_2's mathematics is not specified here.
- The Package 2 coordinated allowlist key is not migrated (E2R-R43); it stays empty.
- No claim is made that the existing E_1 code already meets this contract. E2R-T09 is how that will be shown.

*End of handback.*
