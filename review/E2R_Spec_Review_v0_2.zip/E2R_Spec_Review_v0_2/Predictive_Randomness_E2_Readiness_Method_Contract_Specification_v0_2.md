# Predictive Randomness - E_2-readiness method-generic contract specification, v0.2

**Document:** the stage-1 contract-field schema and acceptance list required before E_2 (R2 v0.5 section 5.6; R3 v0.5 section 17.13 stage 1; Architecture v0.8 section 20A; agreed roles position section 10 item 1).
**Version:** v0.2 DRAFT for independent design review (R-3), 28 October 2026 (Adelaide, UTC+10:30). v0.2 records the owner's decisions of 28 October 2026 on the three questions v0.1 left open (section 14), adds the revision-selection rule E2R-R40A that the owner's question prompted, and changes nothing else. v0.1 was not reviewed.
**Author:** Claude (primary designer and coder). **Independent reviewer:** the ChatGPT reviewer chat. **Ratifier:** the project owner.
**Status:** DRAFT. It becomes binding only when the owner ratifies it. Nothing in it authorises any run, data access, holdout access, switch change, allowlist entry, method registration or code acceptance. Declaring a field, status or capability authorises nothing.
**Base:** repository commit `be185485693f29cf9ab28292dc6eebad00bbc32c`.
**Holdout statement:** no draw outcome appears in or was used for this document. The only numbers are rule constants (barrel sizes, era first draws, development boundaries) already in the ratified documents.

**Tags.** Each requirement is labelled:
- **DECIDED**, citing the owner-ratified source it restates, or the owner decision of 28 October 2026 recorded in section 14;
- **RECOMMENDED**, a design choice Claude proposes for ratification with this document;
- **OPEN**, a decision for the owner, with a recommendation (section 14; none remain at v0.2).

Requirement IDs are `E2R-Rnn`; acceptance tests are `E2R-Tnn`.

---

## 1. Purpose in plain English

E_1 was built with its own one-off conventions: an `e1-` run-ID prefix, hard-coded method and variant constants, Powerball-only result checks, a target ceiling written into the code, and an E_1-shaped result schema. Before E_2 (or any later method) is built, those must be replaced by one shared contract that every method meets (Architecture 20A, DECIDED).

This document specifies that contract. It covers:
- what a method **declares** about itself, once per game, variant and version;
- what a method **returns** for a target draw, and how that output is checked before it is frozen;
- what the **orchestration side** records around the forecast, such as the master-file identity, the environment and the freeze receipt;
- the **scorer-only** record written after an outcome is opened;
- the **acceptance tests** that must pass before E_2 is built;
- how schemas are **versioned and migrated**.

It does not specify E_2's mathematics. That is a separate, later specification under R2 section 7.1.

---

## 2. Principles carried into every record

- **E2R-R01 (DECIDED; R2 3.1, R3 17.3.3, T-05).** Strict N-1: a forecast for target N is computed only from eligible same-game draws with `draw_number < N`.
- **E2R-R02 (DECIDED; register "B1", R2 9.2 and R2-C19).** The whole-master SHA-256, the file length and any other value derived from target-and-later bytes are **orchestration-only provenance**. They never reach a method, a method-facing object, a seed, a cache key or a forecast's content identity.
- **E2R-R03 (DECIDED; R2-C10, R2-C12).** Nothing is fabricated to satisfy an interface. A missing ranking, inverse or probability is recorded as unavailable with a reason. Non-finite numbers, duplicate labels, wrong counts and wrong sums are validation failures, never silently corrected.
- **E2R-R04 (DECIDED; the owner's foundational points of 26 October 2026, H-1 v1r2 section 2A, points 3 and 6).** Mark, never suppress. The contract never makes a method ineligible because of its results. A status records what happened; it does not hide a record.
- **E2R-R05 (DECIDED; R3 17.3.1, R2 3.6).** One game per record. Draws are identified by `(game_id, draw_number)`. Labels and rank positions are 1-based and as printed. Internal 0-based indices never appear in a record.
- **E2R-R06 (RECOMMENDED).** Fail closed. Every validator rejects unknown schemas, unknown fields, missing fields and values outside a closed vocabulary. There is no "best effort" parsing of a scientific record.
- **E2R-R07 (RECOMMENDED).** The **method computes; the contract assembles.** A method returns only its numerical output (scores, rankings, optional probabilities and native selections). The shared contract module adds every identity field from the declaration and the view, then validates and freezes the record. A method therefore cannot mislabel its game, target, variant or view.

---

## 3. The five record families

```text
 (A) Method declaration ----------------------+
     static: game, method, variant, version,  |
     registry status, capabilities, texts     |
                                              v
 (B) Run request (orchestration) --> reader --> DrawView (prefix only)
     pin: master file, ledger version,        |   + method task (no master SHA)
     master SHA (orchestration only)          v
                                     method computes output
                                              |
                                              v
 (C) Forecast record (canonical, pre-target; content identity is suffix-invariant)
                                              |
                                              v
 (D) Freeze receipt (orchestration; holds master/ledger provenance,
     environment, window/cohort, status before opening the outcome)
                                              |
                     ... outcome opened later, separately gated ...
                                              v
 (E) Post-outcome score record (evaluator only; never read by a predictor)
```

- **E2R-R08 (RECOMMENDED).** Families A, C and E are separate schemas, as are B and D, and no record of one family embeds another. They are linked by digests: C names A's declaration digest, D names C's content digest, and E names C's and D's.
- **E2R-R09 (DECIDED as a principle, R2 8.2 and R3 2.2; RECOMMENDED as structure).** A method-facing object never contains anything from B or D except the fields listed as method-visible in section 6.2.

---

## 4. Common encoding rules

- **E2R-R10 (RECOMMENDED; matches the existing `canonical_bytes`).** Canonical JSON: UTF-8 restricted to ASCII (`ensure_ascii`), keys sorted, separators `,` and `:`, `allow_nan=False`, one trailing newline. A record's digest is the lowercase hexadecimal SHA-256 of its canonical bytes.
- **E2R-R11 (DECIDED; R2 5.6 field 3, MRT-12, owner decision 26 October 2026).**
  - Every integer field fits in int64.
  - Every floating value is a finite IEEE-754 float64.
  - Canonical JSON writes floats with Python's shortest round-trip representation, so a float64 value round-trips exactly.
- **E2R-R12 (RECOMMENDED).** Negative zero is rejected by the validator. `0.0` and `-0.0` compare equal but serialise differently, so they would give two digests for one forecast. Methods normalise it before returning.
- **E2R-R13 (RECOMMENDED).** Schema IDs are immutable upper-case names ending `_V<n>`, for example `METHOD_FORECAST_V1`. Once a schema is used to freeze a record, its meaning never changes (section 12).
- **E2R-R14 (DECIDED; R2 5.3).** `method_id` is the permanent `E_n`. `method_revision` changes when the method's specification or implementation changes. `variant_id` names an estimator, fit, view or selection alternative under the same hypothesis. IDs are never reused or renumbered. Formats:
  - `method_id`: `E_[1-9][0-9]*`;
  - `variant_id`: `[A-Z0-9_]{3,96}` (as Package 2);
  - `method_revision`: a positive integer written as text.
- **E2R-R15 (RECOMMENDED).** Vectors indexed by label are JSON arrays in ascending label order, element 1 for label 1. The record also states `label_low` and `label_high`, so the order is never implicit.

---

## 5. (A) Method declaration - stage-1 field 1, and fields 3 and 4 as declarations

One declaration exists per `(game_id, method_id, variant_id, method_revision)`. It is static: it never depends on a target or on data.

### 5.1 Fields (schema `METHOD_DECLARATION_V1`)

| Field | Type | Rule | Source |
|---|---|---|---|
| `schema` | text | `METHOD_DECLARATION_V1` | E2R-R13 |
| `game_id` | text | `POWERBALL` or `OZLOTTO` | field 1 |
| `profile_version`, `era_id` | text | must equal the frozen game profile | field 1 |
| `method_id`, `variant_id`, `method_revision` | text | E2R-R14 | field 1 |
| `registry_status` | enum | `SUPPORTED`, `FORMULA_OPEN`, `UNSUPPORTED_FOR_GAME` | field 1; R2-C13 |
| `registry_status_reason` | text | non-empty, always | field 1 ("with its reason") |
| `method_name` | text | the exact registered name (R2 section 7.1) | field 1 |
| `one_liner` | text | one sentence, plain English | field 1; R2 6.2 |
| `short_explanation` | text | a short paragraph, plain English | field 1; R2 6.2 |
| `text_provenance` | object | `author`, `date`, `text_version`, `source_reference` | field 1 ("per-version provenance") |
| `observation_views` | list | non-empty subset of `UNORDERED_SET`, `OPERATOR_DRAWN_ORDER`, `PAIRED_DIAGNOSTIC` | R2 4; Architecture 20A |
| `uses_dates` | bool | true only if the method reads dates (opt-in; Architecture 20A) | R2 5.6 |
| `minimum_history_draws` | int | at least 1; for fewer eligible prior draws, status `INSUFFICIENT_HISTORY` | R3 17.3.6 |
| `stochastic_fit` | bool | true if fitting uses random numbers (section 6.5) | R2 9.2 |
| `fit_sampling_model_version` | text | the fit's observation model | R3 0.4 (ERR-R2-04) |
| `channels` | object | one entry per barrel of the profile (5.2) | fields 2 and 3 |
| `is_capability` | enum | `IS_STATIC`, `IS_STATEFUL`, `IS_NOT_APPLICABLE` | field 4; R2 8.4.3 |
| `is_interface_version` | text or null | null unless a reviewed fit/apply interface exists for this variant (section 11) | field 4 |
| `source_method_dependencies` | list | empty for ordinary methods; reserved for ensembles (section 11) | R2 5.3, 8.3 |

### 5.2 Per-barrel channel declaration

For each barrel in the game profile (Powerball: `MAIN` 1-35 choose 7 and `POWERBALL` 1-20 choose 1; Oz Lotto: `MAIN` 1-47 choose 7):

| Field | Values |
|---|---|
| `ranking_capability` | `FULL_RANKING` (scores for every label; a complete ranking) or `NONE` |
| `score_type` | `INTEGER`, `FLOAT64` or `NONE` (with `NONE` ranking) |
| `top_rule_id` | `TOP_MARGINAL` (first k of the ranking), `MAP_SET` (a native joint-set choice) or `TOP_UNAVAILABLE` |
| `worst_rule_id` | `INVERSE` (with `TOP_MARGINAL`), `INVERSE_FROM_MARGINALS` (with a native joint-set TOP), or `INVERSE_UNAVAILABLE` |
| `readout_selection_rule_version` | the version of the readout rule (R3 0.4) |
| `ranking_tie_readout_version` | `TIE_SHA256_V1` (DECIDED; TIE v0.2) |
| `probability_kind` | see 5.3 |
| `probability_sum_tolerance` | a float64; required unless the kind is `NONE` or `ABSENT` |
| `smoothing_note`, `calibration_note` | text; required unless the kind is `NONE` or `ABSENT` |

### 5.3 Probability kinds (DECIDED; R2 5.6 field 3)

| Barrel | Allowed `probability_kind` | Vector rule |
|---|---|---|
| `MAIN` (either game) | `NONE` | no vector |
| | `NORMALIZED_LABEL_PROBABILITY` | length = number of labels; each in [0, 1]; sum 1 within tolerance |
| | `MARGINAL_INCLUSION_PROBABILITY` | length = number of labels; each in [0, 1]; sum 7 within tolerance |
| `POWERBALL` (Powerball only) | `NONE` | no vector |
| | `PB_CATEGORICAL` | length 20; each in [0, 1]; sum 1 within tolerance |
| Powerball channel in Oz Lotto | `ABSENT` | no channel, no vector, no field values |

- **E2R-R16 (DECIDED).** A probability kind is declared, never inferred from scores or from a theoretical claim. A declared kind with no lawful vector is a validation failure, not a silent downgrade.
- **E2R-R17 (RECOMMENDED).** The default tolerance is an absolute error of at most 1e-12 on the sum (the example in R2 5.6). A method may declare a different value with its reason; values above 1e-9 need reviewer agreement.
- **E2R-R18 (DECIDED; R2 2.5, R2 5.6 field 7).** No declaration, request, view, record or vector of a predictor ever names or carries Oz Lotto supplementary numbers. Methods never forecast supplementaries.

### 5.4 Declaration rules

- **E2R-R19 (DECIDED; current registry).** E_1 is `SUPPORTED` for both games. E_2 to E_62 are `FORMULA_OPEN` until each method's specification is ratified, implemented and reviewed. A `FORMULA_OPEN` or `UNSUPPORTED_FOR_GAME` declaration is valid and stays registered. It can never produce a forecast record.
- **E2R-R20 (RECOMMENDED).** `UNSUPPORTED_FOR_GAME` is used only for a structural reason, for example a method that needs a Powerball barrel declared for Oz Lotto. It is never used because of performance.
- **E2R-R21A (DECIDED; owner decision D-3, 28 October 2026).** `method_name`, `one_liner` and `short_explanation` are written, in plain English, for E_1 and E_2 in the E_2-readiness code package. For E_3..E_62 they are written with each method's own specification. Until then, those declarations carry the exact R1/R2 name, and their one-liner and explanation say plainly that the method is not yet specified. Every text is reviewed with the package that introduces it.
- **E2R-R21 (RECOMMENDED).** The declaration's digest (canonical bytes) is quoted by every forecast record it governs. Changing any declared field means a new declaration, with a new `method_revision` or `variant_id` where the science changed.

---

## 6. (B) Run request and the method-facing task

### 6.1 Run request (orchestration side; schema `RUN_REQUEST_V1`)

The run request extends today's development pin (`DEVELOPMENT_MASTER_PIN_V1_REVIEW`):
- **identity:** `game_id`; `method_id`; `variant_id`; `method_revision`; the target `draw_number`; `observation_view`; `include_dates`; `run_mode`; `product_kind`; the declaration digest;
- **run ID:** `mg-...` (Package 2's game-qualified format), which replaces the `e1-` prefix;
- **pin:** `master_file`, `ledger_version`, `master_sha256`.

- **E2R-R22 (DECIDED; Architecture 20A).** The reader verifies the pin, the ledger and the INIT record. It refuses symlinks and hard links and parses no row at or after N. The pin is orchestration-only.
- **E2R-R23 (RECOMMENDED).** The run ID, the pin, file paths, times, process IDs and worker numbers never enter the method task or the forecast record's content.

### 6.2 Method-facing task (what a method receives)

A method receives exactly:
- the `DrawView` (prefix only);
- a read-only `MethodTask` holding `game_id`, `profile_version`, `era_id`, `method_id`, `variant_id`, `method_revision`, `target_draw_number`, `observation_view`, `include_dates`, `run_mode` and `product_kind`.

None of these depends on target-and-later bytes.

- **E2R-R24 (RECOMMENDED).** `MethodTask` is frozen (no setters) and holds no path, master hash, ledger or INIT data. The T-05 harness walks its fields exactly as it walks `DrawView.__slots__`.
- **E2R-R25 (RECOMMENDED).** The permitted-view digest is the reader's existing generic digest. For legacy E_1 it is the frozen legacy digest. The contract module exposes it under the neutral name `permitted_view_digest(view)` by calling the existing reader method. **The reader file is not changed by this package.**

---

## 7. (C) Forecast record - stage-1 fields 2, 3 (vectors) and 6 (method-visible identity)

### 7.1 Header fields (schema `METHOD_FORECAST_V1`)

| Field | Rule |
|---|---|
| `schema` | `METHOD_FORECAST_V1` |
| `game_id`, `profile_version`, `era_id` | from the profile |
| `method_id`, `variant_id`, `method_revision`, `declaration_digest` | from the declaration |
| `target_draw_number` | N |
| `draw_key` | display only (`POWERBALL_1300`); never an identity |
| `training_last_draw_number` | N - 1 in historical modes (R2-C07A) |
| `observation_view`, `include_dates` | as requested; must be declared |
| `permitted_view_digest` | E2R-R25 |
| `fit_sampling_model_version` | from the declaration |
| `fit_seed_identity` | null if `stochastic_fit` is false; otherwise section 6.5 |
| `run_mode`, `product_kind` | section 9 |
| `record_status` | section 7.4 |
| `barrels` | one object per profile barrel (7.2) |
| `warnings` | list of text; empty if none |
| `canonical_content_digest` | SHA-256 of the canonical bytes of the record without this field |

- **E2R-R26 (DECIDED; R2 5.3, R2-C19, T-05, T-16).** The content digest covers only pre-target, suffix-invariant content. It excludes run IDs, times, environment, worker identity, paths and every whole-file or ledger hash. Two runs that see the same permitted prefix produce byte-identical records.

### 7.2 Per-barrel output

| Field | Rule |
|---|---|
| `barrel_id` | from the profile (`MAIN`, `POWERBALL`) |
| `label_low`, `label_high`, `selected_count` | from the profile |
| `ranking_status` | `AVAILABLE` or `UNAVAILABLE` (with `ranking_unavailable_reason`) |
| `scores` | score per label, in label order (E2R-R15); integers or float64 per `score_type` |
| `score_direction` | `HIGHER_IS_BETTER` (the only value in V1) |
| `ranking` | the complete frozen ranking: a permutation of all labels, best first |
| `tie_groups` | the labels with exactly equal scores (groups of two or more), each sorted ascending; the groups ordered by their first appearance in `ranking` |
| `tie_identity` | `{version: TIE_SHA256_V1, domain, permitted_view_digest, target, method_id, variant_id, barrel_id}` |
| `ranking_digest` | SHA-256 of canonical `{scores, ranking, tie_version}` for this barrel |
| `top` | `{status, rule_id, rule_version, labels}` |
| `worst` | `{status, rule_id, rule_version, labels}` |
| `probability` | `{kind, vector, tolerance, smoothing_note, calibration_note, provenance, digest}`; or `{kind: NONE}`; omitted for an `ABSENT` channel |

### 7.3 Validation rules (the "shape and numeric contracts")

- **E2R-R27.** `ranking` contains each label exactly once. Scores are non-increasing along `ranking`.
- **E2R-R28 (DECIDED; R3 2.4, TIE v0.2).** Within each equal-score group, the order in `ranking` is ascending `TIE_SHA256_V1` digest, with a numeric-label fallback only on a digest collision. The tuple uses the record's own `permitted_view_digest`, target, method, variant, barrel and tie version. The validator recomputes it.
- **E2R-R29 (DECIDED; R3 2.4, T-31).** With `TOP_MARGINAL`, `top.labels` equals the first k labels of `ranking`, and with `INVERSE`, `worst.labels` equals the first k labels of the exact reversal of `ranking` (k = `selected_count`). Both come from the one frozen ranking. Neither is re-ranked or refitted.
- **E2R-R30 (DECIDED; R2-C11, T-32).** With `MAP_SET`, `top.labels` is the method's native joint choice, recorded as given and validated for size, range and uniqueness. `worst` uses `INVERSE_FROM_MARGINALS` from the frozen marginal ranking, and overlap with TOP is allowed.
- **E2R-R31 (DECIDED; R2 5.6 field 2, R3 2.3).** TOP and WORST statuses are recorded **independently**, per barrel:
  - available: `PREDICTION_AVAILABLE`;
  - unavailable, with a reason: `TOP_MAIN_UNAVAILABLE`, `TOP_PB_UNAVAILABLE`, `INVERSE_MAIN_UNAVAILABLE`, `INVERSE_PB_UNAVAILABLE`. In the R3 evaluation vocabulary the inverse ones count as `INVERSE_UNAVAILABLE`.
  - An inverse is never manufactured. Without a full ranking, `worst` is unavailable whatever TOP is.
- **E2R-R32.** Labels in any selection are distinct integers within the barrel's range, and there are exactly k of them.
- **E2R-R33.** Every score is a finite value of the declared type (no NaN, no infinity, no negative zero). A method that wants an "infinite" or "never seen" value must map it to a finite score under its own ratified method specification. The contract has no sentinel values.
- **E2R-R34.** A probability vector has the declared length. Every element is in [0, 1] and finite, and the sum is within the declared tolerance of 1 (or 7). Its `digest` is the SHA-256 of the canonical vector.
- **E2R-R35.** A validation failure produces no forecast record. It produces a run failure status on the orchestration side (section 8), and the failure is counted, never hidden (R3 3.6).

### 7.4 Record status (method-level)

`record_status` uses the R3 evaluation vocabulary, kept separate from the benchmark and registry vocabularies (DECIDED; R3 3.6, H-1 5.2):
- `PREDICTION_AVAILABLE`: at least one barrel has an available TOP or WORST;
- `DIAGNOSTIC_ONLY`: the method produced no ticket (R2 6.4; R2-C10's `NOT_PREDICTIVE_YET` is recorded under this R3 name);
- `INSUFFICIENT_HISTORY`: fewer than `minimum_history_draws` eligible prior draws. No numbers are recorded.

`RUNTIME_FAILURE` and `NUMERIC_INVALID` never appear in a forecast record. They belong on the orchestration side (section 8), because a failed run has no valid canonical forecast.

### 7.5 The frozen tickets

For each track (section 8.2), the **ticket** for a target is the barrel selections of that readout:
- Powerball: 7 main labels plus 1 Powerball;
- Oz Lotto: 7 labels.

A ticket with any barrel unavailable is unscored for that track, and the status is counted (R3 17.3.4).

### 7.6 Fit seed identity (always-review subject; RECOMMENDED; R2 9.2, R3 0.4)

For `stochastic_fit` methods only:

`fit_seed_identity = SHA-256 of the length-delimited tuple (domain "PREDICTIVE_RANDOMNESS/FIT_SEED_V1", run_mode, method_id, method_revision, variant_id, observation_view, fit_sampling_model_version, target, permitted_view_digest, external_input_digest or "NONE", fitting_config_digest, restart_index)`

- The tuple uses the ratified TIE length-prefix encoding.
- The NumPy `SeedSequence` entropy is that digest's bytes.
- It never includes the whole-file hash, a time, a process ID or a worker position.
- The readout rule is excluded: changing only TOP or WORST readout cannot change the fit (ERR-R2-04).
- Code for this is written only with the first stochastic method, and it always gets RECHECK (review-disposition procedure, section 4).

---

## 8. (D) Freeze receipt and track provenance - stage-1 fields 5 and 6 (orchestration side)

### 8.1 Freeze receipt (schema `FORECAST_FREEZE_RECEIPT_V1`; one per forecast record)

| Field | Meaning |
|---|---|
| `forecast_content_digest` | the record's `canonical_content_digest` |
| `forecast_file_sha256` | SHA-256 of the frozen file's bytes |
| `game_id`, `target_draw_number` | the target `(game_id, draw_number)` |
| `master_file`, `ledger_version`, `master_sha256`, `ledger_sha256`, `init_record_sha256` | provenance only (E2R-R02) |
| `environment_identity` | Python version, NumPy version, psutil version, OS name and build, and the digest of the installed package list |
| `run_id`, `execution_path` | `mg-...`; `STANDALONE` or `COORDINATED` |
| `run_mode`, `product_kind`, `evidence_tier`, `score_status` | section 9 |
| `window` | `[S, L]` when part of a declared window, else null |
| `cohort_id` | a predeclared cohort ID, `EXPLORATORY_COHORT`, or null |
| `status_before_opening` | the per-barrel TOP and WORST statuses and the record status, copied before any outcome is opened |
| `outcome_opened_at_freeze` | always `false` |
| `frozen_at_utc` | orchestration clock (informational; R2 8.2A says commit times are not proof of timeliness) |

- **E2R-R36 (RECOMMENDED).** The receipt is create-only (`os.rename` / exclusive create; never `os.replace`). It is written only after the forecast file is frozen and validated.
- **E2R-R37 (DECIDED; R2 5.6 field 6).** The receipt may differ between two runs that see the same prefix, for example when the master grew. The forecast record must not.
- **E2R-R38 (DECIDED; failed-group firewall, register 23 October 2026).** A run whose status is not a clean success, or whose group is FAIL or orphan-suspected, has no consumable forecast, even if a forecast file exists. The receipt records the failure (`RUNTIME_FAILURE`, `NUMERIC_INVALID`, `TIMEOUT` or a validation failure, with a reason) and no forecast digest.

### 8.2 Tracks

- **E2R-R39 (DECIDED; R3 17.3.4).** A track is `(game_id, method_id, variant_id, readout, mode)`, with readout `TOP` or `WORST` and mode `WF` or `IS`. TOP and WORST of one method and variant come from one ranking, are dependent, and are never counted as unrelated evidence.
- **E2R-R40 (RECOMMENDED format; DECIDED content, owner decision D-1).** `track_id` is the text `GAME:METHOD:VARIANT:READOUT:MODE`, for example `POWERBALL:E_2:EXAMPLE_VARIANT:TOP:WF`. `method_revision` is carried in every record, but is not part of `track_id`. Reports never pool different revisions in one series without a disclosed policy (R3 3.5).
- **E2R-R40A (DECIDED principle, owner decision D-1 and the owner's question of 28 October 2026; RECOMMENDED wording).** Which revision a report uses:
  - A track continues across revisions. Each report or table uses **one declared revision per track** and states it. The default is the latest revision whose method specification is ratified and whose implementation is accepted.
  - Records of other revisions are kept. They are never silently mixed in, and appear only when a report explicitly asks for a labelled side-by-side comparison.
  - Re-running a revision on past draws adds new records for the same targets. It never modifies or replaces earlier records (R2 8.2A, T-36).
  - Prospective records (published before the draw) of every revision are permanent. A later revision re-run over those draws is labelled retrospective development walk-forward, never prospective (R3 17.3.5, 17.3.9).
  - Why superseded results are kept: prospective forecasts cannot be recreated; comparing revisions on the same development draws shows how much of an apparent gain could be tuning to known results (pattern origin PO-3, R3 17.3.9 and 6.2); and the record is never made to look tidier than it was (mark, never suppress).

---

## 9. Separate product, mode, score status and evidence tier - stage-1 field 5

Today the code and documents use overlapping words: Package 2's `SYNTHETIC_CONTRACT_TEST`, `COORDINATED` and `FINAL`; E_1's `REAL_HISTORICAL_DEVELOPMENT`; R2 8.1's run modes; and R3's `WF` / `IS`. The contract keeps five separate fields:

| Field | Values (closed) | Meaning |
|---|---|---|
| `run_mode` | `REAL_DEVELOPMENT`, `REAL_HOLDOUT`, `FINAL_NEXT_DRAW`, `IN_SAMPLE_DIAGNOSTIC`, `SYNTHETIC_CONTRACT_TEST`, `SYNTHETIC_NULL`, `SYNTHETIC_PLANTED`, `SYNTHETIC_IDENTIFIABILITY`, `BENCHMARK_REAL`, `BENCHMARK_SYNTHETIC` | the data namespace and purpose (R2 8.1, plus Package 2's synthetic contract mode) |
| `product_kind` | `WF_FORECAST`, `IS_DIAGNOSTIC_ENTRY`, `SYNTHETIC_TEST_OUTPUT`, `BENCHMARK_TIMING` | what the record is |
| `execution_path` | `STANDALONE`, `COORDINATED` | how it was run (receipt only) |
| `evidence_tier` | `DEVELOPMENT_WF_EXPLORATORY`, `HOLDOUT_MODE_H`, `PROSPECTIVE`, `IS_DESCRIPTIVE`, `NOT_EVIDENCE` | R3 17.3.9, plus `NOT_EVIDENCE` for synthetic and benchmark records (owner decision D-2, 28 October 2026) |
| `score_status` | `NOT_YET_SCORABLE`, `SCORED`, `NEVER_SCORED` | whether an evaluator record exists or may exist |

- **E2R-R41 (DECIDED as principle; R2 5.6 field 5, R2 8.4.4; RECOMMENDED as table).** Only these combinations are legal. The validator rejects every other one:

| `run_mode` | `product_kind` | `evidence_tier` | Allowed `score_status` |
|---|---|---|---|
| `REAL_DEVELOPMENT` | `WF_FORECAST` | `DEVELOPMENT_WF_EXPLORATORY` | `NOT_YET_SCORABLE`, `SCORED` |
| `REAL_HOLDOUT` | `WF_FORECAST` | `HOLDOUT_MODE_H` | `NOT_YET_SCORABLE`, `SCORED` |
| `FINAL_NEXT_DRAW` | `WF_FORECAST` | `PROSPECTIVE` | `NOT_YET_SCORABLE`, `SCORED` |
| `IN_SAMPLE_DIAGNOSTIC` | `IS_DIAGNOSTIC_ENTRY` | `IS_DESCRIPTIVE` | `NOT_YET_SCORABLE`, `SCORED` (IS namespace only) |
| any `SYNTHETIC_*` | `SYNTHETIC_TEST_OUTPUT` | `NOT_EVIDENCE` | `NEVER_SCORED` (synthetic evaluators write only synthetic-namespace records) |
| any `BENCHMARK_*` | `BENCHMARK_TIMING` | `NOT_EVIDENCE` | `NEVER_SCORED` |

- **E2R-R42 (DECIDED; R2 8.4.4, R3 17.7).** An `IS_DIAGNOSTIC_ENTRY` never enters the R3 scientific score ledger or the result allowlist. It is never counted as WF, holdout or prospective evidence, and never feeds a method or meta-method. WF and IS are modes, not readout variants.
- **E2R-R43 (DECIDED; Package 2).** The coordinated science allowlist `_COORDINATED_SCIENCE_ALLOWLIST` stays strict and **empty** until separately authorised. This contract adds no entry. When entries are later authorised, its key is recommended to bind `(game_id, method_id, variant_id, run_mode, product_kind, schema)`, a migration made then and separately reviewed.
- **E2R-R44 (DECIDED; R2 3.5, Package 2).** `REAL_HOLDOUT` and `FINAL_NEXT_DRAW` exist only as vocabulary. Every code path that would act on them stays refused. Mode H and FINAL stay shut.

---

## 10. (E) Post-outcome score record - stage-1 field 7 (type only)

Schema `POST_OUTCOME_SCORE_RECORD_V1`, one per track per scored target:

| Field | Powerball | Oz Lotto |
|---|---|---|
| `game_id`, `draw_number`, `track_id`, `mode` | yes | yes |
| `forecast_content_digest`, `freeze_receipt_digest` | yes | yes |
| `drawn_main` | 7 labels, ascending | 7 labels, ascending |
| `drawn_powerball` | 1 label | absent |
| `main_matches` | 0..7 | 0..7 |
| `powerball_match` | 0..1 | absent |
| `supplementary_matches` | absent | 0..3, at most 7 - `main_matches` |
| `division` | 0..9 (R3 17.4.2) | 0..7 (R3 17.4.3) |
| `evaluator_version` | text | text |

- **E2R-R45 (DECIDED; R2 2.5, R3 17.4.1, R2 5.6 field 7).** Only the evaluator writes this record, after the target's outcome is opened and the track's frozen forecast exists. It is never fed to a predictor. Supplementary numbers themselves are not stored, only their match count.
- **E2R-R46 (RECOMMENDED; agreed roles position section 10 item 2).** In the E_2-readiness code package, this record exists as a **type and validator only, with no data path**: no function that reads an outcome, and no import from any predictor module. Quarantine opening and the R3 scorer stay separately gated (R3 17.13 stage 2).
- **E2R-R47 (RECOMMENDED).** Mid-rank and other evaluator measures (R3 3.1) are not in this record. Stage 2 adds them in their own versioned evaluator records.

---

## 11. Not-applicable behaviour and extension points

### 11.1 Per capability

| Declared | Required behaviour |
|---|---|
| `ranking_capability: NONE` | no `scores` or `ranking`; TOP `TOP_*_UNAVAILABLE` unless a native `MAP_SET` is declared; WORST `INVERSE_*_UNAVAILABLE`; ranking measures later show `MR_NOT_APPLICABLE` |
| `probability_kind: NONE` | no vector; probability measures (MR6, MR14) later show `MR_NOT_APPLICABLE` |
| `probability_kind: ABSENT` (Oz Powerball) | the barrel does not exist in the record; no zero-padding; nothing for that channel at all |
| `is_capability: IS_NOT_APPLICABLE` | the method appears in WF tables only; any IS request for it is refused |
| `IS_STATIC` / `IS_STATEFUL` | a declaration only; no IS run is possible until a reviewed `is_interface_version` exists and the owner authorises IS |
| registry `FORMULA_OPEN` / `UNSUPPORTED_FOR_GAME` | every run request is refused before any data is read; the method stays registered and listed |
| `record_status: DIAGNOSTIC_ONLY` | no tickets; the track's targets are counted as unscored with that status |

### 11.2 Extension points, reserved but not implemented

- **E2R-R48 (DECIDED; R2 5.6 acceptance list, R3 17.13).** The following are reserved by name only. None is implemented in the E_2-readiness package:
  - the IS fit/apply interface (`is_interface_version`);
  - ranking and league-table code (R3 17.13 stages 2-4);
  - ensembles and source dependencies (`source_method_dependencies`, which must form an acyclic graph; R2 5.3);
  - ordered-sequence and joint-set distribution channels (R2 5.1 items 5 and 6), which arrive as a new schema version;
  - external covariates (E_54).

---

## 12. Versioning and migration rule

- **E2R-R49 (RECOMMENDED).** A frozen schema's meaning never changes. Any change to a field, vocabulary or rule is a new schema ID (`_V2`). Old schemas stay readable by validators, for history and reports, and can never be written again.
- **E2R-R50 (DECIDED; R2 5.5).** Legacy E_1 records and goldens are frozen and never rewritten or re-hashed:
  - the `E1_*` schemas;
  - the legacy view digest;
  - the three synthetic goldens and the 1577 forecast-only pair.

  The `legacy_powerball_game_id` compatibility rule applies only to those legacy schemas.
- **E2R-R51 (RECOMMENDED).** E_1 is migrated by adding a `METHOD_DECLARATION_V1` for E_1 and allowing it to write `METHOD_FORECAST_V1` records in synthetic contract tests. A new schema has a new hash (R2 5.5, "a distinct version and distinct hash"). The acceptance test (E2R-T09) requires, for the same synthetic fixture:
  - the new record's scores, ranking, TOP and WORST to equal the legacy ones label for label;
  - the legacy goldens to still reproduce.
- **E2R-R52 (DECIDED; Architecture 20A).** The E_1-only conventions are retired for new work:
  - the `e1-` run-ID prefix (new runs use `mg-`);
  - hard-coded method, variant and schema constants (now from the declaration);
  - Powerball-only output names and checks (now game-namespaced: `<root>/<game_id>/<method_id>/<variant_id>/<run_id>/`);
  - hard-coded target ceilings (now the profile's `historical_development_target_allowed`). The E_1 1577 forecast-only regression stays as a named legacy test.

---

## 13. Acceptance before E_2 (DECIDED list, R2 5.6; tests RECOMMENDED)

All tests are offline. They use synthetic fixtures and, where noted, the accepted development masters read only through the reader at targets below the development boundary. No outcome at or after the boundary is read.

| Test | Acceptance item | What it checks |
|---|---|---|
| E2R-T01 | Shape and numeric contracts | Each rule E2R-R27..R34 has a passing case and at least one failing case: wrong length, duplicate label, out-of-range label, NaN, infinity, negative zero, wrong sum, an int beyond int64, unknown field, unknown schema |
| E2R-T02 | Profile separation between games | Powerball and Oz Lotto declarations, records and vectors cannot be cross-validated. Barrel sizes come only from the profile. A record for one game is refused under the other |
| E2R-T03 | Prefix-only view and digest independence (T-05) | The TH-1 harness extended to records: for a synthetic contract method, at four targets per game, three views and two date modes, two equal-length suffix rewrites and one longer, the forecast record's canonical bytes and digest are identical. The freeze receipt's master SHA differs. `MethodTask` fields are walked like `DrawView` slots |
| E2R-T04 | R3 tie and WORST consistency | The tie order is recomputed from TIE_SHA256_V1. TOP is the first k and WORST the reversal (T-31). Native `MAP_SET` with `INVERSE_FROM_MARGINALS` is allowed to overlap (T-32). No full ranking gives explicit unavailable statuses (T-33) |
| E2R-T05 | No Powerball or supplementaries in Oz predictor views | Static: no predictor or contract module names supplementary columns. Runtime: an Oz `DrawView`, `MethodTask` and record carry no Powerball or supplementary field |
| E2R-T06 | Mode firewall | Every combination outside the E2R-R41 table is rejected. IS records are refused by the (empty) allowlist path. `REAL_HOLDOUT` and `FINAL_NEXT_DRAW` requests are refused |
| E2R-T07 | Not-applicable behaviour per capability | Each row of the 11.1 table, including Oz `ABSENT` with no zero-padding and `FORMULA_OPEN` refused before any read |
| E2R-T08 | Extension points without early implementation | Static check: no IS engine, ranking code or ensemble execution exists. `is_interface_version` is null for every declaration |
| E2R-T09 | Schema versioning and migration | Old schemas are readable and refused for writing. An unknown schema is refused. E_1's legacy goldens reproduce. E_1's `METHOD_FORECAST_V1` equals legacy label for label (E2R-R51) |
| E2R-T10 | B1 and seed hygiene (R2-C19) | No master, ledger or INIT hash appears anywhere in a `MethodTask` or forecast record. Mutation checks (disposable copies only) put the master SHA, the file length or a tail of bytes into the task and expect E2R-T03 to fail |
| E2R-T11 | Post-outcome record has no data path | The type validates synthetic values only. A static import check shows no predictor module imports it, and it contains no function that opens a file |
| E2R-T12 | Determinism (R2 9.3) | The same inputs give byte-identical records across two runs and across one and six workers (synthetic, in-process) |

- **R-4 oracle (agreed roles position section 10, item 2).** The reviewer may write an independent T-05 oracle from this specification without reading Claude's implementation. Agreement with it is evidence, not authorisation.
- **Mutation checks.** For each of E2R-T01, T03, T04, T06 and T10, Claude shows that a planted defect makes the test fail, on disposable copies only.

---

## 14. Owner decisions recorded, and what remains for ratification

**Owner decisions, 28 October 2026** (made on Claude's recommendations, before review):
- **D-1 (was OPEN-1):** `track_id` does **not** include the method revision. A track continues across revisions, and every record carries `method_revision` (E2R-R40, E2R-R40A).
- **D-2 (was OPEN-2):** synthetic and benchmark records get the evidence tier **`NOT_EVIDENCE`**. It is never shown in a league table (section 9).
- **D-3 (was OPEN-3):** the method name, one-liner and short explanation are written for **E_1 and E_2** in the E_2-readiness code package. Each later method's texts are written with its own specification (E2R-R21A).

**RECOMMENDED** for ratification with the document, unless the reviewer or owner objects:
- **Structure:** the five record families and their digest links (E2R-R08), and the method-computes / contract-assembles split (E2R-R07).
- **Encoding:** the canonical encoding, the float and negative-zero rules and schema naming (E2R-R10..R15).
- **Records:** the field tables of sections 5, 7, 8 and 10.
- **Vocabulary:** the five-field mode vocabulary and its legal-combination table (section 9).
- **Seeds:** the seed derivation (7.6), coded only with the first stochastic method.
- **Versioning:** the migration rule (section 12).
- **Tests:** the test list (section 13).

**OPEN:** none at this draft. The reviewer may raise new questions for the owner.

*Document references: R2 v0.5 sections 2.5, 3.1, 3.5, 3.6, 5.1-5.6, 6, 8.1-8.4, 9.2-9.3, 11.1; R3 v0.5 sections 0.4, 2.1-2.4, 3, 17.3, 17.4, 17.7, 17.13; Architecture v0.8 section 20A; TIE_SHA256_V1 v0.2; agreed roles position section 10; register v0.6.*

*End of specification draft v0.2.*
