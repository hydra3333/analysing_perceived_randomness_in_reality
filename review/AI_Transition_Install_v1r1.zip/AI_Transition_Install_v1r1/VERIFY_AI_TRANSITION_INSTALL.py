#!/usr/bin/env python3
"""Read-only installation verifier for the AI roles transition commit (Claude, 27 Oct 2026; r1).

r1: four of the 19 manifest files were already committed, byte-identical, by the owner in commit
6460ae3 (after base ae76c29). They must be present at HEAD with the expected blobs; the
transition commit adds the other 15. Nothing else changed from v1.

Standard library only. Does not import project code, run tests, change files or touch Git state.
Phases:
  pre        clean tree; HEAD descends from the base commit; every new path absent;
             ratified predecessor editions unchanged at HEAD.
  post       after copying the overlay: every new file has the expected bytes (CRLF tolerated in
             the working copy; Git stores LF); predecessors unchanged; only the 15 not-yet-committed
             paths are new or changed.
  committed  after the commit: clean tree; every expected file is in HEAD with the exact
             expected Git blob bytes; the last commit added exactly those 15 paths.
Usage: python VERIFY_AI_TRANSITION_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = 'ae76c29783856dbb9bf0076fabe0c3612340314e'
PREDECESSORS = {  # files that must stay byte-identical in Git (LF content SHA-256)
    'doc/RATIFICATION_REGISTER_v0_4.md': 'cdb8c24eeb1a855a042cfebed30a801e9e36a654ccc655b5a2b8cc4eba4585d7',
    'doc/HANDOVER/HANDOVER_CHANGED_AI_Roles_Agreed_v0_1r1_RATIFIED.md': '7d572400b941ad423978a7542d6c32fb73c934f0057240dbc5138898112bd53b',
    'doc/HANDOVER/Claude_Delta_Handover_D1_since_v10_v1.md': 'ac6dda4f6f965637118dbf2811cb4006497006e10f7be72476e5acd64c37a50c',
    'review/ChatGPT_Coder_ADD_2_Package2_v0_11r1_v0_1.md': 'ebaff99f4fc34ce38099ac5581abada7a1d0ffd1d8a7b7bfe3a0ce5fbb41f35b',
    'doc/HANDOVER/Claude_Reviewer_Handover_Predictive_Randomness_v10.md': '61a5127816d30e2ffc342a011e3d029d7a3a6a80bc55c368751cc9d09ed9b191',
    'doc/HANDOVER/Predictive_Randomness_ChatGPT_Coder_Handover_v1_1r1.md': 'ab0afb64cec845cbbde29265e53309225991cd4a469306c609b905aff9048a01',
    'doc/HANDOVER/Interim_Handover_Note_for_both_claude_and_chatgpt_v1.md': 'a46866cad2c8d16869685f3a37b898dc453bf651572e60d27579024a2015a1e5',
    'doc/HANDOVER/Claude_Checkpoint_v2.md': '33ddaf9c1d0d35726088d832893f72c7c97e532967c24b63cc36e6822f2693cf',
    'doc/HANDOVER/Package2_v0_11r1_Acceptance_Deferred_Work_v0_1.md': '42a75e0d75d33b4d8538070ba557b7e1a8ecc7117205baf131041473227a3ad3',
    'doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md': '53e30a3e649b48b8a88923d08bf578caf04a4ce93d6ea6468891ca97e93a57b6',
    'doc/Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md': '2c67db8fcba50e469b0490cd85caf2fe964b3b79fc17fe7da4ebf033b91d9a3e',
    'doc/Predictive_Randomness_Software_Architecture_Discussion_v0_8.md': '32cf157d9ce8850e790274e962236f2be3b50a8bdee7ec94a28ba00d7fd452ec',
    'doc/Predictive_Randomness_Research_Project_Proposal_v0_6.md': '6a281e05127e7db976a16557ba69006327a8d615c2b0ec90bb6b34ee1c648a73',
}
MANIFEST = 'review/AI_Transition_Install_v1/INSTALL_MANIFEST_SHA256.txt'
PRECOMMITTED = {  # committed by the owner in 6460ae3, byte-identical to the manifest entries
    'review/ChatGPT_Reviewer_Handover_H2_v1.md',
    'review/Claude_Transition_Docs_Review_v1.zip',
    'review/Independent_ChatGPT_Focused_Review_MR_Integration_Install_v1.md',
    'review/MR_Integration_Install_v1r1.zip',
}
# r1 (C-INSTALL-01): every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0, so that
# 'git status' never refreshes or rewrites .git/index (git-status docs, BACKGROUND REFRESH).
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')


def sha(b):
    return hashlib.sha256(b).hexdigest()


def git(repo, *args):
    r = subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def expected():
    """Path -> SHA-256: the manifest's installed-file list, plus the manifest's own bytes."""
    raw = (HERE / 'repo_overlay' / MANIFEST).read_bytes()
    exp = {}
    for line in raw.decode('ascii').splitlines():
        if line and not line.startswith('#'):
            h, p = line.split('  ', 1)
            exp[p] = h
    exp[MANIFEST] = sha(raw)
    need(len(exp) == 19, f'expected 19 files in the package manifest, found {len(exp)}')
    for p, h in exp.items():  # the package itself must be intact
        need(sha((HERE / 'repo_overlay' / p).read_bytes()) == h, f'package file damaged: {p}')
    return exp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    a = ap.parse_args()
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    exp = expected()
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = subprocess.run(['git', '--no-optional-locks', '-C', str(repo), 'merge-base', '--is-ancestor', BASE, 'HEAD'],
                         env=GIT_ENV)
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    status = git(repo, 'status', '--porcelain', '--untracked-files=all').decode(errors='replace')
    for p, h in PREDECESSORS.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'ratified predecessor changed in Git: {p}')
    print(f'{len(PREDECESSORS)} ratified predecessor files unchanged in Git HEAD')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        for p, h in exp.items():
            if p in PRECOMMITTED:
                need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'pre-committed file differs at HEAD: {p}; STOP')
            else:
                need(not (repo / p).exists(), f'new path already exists: {p}; STOP, do not overwrite')
        print('PRE PASS: clean tree; 4 files already committed with the expected bytes; the other 15 paths absent. Nothing was changed.')
        return

    if a.phase == 'post':
        changed = set()
        for line in status.splitlines():
            path = line[3:].strip().strip('"')
            changed.add(path.replace('\\', '/'))
        new = set(exp) - PRECOMMITTED
        need(changed == new, 'unexpected changed paths: ' + ', '.join(sorted(changed ^ new)))
        for p, h in exp.items():
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            data = f.read_bytes()
            if not p.endswith('.zip'):  # text: Git stores LF; a CRLF working copy is normalised
                data = data.replace(b'\r\n', b'\n')
            need(sha(data) == h, f'wrong bytes: {p}')
        print('POST PASS: exactly the 15 expected new files; all 19 manifest files have the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    for p, h in exp.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    names = git(repo, 'diff', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    need(set(got) == set(exp) - PRECOMMITTED and set(got.values()) == {'A'},
         'the last commit did not add exactly the 15 expected paths: ' + repr(sorted(got.items()))[:600])
    print('COMMITTED PASS: the last commit added exactly the 15 new files; all 19 manifest files match their Git blobs.')


if __name__ == '__main__':
    try:
        main()
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        sys.exit(2)
