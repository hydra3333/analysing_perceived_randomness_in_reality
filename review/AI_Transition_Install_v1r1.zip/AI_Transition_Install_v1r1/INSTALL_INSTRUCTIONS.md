# AI roles transition - installation package v1r1

**Prepared by Claude, 27 October 2026. r1:** only the verifier, the staging script and these instructions changed. Four of the 19 files were already committed by the owner, byte-identical, in commit `6460ae3` (after base `ae76c29`): `review/ChatGPT_Reviewer_Handover_H2_v1.md`, `review/Claude_Transition_Docs_Review_v1.zip`, `review/Independent_ChatGPT_Focused_Review_MR_Integration_Install_v1.md` and `review/MR_Integration_Install_v1r1.zip`. The r1 verifier requires them at HEAD with the expected blobs, and the transition commit adds the other 15. `repo_overlay/` and its manifest are byte-identical to v1 (`e5cd06d5...5e1f`), which the ChatGPT reviewer passed.

**Earlier note:** The project owner ratified, on 27 October 2026: H-1 v1r1, H-2 v1r2 (including the reviewer rights R-8..R-11 and section 3.1), H-3 v1r1 and register v0.5, with the final mechanical edits below. **The commit that installs these files is the effective commit of the AI roles transition**: from it, Claude is primary designer and coder and the ChatGPT reviewer chat is the independent reviewer. The owner copies, stages, commits and pushes; Claude then verifies against Git. Nothing here authorises any run, test, holdout access, switch change or code change.

## 1. What this ZIP holds

- `repo_overlay/`: **19 new files**; no existing file changes; no deletions.
  - `doc/HANDOVER/`: H-1 (`Claude_Primary_Handover_H1_v1r1.md`), H-2 (`ChatGPT_Reviewer_Handover_H2_v1r2.md`, byte-for-byte as its author delivered it), H-3 (`AI_Roles_Transition_Record_H3_v1r1.md`).
  - `doc/RATIFICATION_REGISTER_v0_5.md`.
  - `review/`: the review record of the transition and the integration install (the ChatGPT reviews, Claude's fact checks of H-2, the earlier H-2 drafts, the review ZIPs, and `MR_Integration_Install_v1r1.zip`, the package used for `ae76c29`).
  - `review/AI_Transition_Install_v1/`: the external manifest (which holds register v0.5's own SHA-256), the scripts that made the edits, and the exact diffs.
- `VERIFY_AI_TRANSITION_INSTALL.py`: a read-only checker (standard library; every Git call uses `--no-optional-locks`).
- `STAGE_EXACT_FILES.cmd`: optional; stages exactly the 15 new files. It does not commit or push.

## 2. The final mechanical edits (all in `ratified_to_installed.diff`)

- **H-1:** records the owner's ratification of R-8..R-11; adds the owner's oversight instruction (first three reviews) to section 1.5.
- **H-3:** C-FINAL-01 (H-2 v1r2 path; exact H-1 and H-3 paths); the recheck result in place of `[RECHECK]`; H-2 v1r2 and its fact check; the owner's ratification of the rights; section 7 items 5 (oversight instruction) and 6 (the ratification).
- **Register v0.5:** OWNER-RATIFIED status; the three handover hashes; the H-2 v1r2 path; the H-2 footer erratum; register v0.4 superseded; the oversight instruction; a note that the handovers keep their authoring-time "DRAFT" headers (the register records their ratification, as for the method-ranking proposal on 26 October).

The register change from v0.4 is still six existing lines plus one new section; all 32 earlier hashes are preserved.

## 3. Install (Windows CMD, repository root)

**First, make the tree clean:** move every untracked file out of the repository (for example to `E:\TEMP\keep2`), so that `git status --short` prints nothing. The overlay supplies the review files it needs; keep `Independent_ChatGPT_Final_Mechanical_Review_AI_Transition_Install_v1.md` and the two install ZIPs for a later small history commit.

Save this ZIP to `E:\TEMP` and extract it there (`tar -xf "E:\TEMP\AI_Transition_Install_v1r1.zip" -C E:\TEMP`), which creates `E:\TEMP\AI_Transition_Install_v1r1\`. Then:

```bat
python "E:\TEMP\AI_Transition_Install_v1r1\VERIFY_AI_TRANSITION_INSTALL.py" --repo . --phase pre
```

Expected: `PRE PASS` (it reports the 4 already-committed files). Then copy and check:

```bat
xcopy "E:\TEMP\AI_Transition_Install_v1r1\repo_overlay\*" . /E /Y
python "E:\TEMP\AI_Transition_Install_v1r1\VERIFY_AI_TRANSITION_INSTALL.py" --repo . --phase post
call "E:\TEMP\AI_Transition_Install_v1r1\STAGE_EXACT_FILES.cmd"
git diff --cached --name-status
```

Expected: `19 File(s) copied` (four of them overwrite identical committed files, which is harmless; `/Y` suppresses the prompts); `POST PASS`; fifteen lines starting with `A`. "LF will be replaced by CRLF" warnings are harmless.

Commit, push, and verify:

```bat
git commit -m "AI roles transition: install H-1, H-2, H-3 and register v0.5 (effective commit)"
git push
python "E:\TEMP\AI_Transition_Install_v1r1\VERIFY_AI_TRANSITION_INSTALL.py" --repo . --phase committed
git rev-parse HEAD
```

Expected: `COMMITTED PASS`. Send Claude the commit ID; Claude verifies every blob from GitHub and records the ID as the effective commit. If anything prints `STOP`, stop and send Claude the output.
