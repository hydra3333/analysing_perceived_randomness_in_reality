@echo off
setlocal
rem OPTIONAL owner-run staging of exactly the 15 new transition files. No commit, push or deletion.
git add -- ^
  "doc\HANDOVER\AI_Roles_Transition_Record_H3_v1r1.md" ^
  "doc\HANDOVER\ChatGPT_Reviewer_Handover_H2_v1r2.md" ^
  "doc\HANDOVER\Claude_Primary_Handover_H1_v1r1.md" ^
  "doc\RATIFICATION_REGISTER_v0_5.md" ^
  "review\AI_Transition_Install_v1\INSTALL_MANIFEST_SHA256.txt" ^
  "review\AI_Transition_Install_v1\finalise_transition.py" ^
  "review\AI_Transition_Install_v1\make_register_v05.py" ^
  "review\AI_Transition_Install_v1\ratified_to_installed.diff" ^
  "review\AI_Transition_Install_v1\register_v0_4_to_v0_5.diff" ^
  "review\ChatGPT_Reviewer_Handover_H2_v1r1.md" ^
  "review\Claude_Fact_Check_H2_v1_v1.md" ^
  "review\Claude_Fact_Check_H2_v1r2_v1.md" ^
  "review\Claude_Transition_Docs_Recheck_v1r2.zip" ^
  "review\Independent_ChatGPT_Focused_Recheck_Claude_Transition_Docs_v1r2.md" ^
  "review\Independent_ChatGPT_Review_Claude_Transition_Docs_v1.md"
if errorlevel 1 (echo STAGING FAILED & exit /b 1)
git status --short
endlocal
