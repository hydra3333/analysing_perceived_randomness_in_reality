"""Offline-only receipt security tests; NO subprocess, network, or real data."""
from __future__ import annotations

import copy
import json
from pathlib import Path
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src' / 'methods'))
from _common.multigame_coordinator_exit_receipt_v1 import (
    issue_coordinator_receipt, verify_receipt_before_consume, _canonical, _hash
)

CODE_HASH = 'a'*64


def setup(root):
    group = root / 'group-test'
    run = root / 'runs' / 'mg-receipttest001'
    group.mkdir(); run.mkdir(parents=True)
    (group / 'receipts').mkdir()
    identity = dict(group_id='group-test', worker_sequence=1,
                    run_id=run.name, game_id='OZLOTTO', draw_number=1479,
                    method_id='E_1', variant_id='FULL_HISTORY_RAW_COUNTS_V1')
    labels = {k: v for k, v in identity.items() if k not in ('group_id', 'worker_sequence')}
    status = {**labels, 'mode':'COORDINATED', 'state':'SUCCESS',
              'pid':3001, 'process_create_time_epoch':1711111111.25}
    result = {**labels, 'schema':'SYNTHETIC_ONLY_V1',
              'payload':{'balls':'no lottery data'}}
    rbytes = _canonical(result)
    status['canonical_result_sha256'] = _hash(rbytes)
    manifest = {**labels, 'mode':'COORDINATED', 'state':'PASS',
                'orphan_suspected':False, 'marker_write_failed':False,
                'canonical_result_sha256':_hash(rbytes)}
    for name, obj in [('status.json',status),('manifest.json',manifest),
                      ('canonical_result.json',result)]:
        (run/name).write_bytes(_canonical(obj))
    agg = {'group_id':identity['group_id'],'success':True,'status':'PASS',
           'orphan_suspected':False,'marker_write_failed':False,
           'workers':[{'sequence':1,'run_id':identity['run_id'],'state':'SUCCESS'}]}
    (group/'manifest.json').write_bytes(_canonical(agg))
    return group, run, identity, result


def issue(group,run,identity,**changes):
    params = dict(group_dir=group, run_dir=run, identity=identity,
                  coordinator_sha256=CODE_HASH, root_pid=2201,
                  root_create_time_epoch=1711111000.125,
                  wrapper_exit_code=0,
                  exit_observed_utc='2026-10-24T02:25:31+00:00',
                  console_result_digest_match=True)
    params.update(changes)
    return issue_coordinator_receipt(**params)


def consume(group,run,identity):
    return verify_receipt_before_consume(group_dir=group,run_dir=run,
        identity=identity,coordinator_sha256=CODE_HASH,
        global_orphan_marker=group.parent/'UNRESOLVED_ORPHAN.json')


class ReceiptTests(unittest.TestCase):
    def test_valid_issue_and_consume(self):
        with tempfile.TemporaryDirectory() as t:
            group,run,ident,result=setup(Path(t))
            path=issue(group,run,ident)
            self.assertEqual(path.parent,group/'receipts')
            self.assertFalse((run/'exit_receipt.json').exists())
            self.assertEqual(result,consume(group,run,ident))
            issued=json.loads(path.read_bytes())
            self.assertEqual(issued['schema'],'MULTIGAME_COORDINATOR_EXIT_RECEIPT_V1_REVIEW')
            self.assertEqual(set(issued['artifact_sha256']),
                {'status.json','manifest.json','canonical_result.json'})
            self.assertEqual(issued['root_pid'],2201)

    def test_preexisting_receipt_is_tamper_fail_no_overwrite(self):
        with tempfile.TemporaryDirectory() as t:
            group,run,ident,_=setup(Path(t))
            path=group/'receipts'/(ident['run_id']+'.json')
            path.write_bytes(b'SPOOFED')
            with self.assertRaises(FileExistsError):issue(group,run,ident)
            self.assertEqual(path.read_bytes(),b'SPOOFED')
            with self.assertRaises(ValueError):consume(group,run,ident)

    def test_receipt_absent_or_global_marker_blocks(self):
        with tempfile.TemporaryDirectory() as t:
            group,run,ident,_=setup(Path(t))
            with self.assertRaises(ValueError):consume(group,run,ident)
            issue(group,run,ident)
            (Path(t)/'UNRESOLVED_ORPHAN.json').write_text('{}')
            with self.assertRaisesRegex(ValueError,'orphan'):consume(group,run,ident)

    def test_failed_group_and_orphan_group_block_even_with_receipt(self):
        for mode in ('FAIL','ORPHAN_SUSPECTED','MARKER_FAILED','WORKER_FAILED'):
            with self.subTest(mode=mode), tempfile.TemporaryDirectory() as t:
                group,run,ident,_=setup(Path(t));issue(group,run,ident)
                path=group/'manifest.json';obj=json.loads(path.read_bytes())
                if mode=='FAIL':obj['success']=False;obj['status']='FAIL'
                elif mode=='ORPHAN_SUSPECTED':obj['orphan_suspected']=True
                elif mode=='MARKER_FAILED':obj['marker_write_failed']=True
                else:obj['workers'][0]['state']='FAILED'
                path.write_bytes(_canonical(obj))
                with self.assertRaises(ValueError):consume(group,run,ident)

    def test_status_manifest_result_late_mutations(self):
        for name in ('status.json','manifest.json','canonical_result.json'):
            with self.subTest(name=name), tempfile.TemporaryDirectory() as t:
                group,run,ident,_=setup(Path(t));issue(group,run,ident)
                path=run/name; obj=json.loads(path.read_bytes());obj['late_write']=True
                path.write_bytes(_canonical(obj))
                with self.assertRaisesRegex(ValueError,'changed|tampered'):
                    consume(group,run,ident)

    def test_wrong_worker_game_draw_variant_or_coordinator_digest(self):
        for key, val in [('worker_sequence',2),('game_id','POWERBALL'),
                         ('draw_number',1480),('variant_id','WRONG_VARIANT')]:
            with self.subTest(key=key), tempfile.TemporaryDirectory() as t:
                group,run,ident,_=setup(Path(t)); issue(group,run,ident)
                with self.assertRaises(ValueError):consume(group,run,{**ident,key:val})
        with tempfile.TemporaryDirectory() as t:
            group,run,ident,_=setup(Path(t));issue(group,run,ident)
            with self.assertRaises(ValueError):verify_receipt_before_consume(
                group_dir=group,run_dir=run,identity=ident,
                coordinator_sha256='b'*64,
                global_orphan_marker=Path(t)/'UNRESOLVED_ORPHAN.json')

    def test_coordinator_exit_metadata_fails_closed(self):
        for mutation in (dict(wrapper_exit_code=2),dict(root_pid=0),
                         dict(root_create_time_epoch=-1),
                         dict(exit_observed_utc='2026-10-24T12:00:00'),
                         dict(console_result_digest_match=False),
                         dict(coordinator_sha256='nope')):
            with self.subTest(mutation=mutation),tempfile.TemporaryDirectory() as t:
                group,run,ident,_=setup(Path(t))
                with self.assertRaises(ValueError):issue(group,run,ident,**mutation)
                self.assertEqual(list((group/'receipts').iterdir()),[])

    def test_issuer_rejects_tampered_worker_records(self):
        for name in ('status.json','manifest.json','canonical_result.json'):
            with self.subTest(name=name),tempfile.TemporaryDirectory() as t:
                group,run,ident,_=setup(Path(t))
                file=run/name; data=json.loads(file.read_bytes());data['game_id']='POWERBALL'
                file.write_bytes(_canonical(data))
                with self.assertRaises(ValueError):issue(group,run,ident)

    def test_symlink_receipts_directory_is_refused(self):
        with tempfile.TemporaryDirectory() as t:
            group,run,ident,_=setup(Path(t))
            (group/'receipts').rmdir()
            try:
                (group/'receipts').symlink_to(run,target_is_directory=True)
            except (OSError, NotImplementedError):
                self.skipTest('platform disallows symlinks')
            with self.assertRaises(ValueError):issue(group,run,ident)

    def test_integrity_before_result_open(self):
        with tempfile.TemporaryDirectory() as t:
            group,run,ident,_=setup(Path(t));issue(group,run,ident)
            (run/'canonical_result.json').unlink()
            marker=Path(t)/'UNRESOLVED_ORPHAN.json'; marker.write_text('{}')
            with self.assertRaisesRegex(ValueError,'orphan'):
                consume(group,run,ident)
            marker.unlink()
            (group/'manifest.json').write_bytes(_canonical({'status':'FAIL'}))
            with self.assertRaisesRegex(ValueError,'group'):
                consume(group,run,ident)

    def test_existing_poc_gates_remain_disabled_and_original_hash_known(self):
        p=ROOT/'src'/'Powerball_Experiment_Coordinator.py'
        content=p.read_text(encoding='utf-8')
        self.assertIn('ENABLE_PROCESS_TERMINATION = False',content)
        self.assertIn('ENABLE_SCIENTIFIC_COORDINATION = False',content)
        self.assertIn("parser.add_argument('--poc'",content.replace('"','\''))
        self.assertIn('check_exited_worker_for_orphan',content)

if __name__=='__main__':unittest.main()
