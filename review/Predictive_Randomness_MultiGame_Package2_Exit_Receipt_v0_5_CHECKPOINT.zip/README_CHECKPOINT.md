# Multi-Game Package 2 — Coordinator Exit Receipt v0.5 (INTERMEDIATE REVIEW CHECKPOINT)

Status: **NOT INSTALLED / NOT RATIFIED / NO SCIENTIFIC COORDINATION / NO LIVE SCRAPING**.

## Baseline

Exact coordinator v0.6 source SHA-256: `2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b`.
Baseline extracted byte-identically from the previously supplied repository ZIP. Owner-reported Git baseline `057fd8c618c00d162324149e949fc71ab72ca3ce`; this package does NOT independently verify current HEAD.

## Overlay (INCREMENTAL from prior checkpoints)

- `src/methods/_common/multigame_coordinator_exit_receipt_v1.py`: coordinator-owned receipts, per-file SHA-256 binding, consumer group/marker/identity firewall.
- `tests/test_multigame_exit_receipt_v0_5.py`: 11 synthetic, no-network, no-process security tests.
- `src/Powerball_Experiment_Coordinator.py`: proposed **v0.7 review seam**, `ENABLE_SCIENTIFIC_COORDINATION = False` (no CLI override). Continues as POC-only. Records strict console markers and contains a dormant post-exit receipt issuance path. It cannot launch E-methods.

## Bound fields

Receipt schema, coordinator source SHA-256, group_id, worker sequence, run_id, game_id, draw_number, method_id, variant_id, root PID and creation time, wrapper exit code, coordinator-observed exit UTC, status PID and creation time, verified console match flag, exact SHA-256 of worker `status.json`, worker `manifest.json` and `canonical_result.json`. The *group* `manifest.json` is a distinct aggregate written last: consumers require whole group PASS and the given worker SUCCESS before reading a result.

Receipts live only at `group_dir/receipts/<run_id>.json` (never under method run directory), created with exclusive create; a collision is a failure. The method's standalone manifest can never substitute for coordinator-owned receipt.

## Gates

- No issuance unless group PASS, all wrapper Popen handles exited cleanly, status PID plus creation time matched the coordinator's captured experiment identity, last v0.6 descendant/status orphan check clear, strict four-line console publication verified, status/manifest/result canonical and matching.
- Group FAIL, unresolved global marker, missing receipt, mismatched identity, late writes, changed result bytes or invalid content all prevent coordinated consumption.
- The v0.6 termination function, ancestry capture, exit/orphan check, status/result validator, marker persistence, and `ENABLE_PROCESS_TERMINATION = False` remain unchanged. No kill path enabled.
- No receipt is ever issued by the current POC because `scientific_receipt_identity` is never populated and `ENABLE_SCIENTIFIC_COORDINATION` stays `False`.

## Known incomplete work — BLOCKERS before any coordinated/FINAL use

1. The current coordinator is an engineering-only POC; it does not yet have an authorised game-qualified E-method launcher, profile/target cap binding, method-generic child command or run-root/run-ID handshake. The dormant hook must not be enabled independently.
2. Coordinated method worker manifests (`run_dir/manifest.json`) are not yet produced by the current standalone synthetic method prototype (`standalone_manifest.json`). Their trusted schema and producer require later integration.
3. The actual coordinator+method console handshake and Popen/exit/ancestor behaviour need Windows synthetic integration tests, including malformed receipt/collision/failed group/orphan probes. Linux tests here exercise receipt functions and static safety contracts only, not process lifecycle.
4. Only after independent Claude v0.7/consolidated review, owner approval and Windows synthetic gates may a reviewed scientific coordination path be implemented/enabled; process termination remains independently gated and disabled.
5. This reviewer candidate's consumer operates on synthetic fixture artifacts; prospective FINAL is NOT enabled. It is not a signature. It defends against accidental/self-reported success and late file changes, not malicious local users with access to both directories.

## Test evidence

`TEST_TRANSCRIPTS_OFFLINE_LINUX.txt`: 61 multi-game tests (including 11 receipt tests) and 13 legacy E_1 tests, PASS. No subprocess launch, live site contact, synthetic coordinator start, holdout inspection, process termination or scientific run performed.

## Installation

Do NOT apply the overlay to the authoritative repository yet. Keep it in `review/` as an intermediate checkpoint. Combine this overlay with previous Package 2 checkpoints for the consolidated independent Claude code review. The exact v0.6→v0.7 candidate diff is included.
