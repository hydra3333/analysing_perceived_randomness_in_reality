# E_1 v0.3 authority and gates (23 October 2026)

| Gate | State |
|---|---|
| D1 FULL_HISTORY_RAW_COUNTS_V1 | OWNER-RATIFIED |
| D2 TIE_SHA256_V1 length32 LE UTF-8 | OWNER-RATIFIED; revised vectors awaiting Claude verification |
| D3 P3 standalone real development in parallel with P2 | OWNER-RATIFIED subject to production-loader/status/security gates |
| Synthetic arithmetic and contract tests | LOCAL PASS (Python container; Windows still untested) |
| Independent oracle compared with v0.3 golden fixture | LOCAL PASS, not substitute for Claude |
| Real-data U-view loader and strict source/holdout isolation | NOT IMPLEMENTED |
| Standalone method CLI and early STARTED lifecycle | NOT IMPLEMENTED |
| Standalone verified successful-run manifest and result firewall | NOT IMPLEMENTED |
| Windows standalone integration | NOT TESTED |
| FINAL weekly prediction/publish | NOT AUTHORISED |
| Coordinator process termination or destructive testing | NOT AUTHORISED |
