"""Independent synthetic E_1 vector oracle v0.3 (NO E_1 module imports).

Stand-alone implementation from owner-ratified eight-field LE tie tuple and
written hand-checkable invented history. Does not open real draw data.
"""
from __future__ import annotations

import collections
import hashlib
import json
import struct
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
fixture = json.loads((ROOT / 'tests/fixtures/p3_e1_synthetic_v0_3.json').read_text(encoding='utf-8'))
assert fixture['source_kind'] == 'SYNTHETIC_TEST_ONLY'
target = fixture['target']
history = sorted([{'draw': r['draw'], 'main': sorted(r['main']), 'powerball': r['powerball']}
                  for r in fixture['rows'] if r['draw'] < target],key=lambda r:r['draw'])
assert len(history) == 8 and [r['draw'] for r in history] == list(range(1144, 1152))


def hash_json(value):
    raw=(json.dumps(value, sort_keys=True, ensure_ascii=True, separators=(',', ':'), allow_nan=False)+'\n').encode('ascii')
    return hashlib.sha256(raw).hexdigest()


training_digest = hash_json({'schema': 'E1_SYNTHETIC_TRAINING_VIEW_V0_1',
                             'source_kind': 'SYNTHETIC_TEST_ONLY', 'records': history})
main_counts=collections.Counter(n for r in history for n in r['main'])
pb_counts=collections.Counter(r['powerball'] for r in history)
main={i:main_counts[i] for i in range(1,36)}
pb={i:pb_counts[i] for i in range(1,21)}
assert sum(main.values()) == 56 and sum(pb.values()) == 8


def tie_hex(barrel, label):
    fields=['PREDICTIVE_RANDOMNESS/TIE_SHA256_V1', training_digest, str(target),
            'E_1', 'FULL_HISTORY_RAW_COUNTS_V1', barrel, 'TIE_SHA256_V1', str(label)]
    raw=b''.join(struct.pack('<I', len(f.encode('utf-8')))+f.encode('utf-8') for f in fields)
    return hashlib.sha256(raw).hexdigest()


main_rank=sorted(main, key=lambda n:(-main[n], tie_hex('MAIN', n), n))
pb_rank=sorted(pb, key=lambda n:(-pb[n], tie_hex('POWERBALL', n), n))
forecast={
    'schema': 'E1_SYNTHETIC_FORECAST_V0_1_NOT_FINAL',
    'data_kind':'SYNTHETIC_TEST_ONLY',
    'method_id':'E_1', 'variant_id':'FULL_HISTORY_RAW_COUNTS_V1',
    'fit_sampling_model_version':'RAW_APPEARANCE_COUNTS_V1',
    'ranking_tie_readout_version':'TIE_SHA256_V1',
    'target_draw':target, 'last_training_draw':target-1,
    'training_view_sha256':training_digest,
    'MAIN':{'scores':main, 'ranking':main_rank, 'top':main_rank[:7],
            'worst':list(reversed(main_rank))[:7]},
    'POWERBALL':{'scores':pb, 'ranking':pb_rank, 'top':pb_rank[0],
                 'worst':pb_rank[-1]},
}
result={
    'training_view_sha256':training_digest,
    'tie_main_label_3_sha256':tie_hex('MAIN',3),
    'canonical_forecast_sha256':hash_json(forecast),
    'main_top':forecast['MAIN']['top'],
    'main_worst':forecast['MAIN']['worst'],
    'pb_top':forecast['POWERBALL']['top'],
    'pb_worst':forecast['POWERBALL']['worst'],
}
print(json.dumps(result, indent=2))
