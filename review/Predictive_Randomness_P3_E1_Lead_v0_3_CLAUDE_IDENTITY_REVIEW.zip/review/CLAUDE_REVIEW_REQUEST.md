# Claude independent review request - P3 E_1 v0.3

Owner has RATIFIED D1, revised D2 (LE rather than BE), and D3. Review **only** the E_1 v0.3 synthetic identity and associated design consistency; source baseline v0.2 package, repository reference 18fa741. No real data is to be opened or run.

1. Independently derive the synthetic prefix SHA from the written fixture; ensure label/order invariance and N-1 cutoff.
2. Independently hash the **eight fields in R3 order**, each length-prefixed with 4-byte unsigned **little-endian** byte count then UTF-8. The integers are canonical base-10 ASCII, source digest lowercase 64-hex, MAIN/POWERBALL and final version `TIE_SHA256_V1`. Cross-check the full rankings, TOP/WORST and canonical SHA against the supplied vectors.
3. Check that the change from earlier unratified BE golden outcomes to LE outcomes also updates expected evaluator values (main WORST now 1, not 0); mid-ranks remain native-score based.
4. Review code, tests, fixture and document diffs; identify any regression or scientific-contract misstatement. Check D3 is limited to development after the separate reviewed loader/status gate, never FINAL or holdout access.
5. Confirm no code here reads real data or authorises use of Run_Experiment.bat with the import-only synthetic prototype.

Provide substantive blockers vs optional improvements, and a concise owner-pasteable verdict. No destructive tests, marker clearance, termination, holdout unsealing or FINAL authorised.
