# P3 E_1 Lead v0.3 - owner-ratified identity, Claude verification package

**Date:** 23 October 2026. **Reference source baseline:** reviewed v0.2 E_1 decision package, with repository baseline `18fa741353399241380cfc8f52e35cbcf01f9dd6` as reported by Claude. Later repository housekeeping may have advanced HEAD: do not mistake this source baseline for the current HEAD.

**OWNER-RATIFIED (23 Oct):**

- D1: First variant `FULL_HISTORY_RAW_COUNTS_V1`; other frequency/recency variants remain possible.
- D2: `TIE_SHA256_V1` eight-field tuple; four-byte unsigned **little-endian** UTF-8 byte-length prefix for each field, then UTF-8 field bytes. Integers use unsigned, base-10 ASCII with no leading zero; training digests are exactly 64 lowercase hex; barrel is `MAIN` or `POWERBALL`. This replaces the earlier unratified big-endian candidate.
- D3: P3 historical real-data *development* may progress in parallel with unfinished P2 only after separate production-loader, safety/status contracts and tests are implemented and independently reviewed. Execution must be standalone via `Run_Experiment.bat`, with strict N-1, sealed 1578-1587 holdout, synthetic/real firewall, strict FAILED/orphan-suspected result rejection, no reliance on coordinator timeout/termination. **No weekly FINAL, no destructive tests, no process-termination enablement.**

**IN THIS PACKAGE:** one import-only synthetic E_1 prototype, fixtures, independent oracle, exact contract tests, versioned design documents, old-to-new diffs and SHA-256 manifest. No real-data adapter, status CLI, publication or coordinator modifications. Not an installation instruction or permission to run real data.

## Recomputed v0.3 synthetic goldens

- Training-view SHA-256 (unchanged): `df21871f8067e5405b4fdb1eec50c65dddbaa35958872bad3230d3c10a791fd4`.
- Tie `MAIN`, label 3 SHA-256: `7ce5ab1bae014adf61f1f02dd152d4b500cb405b65cb3886cdcee8dd9e2c9932`.
- Canonical forecast SHA-256: `7b43d659d611791deb14d106a72984f153d9f79cc63b3d25000365de4c811d1e`.
- MAIN TOP `[1,8,2,6,3,7,9]`; MAIN WORST `[23,26,18,30,24,25,12]`; PB TOP `1`, PB WORST `9`.
- Future invented actual draw scoring: MAIN TOP 4, WORST 1, PB TOP 1, WORST 0, main mean native-score mid-rank `167/14`, PB mid-rank `1`.

**INDEPENDENT REVIEW REQUIRED:** Claude should independently recompute from the documented formula rather than trust the supplied oracle or method implementation. In particular, check the exact eight tuple fields/order, length endian/UTF-8 bytes, new golden tie digest, full ranking and score cardinalities, the synthetic/real firewall, and unchanged N-1 perturbation safety. Review `review/diffs/*` against the supplied v0.2 files. Flag any substantive overreach.

Run in a clean extracted directory, Python 3.13+ (prototype has no external package dependencies):

```
python -B review/independent_e1_vector_oracle_v0_3.py
python -B tests/p3_e1_synthetic_contract_v0_3.py
```

**NEXT after review:** design/implement separately reviewed real `U` training view loader, standalone method CLI, early durable STARTED/status, immutable result publisher and group firewall; test in synthetic mode first. Do not run historical real-data E_1 before those gates pass.
