# Predictive Randomness - P3 E_1 lead method and contract - v0.3 RATIFIED-IDENTITY REVIEW CANDIDATE

**Date:** 23 October 2026 (Australia/Adelaide). **Status:** owner-ratified D1/D2/D3 identity decisions; synthetic-only code awaits independent review. **Baseline:** repository `18fa741353399241380cfc8f52e35cbcf01f9dd6` (owner-reported clean pushed HEAD); coordinator v0.6 hash `2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b`.

**Scope:** only a synthetic-only arithmetic/readout proof and proposed shared method contracts. No real data runs, no holdout unsealing, no production forecast, no process management. It does not amend or supersede Proposal v0.3, R1 v0.4, R2 v0.3 + approved erratum, R3 v0.2, ratified Architecture v0.5 or POC Task Spec v0.2.

## 1. Authority and parallel development

- **OWNER-RATIFIED previously:** all 62 E-methods stay registered, no exclusion due to orthodoxy/weak results; strict N-1 historical training boundary, TOP/WORST from one frozen model, label-neutral `TIE_SHA256_V1` policy, original 1578-1587 holdout sealed for development, synthetic/real separation, late results from FAILED/orphan-suspected groups never consumed; coordinator kill switch False.
- **OWNER-RATIFIED D3 (23 Oct):** P3 real-data *development* may proceed before P2 closes, solely as standalone `Run_Experiment.bat` methods after the production loader, safety/status contracts and tests are implemented and independently reviewed. No reliance on coordinator timeouts or process termination, no holdout access, no FINAL and no destructive tests. This is an explicit owner-approved sequencing exception to Task Spec v0.2 section 7.3, not an implicit supersession of that specification. This synthetic-only candidate still MUST NOT run on real data.
- **DECIDED (routine design):** E_1 is the shared method lead; use a pure, synthetic-only function first, without spawning processes or reading source files. The test harness is independent of the production evaluator and refuses synthetic->real relabelling.
- **OWNER-RATIFIED D1 (23 Oct):** initial E_1 variant `FULL_HISTORY_RAW_COUNTS_V1`; unsmoothed full-prefix appearance counts (equivalent rates for ordering because all numbers share denominator), with complete 35/20 rank channels. Retain alternative full/recent/recency-weighted E_1 variants as separate possibilities; E_9 remains a separate scientific method.
- **OWNER-RATIFIED D2 (23 Oct):** `TIE_SHA256_V1` uses 4-byte unsigned **little-endian** UTF-8-byte lengths, canonical field representations and the exact 8-field tuple listed below. This deliberately changes the earlier unratified big-endian candidate; SHA and TOP/WORST golden vectors have been regenerated using a separate oracle and MUST be independently checked by Claude before production use.

## 2. Proposed E_1 formula (hand-checkable)

For target N, define eligible prefix H_N as all current-format draws strictly earlier than N (or the declared approved rolling variant). The development loader must never reveal target N or later to fitting code; original holdout 1578..1587 remains inaccessible in development mode.

For each main number i in 1..35, `c_main(i) = sum_{d in H_N} 1[i in seven_set(d)]`.
For each Powerball j in 1..20, `c_pb(j) = sum_{d in H_N} 1[j == powerball(d)]`.
No smoothing or learned weights in this candidate. Every score must be a finite exact integer >=0. This *is not* a calibrated joint probability model; it is only a relative score/rank method. Score sum invariants: `sum c_main = 7*len(H_N)`, `sum c_pb=len(H_N)`.

Sort score descending; within exact ties sort by ascending SHA-256 digest of the versioned, domain-separated tuple. OWNER-RATIFIED encoding: each field is UTF-8 preceded by its four-byte unsigned little-endian byte length; tuple fields are domain, training-view SHA-256, target, method ID, variant ID, barrel, ranking tie version, tied label. A SHA-256 collision falls back to numeric label. Integer values are signless base-10 ASCII, without leading zeros; the training digest is exactly 64 lowercase hexadecimal characters; barrel identifiers are precisely `MAIN` and `POWERBALL`; variant ID `FULL_HISTORY_RAW_COUNTS_V1`; readout version exactly `TIE_SHA256_V1`. This byte encoding is OWNER-RATIFIED. The digest never influences the counts or fit and cannot depend on whole source-file hash, wall time, source rows N+, or result scores.

One frozen full ranking per barrel yields main TOP first 7, main WORST the **exact reversal** first 7; Powerball TOP first and WORST last. Do not independently sort the inverse side. R3 evaluator-only rank position uses *native-score* mid-ranks before digest tie-breaking.

## 3. Synthetic hand-calculation fixture

`tests/fixtures/p3_e1_synthetic_v0_3.json`: 8 invented consecutive draws 1144..1151, target 1152. These are **not real Powerball data** and must never be mixed into a real model. Each draw has 7 distinct main labels and 1 Powerball.

Hand-check: main label 1 appears **8**, label 8 appears **7**, label 2 appears **3**, labels 3/4/5/6/7/9 appear **2** each; 10 appears once. Main counts sum **56**. Powerball 1 appears **3**, each of 2..6 once, 7..20 zero; counts sum **8**. Thus main top three must be `[1,8,2]` regardless of tie policy; Powerball top must be `1`. Other TOP and WORST identities are digest-dependent and are versioned golden vectors for the owner-ratified byte encoding, pending independent Claude re-computation.

The synthetic *future* draw 1152 is supplied only to a separate evaluator in the test. Its exact contents are irrelevant to the prediction. Tests change that outcome and append future draws, verify identical canonical forecast bytes, and separately test mutation of an earlier permitted draw changes the training view identity.

Golden vectors for the ratified identifiers are asserted by `tests/p3_e1_synthetic_contract_v0_3.py`. The entire synthetic canonical forecast SHA-256, full rankings and selected labels should be independently recomputed by Claude; do not treat self-consistency checks as proof of the cryptographic tuple convention.

## 4. Guardrails and review/test matrix

| Check | Status in this package | Production gate |
|---|---|---|
| exact 35 and 20 scores, count totals, hand-checked labels | Synthetic PASS | Repeat with production view loader |
| full ranking, deterministic tie order, exact WORST reversal | Synthetic PASS | Have Claude independently verify ratified byte encoding and regenerated SHA vectors |
| N-1: change outcome N, append/change future | Synthetic PASS | Repeat T-05 on real development data *without accessing holdout* |
| early-future change must not change fit seed/content identity | Synthetic PASS | Bind to actual canonical data adapter |
| evaluate frozen TOP/WORST + score mid-rank separately | Synthetic PASS | Independent R3 contract implementation and validation |
| blocked group manifest FAIL/ORPHAN -> no evaluation | Synthetic PASS (test helper) | Enforce at all production result consumers, batch aggregator and scorer |
| sorted per-draw input labels do not change unordered predictions | Synthetic PASS | Real CSV validator/provenance |
| synthetic/real firewall | Prototype refuses real kind | Real loader must enforce distinct trusted source path + provenance |
| Windows BAT, early durable STARTED, SUCCESS/FAILED lifecycle | NOT TESTED | Mandatory before standalone real use |
| immutable storage + pre-draw Git push, no overwrites | NOT IMPLEMENTED | Mandatory before any real FINAL batch |
| holdout 1578..1587 sealed | NOT ACCESSED | Independent review before any future unsealing |
| six-workers, real process termination | NOT TESTED | P2 review/owner gate separate |

**DO NOT** run this prototype through `Run_Experiment.bat`: it intentionally has no CLI/STARTED/SUCCESS status publisher. It is import-only and cannot produce real-data forecasts. Synthetic test script runs directly with project `.venv` Python and never accesses repository draw CSV files.

## 5. Next implementation milestones (after review and owner FORMULA_OPEN decision)

1. D1 and D2 are already owner-ratified; obtain Claude verification of the revised identity and goldens. Keep other E_1 variants registered as open.
2. Implement a shared real-data loader with `HISTORICAL_DEVELOPMENT` vs `FINAL_NEXT_DRAW` policy, trusted source hashes for audit only, target cutoff, schema checks, original holdout protections and closed synthetic/real boundary; never infer mode from available dates alone.
3. Implement early durable STARTED, immutable status transition, non-clobber canonical result, identifiable run grouping and a method CLI compatible with the existing `Run_Experiment.bat` without weakening it. Standalone-only until P2 authorises coordinator invocation.
4. Implement immutable forecast store and scoring follow-up contract described in the companion document. Do not publish first genuine FINAL batch until modelling and catalogue are ready per owner policy.
5. Once E_1 passes tests and Claude review, develop E_2..E_6 as one small batch (independent maths fixtures and versioned variant contracts) while reserving future family-by-family owner `FORMULA_OPEN` ratification and special review cases.

## 6. DECIDED / RECOMMENDED / OPEN

**DECIDED:** synthetic-only proof first; exhaustive score/rank checks; exact reverse frozen WORST; test helper rejects FAIL/orphan; single lead E_1 then E_2..E_6 batch design.

**OWNER-RATIFIED (23 Oct):** first E_1 variant = full-history unsmoothed raw counts; four-byte LE length-delimited UTF-8 fields for the SHA-256 tie tuple; D3 permits only constrained standalone real-development work after a separate reviewed production-loader gate. Other E_1 variants remain registered possibilities.

**OPEN (engineering/review):** real-data loader and historical/FINAL gating; exact final storage schema; categorical manifest statuses; Windows durable early STARTED implementation; prospective Git evidence capture; scored-track version keys; connection to scanner(s) and batch modes; holdout never opened for this package.

## 7. Claude independent review of v0.1 and v0.2 test strengthening

Claude independently verified the baseline `18fa741` and recomputed the fixture from the written specification without importing the candidate. Verdict: **NO BLOCKERS** for the synthetic prototype. The v0.1 fixture counts and digest goldens were confirmed (see review handback for the full values). This is not evidence of production/Windows/real-data correctness.

The v0.2 reviewer verified the **old, unratified big-endian** vectors (TOP/WORST/PB = `4/0/1/0`). The **new owner-ratified little-endian** synthetic golden outcome is `4/1/1/0`; its native-score evaluator ranks remain `167/14` (main) and `1.0` (PB), independent of the tie readout. All-tied native-score mid-ranks remain 18.0 and 10.5; the never-drawn supplemental fixture requires 33,34,35 to lead the WORST readout. The v0.3 harness independently assembles the LE bytes via `struct.pack('<I', length)`. All tests remain synthetic-only.

**Owner decisions resolved, 23 Oct 2026:**

- **D1 OWNER-RATIFIED:** `FULL_HISTORY_RAW_COUNTS_V1` initial E_1 variant, alternate frequency variants preserved.
- **D2 OWNER-RATIFIED:** the eight-field R3 tuple, byte length prefixes are 4-byte unsigned **little-endian**; canonical integer, digest, barrel and readout representations in section 2. Independent SHA-vector review still required before production use.
- **D3 OWNER-RATIFIED:** parallel P3 real-data *development* can begin only with reviewed production-loader / standalone status and source-boundary guarantees, not with this import-only synthetic prototype. Original holdout remains sealed; FINAL remains separate.

**DECIDED for synthetic-only code:** exact evaluator and zero-score regression checks.

**OPEN / later decision:** real canonical E_1 training view: use *U* input only — draw number, sorted seven-number main set and Powerball; exclude drawn-order columns from the content digest and fitting input. Add explicit source-kind/mode boundary, validation and holdout check in a separate real loader specification before any real-data run.

Claude's review also noted prospective Git client commit timestamps alone are not proof of pre-draw publication. An independent trusted timestamp or GitHub server-side event timestamp linked to the frozen SHA-256 is required for a prospective claim.

**Change discipline:** no ratified governing source, real draw data, or coordinator file changes in this candidate. Synthetic E_1 implementation uses the owner-ratified variant and readout identity; the *prototype and entire document* remain review candidates for acceptance, and real-data use is still prohibited. This v0.3 review candidate does not set a real-method launch gate to PASS.

## 8. v0.3 independent verification gate

The only mathematical identity changes from v0.2 are the ratified full variant/readout identifiers and the 4-byte LE length encoding. A canonical-ASCII/UTF-8 validation guard has been added for the tie tuple; the synthetic-only input firewall remains. An **independent oracle** in `review/independent_e1_vector_oracle_v0_3.py` computes the expected vectors directly from the written synthetic fixture without importing `E_1_Historical_Appearance_Frequency.py`. Claude should repeat that computation independently. The prototype still has no production loader, process launch, status publisher or immutable result writer.
