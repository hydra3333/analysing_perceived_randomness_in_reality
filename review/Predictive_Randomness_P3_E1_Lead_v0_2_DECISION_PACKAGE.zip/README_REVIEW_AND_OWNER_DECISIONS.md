# E_1 synthetic lead - v0.2 owner decision package

Baseline: GitHub `18fa741353399241380cfc8f52e35cbcf01f9dd6` per Claude v0.1 review. This package includes **review candidates, not an install instruction**. It is self-contained for the synthetic-only v0.2 test and has no real-data dependency.

Run (in extracted tree): `python tests/p3_e1_synthetic_contract_v0_2.py`.

There are three separate owner approvals sought: (1) E_1 initial raw full-history count variant; (2) length32 BE UTF-8 tuple semantics and final TIE_SHA256_V1 identity; (3) standalone real *development* work in parallel with unfinished P2, preserving the listed safety conditions. None implies first FINAL publication.

After owner approval, the implementation will be revised to remove temporary candidate suffixes and all golden vectors recalculated. The final-code SHA vector verification is a substantive independent review gate. Production real-mode loader, on-disk result/status publisher, method launcher, and store remain unimplemented.
