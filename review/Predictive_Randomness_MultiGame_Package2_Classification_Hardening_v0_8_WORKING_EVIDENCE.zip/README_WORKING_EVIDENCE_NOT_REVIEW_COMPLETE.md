# Multi-Game Package 2 — Classification Hardening v0.8

**Status: INCREMENTAL WORKING EVIDENCE. Not code-complete. Do not install.**

Inputs: ratified Package 1; v0.1, v0.3, v0.4 and v0.6 checkpoints,
and v0.7 working evidence. This ZIP supersedes only the v0.7 synthetic-
identity/receipt classifications and corresponding tests. The approved
Powerball E_1 source, historical hashes, coordinator process ownership/
orphan/termination functions and existing Powerball scraper are untouched.

## Reviewer findings addressed

1. The E_1 **synthetic-only** plumbing variant is now `SYNTHETIC_PLUMBING_V1`.
   The registered `FULL_HISTORY_RAW_COUNTS_V1` scientific variant is *not*
   admitted by the synthetic launch spec or synthetic worker handshake.
2. Mode is `SYNTHETIC_CONTRACT_TEST` across status, worker manifest,
   canonical result and coordinator-issued receipt. No probe claims mode
   `COORDINATED` or `FINAL`.
3. The coordinated/FINAL consumer checks a strict registry binding of
   `(game_id, method_id, variant_id, mode) -> (result_schema, data_kind)`.
   **There are zero approved scientific coordinated/FINAL entries**.
   Existing accepted standalone E_1 schema is not silently re-used.
4. The synthetic receipt is expressly unscoreable; the consumer refuses
   it **before reading canonical_result.json**. `not_a_forecast` and
   `synthetic_only` stay defence in depth, not authorisation controls.
5. The test-only scientific fixture uses a temporary in-memory patched
   allowlist solely to exercise integrity behaviour under a hypothetical
   future reviewed scientific schema. **The shipped allowlist is empty**.

## Offline verification in this ZIP

- 85/85 multigame unittest cases PASS (Linux Python 3.13).
- 13/13 existing E_1 synthetic unittest cases PASS (Linux Python 3.13).
- This includes the frozen draw-1577 prefix-only regression tests.
- The frozen Powerball regression read only its already-authorised
  training prefix 1144..1576 (no target or sealed holdout outcomes).
  All new security fixtures were synthetic. No live scraping, Windows
  Popen process, kill, holdout access or scientific scoring occurred.

## Deferred prerequisites before code-complete consolidated overlay

- Executable, reviewed game-qualified launch integration with genuine Windows
  Popen handle and ancestry capture, with hard no-status/no-kill interlock.
- Coordinator-worker handshake binding and matching the method-side manifest
  to an independently observed exit and group-frozen PASS.
- Windows synthetic lifecycle acceptance tests and independent review,
  separately owner-authorised before execution.
- Shared scraper/source adapter and remaining code integration to be included
  in the ONE consolidated overlay against the then-current GitHub HEAD.

`ENABLE_PROCESS_TERMINATION=False` and
`ENABLE_SCIENTIFIC_COORDINATION=False` remain mandatory.
No Package 3 scraping or Oz Lotto scientific use is authorised.

Keep this alongside prior checkpoints as working evidence; do not treat it as a
replacement for the consolidated Claude review.
