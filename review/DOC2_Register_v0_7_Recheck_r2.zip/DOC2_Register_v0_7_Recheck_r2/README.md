# DOC-2 - register v0.7 r2 - focused recheck of DOC2-C01, DOC2-C02 and DOC2-O01

| Field | Value |
|---|---|
| Item | DOC-2 register v0.7, revision r2 |
| Author / reviewer | Claude / ChatGPT reviewer chat |
| Responds to | `Independent_ChatGPT_Review_DOC2_Register_v0_7_v1.md` (`1f14a995b1d22403d58a87613dce0eff6dbd7c205cd962afefa19c2d8c2756ac`) |
| Base | register v0.6 Git blob `5e677dce3f2ae01cd7a3f6cc1ff408c8e32e268150fe0c956e42bf703a9b074c`; GitHub `38fc60e` |
| Disposition asked | Focused RECHECK of the three changed passages only |
| Evidence state | IMPLEMENTED (draft); mechanically checked; not yet RECHECKED |

**Date:** 28 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears in or was used for this file.

| File | SHA-256 |
|---|---|
| `RATIFICATION_REGISTER_v0_7.md` (r2; UTF-8, LF) | `8b751a878e0626165b6c01bbc49d7d3014b3bd83a171200b4247eb5ec761796d` |
| r1 (reviewed) | `92e73afba1f7cdb55f38959df67c01d5312f4bc4d50ab3fce6ab1b26f89ce4b1` |
| `evidence/register_v0_7_r1_to_r2.diff` (r1 to r2; 2 hunks, 3 lines) | `aa15cb72f56309185fd4ee0d08ee1c834e3efd4d7284f049f17e3bea6ce53c33` |
| `evidence/register_v0_6_to_v0_7.diff` (full v0.6 to r2) | `b112ad10c031a28473433744220f7b9e0baa8f6a5359eaf3f5a20541a5bf033b` |
| `evidence/make_register_v07_r1_to_r2.diff` (builder change) | `3592ca5ee60b9fb1825fb63cfce423fe0eb4a6e2f2143cc1a580869ea548cd23` |
| `tools/make_register_v07.py` (r2; still 5 counted edits; refuses any other input) | `41a10258119406d19b84f6506b26ab4845ee6d740cf5440a276c8aa29566b2ea` |

## What changed from r1 (three lines; nothing else)

- **DOC2-C01** (out-of-date statements, first bullet): replaced with the reviewer's required text verbatim. D-4's own line is unchanged, so its authority is preserved, and nothing pre-ratifies the NAMES-1 layout.
- **DOC2-C02** (basis line): "the v0.7 entries against GitHub HEAD `38fc60e`" now reads "the already-committed v0.7 references against GitHub commit `38fc60e` (28 October 2026). The E2R-1 v0.3r3 specification is not present at that commit; it is verified by its content hash below, and its installation is a separate owner decision." No E2R status or hash changes.
- **DOC2-O01** (process decisions, oversight bullet): now says explicitly that this is a newer owner instruction superseding the earlier all-items reporting; the reviewer still lists every item and Claude still checks every one; reviewer rights unchanged; authority not delegated. The owner's acceptance stays part of DOC-2 ratification.

## Mechanical checks

- `patch` of v0.6 with the full diff reproduces r2 exactly; running the r2 builder on v0.6 reproduces r2 exactly.
- Inserted text is ASCII; the placeholder `[E2R-DATE]` and "RATIFICATION CANDIDATE" remain, for finalisation after the owner's dated decision. The final file's hash will differ and will be recorded at install.

*End of handback.*
