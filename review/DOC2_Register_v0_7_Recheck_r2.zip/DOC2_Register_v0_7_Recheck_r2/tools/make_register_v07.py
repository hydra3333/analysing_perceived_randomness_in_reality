"""Draft register v0.7 from the installed register v0.6 by counted in-place edits (Claude, 28 Oct 2026).

Work item DOC-2. Records the E2R-1 specification ratification, the owner decisions of 28 October 2026
(D-1..D-11 and process decisions), the DOC-1 and snapshot commits, and out-of-date statements.
Every old string must occur exactly once; inserted text is ASCII. The input is the Git (LF, UTF-8)
blob of doc/RATIFICATION_REGISTER_v0_6.md (5e677dce...074c). The placeholders [E2R-DATE] and
"RATIFICATION CANDIDATE" are finalised after review and the owner's confirmation, as before.
Revision r2 (28 Oct 2026) applies the reviewer's DOC2-C01, DOC2-C02 and DOC2-O01 to the inserted text only;
the edit count is unchanged.
Usage: python3 -I make_register_v07.py REGISTER_v0_6 OUT_v0_7
"""
import hashlib, sys

src, out = sys.argv[1], sys.argv[2]
raw = open(src, 'rb').read()
assert hashlib.sha256(raw).hexdigest() == '5e677dce3f2ae01cd7a3f6cc1ff408c8e32e268150fe0c956e42bf703a9b074c'
t = raw.decode('utf-8')
assert '\r' not in t

SPEC = 'Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md'

NEW_SECTION = f"""## E2R-1 specification and owner decisions of 28 October 2026 (register v0.7)

Paths in this section are under `doc/`, except those beginning `review/`, which are from the repository root. In this section, "this register" means register v0.7.

**DOC-1 installation.** Register v0.6, H-1 v1r2 and H-2 v1r3 were installed at commit `be185485693f29cf9ab28292dc6eebad00bbc32c` (parent `b14116b`; 9 files added; Claude verified every blob against `review/DOC1_Install_v1/INSTALL_MANIFEST_SHA256.txt`, whose SHA-256 is `6d992efa1fc78e286702f351c4180ef13720d93eca5c1cfbafade8fafc3c9476`, and which gives register v0.6's own hash, `5e677dce3f2ae01cd7a3f6cc1ff408c8e32e268150fe0c956e42bf703a9b074c`). The DOC-1 review is `review/Independent_ChatGPT_Review_DOC1_Records_Refresh_v1.md` (PASS). That review was the third of the first three reviews under the owner's oversight instruction; no departure was found.

**E2R-1, the E_2-readiness method-generic contract specification.** `{SPEC}` (`0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954`) is OWNER-RATIFIED [E2R-DATE]. It is the stage-1 contract-field schema and acceptance list required by R2 v0.5 section 5.6, R3 v0.5 section 17.13 (stage 1) and Architecture v0.8 section 20A. Its authoring-time "DRAFT" header is historical; this register records its ratification.
- **Review history**, all by the ChatGPT reviewer chat:
  - the R-3 review of v0.2, `review/E2R_R3_Review_Commit_Independent.md` (`17087f5715bc3cfe49a2120fd25d1cdb626c6d9c480d53b5f3bb73559e93b2b2`; 3 BLOCKER, 10 CORRECTION, 2 OPTIONAL, 1 RECONSIDER);
  - its unforwarded predecessor, `review/Independent_ChatGPT_R3_Design_Review_E2R_v0_2_FINAL_OWNER_Addendum_v0_2.md` (history only; superseded);
  - focused rechecks of v0.3r1 (`review/Independent_ChatGPT_E2R_v0_3r1_Focused_Recheck_v0_1.md`, `866974a7ca38a156c76d46034fd0f31c2970b814dc627685f33c9c585f8ae392`) and v0.3r2 (`review/Independent_ChatGPT_E2R_v0_3r2_Focused_Recheck_v0_1.md`, `865edd97b97b06a5975b3ddc037dc5d3053e1f563cd1f295857a7a9d7623def2`);
  - the **PASS** recheck of v0.3r3, `review/Independent_ChatGPT_E2R_v0_3r3_Focused_Recheck_v0_1.md` (`3b69f540c637f400c503092daef9072c0069a857b9450cc91355e48e7c7d6646`; 0 findings).

  The review packages are `review/E2R_Spec_Review_v0_2.zip` and `review/E2R_Spec_Recheck_v0_3r1.zip` .. `_v0_3r3.zip` (commit `319fd11`).
- **What ratification does:** it fixes the design that the E_2-readiness code package implements. It authorises no code, no NAMES-1 work, no source move, no run, no registry change and no release. Each of those needs its own owner decision. It changes no ratified text of R2, R3 or Architecture; where it extends them, the next editions fold it in (out-of-date statements below).

**Owner decisions of 28 October 2026 recorded in the specification (its section 14).** Each is OWNER-DECIDED:
- **D-1:** `track_id` excludes the method revision. Each report uses one declared revision per track, and nothing is silently mixed or replaced (E2R-R40, R40A).
- **D-2:** synthetic and benchmark records carry the evidence tier `NOT_EVIDENCE`.
- **D-3:** method texts for E_1 and E_2 are written in the E_2-readiness code package; later methods' texts are written with their own specifications.
- **D-4:** `src/` holds current code only, with stable names and a folder per method (`src/methods/E_<nnn>/`, a locator only).
- **D-5:** superseded revisions move to revision-labelled archives (`archive/methods/E_<nnn>/r<k>/`, `archive/common/<name>/r<k>/`) with a README. There are no commit IDs, no stored file hashes and no run-time code-identity recording. Exact historical replay is not promised.
- **D-6:** a method runs only if its active registry entry is `SUPPORTED` for its current revision **and** no `IN_DEVELOPMENT.txt` flag is present. Release is the owner's two deliberate actions.
- **D-7:** NAMES-1, a one-off rename of existing versioned file names, comes before the E_2-readiness code.
- **D-8:** prospective results are shown both "as published" and "current methods".
- **D-9:** a seed policy's root is a pre-announced NIST Randomness Beacon pulse, fetched once by hand and independently verified. Runs never fetch.
- **D-10:** roots may be switched as a new revision or variant. Every root tried is logged and counted.
- **D-11:** a root published after historical targets may be used for retrospective development runs, labelled as experiment randomisation. A real forecast needs an already-approved root.

**Process decisions of 28 October 2026 (OWNER-DECIDED).**
- **Oversight instruction:** extended from three to six reviews under the new roles. The reviewer counts the E2R-1 rechecks as continuations of review 4 (its E2R-RD-13, -17 and -21). This newer owner instruction of 28 October 2026 supersedes the earlier requirement to send the owner every REVIEWER-DECIDED item: the reviewer still lists every item, and Claude still checks every one, but reports one to the owner only if Claude disagrees with it, or judges that it would interest the owner. It changes reporting only; reviewer rights are unchanged, and the authority is not delegated.
- **Handover documents get one review** each.
- **Git history:** the owner may clean or rewrite it once the code base is stable and in production, and does not plan to before then. Before any clean-up, Claude records which commit IDs this register and the handovers rely on. The E2R-1 design does not depend on Git history.

**Snapshot commits.** `319fd11` added `HANDOVER/Claude_Checkpoint_v4.md` (`d7634683d3d40edaa27c91576531cb198f1358613ca84c2e67e42096a1a6456e`; a non-authoritative running checkpoint) and the E2R-1 review history above. `38fc60e` added the superseded interim review and a duplicate copy of the checkpoint at `review/Claude_Checkpoint_v4.md`, byte-identical; history only.

**Out-of-date statements (register v0.7).** This register prevails, and the files are not edited:
- Architecture v0.8's standalone `.py` wording is extended by owner decision D-4. NAMES-1 proposes stable filename renaming only, without implementing per-method folders; its exact entry-file/folder layout is subject to the owner's separate OPEN-N1 decision. The next Architecture edition will incorporate the settled layout.
- R2 v0.5 section 5.6 and R3 v0.5 section 17.13 say the owner ratifies the stage-1 field schema first: done (above).
- H-1 v1r2:
  - section 1.5 describes the oversight instruction as three reviews with full reporting (now six, by exception);
  - section 9 lists the E_2-readiness specification as next (done; NAMES-1 is next, then the E_2-readiness code);
  - it does not mention the E2R-1 specification or decisions D-1..D-11.

  The next H-1 revision folds these in.
- Register v0.6, "Oversight instruction status" (two of three reviews done): superseded by the paragraph above.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `{SPEC}` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED [E2R-DATE]; `0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954` |
| `RATIFICATION_REGISTER_v0_6.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 28 Oct 2026; superseded by this register; `5e677dce3f2ae01cd7a3f6cc1ff408c8e32e268150fe0c956e42bf703a9b074c` |

"""

EDITS = [
    ('**Register version:** v0.6 OWNER-RATIFIED 28 October 2026, recording',
     '**Register version:** v0.7 RATIFICATION CANDIDATE (drafted 28 October 2026), recording the E2R-1 specification ratification and the owner decisions of 28 October 2026; v0.6 OWNER-RATIFIED 28 October 2026, recording'),
    ('and the v0.6 entries against GitHub HEAD `b14116b` (27 October 2026).',
     'the v0.6 entries against GitHub HEAD `b14116b` (27 October 2026), and the already-committed v0.7 references against GitHub commit `38fc60e` (28 October 2026). The E2R-1 v0.3r3 specification is not present at that commit; it is verified by its content hash below, and its installation is a separate owner decision.'),
    ('**Oversight instruction status.** Two of the first three reviews under the new roles are done',
     '**Oversight instruction status (as at register v0.6; superseded by register v0.7).** Two of the first three reviews under the new roles are done'),
    ('| OWNER-RATIFIED 27 Oct 2026; superseded by this register; `551c1b42e99b58ad313dabe7d533e5650db83edce58e04f954b2f616c77afb3f` |',
     '| OWNER-RATIFIED 27 Oct 2026; superseded by register v0.6; `551c1b42e99b58ad313dabe7d533e5650db83edce58e04f954b2f616c77afb3f` |'),
    ('\n## Interpretation and verification\n',
     '\n' + NEW_SECTION + '## Interpretation and verification\n'),
]
for old, new in EDITS:
    n = t.count(old)
    assert n == 1, (n, old[:80])
    assert all(ord(c) < 128 for c in new), old[:60]
    t = t.replace(old, new)
assert t.endswith('\n')
open(out, 'wb').write(t.encode('utf-8'))
print(out, hashlib.sha256(t.encode()).hexdigest(), len(t.splitlines()), 'lines')
