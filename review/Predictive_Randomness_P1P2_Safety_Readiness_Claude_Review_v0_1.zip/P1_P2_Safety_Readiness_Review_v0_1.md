# Predictive Randomness — P1/P2 Coordinator Non-destructive Closure and Destructive-test Readiness Review v0.1

**Date:** 23 October 2026  
**Status:** REVIEW CANDIDATE for independent Claude assessment and owner decision; **NOT approval for process termination or production Option F**.  
**Scope:** Architecture v0.4 §5C; current engineering-only coordinator safety v0.3. No scientific E-methods or real/holdout lottery inputs used.

## 1. Decision summary for owner and reviewer

- **DECIDED within existing authority:** Accept the *core* non-destructive Windows P1/P2 ownership tests as PASS. Retain the unchanged single-wrapper Option F route and reviewed v0.3 coordinator. No changes to ratified documents, `.bat` files, dependencies or scientific source data. Perform milestone-batched rather than per-test review.
- **RECOMMENDED — owner decision outstanding:** Retain the initial **strict no-status/no-kill** rule: even if wrapper ancestry is verified, if the experiment's PID + creation time cannot be positively matched to `status.json`, **do not signal any process**. Report `UNVERIFIED` / `ORPHAN_SUSPECTED`, cease new scheduling, and require manual inspection. Trade-off: an experiment hung before status publication may remain running, but this favours avoidance of inadvertent process termination. This recommendation is **not yet ratified** and v0.3 already follows it.
- **OPEN — independent reviewer:** Is the evidence sufficient to proceed *towards* carefully controlled destructive test design? Specifically identify any remaining **non-destructive prerequisite**, including Windows forged/stale-status decoy validation, active/absent `.venv` coordinator refusal, console code-page before/after, and owner-switch risk.
- **OPEN — owner/reviewer:** The optional `known`-membership tightening from Claude's v0.3 review (`_member_alive(m) is True`, rather than `is not False`), and optional survivor-log refinements, have **not** been implemented. Determine whether any such refinement should be a pre-destructive blocker. Do not silently alter kill semantics as housekeeping.
- **REQUIRED:** `ENABLE_PROCESS_TERMINATION = False` remains mandatory. No CLI override. **No actual coordinator process kill has been Windows-tested.** Before/after PID+name+creation-time safety reports must remain mandatory. No command in this package enables or performs destructive tests.

## 2. Authoritative source and proof boundaries

The latest source archive available **to this author** is `analysing_perceived_randomness_in_reality-main(4).zip` (SHA-256 `77cfd287e5d444c3eae426392c8dccc4e5cc188d1e1e5faa2e7b4ce067105b06`; GitHub ZIP comment `6b527627f7f98fd5cd88f4bea76e16b9cb56d372`). It contains the *committed v0.2* coordinator (SHA-256 `26c471e183d073db6e258a51c5b363f90d3024bc497ebebeba804a25ab187cf4`), not v0.3. Following subsequent user installation, Windows v0.3 results were reported in chat. The user's later handover commit/push and local `HEAD` were **not independently inspected**. Thus the included diff is exact **against snapshot (4) v0.2**, not a claim to match the user's most recent unprovided Git HEAD.

Reviewed/current v0.3 coordinator SHA-256 `a2402175eaf22bf9d0293b49a6d1c91b48fe20d26866cf5d096dcfae6a95a58b`. The automated decoy utility requires that exact digest and verifies the global owner switch remains False.

`SHA256_and_Baseline_Manifest.json` records all source anchors. `Coordinator_v0_2_to_v0_3_EXACT.diff` contains the actual 90-line unified source diff. `New_Tests_Added_vs_Snapshot_4.diff` provides the add-only v0.3 regression and automated decoy utility, including complete new-file content. Review may cross-check the preserved `source_committed_v0_2.py`, `source_reviewed_v0_3.py`, the new test sources and original `.bat`/test/document reference files provided in this ZIP.

## 3. Binding architecture and safety controls

Under **ratified Architecture v0.4 §5C**:

```text
Manual:      user → Run_Experiment.bat → independent method Python
Coordinated: user → Run_Coordinator.bat → Python coordinator
               → Run_Experiment.bat (for each worker) → method Python
```

`Run_Coordinator.bat` activates/restores the project `.venv` as needed. The Python coordinator requires matching project `VIRTUAL_ENV` and `sys.prefix`; children inherit the validated environment. Current coordinator is **POC-only**, whitelists engineering probes and runs 1–6 workers; none of this proves production predictions work.

Termination invariants: prove wrapper-root identity from its own `Popen` handle; observe and retain descendants **while that root is alive**; verify parent-child ancestry, PID and creation time; ensure status PID is *evidence only*, never the source of kill targets; verify executable names as sanity check, not proof of ownership; terminate the root **only by `Popen` handle**, descendants **only through captured `psutil.Process` objects**; never employ `taskkill /T /F` or process-name-wide killing. If uncertain, fail safely and report. Initial methods may not spawn their own subprocesses. This is best-effort supervision, **not OS containment**.

Source v0.3 fixes two previously independently reviewed defects: (a) retire a stored transient member confirmed gone before independently assessing a reused PID; (b) use bounded `psutil.wait_procs` on kill-requested retained descendants before final survivor evaluation. In fake/synthetic tests only, these now pass. Strict status-matching before *any* kill remains the current source rule. The owner safety switch is **False**, no CLI override; pre/post safety logging is mandatory.

## 4. Windows evidence ledger — actual owner-reported console outputs

These are **evidence statements derived from the owner's supplied terminal transcripts**. The corresponding generated PC-local JSON manifests and coordinator-console files have **not been provided to this ChatGPT as attachments**, so do not claim their contents were independently inspected. Dates: 22–23 October 2026. All runs used synthetic engineering probes, not historical Powerball draws.

| ID / local evidence | Observed outcome | Assessment |
|---|---|---|
| P0 standalone wrapper | Correct `.venv` auto-activation and restoration from initially inactive CMD; canonical fixture digest `a853ac3545213c8f9be9355e312bf220a74fa89f240e4123aed308d983350937`; deliberate failure exit 3; abrupt exit 7; no-clobber sentinel preserved; invalid filename/path refused | **PASS for tested cases**, not comprehensive W-suite |
| P0/P1 startup sanity | Rejected fake conflicting `VIRTUAL_ENV` with exit 6, nonexistent filename with exit 5, invalid extension/traversal with exit 4 | **PASS**; early interactive `SETLOCAL` instructions were invalid and corrected by separate CMD retest |
| P1 coordinator one-worker canonical | Coordinator via batch returned canonical digest `a853ac3545213c8f9be9355e312bf220a74fa89f240e4123aed308d983350937`, `PASS successes=1/1`, exit 0 | **PASS** |
| v0.2 plan-only one-worker `coord-04692b32b8ee4e6d97f0ac8dd5cb04a8` | Normal wrapper → two Python descendants; status/ancestry match; `ENABLE_PROCESS_TERMINATION=False`; BEFORE/AFTER preview; normal successful finish | **PASS** for v0.2 preview |
| Four Windows static/synthetic suites after v0.3 install | `p0_static_checks`, `p1p2_static_checks`, `p1p2_non_destructive_safety_checks`, `p1p2_safety_regression_v0_3`: all PASS; fakes only for PID reuse / wait path | **PASS** in reported Windows console; **no live kill** |
| v0.3 six-worker preview `coord-f0bb1ffebc014ec883bdfa3890d904a1` | Six workers `experiment_matched=True`, `unmatched_status=none`, `ownership_anomalies=none`; BEFORE/AFTER all six; identical digest `234dab5ff151e4aa58cc77a1198cf69a50b5e63745e4a9464e5b6d42692b1b34`; `PASS successes=6/6`, exit 0 | **PASS**; plan-only, no kills |
| Inactive-CMD coordinator start `coord-6642bc2c09a14959b5c664dbcaa98e7c` | Initially `VIRTUAL_ENV` undefined; `Run_Coordinator.bat` canonical one-worker PASS, exit 0; `VIRTUAL_ENV` undefined afterwards; expected digest | **PASS** automatic activation/restoration |
| Same-project-venv unrelated Python decoy `coord-f48349f954094966a16f997d0ab16780` | Independent Python PID `17304` verified with same creation time before and after; absent from all six targets; six workers passed, no kills | **PASS** for this decoy, plan-only |
| Earlier manually managed global Python+CMD test | Temporary redirector misidentified as CMD (PID `12860`); process ended; no coordinator run performed; CMD windows closed | **INCOMPLETE — not a product failure**; superseded by automated test |
| Automated 3-decoy group `decoy_c2bf703c078f46e1b922285a8088d5f3` | Global Python PID 19732; project-venv Python PID 20312; independent CMD PID 7568; all original identities alive afterward; none in kill plans; six workers `6/6`; no kill; cooperative decoy shutdown exit 0; utility exit code 0 | **PASS** — actual Windows `cmd.exe` decoy now covered |

Automated decoy utility records paths under `transitory_data/poc_runs/decoy_c2bf703c078f46e1b922285a8088d5f3/` (`decoy_test_report.json`, `coordinator_console.txt`); the associated coordinator manifest is in a sibling `_coord` directory. These PC-local files are not in this review ZIP. The transcript-derived evidence suffices for a preliminary review but does **not** substitute for inspecting those artifacts at final acceptance if detailed trace corroboration is required.

**Test classification correction:** The previous successful no-clobber sentinel test (`poc_W23_20261022_A` directory label) belongs to A-17/A-18 and POC-Q08, **not** the actual W-23 upgrade gate. **W-23 remains NOT RUN.**

## 5. Outstanding evidence and review gates

**Completed for the non-destructive ownership subset:** live six-worker ancestry/status plans; switch False with per-worker BEFORE/AFTER; simultaneous unrelated global Python, project-venv Python and CMD decoys excluded; naturally completed jobs validated; coordinator wrapper .venv auto-activation and restoration tested. This is a credible **subset closure**, not entire P2 closure.

**Not yet shown on Windows / to classify before destructive permission:**

1. A **live** forged/stale-status PID that names an unrelated decoy was not reported; N2/N3 currently have synthetic status tests. Ratified §5C.3 requires forged/stale status PID consideration. Ask whether the synthetic contract test suffices before destructive readiness or develop an explicitly plan-only negative Windows probe.
2. A separate direct Python coordinator startup rejection with absent or mismatched `VIRTUAL_ENV` was not evidenced in provided terminal outputs. Normal batch wrapper activation from inactive CMD did PASS. Avoid direct launcher if it could start work under an unanticipated environment; a negative validation-only test can be designed.
3. A documented before/after Windows **console code page** (`chcp`) check was not in the reported inactive-CMD wrapper test. Ratified §5C.3 asks for it. Build this into a safe ordinary-CMD run or explicit wrapper test.
4. Synthetic-only PID collision and wait tests do not prove live Windows forced termination; the global switch remained False throughout the run. The optional `known` live-member filtering and survivor-log detail from Claude remain unresolved for pre-destructive classification.
5. **Destructive acceptance tests not attempted:** one-worker timeout, six-worker timeout, root-wrapper loss/recovery, Ctrl+C (including repeated), memory guard, live decoy preservation after actual termination. W-23 dependency-upgrade gate remains untested. Full W-suite, release-grade P2 evidence and Option F production acceptance remain OPEN.
6. The older `tests/windows_architecture_poc_suite.py` has an independent `subprocess.run(..., timeout=120)` watchdog that can **kill its launched batch handle** even with coordinator switch False, potentially orphaning descendants. Do not call it a kill-free test or run it casually under a blanket non-destructive policy.
7. Unresolved orphan handling/next-launch interlock should be checked against ratified architecture v0.4 §5C.2: do not silently continue after `ORPHAN_SUSPECTED`. How the current code represents persistent orphans across restarts is not yet acceptance-verified.
8. No genuinely independent *other-project* Python venv decoy was included (same-project venv + global Python + CMD were). Review whether that adds material evidence, rather than manufacturing another environment solely for testing.

## 6. Proposed staged path — NOT authorisation to execute

**Stage R0 (now):** Claude independently reviews this consolidated source, source diff, manifest and owner-reported Windows outcomes. Request classification of remaining non-destructive prerequisites, strong concerns, and evidence gaps. Owner considers ratifying **strict no-status/no-kill**.

**Stage R1 (if required):** Run only focused **non-destructive** gap-closing tests, ideally as one group: console code page before/after; direct coordinator guard rejection; synthetic vs actual forged-status decoy probe; optional monitoring-hardening choices. Update the review ledger and source hashes if code changes.

**Stage R2 (future owner + Claude gate):** Independent review of the exact source actually installed on the Windows PC, closure of any blockers, an owner-approved **controlled destructive test plan**. No broad switch flip as a preliminary diagnostic. Require confirming current Git identity, switch setting, decoys and their PID/ctime, and exact per-test commands before the first kill test.

**Stage R3 (only after explicit owner authorisation):** Enable kill switch in a controlled reviewed revision **only for the approved test window**, start with one disposable POC worker timeout, observe BEFORE/PID+name+ctime → ACTION → AFTER+survivor proof; check unrelated decoy identity again. Proceed gradually through six-worker timeout, root-only and interrupt/memory tests only on separate acceptance evidence. If anything cannot be verified, **fail closed** and return the switch to False before any further testing. This sequence is a proposal, not instructions to run now.

## 7. Independent reviewer questions

1. Do you agree with the explicit PASS / INCOMPLETE / NOT TESTED classifications, and with treating the complete *core* non-destructive phase as passed but P2 overall still open?
2. Are the v0.3 fixes adequate for approaching a controlled kill-path readiness review? Does `known` currently retain unverifiable parents (`_member_alive is None`) in a way that warrants tightening **before** any real kill attempt?
3. Should the **strict no-status/no-kill** rule be formally ratified as the first-release safety policy? Distinguish preserving unknown processes from leaving a genuine orphan behind.
4. Which remaining non-destructive gates of §5C.3 are **mandatory** before kill-enablement (live forged status, code page, startup negative checks, persistence/orphan interlock)? Which can be deferred to production readiness?
5. What minimal, operator-visible, single-process destructive test procedure would give convincing evidence that only captured owned members can be signalled? Do not recommend flipping the global safety switch merely to explore behaviour.
6. What further evidence of child console/`Ctrl+C` semantics or ephemeral Windows process ordering is required before moving beyond the first timeout test?
7. Would you require archived actual Windows JSON/log evidence before certifying P2, instead of accepting pasted console results? If so, name a compact reproducible evidence bundle format.
8. Is there any material gap against ratified Architecture v0.4 §5C, POC task spec v0.1 and the owner's prohibition against killing unrelated processes?

Please provide a concise independent assessment with **BLOCKERS**, **RECOMMENDATIONS**, **SAFE TO DEFER**, and an **OWNER DECISION LIST**; do not modify source and do not authorise destructive tests on the strength of this document alone.

## 8. Review package inventory

- This review report and a short separate review request.
- `Coordinator_v0_2_to_v0_3_EXACT.diff`, plus full committed-v0.2 and reviewed-v0.3 coordinator sources.
- `New_Tests_Added_vs_Snapshot_4.diff`, the regression and automated decoy test sources.
- `SHA256_and_Baseline_Manifest.json` with snapshot and file digests.
- Exact unmodified baseline `Run_Coordinator.bat`, `Run_Experiment.bat`, original relevant test scripts, ratified v0.4 architecture and POC specification under `reference_baseline/`.

**No Git mutations, dependency updates, owner-switch changes, actual kills or Windows testing were performed to assemble this review package.**
