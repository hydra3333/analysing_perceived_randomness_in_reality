"""Spec v0.3r1 -> v0.3r2: answer the focused recheck (F-B01, F-C01..C04) and record owner decisions D-9, D-10.

Counted replacements; each old string must occur exactly once; inserted text is ASCII.
Usage: python3 -I make_v03r2.py IN_v0_3r1 OUT_v0_3r2
"""
import hashlib, sys

src, out = sys.argv[1], sys.argv[2]
t = open(src, encoding='ascii').read()
assert hashlib.sha256(t.encode()).hexdigest() == '7211f4c9d6f8e51a83629e68d03c9fe2d7593acca11a1b904ec75123dde5dbd0'

REGISTRY_SECTION = """### 5.5 Registry entries: administrative status, kept apart from the declaration (new for F-B01)

- **E2R-R21B (DECIDED principle, R2 5.6 field 1 and R2-C13; RECOMMENDED structure).** The registry status, its reason and the descriptive texts live in **registry entries**, not in the declaration. The declaration therefore never changes when a method is released, and forecast records keep the same declaration digest.
- Each `(game_id, method_id, variant_id)` has an append-only sequence of `REGISTRY_ENTRY_V1` records. The newest entry is the **active** one, and earlier entries are never edited or deleted.

| Field | Rule |
|---|---|
| `schema` | `REGISTRY_ENTRY_V1` |
| `game_id`, `method_id`, `variant_id` | the method variant |
| `entry_sequence` | 1, 2, 3 ... with no gaps, per method variant |
| `method_revision`, `declaration_digest` | the revision and immutable declaration this entry governs; null only while no declaration exists (`FORMULA_OPEN` with no specification yet) |
| `registry_status` | `SUPPORTED`, `FORMULA_OPEN` or `UNSUPPORTED_FOR_GAME` |
| `registry_status_reason` | non-empty, always |
| `method_name` | the exact registered name (R2 section 7.1) |
| `one_liner`, `short_explanation` | plain English (E2R-R21A) |
| `text_provenance` | `author`, `date`, `text_version`, `source_reference` (field 1, "per-version provenance") |
| `effective_date` | the date the entry was installed |
| `previous_entry_digest` | the digest of entry `entry_sequence - 1`, or null for the first |

- **E2R-R21C (RECOMMENDED).** Rules for registry entries:
  - Only an active entry with status `SUPPORTED` can admit a run, and only for its own declaration digest (section 12A.3). `FORMULA_OPEN` and `UNSUPPORTED_FOR_GAME` entries never have method output records.
  - Release, a text correction or a status change appends a new entry. None of them changes the declaration, and none forces a new scientific revision.
  - A new revision always gets a new declaration, plus a new entry that points to it, normally starting as `FORMULA_OPEN` until release (E2R-R58).
  - Every past declaration and registry entry stays readable. Historical records are validated against the declaration digest they quote.
  - A `SUPPORTED` entry may point only to a declaration whose `stochastic_fit` is false, or whose `fit_seed_policy_id` names a reviewed seed policy (E2R-R61).

"""

T14_NEW = ("| E2R-T14 | Dispatch gate truth table and release transition (ADD-C08, F-B01) | SUPPORTED or not, times flag present or absent; "
           "missing and stale registry entries; a retired-revision approval against new code; both launchers; refusal before any data read; "
           "the refusal text. Release transition (synthetic): declaration D and entry 1 (`FORMULA_OPEN`) are refused; entry 2 (`SUPPORTED`, same D) "
           "is appended and dispatch is admitted once the flag is gone; entry 1 and D are unchanged; records made under D stay valid; a request "
           "pinning a stale entry digest or a mismatched declaration digest is refused. No existing gate is bypassed |")

T16_NEW = ("| E2R-T16 | Receipts and terminal records (E2R-B03, F-C01) | A freeze receipt is issued only after a valid C1 and has no scoring field. "
           "Consumption needs a valid SUCCESS terminal record with matching receipts. Simulated cases, all non-consumable: interruption after the "
           "freeze receipt but before the SUCCESS terminal record; no terminal record at all; a failed terminal record; an orphan-suspected group. "
           "Each leaves its files preserved, triggers no cleanup or termination, and counts as unsuccessful. No real process is killed and no "
           "destructive fault is injected |")

T17_NEW = ("| E2R-T17 | Multiple publications for one target (F-C03; specification-level scenario) | Two timely published revisions for one track "
           "and target, one designated official before the draw, plus one late or unverified candidate: all three are retained and labelled; the "
           "\"as published\" series shows the official one and counts the others; nothing is chosen after the outcome; publication totals state "
           "their denominator. Checked as a scenario on synthetic records now; the publication mechanism itself waits for the FINAL specification |")

EDITS = [
    ('# Predictive Randomness - E_2-readiness method-generic contract specification, v0.3r1\n',
     '# Predictive Randomness - E_2-readiness method-generic contract specification, v0.3r2\n'),
    ('v0.3r1 differs from v0.3 (never sent for review) only by recording the owner\'s decision D-8 on OPEN-4 (E2R-R40B, section 14, Appendix A).',
     'v0.3r2 answers the reviewer\'s focused recheck of v0.3r1 (`Independent_ChatGPT_E2R_v0_3r1_Focused_Recheck_v0_1.md`, `866974a7...e392`: 1 BLOCKER, 4 CORRECTION), and records the owner\'s seed decisions D-9 and D-10; Appendix B maps each item. v0.3r1 differed from v0.3 (never sent for review) only by recording the owner\'s decision D-8 on OPEN-4.'),
    ('(section 14; none remain at v0.3r1).', '(section 14; none remain at v0.3r2).'),
    (' (A) Method declaration ----------------------+\n     static: game, method, variant, revision, |\n     registry status, capabilities, texts     |\n',
     ' (A1) Method declaration (immutable) ---------+\n      game, method, variant, revision,        |\n      capabilities                            |\n (A2) Registry entries (append-only) ---------+\n      status, reason, texts; newest is active |\n'),
    ('  - C names A\'s declaration digest;\n',
     '  - C names A\'s declaration digest;\n  - B, D1 and D2 name the active registry entry\'s digest as well (section 5.5);\n'),
    # F-C02
    ('  - If an approved method\'s specification or implementation changes, or a behaviourally relevant shared helper it uses changes, each affected runnable method gets a successor revision, or a reviewed compatibility decision recorded in the package. This applies even if the method\'s own entry file is unchanged.\n',
     '  - If an approved method\'s specification or behaviourally relevant implementation actually changes, including a change to a behaviourally relevant shared helper it uses (arithmetic, selection, encoding or view preparation, directly or through other helpers), that method **must** get a successor revision. This applies even if its own entry file is unchanged (reviewer\'s F-C02).\n'
     '  - A documented compatibility finding may establish only that a changed helper is **not used** by a method, or that the changed part is **not behaviourally relevant** to it. It never excuses a known change to that method\'s implementation.\n'),
    ('  - *Example:* E_2 r1 and E_3 r1 both use shared helper H r1. A package changes H\'s arithmetic, making H r2. That package also declares E_2 r2 and E_3 r2 (or records a reviewed compatibility decision for each), and moves H r1 and both methods\' r1 files to the archive (section 12A). E_4, which does not use H, stays at its revision.\n',
     '  - *Example:* E_2 r1 and E_3 r1 both use shared helper H r1. A package changes H\'s arithmetic, making H r2. That package also declares E_2 r2 and E_3 r2, and moves H r1 and both methods\' r1 files to the archive (section 12A). E_4, which does not use H, stays at its revision, and the package records that finding.\n'
     '  - The one scoped exception is NAMES-1\'s purely structural rename, decided and reviewed in that package (12A.5). It is not a precedent for later substantive changes.\n'),
    # F-B01: declaration fields
    ('One declaration exists per `(game_id, method_id, variant_id, method_revision)`. It is static: it never depends on a target or on data.',
     'One declaration exists per `(game_id, method_id, variant_id, method_revision)`. It is static and immutable: it never depends on a target or on data, and it never changes after it is installed. Status, reason and descriptive texts are not part of it. They live in registry entries (section 5.5), so releasing a method never changes its declaration (reviewer\'s F-B01).'),
    ('| `registry_status` | enum | `SUPPORTED`, `FORMULA_OPEN`, `UNSUPPORTED_FOR_GAME` | field 1; R2-C13 |\n'
     '| `registry_status_reason` | text | non-empty, always | field 1 ("with its reason") |\n'
     '| `method_name` | text | the exact registered name (R2 section 7.1) | field 1 |\n'
     '| `one_liner` | text | one sentence, plain English | field 1; R2 6.2 |\n'
     '| `short_explanation` | text | a short paragraph, plain English | field 1; R2 6.2 |\n'
     '| `text_provenance` | object | `author`, `date`, `text_version`, `source_reference` | field 1 ("per-version provenance") |\n',
     ''),
    # F-C04: seed policy field rule
    ('| `fit_seed_policy_id` | text or null | null when `stochastic_fit` is false; otherwise the ID of a reviewed seed policy (section 7.6) | R2 9.2; E2R-C01 |',
     '| `fit_seed_policy_id` | text or null | null when `stochastic_fit` is false. When `stochastic_fit` is true: null means "seed policy not yet specified", a legal placeholder for a non-runnable method; otherwise the ID of a reviewed seed policy. A `SUPPORTED` registry entry requires a reviewed policy (E2R-R21C, E2R-R61) | R2 9.2; E2R-C01; F-C04 |'),
    ('- **E2R-R19 (DECIDED; current registry).** E_1 is `SUPPORTED` for both games. E_2 to E_62 are `FORMULA_OPEN` until each method\'s specification is ratified, implemented and reviewed. A `FORMULA_OPEN` or `UNSUPPORTED_FOR_GAME` declaration is valid and stays registered. It can never produce a method output record.',
     '- **E2R-R19 (DECIDED; current registry).** E_1\'s active registry entry is `SUPPORTED` for both games. E_2 to E_62 have `FORMULA_OPEN` entries until each method\'s specification is ratified, implemented and reviewed. A `FORMULA_OPEN` or `UNSUPPORTED_FOR_GAME` entry is valid and stays registered. It can never produce a method output record.'),
    ('`method_name`, `one_liner` and `short_explanation` are written, in plain English, for E_1 and E_2 in the E_2-readiness code package. For E_3..E_62 they are written with each method\'s own specification. Until then, those declarations carry',
     '`method_name`, `one_liner` and `short_explanation` (held in registry entries, section 5.5) are written, in plain English, for E_1 and E_2 in the E_2-readiness code package. For E_3..E_62 they are written with each method\'s own specification. Until then, those registry entries carry'),
    ('Changing any declared field means a new declaration, with a new `method_revision` or `variant_id` where the science changed. The declaration holds no source path, file hash or commit ID (E2R-R14A).\n\n---\n',
     'Changing any declared field means a new declaration, with a new `method_revision` or `variant_id` where the science changed. The declaration holds no source path, file hash or commit ID (E2R-R14A).\n\n' + REGISTRY_SECTION + '---\n'),
    ('`run_mode`; `product_kind`; the declaration digest;',
     '`run_mode`; `product_kind`; the declaration digest; the active registry entry digest;'),
    # F-C04: 7.6
    ('  - a declaration with `stochastic_fit: true` names a `fit_seed_policy_id`;\n',
     '  - a declaration with `stochastic_fit: true` may carry a null `fit_seed_policy_id` (a placeholder: seed policy not yet specified) only while its registry entry is not `SUPPORTED`; a `SUPPORTED` entry requires a reviewed policy (E2R-R21C);\n'),
    ('  No seed policy exists yet, so stage 1 accepts no stochastic declaration as `SUPPORTED`.',
     '  No seed policy exists yet, so in stage 1 no `SUPPORTED` entry can point to a stochastic declaration, and no stochastic fit runs. Typed placeholders for future stochastic methods are legal.'),
    ('- The reviewer verifies outcome-independence and suffix-invariance. Code for this always gets RECHECK (review-disposition procedure, section 4).\n',
     '- The reviewer verifies outcome-independence and suffix-invariance. Code for this always gets RECHECK (review-disposition procedure, section 4).\n'
     '- **E2R-R63 (DECIDED; owner decisions D-9 and D-10, 28 October 2026; RECOMMENDED wording).** Root seeds and switching between them:\n'
     '  - **Source (D-9):** a seed policy\'s root comes from the NIST Randomness Beacon. It is the single pulse at a time stated in the policy **before** that time arrives, fetched once by hand after it is published, and recorded in the policy with its pulse identifier. Runs never fetch anything. The root and the per-target derivation are fixed for that policy, so every run under it is exactly reproducible.\n'
     '  - **One policy per tune:** each revision or variant may name its own pulse in its own policy.\n'
     '  - **Switching (D-10):** the owner may replace a root, for example on intuition. A replacement is a new seed policy ID, under a new revision (replacing the old one) or a new variant (running alongside it). Results under every earlier root are kept and remain reportable.\n'
     '  - **Counting:** every seed policy tried for a method is logged in the programme search log, and reports state how many were tried for each method. This is how luck from trying several roots is judged; it is never a limit on trying (pattern origin PO-3, R3 17.3.9).\n'),
    # F-B01: receipt carries registry entry
    ('| `run_id`, `execution_path` | `mg-...`; `STANDALONE` or `COORDINATED` |',
     '| `run_id`, `execution_path` | `mg-...`; `STANDALONE` or `COORDINATED` |\n| `registry_entry_digest` | the active registry entry that admitted the run (orchestration side only; it never enters the forecast content) |'),
    # F-C01: terminal record
    ('- **E2R-R38 (DECIDED; failed-group firewall, register 23 October 2026; structure RECOMMENDED).** Every admitted run ends with a create-only terminal record holding:\n',
     '- **E2R-R38 (DECIDED; failed-group firewall, register 23 October 2026; structure RECOMMENDED; revised for F-C01).** A run that completes the terminal-publication protocol ends with one create-only terminal record holding:\n'),
    ('  - on success, the digests of the freeze receipt(s) issued.\n',
     '  - the active registry entry digest;\n  - on success, the digests of the freeze receipt(s) issued.\n'),
    ('  A run whose outcome is not `SUCCESS`, or whose coordinated group is FAIL or orphan-suspected, has **no consumable output**, even if an output file exists, and it never gets a freeze receipt. In the code package, this record generalises Package 2\'s existing status and manifest records, which keep their firewall semantics. A refused dispatch (section 12A.3) is reported, not run, and gets no terminal record, because no run started.\n',
     '  The terminal record is written by the orchestration side (the coordinator or the standalone runner wrapper), never assumed to be written by a failed method process. In the code package, it generalises Package 2\'s existing status and manifest records, which keep their firewall semantics. A refused dispatch (section 12A.3) is reported, not run, and gets no terminal record, because no run started.\n'
     '- **E2R-R38A (RECOMMENDED; F-C01).** Publication order and consumption:\n'
     '  1. The method output file (C1 or C2) is created, create-only.\n'
     '  2. It is validated, then its freeze receipt (D1 or the diagnostic receipt) is created, create-only.\n'
     '  3. Only then is a `SUCCESS` terminal record (D2) created, naming those receipts.\n\n'
     '  An output is consumable **only if** all of these hold:\n'
     '  - a valid `SUCCESS` D2 exists;\n'
     '  - its receipts and output files match;\n'
     '  - every existing group and firewall gate passes, including the coordinator\'s exit receipt and the orphan-marker interlock.\n\n'
     '  An absent, invalid, incomplete or non-`SUCCESS` D2 means **not successful**, whatever other files exist. A D1 left by an interrupted run is preserved and treated as quarantined. It never counts as an accepted freeze, and it never triggers automatic cleanup, deletion or termination. The no-status/no-kill rule and the global orphan marker apply unchanged. There is no automatic recovery: any later disposition of such a run is a separate, owner-approved inspection.\n'),
    # F-C03
    ('  - Neither view mixes revisions into one model\'s statistics, and comparisons and league tables use the single-revision rule.\n',
     '  - Neither view mixes revisions into one model\'s statistics, and comparisons and league tables use the single-revision rule.\n'
     '- **E2R-R40C (RECOMMENDED; F-C03).** More than one publication for the same target:\n'
     '  - **Every** genuine before-draw publication stays visible, in an immutable publication history, with its revision and its publication evidence.\n'
     '  - If the "as published" series shows **one official forecast per track and target**, which one is official is fixed **before the outcome** by a predeclared rule or an official-batch designation. Other publications for that target are counted and listed separately. Nothing is chosen after the outcome.\n'
     '  - If a view lists several publications for one target, its totals state the publication denominator, and several attempts at one target are never counted as independent target outcomes.\n'
     '  - `frozen_at_utc` is a local time, not proof of timely publication (R2 8.2A). Publications without independent publication evidence are labelled unverified and counted. Retained archives remain valid if Git history is later cleaned, but they are not themselves publication evidence.\n'
     '  - The exact publication and evidence mechanism belongs to the later, separately reviewed FINAL and publication specification. Stage 1 does not assume one publication per target.\n'),
    # F-B01 gate wording
    ('  1. an exactly matching **SUPPORTED** registry declaration for the requested game, method, variant and **current revision**;\n',
     '  1. an **active SUPPORTED registry entry** for the requested game, method and variant, whose revision and declaration digest exactly match the request, and whose entry digest the request pins (section 5.5);\n'),
    ('  - A missing, stale or non-SUPPORTED registry entry denies. An approval for a retired revision is not an approval for its successor.\n',
     '  - A missing, stale (not the active entry) or non-SUPPORTED registry entry denies, as does a declaration digest that does not match. An approval for a retired revision is not an approval for its successor.\n'),
    ('  - A package that introduces new or revised method code installs it **non-runnable**: the flag file is present, and the registry does not yet support the new revision.\n'
     '  - Release is a separate, small, reviewed package the owner installs. It deletes the flag and changes the registry entry: the owner\'s two deliberate actions.\n',
     '  - A package that introduces new or revised method code installs it **non-runnable**: the flag file is present, the new declaration is installed, and the active registry entry for the new revision is not `SUPPORTED`.\n'
     '  - Release is a separate, small, reviewed package the owner installs. It deletes the flag and appends a `SUPPORTED` registry entry for the same declaration: the owner\'s two deliberate actions. The declaration and earlier entries are not changed.\n'),
    ('- **On revisions:** Claude recommends that NAMES-1 keeps E_1 at revision 1, because its proof shows the code identical apart from import paths. NAMES-1 records that decision explicitly for review; unchanged goldens alone would not be enough.\n',
     '- **On revisions:** Claude recommends that NAMES-1 keeps E_1 at revision 1, because its proof shows the code identical apart from import paths. NAMES-1 records that decision explicitly for review; unchanged goldens alone would not be enough. This structural exception is scoped to NAMES-1 only (E2R-R14A).\n'),
    # tests
    ('`is_interface_version` and `fit_seed_policy_id` are null in every declaration |',
     '`is_interface_version` is null in every declaration. Every declaration that a stage-1 `SUPPORTED` entry points to is deterministic, with a null `fit_seed_policy_id`. A typed stochastic placeholder (`stochastic_fit` true, null policy, entry not `SUPPORTED`) validates. A `SUPPORTED` entry pointing to a stochastic declaration without a reviewed policy is rejected (F-C04) |'),
    ('| E2R-T13 | Revision rollover (ADD-C06) | In synthetic identities, a changed shared helper requires successor declarations for its dependent runnable methods, and unaffected methods keep their revisions. No path, file hash or commit enters a declaration or content digest |',
     '| E2R-T13 | Revision rollover (ADD-C06, F-C02) | In synthetic identities, a changed arithmetic helper with an unchanged dependent revision fails, even when a narrow fixture happens to give the same numbers; dependent runnable methods require successor declarations; genuinely unaffected methods keep their revisions with a recorded finding; the NAMES-1 structural exception is recognised only for that package. No path, file hash or commit enters a declaration or content digest |'),
    ('| E2R-T14 | Dispatch gate truth table (ADD-C08) | SUPPORTED or not, times flag present or absent; missing and stale registry entries; a retired-revision approval against new code; both launchers; refusal before any data read; the refusal text. No existing gate is bypassed |', T14_NEW),
    ('| E2R-T16 | Receipts and terminal records (E2R-B03) | A freeze receipt is issued only after a valid C1 and has no scoring field. Every run, successful or failed, gets one terminal record. A failed run gets no freeze receipt, and its output is not consumable even if a file exists |',
     T16_NEW + '\n' + T17_NEW),
    # section 14
    ('- **D-8 (was OPEN-4, the reviewer\'s E2R-REC01):**',
     '- **D-9:** a seed policy\'s root comes from a pre-announced NIST Randomness Beacon pulse, fetched once by hand; runs never fetch (E2R-R63).\n- **D-10:** the owner may switch roots ("another universe") as a new revision or variant; every root tried is logged and counted in reports (E2R-R63).\n- **D-8 (was OPEN-4, the reviewer\'s E2R-REC01):**'),
    ('*End of specification draft v0.3r1.*',
     """## Appendix B. Resolution of the focused recheck of v0.3r1

| Finding | Class | Resolution in v0.3r2 |
|---|---|---|
| F-B01 immutable declaration versus changing registry status | BLOCKER | Status, reason and texts moved out of the declaration into append-only `REGISTRY_ENTRY_V1` records (5.5, E2R-R21B/C). The declaration is immutable; release appends a `SUPPORTED` entry for the same declaration; the run request, receipts and terminal record pin the active entry digest; stale and mismatched digests are refused (E2R-R57); test E2R-T14 extended with the release transition |
| F-C01 interruption between freeze receipt and terminal record | CORRECTION | E2R-R38 limited to runs that complete the protocol; E2R-R38A defines the publication order, consumption only with a valid `SUCCESS` D2 plus all existing gates, quarantine of stray D1s, no automatic cleanup or termination, and no assumption that a failed process writes its own D2; test E2R-T16 extended |
| F-C02 compatibility exception too broad | CORRECTION | E2R-R14A: a successor revision is mandatory when the behaviourally relevant implementation changes, including through helpers; compatibility findings only for "not used" or "not relevant"; the NAMES-1 structural exception is scoped to that package; test E2R-T13 extended |
| F-C03 several publications for one target | CORRECTION | E2R-R40C: all publications retained with evidence; a predeclared official designation if one per target is shown; others counted; denominators stated; local times not proof; the mechanism is deferred to the FINAL specification; new test scenario E2R-T17 |
| F-C04 stochastic placeholder versus T08 | CORRECTION | A null `fit_seed_policy_id` is a legal placeholder for a non-`SUPPORTED` stochastic method; `SUPPORTED` requires a reviewed policy (5.1, E2R-R21C, E2R-R61); test E2R-T08 revised |
| Owner D-9, D-10 (not findings) | - | E2R-R63: NIST beacon root, one pulse per policy, switching roots as a new revision or variant, and every root tried logged and counted |

*End of specification draft v0.3r2.*"""),
]

for old, new in EDITS:
    n = t.count(old)
    assert n == 1, (n, old[:90])
    t = t.replace(old, new)
assert all(ord(c) < 128 for c in t)
assert t.endswith('\n')
open(out, 'w', encoding='ascii', newline='\n').write(t)
print(hashlib.sha256(t.encode()).hexdigest())
