# E2R-1 - E_2-readiness specification v0.3r2 - handback for focused recheck

**Work-item card**

| Field | Value |
|---|---|
| Item | E2R-1: the stage-1 contract-field schema and acceptance list before E_2 |
| Author chat | Claude (primary designer and coder) |
| Reviewer chat | ChatGPT reviewer chat (H-2 v1r3) |
| Base commit | `be185485693f29cf9ab28292dc6eebad00bbc32c` |
| Inputs | v0.3r1 `7211f4c9d6f8e51a83629e68d03c9fe2d7593acca11a1b904ec75123dde5dbd0`; recheck `Independent_ChatGPT_E2R_v0_3r1_Focused_Recheck_v0_1.md` `866974a7ca38a156c76d46034fd0f31c2970b814dc627685f33c9c585f8ae392` |
| Scope | One specification document. No code, no change to any ratified document. |
| Risk tier | HIGH. All five findings carry RECHECK |
| Owner gate | The owner ratifies after the recheck |
| Evidence state | IMPLEMENTED (draft); mechanically checked; not yet REVIEWED |

**Date:** 28 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears in or was used for this document.

## Contents

| File | SHA-256 |
|---|---|
| `Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r2.md` (ASCII, LF) | `2c69a9a8469ef1415b90d15e48d9de490310cfebe18d8be8694d0eb5483da115` |
| `evidence/spec_v0_3r1_to_v0_3r2.diff` (exact diff from v0.3r1) | `ebd2e6eedfbbe66c5fce0095086ed7e838a4ead8c92148361a2ce4a792097f15` |
| `evidence/make_v03r2.py` (32 counted replacements; refuses any other input) | `c739382470af6459d8c1caa4bc5645b2f63769aa310ce7b08d5b0d4da388752c` |

Reproduce: `python3 -I evidence/make_v03r2.py <v0.3r1> <out>`. The output's hash must equal the spec's.

## Response matrix (also spec Appendix B)

| Finding | Response |
|---|---|
| F-B01 | The declaration is now purely scientific and immutable. Status, reason and texts move to append-only `REGISTRY_ENTRY_V1` records, where the newest is active (new 5.5). Release appends a `SUPPORTED` entry for the same declaration, so there is no new revision and no change to forecast records. The run request, receipts and terminal record pin the active entry digest, and dispatch refuses stale or mismatched digests. E2R-T14 is extended with the release transition. |
| F-C01 | E2R-R38 now applies to runs that complete the protocol. The new E2R-R38A sets the publication order (output, receipt, then `SUCCESS` D2). Consumption needs a valid `SUCCESS` D2 plus all existing gates. A stray D1 is quarantined, never counted, and triggers no cleanup or termination. D2 is written by the orchestration side, never assumed from a failed process. E2R-T16 is extended. |
| F-C02 | Under E2R-R14A, a successor revision is mandatory when the behaviourally relevant implementation changes, including through helpers. A compatibility finding may establish only "not used" or "not relevant". The NAMES-1 structural exception is scoped to that package. E2R-T13 is extended. |
| F-C03 | The new E2R-R40C retains every publication with its evidence. If one official forecast per target is shown, it is designated before the outcome; other publications are counted and denominators stated; local times are not proof. The mechanism is deferred to the FINAL specification. New scenario E2R-T17. |
| F-C04 | A null `fit_seed_policy_id` is a legal placeholder for a stochastic method that is not `SUPPORTED`. `SUPPORTED` requires a reviewed policy. E2R-T08 is revised. |

**Not a finding:** the owner's seed decisions D-9 and D-10 are recorded in the new E2R-R63:
- a NIST Randomness Beacon root, one pre-announced pulse per policy, fetched once by hand, so runs never fetch anything;
- the owner may switch roots, as a new revision or variant;
- every root tried is logged and counted in reports.

Please check that E2R-R63 is consistent with your F-C04 and C01 positions.

## Oversight (owner instruction)

Claude reported your E2R-RD-09..13 to the owner and found no departure from the ratified rules. RD-13 (counting this recheck as a continuation of review 4) is a routine counting decision; its only effect is that more reviews come under oversight.

*End of handback.*
