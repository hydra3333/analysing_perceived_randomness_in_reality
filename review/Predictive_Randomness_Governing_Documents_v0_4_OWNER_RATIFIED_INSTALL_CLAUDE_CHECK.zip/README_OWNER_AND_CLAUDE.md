# Predictive Randomness — ratified governing documents installation package

**Owner ratification:** 26 October 2026. **State:** awaiting independent Claude mechanical comparison *before* owner installs/commits.

**Source candidate:** `Predictive_Randomness_Governing_Documents_CONSOLIDATED_v0_4_CLAUDE_SPOTCHECK.zip` (SHA-256 documented in the JSON manifest). Independent Claude v0.4 review: PASS; no BLOCKERS or CORRECTIONS; reference HEAD `c93ef81`.

## Install sequence

1. Give this complete ZIP to Claude and request the agreed mechanical comparison against the v0.4 candidates, including protected blocks, original 17 ratified-register identities, all eight destination file names and all seven non-self SHA entries. **Do not install if Claude identifies unapproved drift.**
2. After PASS, inspect `INSTALL_OVERLAY/doc/` and copy these **eight new versioned files** to the repository `doc/` folder. No renames/overwrites/deletes of the older ratified files, R1, TIE contract or handovers.
3. Check the eight Git-stored file contents against `REVIEW_EVIDENCE/SHA256_AND_CANDIDATE_COMPARISON.json` and `git status`. Use `git hash-object` only if aware SHA-1 != the listed SHA-256; `git show HEAD:doc/... | python -c ...` after commit gives LF SHA-256.
4. Owner commits and pushes the documents. Record the final commit ID and verify each of the eight `git show <HEAD>:doc/...` SHA-256 matches. Never claim a push before confirmation.
5. **Then** prepare the definitive full ChatGPT coder handover from the committed HEAD and owner decisions. Claude prepares its current reviewer handover if needed to compare two ways and performs the **one agreed independent review** of the ChatGPT handover. Owner accepts the corrected handover; a FRESH ChatGPT coding conversation then orients from these ratified documents + reviewed handover.

## Boundaries

Ratification and installation grant **no** scientific run, Windows run, dependency upgrade, master update, new source acquisition, holdout opening, Mode H, FINAL, process termination, safety switch change, or Package 2 v0.11 code permission. ERR-R2-02 Option F remains PROVISIONAL. Decisions flagged RECOMMENDED, OPEN or PROPOSED remain so unless separately owner-decided.

## Technical notes

- All eight installed Markdown files use UTF-8 / LF; the register tracks seven other new file SHA-256s, and its own hash is external to avoid self-reference.
- Seven protected byte-identical blocks verified in the installation files. The original 17 historic hashes were not altered.
- The separate `REVIEW_EVIDENCE/status_only_diffs/` files show the precise candidate-to-install changes. Historical source documents remain in Git, unchanged.
- The v0.4 Architecture 5A.2 optional wording recommendation has **not** been incorporated, preventing unreviewed semantic drift; it may be considered in a later reviewed change.
