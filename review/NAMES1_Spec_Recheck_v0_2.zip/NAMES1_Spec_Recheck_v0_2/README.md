# NAMES-1 specification v0.2 - focused RECHECK of N1-C01..C04, N1-O01 and N1-REC01

| Field | Value |
|---|---|
| Item | NAMES-1 one-off rename specification, v0.2 (design only) |
| Author / reviewer | Claude / ChatGPT reviewer chat |
| Responds to | `Independent_ChatGPT_R3_Design_Review_NAMES1_v0_1.md` (`30d24ed02ff4ba3b0c84c760f306c8bfd02ddd2717db61013e60f855e3ace85a`) |
| Base | `38fc60e03ea0766f72476cbab7c0e1eb5bd59d07`; v0.1 `88379b2800f0b660242ece361178eff7c0a2ebc70c68a83916cb187d1fa9dce5` |
| Disposition asked | Focused RECHECK |
| Owner decisions | OPEN-N1 (A or B), OPEN-N2, OPEN-N3: requested from the owner in parallel |
| Evidence state | IMPLEMENTED (draft); author-side Linux trials only; not yet RECHECKED; no Windows result |

**Date:** 28 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears in or was used for this package. All trials ran on disposable exports of `38fc60e`, with the offline synthetic suite only.

| File | SHA-256 |
|---|---|
| `Predictive_Randomness_NAMES1_Rename_Specification_v0_2.md` | `07bda3e4a8a99bfc611a76cec672f8642532186567737e1a23de5e5701489e5a` |
| `evidence/names1_spec_v0_1_to_v0_2.diff` (exact; 3 hunks) | `304768c45377698c5db73f4d85bdaede42a1464c39f551f9ce383f46c983625b` |
| `evidence/allowlist.tsv` (94 rows) | `2074f152b52f0adadd581546ef704341962cffe0c2d00a4d59d8301e1a3c315f` |
| `evidence/t02_check_output.txt` | `ee63645e64bbd9deb4ff61ff1b3f6b0274509068bd66d5c2997ff5547f43da34` |
| `evidence/negative_checks_output.txt` (94 checks) | `46c9190b6f87697da83274cfc8855560719b78e4586b2cdbd635f0a54bf3bf10` |
| `evidence/suite_base_per_module.txt` | `51b284ad1b9f1347d2720e79de6a025618c1c5ca5ce8fe41c4b73b5a89a3fdbf` |
| `evidence/suite_renamed_per_module.txt` | `f7c72673a8d157aa7d01f4b0eb4a1c24fb5234ade870a460fd2bab3ff843e844` |
| `tools/rename_map.py` (unchanged from v0.1) | `8a361e93691a2afe0ca2dbd670bcc327d4d624c4fe846933da7d83115a6793ae` |
| `tools/apply_trial.py` (unchanged from v0.1) | `82aecd26b05d295113e0348f58d788bda9efcb8eedf6bbdcb4fd0dd3140eb790` |
| `tools/build_allowlist.py` (new) | `cfa17a79c150f58b7dc9c529f02e85adc23c683639ff8ebb7c3717dcd0bbb20b` |
| `tools/t02_check.py` (new) | `b09396ed2b3bb21b7e187a453df899078c191677c9f19a537d57ddd7e83e2064` |
| `tools/negative_checks.py` (new) | `becb034a832d499d0b6de39ac8400409e0ef5dad6d1026f8395a121653fdcaf6` |
| `tools/per_module_suite.py` (new) | `0c3a32bb5a1e25426cb6b8481b5608a5418a48394f1dae4fdacc5fdf63890ae8` |

## Where each finding is answered

- **N1-C01:** N1-R01 (bounded), new N1-R01A (categories A to D), new N1-R01B (the receipt's contract-file keys change; old receipts fail closed), section 5A (the 12 fixed non-import sites), N1-T02 (exact allowlist, every change printed), new N1-T05A (mutations). The v0.1 "test logic unchanged" claim is withdrawn.
- **N1-C02:** N1-T09 (all 79 on Windows; per-module counts; symlink skips possible, not required; anything else stops); the 19-test command is added.
- **N1-C03:** N1-T01 (every live file, empty non-Python allowlist, `.bat` byte-identical, no stray old-name `.py`/`.pyc`), N1-T05 (fresh `-I -B` interpreters), N1-T05A (issuer literal, unchanged comparison and refusal, fresh-process origin equality, old literal fails closed).
- **N1-C04:** N1-T10 (immediate install-recovery check, disposable clone, while the commit exists).
- **N1-O01:** section 4 (no "superseded"; NAMES-1 does not run, import, rename or retire them); OPEN-N2.
- **N1-REC01:** N1-R05 and OPEN-N1 (A or B, owner's choice, recorded in the next register edition; no claim that NAMES-1 implements per-method folders).

## Points worth your attention

- **N1-R01B is new information from the code.** The exit receipt hashes its two contract files and stores the hashes keyed by file name, then recomputes them on consumption (`multigame_coordinator_exit_receipt_v2.py` lines 31-38, 169 and 247). So the B2 change alters a receipt field's keys. Claude judges this acceptable: no scientific receipt can exist, synthetic receipts are made for each run, and no committed fixture holds one. Please check that judgement.
- **A gap for later, not for NAMES-1.** The firewall test scans only `src/methods/*.py`. Under option A, method modules in `src/methods/E_<nnn>/` would not be scanned, so the E_2-readiness package must widen it (noted in N1-R05).

## How to reproduce

```
git archive 38fc60e | tar -x -C BASE ; git archive 38fc60e | tar -x -C NEW
python3 -I tools/apply_trial.py NEW
python3 -I tools/build_allowlist.py BASE allowlist.tsv      # equals evidence/allowlist.tsv
python3 -I tools/t02_check.py BASE NEW allowlist.tsv        # RESULT PASS
python3 -I tools/negative_checks.py BASE NEW EMPTY_WORK_DIR # RESULT PASS (94 checks)
```

*End of handback.*
