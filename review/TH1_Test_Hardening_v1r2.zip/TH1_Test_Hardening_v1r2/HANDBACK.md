# TH-1 - offline test hardening (P2-R1-O1, P2-R1-O3) - handback v1r2

**r2 (supersedes r1, `e01fd971...c0a0`):** applies the ChatGPT reviewer's TH1-C01 and TH1-O01 (section 1B). Everything else in r1 is unchanged.

**r1 (supersedes v1, `f056d361...6fa3`, before any review verdict):** adds one test fix found by the project owner's first Windows run of the suite (section 1A). Everything in v1 is unchanged.

**Work-item card**

| Field | Value |
|---|---|
| Item | TH-1: the deferred Package 2 test items P2-R1-O1 (T-05 coverage) and P2-R1-O3 (no-skip protected AST check) |
| Author chat | Claude (new Claude chat; primary designer and coder since effective commit `d36735d`) |
| Reviewer chat | ChatGPT reviewer chat (H-2 v1r2) |
| Base commit | `997ed46081695c0be68fd5b5db2efa95ce838a8b` |
| Scope | Tests only: 1 new test module, 2 changed test functions (plus one module docstring), 1 new hash-pinned fixture. Also carries `review/Claude_Verification_Transition_Commit_d36735d_v1.md` (history record, promised earlier). No source, reader, coordinator, golden, switch, allowlist or document change. |
| Risk tier | HIGH (reader isolation tests and the protected-function check) |
| Owner gate | The owner scoped and authorised this package on 27 October 2026 ("please go ahead now"); acceptance and installation are owner decisions |
| Evidence state | IMPLEMENTED and TESTED (author-side, Linux); not yet REVIEWED |

**Date:** 27 October 2026 (Adelaide). **Holdout statement:** every master used by the new test is invented in a temporary directory; no file under `source_data/` is opened by it, and no draw outcome is read, shown or used. The existing suite reads only the accepted development masters, as before.

**R-3 note for the reviewer:** this is HIGH work, so you have the right to a design-stage review before code. To save a round trip, the design (section 1) and the implementation come together. If you prefer to review the design first, please review only section 1 and say so; the code will be revised to match any design finding before acceptance.

## 1. Design

### P2-R1-O1 - T-05 at intermediate targets, with equal-length rewrites

New module `tests/test_p2_r1_t05_hardening_v1.py`, two tests (the second added in r2, section 1B), leaving the existing T-05 test byte-identical. For each game and four development targets N (first + 2, midway, last - 1, last), each of the three view kinds, with and without dates, it builds a full-length synthetic master (every row structurally valid, all values invented) four times:
- **variant 0:** the base;
- **variants 1 and 2:** every row at and after N rewritten **at the same byte length** (different numbers; reversed drawn order), so the whole file has an identical size but a different SHA-256;
- **variant 3:** rows at and after N changed **and** the file made longer.

Each variant re-pins the ledger and INIT record to its own whole-file hash. The test requires every `DrawView` slot (walked from `__slots__`, so new fields are covered automatically), every array's bytes, dtype and shape, `simple_rows()` and `e1_view_digest()` to be identical across all four variants; scans every slot recursively for any master, ledger or INIT-record hash; checks arrays are byte-owned and read-only; and checks the prefix has exactly N - first rows. 4 targets x 3 kinds x 2 date modes x 2 games = 48 subtests.

Why it adds coverage: the existing test uses only the last target and undecodable suffixes of different length. Here the later rows are **valid**, so a reader that wrongly reads past N gets a plausible but different view (not a crash), and the equal-length variants ensure that a value leak is caught at the same file size.

### P2-R1-O3 - the protected AST check never skips

- **Fixture:** `tests/fixtures/coordinator_v0_6_baseline/Powerball_Experiment_Coordinator_v0_6.py.txt`, the committed v0.6 coordinator taken from Git commit `d09d669` (SHA-256 `2e23d550...b822`, the pinned anchor). The `.txt` name keeps it from being imported or collected.
- **Test change** in `tests/test_multigame_v011_static_and_timing.py`: `test_protected_v06_ast_mechanically_equal_when_baseline_available` becomes `test_protected_v06_ast_mechanically_equal`. It uses `V06_BASELINE` if set (unchanged behaviour), else the packaged fixture, and **fails** instead of skipping if neither exists. It hashes the baseline after CRLF->LF normalisation, so a Windows checkout passes. The 11-function list and the AST comparison are unchanged. The module docstring is updated to match. Exact diff: `evidence/static_test_change.diff`.

### 1A. r1: the link-refusal test on Windows

The owner ran the current suite on Windows (Python 3.14.8, NumPy 2.5.4; `evidence/owner_windows_run_20261027_before_TH1.txt`) after a dependency check that changed no package. Result: 58 tests, **1 error, 2 skips**. The error is in `test_reject_symlinks_and_hardlinks_and_dateload_mismatch`: creating a symlink on Windows needs a privilege the account lacks (WinError 1314), so the test crashed before it reached the **hardlink** check. This is a test defect, not a reader defect, but it meant the reader's hardlink refusal (the NTFS `st_nlink` TO-TEST item) never ran on Windows.

Fix in `tests/test_multigame_v011_reader_contracts.py` (that one test function only; diff `evidence/reader_test_change.diff`): the symlink and hardlink checks become separate subtests. If a link cannot be created, that subtest is **skipped with a reason** (never passed) and the other still runs. The symlink now points at a real file (the old test pointed at a missing one), so the reader must refuse even a valid symlink. Simulated on Linux: with symlink creation denied, the symlink subtest skips and the hardlink subtest runs and passes; with both denied, both skip. Two new mutants (reader accepts hardlinks; reader follows symlinks) are caught.

The other skip in the owner's run is `test_multigame_exit_receipt_v0_8` ("platform disallows symlinks"), an existing, correct skip; and the AST skip, which TH-1 removes. Expected on the owner's Windows after TH-1: 60 tests, OK, with skips only where a link cannot be created (the exit-receipt symlink test, and the reader's symlink subtest), and the reader's hardlink subtest **run**.

### 1B. r2: reviewer findings TH1-C01 and TH1-O01

- **TH1-C01 (accepted; Claude reproduced it first).** The v1 claim that every synthetic row is valid was false. Variant 3 made the file longer by padding the row's last field with spaces, and for Powerball that field is the Powerball number, so the row would be rejected if it ever fell inside an eligible prefix ("invalid prefix Powerball"). The main T-05 test still passed only because those rows always lay at or after N. Fix, the reviewer's replacement: variant 3 now quotes every number field instead, which is valid CSV and still longer. Added the reviewer's recommended grammar check, `test_every_suffix_variant_row_is_a_valid_row`: for each game, variant, kind and date mode, the changed rows start at a mid target S and the view is taken at S + 1, so the reader must decode row S as an ordinary prefix row (48 subtests; synthetic data only; never a real target-or-later row). With the old padding put back it fails (6 errors, Powerball variant 3; Oz Lotto's padded field is a supplementary, which the reader never parses). Diff: `evidence/t05_module_v1r1_to_v1r2.diff`.
- **TH1-O01 (accepted).** The verifier docstring said "4 paths (3 added, 2 modified)"; now "5 paths".

### DECIDED / RECOMMENDED / OPEN

- DECIDED (mechanical, inside the approved scope): new module rather than editing the existing T-05 test; four targets per game; the fixture path and `.txt` name; CRLF normalisation of the fixture hash.
- RECOMMENDED (owner): add the new module to the standard offline suite command (below). H-1 section 7.1 still lists the old command; the next H-1 revision should carry the new one.
- OPEN: none.

## 2. Evidence (author-side)

- **Offline suite** (Linux, Python 3.13.17, NumPy 2.5.3, psutil 7.2.2), from the repository root:
  `PYTHONPATH=src:src/methods:tests python -m unittest -v tests.test_multigame_v011_reader_contracts tests.test_multigame_v011_static_and_timing tests.test_multigame_launch_and_manifest_v0_8 tests.test_multigame_exit_receipt_v0_8 tests.test_multigame_science_allowlist_v0_8 tests.test_multigame_console_and_synthetic_scorer_v0_4 tests.test_p2_r1_t05_hardening_v1`
  Result (Linux, where links can be created): **60 tests OK, 0 skipped** (was 58 OK, 1 skipped). Full output: `evidence/offline_suite_output.txt`. Also passes in a scratch clone with `core.autocrlf=true` and CRLF working files.
- **Mutation checks** (`evidence/mutation_checks.py`, output `evidence/mutation_output.txt`): each mutant applied to a disposable copy; the relevant test must fail. All 11 caught: whole-file length, a truncated whole-file hash, the whole-master SHA (B1), and the last 60 file bytes, each put into `order_evidence`; the prefix cut off by one (includes row N); a change inside protected `terminate_owned_tree`; a tampered fixture; a missing fixture; the reader accepting hardlinked masters; the reader following symlinked masters; a synthetic variant row made invalid again (the v1 padding).
- **Fixture provenance:** `evidence/fixture_provenance.txt` (`git show d09d669:...` hash equals the fixture and the pinned anchor).
- **Install verifier:** `VERIFY_TH1_INSTALL.py` passed pre/post/committed in LF and CRLF scratch clones of `997ed46`.

## 3. Not tested

- TH-1's new and changed tests on Windows and Python 3.14: the owner's run above used the pre-TH-1 suite. The optional suite run in the install instructions would be their first Windows run.
- The reader's symlink refusal on Windows, unless the account can create symlinks (Developer Mode or the privilege); that subtest skips there.
- A leak that depends only on the number of rows after N: all variants keep the full development row count, as every real master does, so such a leak would not show. Real masters' row counts are fixed by the development boundary, so it carries no outcome information.
- No Windows, lifecycle, destructive, scientific, network, holdout or dependency test was run or is authorised.

## 4. Changed files

| Path | Change | SHA-256 |
|---|---|---|
| `tests/test_p2_r1_t05_hardening_v1.py` | added (r2) | `c3341ce2fa7409335f6232c0f65b2d9b5a1b2d03fde6ee863e4fe4e30c8b9e58` |
| `tests/fixtures/coordinator_v0_6_baseline/Powerball_Experiment_Coordinator_v0_6.py.txt` | added | `2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b` |
| `tests/test_multigame_v011_static_and_timing.py` | modified (base `578f6206...1bd4`) | `8e606e965f748cb7b48f3ba8f76b29dfecf71552f59c4b3292cc76f42ab43696` |
| `tests/test_multigame_v011_reader_contracts.py` | modified, r1 (base `d3d3b516...b8a4`) | `a0460c49ac5d193871dd35f02ba532271e9c943185b8a9b759f0ee5b4a0da2dc` |
| `review/Claude_Verification_Transition_Commit_d36735d_v1.md` | added (history) | `c76b3bb305fca61bec0b791e6d792bc5b33f46529df0222498cbc5669a9343a0` |

Guarded and unchanged (checked by the verifier): the coordinator (`bc8380b5...b822`), the reader (`e06e0cca...42b5`) and register v0.5.

*End of handback.*
