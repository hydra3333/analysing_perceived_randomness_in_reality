"""Author-side mutation checks for TH-1 r2 (P2-R1-O1, P2-R1-O3, link-test portability, TH1-C01). Offline; disposable copies only.

Each mutant is applied to a fresh temporary copy of the candidate tree, never to an installed
file. The named test module is run there, and the check requires it to FAIL. Synthetic fixtures
only; no real master, holdout input, process or switch is touched.
Usage: python3 mutation_checks.py CANDIDATE_TREE
"""
import os, shutil, subprocess, sys, tempfile
from pathlib import Path

TREE = Path(sys.argv[1]).resolve()
READER = 'src/methods/_common/game_draws_reader_v1.py'
COORD = 'src/Powerball_Experiment_Coordinator.py'
FIXTURE = 'tests/fixtures/coordinator_v0_6_baseline/Powerball_Experiment_Coordinator_v0_6.py.txt'
T05 = 'tests.test_p2_r1_t05_hardening_v1'
AST = 'tests.test_multigame_v011_static_and_timing.StaticSafetyTests.test_protected_v06_ast_mechanically_equal'
LINKS = 'tests.test_multigame_v011_reader_contracts.V011ReaderTests.test_reject_symlinks_and_hardlinks_and_dateload_mismatch'
GRAMMAR = 'tests.test_p2_r1_t05_hardening_v1.T05HardeningTests.test_every_suffix_variant_row_is_a_valid_row'
T05FILE = 'tests/test_p2_r1_t05_hardening_v1.py'
OE = "order_evidence = {'record': evidence_name, 'status': _ORDER_STATUS}"


def oe(extra):
    return (READER, OE, "order_evidence = {'record': evidence_name, 'status': _ORDER_STATUS, " + extra + "}")


MUTANTS = [
    ('whole-file length in order_evidence', T05, [oe("'size': str(len(raw))")]),
    ('truncated whole-file hash in order_evidence', T05, [oe("'tag': hashlib.sha256(raw).hexdigest()[:12]")]),
    ('whole-master SHA in order_evidence (B1)', T05, [oe("'master_sha256': sha")]),
    ('last 60 bytes of the master in order_evidence', T05, [oe("'tail': raw[-60:].decode('ascii', 'replace')")]),
    ('prefix cut off by one (includes row N)', T05,
     [(READER, '    length = target - profile.first_draw\n', '    length = target - profile.first_draw + 1\n')]),
    ('protected function changed in the coordinator', AST,
     [(COORD, '    capture_owned_tree(worker, force=True)\n    print_termination_plan(worker, reason, preview=False)',
       '    capture_owned_tree(worker, force=False)\n    print_termination_plan(worker, reason, preview=False)')]),
    ('v0.6 fixture tampered', AST, [(FIXTURE, None, '\n# tampered\n')]),
    ('v0.6 fixture missing', AST, [(FIXTURE, 'DELETE', None)]),
    ('reader accepts hardlinked masters', LINKS,
     [(READER, "before.st_nlink != 1:", "before.st_nlink < 1:")]),
    ('reader follows symlinked masters', LINKS,
     [(READER, "if not isinstance(path, Path) or path.is_symlink():", "if not isinstance(path, Path):"),
      (READER, "| getattr(os, 'O_NOFOLLOW', 0)", "| 0")]),
    ('synthetic variant row made invalid (v1 trailing padding)', GRAMMAR,
     [(T05FILE, "        fields[2:] = [f'\"{field}\"' for field in fields[2:]]\n", "        fields[-1] += ' ' * 40\n")]),
]


def run(tree, test):
    env = dict(os.environ, PYTHONPATH=os.pathsep.join(['src', os.path.join('src', 'methods'), 'tests']))
    r = subprocess.run([sys.executable, '-m', 'unittest', test], cwd=tree, env=env,
                       stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    return r.returncode, r.stdout.strip().splitlines()[-1]


rc, last = run(TREE, T05)
assert rc == 0, 'unmutated T-05 hardening test must pass: ' + last
rc, last = run(TREE, AST)
assert rc == 0, 'unmutated AST test must pass: ' + last
rc, last = run(TREE, LINKS)
assert rc == 0, 'unmutated link test must pass: ' + last
rc, last = run(TREE, GRAMMAR)
assert rc == 0, 'unmutated grammar test must pass: ' + last
print('baseline: all four tests PASS on the unmutated tree')
bad = 0
for name, test, edits in MUTANTS:
    with tempfile.TemporaryDirectory() as td:
        copy = Path(td) / 'tree'
        shutil.copytree(TREE, copy)
        for path, old, new in edits:
            f = copy / path
            if old == 'DELETE':
                f.unlink()
            elif old is None:
                f.write_text(f.read_text() + new)
            else:
                s = f.read_text()
                assert s.count(old) == 1, (name, path)
                f.write_text(s.replace(old, new))
        rc, last = run(copy, test)
        ok = rc != 0
        bad += not ok
        print(f"{'CAUGHT' if ok else 'MISSED'}  {name:48s} {test.split('.')[-1]}: {last}")
print('ALL MUTANTS CAUGHT' if bad == 0 else f'{bad} MUTANT(S) MISSED')
sys.exit(1 if bad else 0)
