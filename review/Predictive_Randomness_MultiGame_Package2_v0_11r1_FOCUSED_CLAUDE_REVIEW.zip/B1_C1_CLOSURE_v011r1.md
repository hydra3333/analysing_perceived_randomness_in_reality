# Package 2 v0.11-r1 — focused Claude review closure

**Status:** coding review candidate only, 26 October 2026. **Not installed or ratified.** Owner-approved offline sandbox scope only. Baseline Git commit `618fe48c48ada46bcf60c80bbd291acc216d7e3b`; parent v0.11 review ZIP SHA-256 `0e00e231c46dafd01df52fb6f50db6ceaf399ea27be40efb318529101611d74c`.

## B1 BLOCKER — removed method-facing whole-master SHA

- `src/methods/_common/game_draws_reader_v1.py`: `DrawView.order_evidence` for `OPERATOR_DRAWN_ORDER` and `PAIRED_DIAGNOSTIC` is **only** an immutable map of `record: <GAME>_results_master_init_verification.json` and `status: OPERATOR_DRAWN_ORDER_ASSUMED_OWNER_DECISION`. `UNORDERED_SET` retains `order_evidence=None`. No `master_sha256` or other future-dependent source hash exists in any `DrawView` attribute.
- The complete master SHA, ledger version, and INIT verification identity **remain checked in the orchestration-only loader** and pinned run manifest. They are not passed to a method and never enter the prefix predictor digest.
- New T-05 regression `test_t05_complete_drawview_is_suffix_independent_for_every_kind`: creates synthetic full-length stand-ins for the **last authorised development targets** Powerball/1576 and Oz Lotto/1693, re-pins master+ledger+INIT records after changing **both target N and later synthetic bytes**, then checks equality of **every slot** of the resulting `DrawView`, including array raw bytes, shapes, dtypes, read-only ownership, order metadata, plain rows and the view digest. Covers all three view kinds **with and without dates** for both games. Scans all field values for source master, ledger and INIT-file SHA-256 fingerprints; statically checks `DrawView` class source/slots for a master hash field. Suffix data are deliberately invalid binary and never parsed.
- Existing `test_dates_opt_in_schema_digest_and_order_evidence` now checks exactly the immutable `record` + `status` fields, not a full-master hash.

## C1 CORRECTION — two distinct synthetic golden sets

- **Ratified R2 v0.4 §5.5 / TIE v0.2, synthetic fixture `tests/p3_e1_synthetic_v0_3.json`, target 1152, committed `e1_historical_appearance_frequency_v0_3.py`:** `df21871f8067e5405b4fdb1eec50c65dddbaa35958872bad3230d3c10a791fd4` (training view), `7ce5ab1bae014adf61f1f02dd152d4b500cb405b65cb3886cdcee8dd9e2c9932` (MAIN/label 3 tie) and `7b43d659d611791deb14d106a72984f153d9f79cc63b3d25000365de4c811d1e` (canonical forecast). All three are **now asserted** from the committed prototype source and the immutable expected fixture/literal values; TOP/WORST outputs also checked. This is a **synthetic fixture** and its evaluator-only synthetic target is not used as a model input.
- **Separate later E_1 standalone-runner synthetic test:** training-view `3851fa46400f44a1be6fb85fee72dfc4cc93585cef81b2a394bc0d86c4b895c9`, result `8a7f917ac8deb9307d31100e7cd811f87897b563d907d5ab5eab911708545eb9`. Existing assertions retained without relabeling as the ratified R2 §5.5 vectors.
- **Separate real E_1 forecast-only goldens (unchanged):** view `d47fbbd6e60e6abc429fb74f47d8bbeafc6560152c2ecddb3b75d79932df4339`; frozen forecast `7f1130872b3afaa222ff4e8c2396cd2c2872583544dfa6b31cc5a07cd067164e`, target 1577 **trained strictly on Powerball 1144–1576**. Neither result nor score of target 1577 is read/produced.

## Verification and restrictions

- Selected allowed offline suite: **58 tests, OK (one skipped)**. The single skip is the inherited baseline-path AST test, independently replaced for this review by static comparison of all **11** protected coordinator functions against committed v0.6. `evidence/STATIC_PRESERVATION_v011r1.json` records that proof. Coordinator SHA remains `bc8380b5f20a704c0f47d5f76eeb86156237142b5639e5b9770b8314db3bb822`.
- Two source/test files changed versus v0.11. The other **24** v0.11 overlay files are unchanged. Original v0.6→v0.11 coordinator patch/evidence remains valid and unchanged; r1 adds a separately mechanically replayed v0.11→v0.11-r1 patch.
- All three safety switches remain `False`. Scientific-result allowlist remains empty. No ranking code, E_2-readiness fields, source/master update, holdout data or scoring, real scientific experiment, network, Windows lifecycle/destructive run, Mode H or FINAL operation.
- Claude's **OPTIONAL** O1 (resolved source_data parent path), O2 (NTFS `st_nlink` testing) and O3 (future full lifecycle-module review) remain **unimplemented/not executed** rather than being silently included in this limited correction.

**Request to Claude:** focused independent B1/C1 review against v0.11 and the exact original v0.11 ZIP; specifically check method-facing metadata, T-05 full-field invariant, all three R2/TIE vectors, and that no other source changed. Do not install or run any Windows/lifecycle gates.
