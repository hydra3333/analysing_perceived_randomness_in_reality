# Package 2 v0.11-r1 — SMALL DELTA, CLAUDE REVIEW ONLY

This ZIP is **not a replacement full Package 2 overlay** and is not authorised for Git installation. It contains only two replacement files relative to `Predictive_Randomness_MultiGame_Package2_v0_11_CLAUDE_REVIEW_ONLY.zip` (SHA-256 `0e00e231c46dafd01df52fb6f50db6ceaf399ea27be40efb318529101611d74c`), plus focused documentation/evidence.

**Scratch reconstruction (no owner checkout edits):**
1. Independently verify parent v0.11 ZIP and its `SHA256_MANIFEST.json`. Build a scratch tree from committed `618fe48` with the parent ZIP's 26-file `repo_overlay/` and previous retirement inventory, exactly as Claude did for v0.11.
2. Overlay just `repo_overlay/src/methods/_common/game_draws_reader_v1.py` and `repo_overlay/tests/test_multigame_v011_reader_contracts.py` from this v0.11-r1 ZIP onto that scratch tree. Both file paths replace the same files in v0.11; all remaining files stay byte-identical.
3. Independently verify `SHA256_MANIFEST_V011R1.json`. `evidence/V011_TO_V011R1_EXACT.diff` uses `a/repo_overlay/` and `b/repo_overlay/` paths; `patch -p1` on an **extracted parent v0.11 ZIP in scratch** exactly reconstructs these two changed files. Both methods of applying r1 are alternatives, not cumulative patches.
4. Review `B1_C1_CLOSURE_v011r1.md` and run only the selected **offline** test suite in an isolated sandbox that already has NumPy and psutil (never run the dependency installer):

```
PYTHONPATH=src:src/methods:tests python -m unittest -v tests.test_multigame_v011_reader_contracts tests.test_multigame_v011_static_and_timing tests.test_multigame_launch_and_manifest_v0_8 tests.test_multigame_exit_receipt_v0_8 tests.test_multigame_science_allowlist_v0_8 tests.test_multigame_console_and_synthetic_scorer_v0_4
```

The test suite reads synthetic fixtures and the **accepted development-prefix** master only, in accord with the owner's narrow authorisation. The Powerball E_1 target-1577 regression is forecast-only on earlier rows; no target outcome read/score. All three process-safety gates stay disabled; no scientific-result allowlist entry.

**Not permitted:** Windows/lifecycle/destructive testing, process termination, dependency upgrades, source master update, holdout access, Mode H, FINAL, ranking or E_2-readiness implementation. Claude's optional O1–O3 are deferred. The absence of an orphan marker as checked by the owner on 26 October is not a launch authorisation.
