# Consolidated governing documents v0.4 — focused Claude diff spot-check

**NOT RATIFIED. DOCUMENTATION ONLY. NO SCIENTIFIC, WINDOWS, MASTER-UPDATE, HOLDOUT, MODE H, FINAL OR PROCESS-TERMINATION EXECUTION AUTHORISED.**

## Baseline and review history

This ZIP is a **local edit of v0.3** (`0cc30ae9...86d9e`), reviewed fully by Claude (v0.3 review v1, 25 October 2026; HEAD `ce462be`, document content same as `cf00999`). It responds to the final six-part B1 missing multi-game rules and corrections C1-C9; optional O1-O2 are also incorporated. It is not a fresh rewrite or a repository replacement.

The owner's unratified candidate set remains Proposal v0.5, R2 v0.4, R3 v0.4, Architecture v0.7, P3 v0.2, register v0.3, exposure record v0.1, and non-normative numerical technical reference v0.1. R1 v0.4, original R2/R3 predecessors, and TIE_SHA256_V1 remain untouched in the owner's repository. No ratified file is edited in place.

## Review priority

1. Read `review_evidence/*.v03_to_v04.unified.diff`; these are the **exact changes** in the candidate Markdown since Claude's last full review.
2. Independently verify B1: (1) derived weekly date discrepancy halts date-dependent methods only, (2) new view schema game/era/profile domain with sole E_1 exception, (3) per-game support statuses, (4) machine identity vs `draw_key`, (5) OPEN list/no authorisation, (6) pre-E_2 method-generic architecture requirement.
3. Independently verify corrections C1-C9: retired twelve-worker wording, B10-short, caller-declared view terminology, Proposal next step and assumed order, verbatim R2 change control/philosophy, C08/C09 DECIDED, ERR index, and full numbered installer list with default upgrade and post-upgrade STOP.
4. Seven protected text blocks and original identifier inventories must remain byte-preserved / present. The added decision checklist intentionally includes **un-numbered** normative requirements the older inventory missed.
5. Confirm there are no new hidden decisions or authority changes and that the new R3 date check does not grant access to a holdout outcome.

## Evidence and limits

**Inventory metadata correction:** the previous JSON reported 108 distinct R2 identifiers. An independent extraction of v0.3 and v0.4 finds 107 distinct IDs (17 I, 23 R2-C including C07A/C11A/C17A, 28 R2-D, 39 T), with **no removals**. This is a correction of the package counter, not deletion of a ratified requirement; Claude should recheck independently.

- `review_overlay/doc`: eight full candidate documents.
- `review_evidence/*.v03_to_v04.unified.diff`: exact incremental diffs; untouched documents produce empty diffs.
- `review_evidence/*.unified.diff`: original ratified source to current candidate; historical lines disclosing quarantined outcomes are value-redacted in diff evidence, with hashes separately recorded. They are review aids, **not patch files**.
- `REQUIREMENT_DISPOSITION_MATRIX.csv`: source-to-candidate requirement records, exact candidate locations refreshed, plus explicit no-ID B1 rows; headings that need human semantic assessment remain labelled.
- `VERBATIM_BLOCK_SHA256.json`, `verbatim_source/`, `REQUIRED_ID_INVENTORY.json`, `V04_REVIEW_DECISION_CHECKLIST.json`, `STALE_PHRASE_SCAN.json` and `verify_package.py`: reproduce required checks without running experimental code.
- `SHA256_MANIFEST.json` lists all artifacts except itself; archive validated independently after packaging.

**No claims of successful independent semantic review are made by ChatGPT.** Claude should classify residual findings BLOCKER / CORRECTION / OPTIONAL. If clear, the owner may ratify, after which a separate mechanically checked final installation ZIP is built and the Git push/definitive new-chat coder handover sequence starts.
