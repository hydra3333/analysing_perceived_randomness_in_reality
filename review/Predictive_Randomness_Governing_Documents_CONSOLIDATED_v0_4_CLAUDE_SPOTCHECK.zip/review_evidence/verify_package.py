#!/usr/bin/env python3
"""Offline only; checks v0.4 candidate package, not scientific operations."""
from pathlib import Path
import hashlib,json,re,sys
ROOT=Path(__file__).resolve().parent.parent
E=ROOT/'review_evidence';D=ROOT/'review_overlay'/'doc'
h=lambda b:hashlib.sha256(b).hexdigest()
for entry in json.loads((E/'SHA256_MANIFEST.json').read_text())['files']:
 f=ROOT/entry['path'];assert f.is_file(),entry['path']
 assert h(f.read_bytes())==entry['sha256'],entry['path']
for block in json.loads((E/'VERBATIM_BLOCK_SHA256.json').read_text()):
 b=(E/'verbatim_source'/block['block']).read_bytes()
 assert h(b)==block['source_sha256']
 assert b in (D/block['candidate']).read_bytes(),block['block']
for inv in json.loads((E/'REQUIRED_ID_INVENTORY.json').read_text()):
 assert inv['missing']==[] and inv['unexpected']==[] and inv['expected']==inv['present'],inv
names={'Proposal':'*Proposal_v0_5*','R2':'*R2_v0_4*','R3':'*R3_v0_4*','Architecture':'*Architecture_Discussion_v0_7*','P3':'*P3_Task*'}
for check in json.loads((E/'V04_REVIEW_DECISION_CHECKLIST.json').read_text())['conditions']:
 s=next(D.glob(names[check['document']])).read_text()
 for expected in check['requirements']:assert expected in s,(check['id'],expected)
scan=json.loads((E/'STALE_PHRASE_SCAN.json').read_text())
assert not scan['unexplained'],scan['unexplained']
print('PASS manifest, 7 protected blocks, all required IDs, B1/C1-C9 content and stale scan')
print('Review is NOT RATIFICATION; semantic check by independent Claude remains required.')
