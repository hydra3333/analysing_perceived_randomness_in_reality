# DOC-1 - records refresh (H-1 v1r2 and register v0.6) - handback v1

**Work-item card**

| Field | Value |
|---|---|
| Item | DOC-1: bring H-1 and the register up to date with the events and owner decisions after the effective commit |
| Author chat | Claude (primary designer and coder) |
| Reviewer chat | ChatGPT reviewer chat (H-2 v1r2) |
| Base commit | `b14116b` (GitHub `main`, fetched 28 October 2026; nothing newer) |
| Inputs | H-1 v1r1 Git blob `3223c41732888ea56c5458b365488660d157c93902b3745ed71d7d300fc2751e`; register v0.5 Git blob `551c1b42e99b58ad313dabe7d533e5650db83edce58e04f954b2f616c77afb3f` |
| Scope | Two continuity / authority documents only. No code, test, golden, switch, allowlist or governing specification changes. H-2 v1r3 is the reviewer's own draft and joins this package for installation if the reviewer prepares it. |
| Risk tier | HIGH (authority text; the register) |
| Owner gate | The owner asked for the refresh on 27 October 2026; ratification and installation are owner decisions |
| Evidence state | IMPLEMENTED (drafts); mechanically checked; not yet REVIEWED |

**Date:** 28 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears in or was used for these files. The only number lists are the frozen E_1 forecast outputs already in H-1 section 7.2, unchanged.

## Contents

| File | What it is | SHA-256 |
|---|---|---|
| `Claude_Primary_Handover_H1_v1r2.md` | H-1 v1r2 (ASCII, CRLF for reading). Git (LF) content: `55543ba522a4085fc4f2476d421a4940171bcd4c183a1fab5a691d291605eac0` | `d32bf2f4f7781e02fee54d8cf48ef2e40057290d3cc817dd0c6993690b6d43a1` |
| `RATIFICATION_REGISTER_v0_6.md` | Register v0.6 candidate (UTF-8, LF, as its lineage), built with the H-2 v1r3 row | `c5005a04918935c2d7f2f35b009c6a1949aaba6e22a5ea8a36bbba5fa239bc93` |
| `evidence/H1_v1r1_to_v1r2.diff` | Exact diff, H-1 v1r1 to v1r2 (LF) | `c5cf26a3e3ff78640347e3eec2a251bb87b495d9cc4e2360342e44d7fa0d8522` |
| `evidence/register_v0_5_to_v0_6.diff` | Exact diff, register v0.5 to v0.6 | `75251e1bee237bafa81861894cc49b3a0cb453f1f1bb4302af02c3e29e9e4cab` |
| `evidence/mechanical_checks.txt` | Output of `tools/check_doc1.py` | `648c4c39ce1cad43e92063f684f046064763a088712b45224b93530efa23fac6` |
| `tools/make_h1_v1r2.py` | Builds H-1 v1r2 from the v1r1 blob: 32 counted replacements, each asserted to occur exactly once | `282e0622550221ab459aa2842f2237e3dcf2b0a75171acdc109ced33a8006b3c` |
| `tools/make_register_v06.py` | Builds register v0.6 from the v0.5 blob: 7 counted replacements (8 with `--with-h2`) | `907cf07eeae7dbc313d3a002e6739f3fb3d2719bbb0b9c988571b40dbf4f98c7` |
| `tools/check_doc1.py` | Mechanical checks | `6674d67733dbe3719151aff48426a4a4d23b32efe096c1cb5deff43cffa2baa8` |

Reproduce: `git show b14116b:doc/HANDOVER/Claude_Primary_Handover_H1_v1r1.md > H1_v1r1.md`, `git show b14116b:doc/RATIFICATION_REGISTER_v0_5.md > REG_v0_5.md`, then `python3 -I tools/make_h1_v1r2.py H1_v1r1.md H1_v1r2.md` and `python3 -I tools/make_register_v06.py REG_v0_5.md REG_v0_6.md --with-h2`. Each builder refuses an input whose hash differs.

## What changes, in plain English

**H-1 v1r2** (Appendix B of the file lists every change):
- names the effective commit `d36735d` and lists the later commits;
- records the FIX AND PROCEED / RECHECK procedure (`b14116b`), including the owner's rule that FIX AND PROCEED never applies to always-review code;
- replaces the "two delivery routes, transport not yet ratified" text with the owner's delivery decision;
- adds package sizing as the owner confirmed it;
- points section 4 at register v0.5 / v0.6;
- records the owner's NTFS hard-link evidence;
- gives the new 60-test suite command and results, and a new section 7.1A for TH-1;
- adds three lessons from TH-1;
- marks section 9 item 1 done and removes the transport question from the open decisions.

**Register v0.6:**
- seven existing lines change (six without `--with-h2`): the version line; the basis line; the effective-commit sentence (it said "this register edition", which would be wrong in v0.6, and now names `d36735d`); the H-1 v1r1 and H-2 v1r2 rows ("superseded by"); the Package 2 deferred-items sentence; and the v0.4 row's "superseded by this register";
- one new section, "Records after the effective commit": the commit's identity; the delivery method; the review dispositions; package sizing; TH-1 at `744afea` with the Windows evidence; the oversight status; and the continuity table (H-1 v1r2, H-2 v1r3, register v0.5 superseded);
- every other line is byte-identical.

## Mechanical checks (evidence/mechanical_checks.txt)

- Both builders assert every old string occurs exactly once and every inserted string is ASCII.
- H-1 v1r2: ASCII, LF, single final newline; 312 of 341 predecessor lines kept verbatim.
- Register v0.6: 139 of 146 predecessor lines kept verbatim; the 28 non-ASCII characters of v0.5 (for example the section sign before "5C") are unchanged in number. The checker's "all ASCII: False" for changed register lines comes from that pre-existing section sign on the changed basis line, not from inserted text.
- Every 64-character hash in a new line matches the Git content of a file at `b14116b`. The one exception is in H-1, on a line that changed for another reason: the Package 2 EOL verifier hash from v1r1, which v1r1 already says is not in the repository.
- Every commit ID cited resolves in the repository.
- Facts checked against GitHub: the parent of `d36735d` is `6460ae3`; `6460ae3` added exactly four files; `744afea` changed exactly five paths, with the hashes in H-1 section 7.1A; all 290 files are mode 100644; `review/TH1_Test_Hardening_v1r2.zip` holds `VERIFY_TH1_INSTALL.py`. The offline suite at `b14116b` on Linux gives 60 OK, 0 skipped (Python 3.13.17, NumPy 2.5.3, psutil 7.2.2).

## DECIDED / RECOMMENDED / OPEN

- **DECIDED** (owner, 27 October 2026; this package only records them): the delivery method; the FIX AND PROCEED / RECHECK procedure and the always-review exclusion; package sizing; TH-1 acceptance; the oversight instruction.
- **DECIDED** (mechanical, inside the requested scope): the change list goes in an appendix, so "section 11" never means two things (H-1 already cites agreed position section 11); the register draft carries `[H1-SHA]` / `[H2-SHA]` placeholders and "RATIFICATION CANDIDATE", which are filled and changed to OWNER-RATIFIED with the date at finalisation, after review and ratification, as was done for v0.5.
- **RECOMMENDED:** install H-1 v1r2, register v0.6 and (if prepared) H-2 v1r3 in one commit, with a verifier, the usual way. If the reviewer decides H-2 needs no new edition, the register is rebuilt without `--with-h2`: it then keeps H-2 v1r2 current and adds one out-of-date line for its pending-items statements.
- **OPEN:** none.

## Oversight (owner instruction; reviews 1 and 2 of 3)

| Item | Reviewer decision | Claude's check |
|---|---|---|
| TH1-RD-01 | Treat TH1-C01 as a narrow fixture correction, not a reader change | Within latitude; no rule touched |
| TH1-RD-02 | Accept the symlink/hardlink subtest split with an explicit skip | Within latitude; the hard-link check still runs, so no test is lost |
| TH1-RD-03 | Close TH1-C01 after independent reproduction | Within latitude; evidence present |
| TH1-RD-04 | Close TH1-O01; PASS v1r2 | Within latitude; acceptance stayed with the owner |

No departure from the ratified rules. The review of this package is the third.

## Not done or not tested

- These are drafts. They have not been reviewed, ratified or installed, and there is no installation package or verifier yet. Those come after the review.
- H-2 v1r3 is the reviewer's to draft. Claude will fact-check it.
- The TH-1 v1 review (the one that first raised TH1-C01) is not in `review/`; only the v1r1 review and the v1r2 recheck are. The owner may add it with the next history commit if he has it.
- H-3 v1r1 and the governing specifications are unchanged. Their known out-of-date lines stay listed in register v0.5.

*End of handback.*
