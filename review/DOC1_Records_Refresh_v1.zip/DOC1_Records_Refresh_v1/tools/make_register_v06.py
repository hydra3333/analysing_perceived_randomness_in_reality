"""Draft register v0.6 from the installed register v0.5 by counted in-place edits (Claude, 27 Oct 2026).

Work item DOC-1 (records refresh). Records what happened after the effective commit: its
identity, the delivery method, the review-disposition procedure, package sizing, TH-1 and the
continuity documents. Every old string must occur exactly once; inserted text is ASCII. The
input is the Git (LF, UTF-8) blob of doc/RATIFICATION_REGISTER_v0_5.md (551c1b42...afb3f).
Placeholders [H1-SHA] (and [H2-SHA] with --with-h2) are filled at finalisation, after review,
as was done for v0.5.
Usage: python3 -I make_register_v06.py REGISTER_v0_5 OUT_v0_6 [--with-h2]
"""
import hashlib, sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
with_h2 = '--with-h2' in sys.argv[3:]
raw = src.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '551c1b42e99b58ad313dabe7d533e5650db83edce58e04f954b2f616c77afb3f'
t = raw.decode('utf-8')
assert '\r' not in t and t.endswith('\n')

PROC = '`review/REVIEWER_FIX-and-PROCEED_RECHECK_PROCEDURE_v1.md`'
H1 = 'HANDOVER/Claude_Primary_Handover_H1_v1r2.md'
H2 = 'HANDOVER/ChatGPT_Reviewer_Handover_H2_v1r3.md'

h2_row = (f"| `{H2}` | ChatGPT reviewer chat; facts checked by Claude; rights section checked by the owner alone | RATIFICATION CANDIDATE; `[H2-SHA]` |\n"
          if with_h2 else '')
h2_text = ('H-2 v1r3 replaces H-2 v1r2' if with_h2 else 'H-2 v1r2 is unchanged')
h2_stale = ('' if with_h2 else
            "**Out-of-date statements (register v0.6).** H-2 v1r2 describes P2-R1-O1 and P2-R1-O3 as still to be scoped, "
            "and tells a new reviewer chat to identify the effective commit; both are overtaken by the records above. "
            "This register prevails, and the file is not edited.\n\n")

NEW_SECTION = f"""## Records after the effective commit (register v0.6; 27 October 2026)

Paths in this section are under `doc/`, except those beginning `review/`, which are from the repository root. In this section, "this register" means register v0.6.

**Effective commit identity.** The effective commit is `d36735da777b7d8403718af9e1d9d65c1cad47cc` (parent `6460ae3`), verified by Claude in `review/Claude_Verification_Transition_Commit_d36735d_v1.md` (`c76b3bb305fca61bec0b791e6d792bc5b33f46529df0222498cbc5669a9343a0`, committed at `744afea`). The owner's commit `6460ae3` had already added four history files listed in the installation manifest, byte-identical to it; installation package v1r1's verifier accepted them. History commit `997ed46` added the final mechanical review and the installation ZIPs.

**Delivery method (owner decision, 27 October 2026; settles the Git transport question in the agreed roles position, section 11).** Changes are delivered as whole-file replacements: a `repo_overlay/` folder the owner copies onto the repository root, a read-only verifier with `pre`, `post` and `committed` phases (tolerant of CRLF working copies; every Git call uses `--no-optional-locks`), and a staging script naming the exact files. The exact unified diff of every changed file always travels with the package as evidence. No hand edits to project files; any deletion is explicit, listed and verified.

**Review dispositions (owner-accepted 27 October 2026).** {PROC} (`5067aa520990b8ccc8521a04f3581424100cdd94994f5b9e3cb9e37863685339`, committed at `b14116b`) adds two reviewer-controlled dispositions to the four finding classes, which are unchanged. FIX AND PROCEED: Claude makes exactly the correction the reviewer authorised and continues without a separate recheck of it, keeping the evidence the procedure lists. RECHECK: the corrected material returns to the reviewer before acceptance. RECHECK is the default. Only the reviewer assigns a disposition, under its REVIEWER-DECIDED latitude; the owner may override. **Owner decision, 27 October 2026: FIX AND PROCEED never applies to code concerning any of the eight standing always-review subjects, however small the change.** The procedure changes no risk tier, always-review subject, reviewer right (R-1 to R-11), firewall, holdout safeguard or owner gate.

**Package sizing (owner-confirmed 27 October 2026).** Small packages for complex or HIGH work; a lead item that proves the pattern before a batch of similar items (for example, one lead method per family); heavy methods one at a time; ensembles last.

**TH-1 offline test hardening: ACCEPTED by the owner and installed at commit `744afea085c9fabc62c18ee5c18ee400d0853a9d`** (5 paths: 3 added, 2 modified; Claude verified every blob; the coordinator and the reader are unchanged; every file mode 100644). It closes the deferred Package 2 items P2-R1-O1 and P2-R1-O3. Installed package `review/TH1_Test_Hardening_v1r2.zip` (`47d6e5a67eb60b045c9b3c1b0930f0ced2ad082cee47dbdd93caaa74196c3015`); ChatGPT reviews `review/Independent_ChatGPT_Review_TH1_Test_Hardening_v1r1.md` and `review/Independent_ChatGPT_Focused_Recheck_TH1_Test_Hardening_v1r2.md` (PASS). The standard offline suite adds `tests.test_p2_r1_t05_hardening_v1` (60 tests). Owner-reported Windows evidence (Windows 11, Python 3.14.8): 60 OK with 2 skips, both because the owner's account cannot create symlinks; the reader's refusal of a hard-linked master passed on NTFS. Acceptance grants no Windows lifecycle, destructive, scientific, holdout, Mode H, FINAL, switch or allowlist authority.

**Oversight instruction status.** Two of the first three reviews under the new roles are done (the TH-1 review and its recheck). Claude listed the REVIEWER-DECIDED items (TH1-RD-01 to TH1-RD-04) and found no departure from the ratified rules. The third is the review of the package that carries this register edition.

**Continuity documents (register v0.6).** H-1 v1r2 replaces H-1 v1r1 for future roles; {h2_text}; H-3 v1r1 is unchanged. Earlier editions stay in place as history.

| Document (path under `doc/`) | Author / check | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `{H1}` | Claude; reviewed by the ChatGPT reviewer chat | RATIFICATION CANDIDATE; `[H1-SHA]` |
{h2_row}| `RATIFICATION_REGISTER_v0_5.md` | Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 27 Oct 2026; superseded by this register; `551c1b42e99b58ad313dabe7d533e5650db83edce58e04f954b2f616c77afb3f` |

{h2_stale}"""

EDITS = [
    ('**Register version:** v0.5 OWNER-RATIFIED 27 October 2026, recording the AI roles transition,',
     '**Register version:** v0.6 RATIFICATION CANDIDATE (drafted 28 October 2026), recording the records after the effective commit (its identity, the delivery method, the review-disposition procedure and TH-1); v0.5 OWNER-RATIFIED 27 October 2026, recording the AI roles transition,'),
    ('and the v0.5 entries against GitHub HEAD `ae76c29` (27 October 2026).',
     'the v0.5 entries against GitHub HEAD `ae76c29` (27 October 2026), and the v0.6 entries against GitHub HEAD `b14116b` (27 October 2026).'),
    ('the commit that installs this register edition together with H-1, H-2 and H-3; it is not the Package 2 acceptance commit.',
     'the commit that installed register v0.5 together with H-1, H-2 and H-3, which is `d36735da777b7d8403718af9e1d9d65c1cad47cc` (identified in register v0.6); it is not the Package 2 acceptance commit.'),
    ('| Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 27 Oct 2026; `3223c41732888ea56c5458b365488660d157c93902b3745ed71d7d300fc2751e` |',
     '| Claude; reviewed by the ChatGPT reviewer chat | OWNER-RATIFIED 27 Oct 2026; superseded by H-1 v1r2 (register v0.6); `3223c41732888ea56c5458b365488660d157c93902b3745ed71d7d300fc2751e` |'),
    ('OWNER-RATIFIED 27 Oct 2026; superseded by this register (v0.5, OWNER-RATIFIED 27 Oct 2026) |',
     'OWNER-RATIFIED 27 Oct 2026; superseded by register v0.5 (OWNER-RATIFIED 27 Oct 2026) |'),
    ('Deferred test items P2-R1-O1 and P2-R1-O3 are scheduled as the first package under the new roles (owner decision, 27 October 2026); the other open optionals stay open.',
     'Deferred test items P2-R1-O1 and P2-R1-O3 were scheduled as the first package under the new roles (owner decision, 27 October 2026) and are now done (TH-1, register v0.6); the other open optionals stay open.'),
    ('\n## Interpretation and verification\n',
     '\n' + NEW_SECTION + '## Interpretation and verification\n'),
]
if with_h2:
    EDITS.append((
        '| ChatGPT reviewer chat; facts checked by Claude; rights section checked by the owner alone | OWNER-RATIFIED 27 Oct 2026, including R-8..R-11 and section 3.1; `53f3af3f',
        '| ChatGPT reviewer chat; facts checked by Claude; rights section checked by the owner alone | OWNER-RATIFIED 27 Oct 2026, including R-8..R-11 and section 3.1; superseded by H-2 v1r3 (register v0.6); `53f3af3f'))

for old, new in EDITS:
    n = t.count(old)
    assert n == 1, (n, old[:80])
    assert all(ord(c) < 128 for c in new), old[:60]
    t = t.replace(old, new)
assert t.endswith('\n')
out.write_bytes(t.encode('utf-8'))
print(out, hashlib.sha256(t.encode()).hexdigest(), len(t.splitlines()), 'lines', 'with H-2 row' if with_h2 else 'without H-2 row')
