"""Mechanical checks for DOC-1 drafts (Claude). Usage: python3 -I check_doc1.py IN_DIR OUT_DIR HEAD_HASHES"""
import hashlib, re, sys
from pathlib import Path
i, o, hh = Path(sys.argv[1]), Path(sys.argv[2]), Path(sys.argv[3])
known = {l[:64]: l[65:].strip() for l in hh.read_text().splitlines()}
known['1000017891e90f8dcbe7700afd68d5985b713d4a241c0e24df128e5276b98ac7'] = '(pre-existing v1r1 text: Package 2 EOL verifier, not in repository)'
for old, new in [('H1_v1r1.md', 'Claude_Primary_Handover_H1_v1r2.md'), ('REG_v0_5.md', 'RATIFICATION_REGISTER_v0_6.md')]:
    a = (i / old).read_text(encoding='utf-8'); b = (o / new).read_text(encoding='utf-8')
    print(f'== {new}: sha256 {hashlib.sha256(b.encode()).hexdigest()}, {len(b.splitlines())} lines')
    print('   input sha256', hashlib.sha256(a.encode()).hexdigest())
    print('   LF only:', '\r' not in b, '| single final newline:', b.endswith('\n') and not b.endswith('\n\n'))
    print('   non-ASCII characters: before', sum(ord(c) > 127 for c in a), 'after', sum(ord(c) > 127 for c in b))
    la, lb = a.splitlines(), set(b.splitlines())
    print('   predecessor lines kept verbatim:', sum(l in lb for l in la), 'of', len(la))
    added = [l for l in b.splitlines() if l not in set(la)]
    print('   new or changed lines:', len(added), '| all ASCII:', all(ord(c) < 128 for l in added for c in l))
    bad = [h for l in added for h in re.findall(r'\b[0-9a-f]{64}\b', l) if h not in known]
    print('   64-hex hashes in new lines:', len({h for l in added for h in re.findall(r'\b[0-9a-f]{64}\b', l)}), '| not matching a file at b14116b:', bad or 'none')
    ph = sorted(set(re.findall(r'\[H[0-9]-SHA\]', b))); print('   placeholders (filled at finalisation):', ph or 'none')
