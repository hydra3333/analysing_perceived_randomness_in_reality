"""Draft H-1 v1r2 from the installed H-1 v1r1 by counted in-place edits (Claude, 27 Oct 2026).

Work item DOC-1 (records refresh). Every old string must occur exactly once; inserted text is
ASCII. The input is the Git (LF) blob of doc/HANDOVER/Claude_Primary_Handover_H1_v1r1.md
(3223c417...751e). Output is LF; the package also carries a CRLF copy for reading.
Usage: python3 -I make_h1_v1r2.py H1_v1r1 OUT_v1r2
"""
import hashlib, sys
from pathlib import Path

src, out = Path(sys.argv[1]), Path(sys.argv[2])
raw = src.read_bytes()
assert hashlib.sha256(raw).hexdigest() == '3223c41732888ea56c5458b365488660d157c93902b3745ed71d7d300fc2751e'
t = raw.decode('ascii')
assert '\r' not in t and t.endswith('\n')

PROC = '`review/REVIEWER_FIX-and-PROCEED_RECHECK_PROCEDURE_v1.md`'

TH1_SECTION = """### 7.1A TH-1 offline test hardening - ACCEPTED and COMMITTED at `744afea`

- **Scope:** tests only; it closes the deferred Package 2 items P2-R1-O1 and P2-R1-O3. Installed at `744afea085c9fabc62c18ee5c18ee400d0853a9d` (verified by Claude: exactly 5 paths, 3 added and 2 modified, every blob matching the reviewed bytes; all 290 files mode 100644; switches False; allowlist empty). The coordinator (`bc8380b5...b822`) and the reader (`e06e0cca...42b5`) are unchanged.

| Path | Change | Git-content SHA-256 |
|---|---|---|
| `tests/test_p2_r1_t05_hardening_v1.py` | added | `c3341ce2fa7409335f6232c0f65b2d9b5a1b2d03fde6ee863e4fe4e30c8b9e58` |
| `tests/fixtures/coordinator_v0_6_baseline/Powerball_Experiment_Coordinator_v0_6.py.txt` | added (the committed v0.6 coordinator from `d09d669`; the AST anchor) | `2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b` |
| `tests/test_multigame_v011_static_and_timing.py` | modified | `8e606e965f748cb7b48f3ba8f76b29dfecf71552f59c4b3292cc76f42ab43696` |
| `tests/test_multigame_v011_reader_contracts.py` | modified | `a0460c49ac5d193871dd35f02ba532271e9c943185b8a9b759f0ee5b4a0da2dc` |
| `review/Claude_Verification_Transition_Commit_d36735d_v1.md` | added (history record) | `c76b3bb305fca61bec0b791e6d792bc5b33f46529df0222498cbc5669a9343a0` |

- **What the tests add:** T-05 at four development targets per game (first + 2, midway, last - 1, last), for each view kind, with and without dates, using invented masters in which the rows at and after N are rewritten twice at the same file length and once longer. A second test proves every rewritten row is itself a valid row. The 11-function AST check now reads a hash-pinned copy of the committed v0.6 coordinator and never skips. The reader's symlink and hard-link checks are separate subtests, so a missing symlink privilege skips only the symlink part.
- **Reviews:** `review/Independent_ChatGPT_Review_TH1_Test_Hardening_v1r1.md` (the link-test change passed; CORRECTION TH1-C01: the v1 "longer" rows were padded in a way that made them invalid; OPTIONAL TH1-O01, a count) and `review/Independent_ChatGPT_Focused_Recheck_TH1_Test_Hardening_v1r2.md` (PASS). Installed package `review/TH1_Test_Hardening_v1r2.zip` (`47d6e5a67eb60b045c9b3c1b0930f0ced2ad082cee47dbdd93caaa74196c3015`); v1 and v1r1 are kept beside it as history (commit `151f393`).
- **Author mutation checks** (disposable copies only): 11 mutants, all caught - the whole-file length, a truncated whole-file hash, the whole-master SHA and the last 60 file bytes each put into `order_evidence`; the prefix cut off by one; a change inside protected `terminate_owned_tree`; a tampered fixture; a missing fixture; the reader accepting hard links; the reader following symlinks; an invalid suffix row.

"""

DISPOSITIONS = (
    "- **Review dispositions (owner-accepted 27 October 2026; " + PROC + ", committed at `b14116b`):** "
    "a finding that needs a change may also carry a disposition. **FIX AND PROCEED:** Claude makes exactly the "
    "correction the reviewer authorised, meets the reviewer's stated verification conditions and continues "
    "without a separate recheck of that correction. **RECHECK:** the corrected material goes back to the reviewer "
    "before acceptance. **RECHECK is the default** when the reviewer gives no disposition. Only the reviewer "
    "assigns a disposition, under its REVIEWER-DECIDED latitude; Claude may recommend one but never assigns, "
    "broadens or changes it; the owner may override. **Owner decision, 27 October 2026: FIX AND PROCEED never "
    "applies to code concerning any of the eight always-review subjects listed above, however small the change; "
    "such code always gets RECHECK.** Authority text and the register qualify for FIX AND PROCEED only for "
    "wording that changes no rule, status or authority; if in doubt, RECHECK. For every FIX AND PROCEED item, "
    "Claude keeps the exact before-and-after diff, the changed-file hashes, the reviewer's authorised wording and "
    "scope, the test commands and outputs, and a not-tested list, and shows the diff when the reviewer next looks "
    "at the package (procedure section 6). If the fix needs more than was authorised, differs from it, fails a "
    "test or reveals another issue, it becomes RECHECK. The procedure changes no risk tier, always-review "
    "subject, reviewer right (R-1..R-11) or owner gate.\n"
)

APPENDIX_B = """## Appendix B. Changes in v1r2 (records refresh DOC-1)

v1r2 is v1r1 with the following changes and nothing else; the exact diff travels with the DOC-1 package.

1. Header, section 0 and Appendix A: the effective commit named (`d36735d`); later commits listed; the review-disposition procedure added to the reading list and identities.
2. Section 1.5: the FIX AND PROCEED / RECHECK procedure with the owner's exclusion for always-review code; the status of the first-three-reviews oversight.
3. Section 1.6: the delivery method the owner decided on 27 October 2026 replaces the "two routes, transport not yet ratified" text.
4. Section 2: package sizing, as the owner confirmed on 27 October 2026.
5. Section 4: register v0.5 and v0.6 replace the register v0.4 row; the out-of-date list no longer names lines register v0.5 already corrected.
6. Section 6: the owner's NTFS hard-link evidence replaces "TO-TEST" for hard links.
7. Section 7: the new suite command and results; the new section 7.1A (TH-1); the deferred list and not-tested list updated.
8. Section 8.6: three lessons from TH-1.
9. Section 9: item 1 done; the transport decision removed from the open owner decisions.

"""

EDITS = [
    ('# H-1 - Claude primary designer and coder handover - Predictive Randomness project, v1r1\n',
     '# H-1 - Claude primary designer and coder handover - Predictive Randomness project, v1r2\n'),
    ("**Version:** v1r1 DRAFT, 27 October 2026 (Adelaide, UTC+10:30); v1r1 applies the ChatGPT reviewer's",
     "**Version:** v1r2 DRAFT, 28 October 2026 (Adelaide, UTC+10:30). v1r2 is a records refresh (work item DOC-1): it brings v1r1 (owner-ratified 27 October 2026 and installed at the effective commit) up to date with the events and owner decisions since then; Appendix B lists every change. v1r1 applied the ChatGPT reviewer's"),
    ('Author: Claude (the new Claude chat). Independent reviewer:',
     'Author: Claude. Independent reviewer:'),
    ('It becomes authoritative only when the owner ratifies it and installs it together with H-2 and H-3 at the transition commit (the effective commit). Until then the earlier roles stand.',
     'It becomes authoritative only when the owner ratifies it and installs it together with register v0.6; until then H-1 v1r1 stands.'),
    ("The transition commit that installs this file cannot name itself; its ID is recorded in Claude's post-push verification evidence and may be entered in a later register edition (after v0.5); register v0.5 defines the effective commit by the set of documents it installs.",
     "The roles transition took effect at commit `d36735da777b7d8403718af9e1d9d65c1cad47cc` (the effective commit; verified by Claude in `review/Claude_Verification_Transition_Commit_d36735d_v1.md`). Since then, TH-1 was installed at `744afea085c9fabc62c18ee5c18ee400d0853a9d` (section 7.1A) and the review-disposition procedure was committed at `b14116b` (section 1.5). The commit that installs this file cannot name itself; Claude records its ID in the post-push verification."),
    ('**Replaces, for future roles:** Claude reviewer handover v10,',
     '**Replaces, for future roles:** H-1 v1r1 (kept as history); and, as v1r1 did, Claude reviewer handover v10,'),
    ('1. Clone `main`. Verify that this file, H-2 and H-3 are committed together, and that the hashes',
     '1. Clone `main`. Verify that this file is the H-1 edition the current register names, and that the hashes'),
    ('H-3; the register (current edition);',
     'H-3; the review-disposition procedure (' + PROC + '); the register (current edition);'),
    ('This is reporting only: Claude does not overrule the reviewer or narrow its rights; the owner decides.\n',
     'This is reporting only: Claude does not overrule the reviewer or narrow its rights; the owner decides. **Status at v1r2:** two of the three are done (the TH-1 review and its recheck; REVIEWER-DECIDED items TH1-RD-01..04; no departure found). The third is the review of DOC-1, the package that carries this edition.\n'),
    ('The agreed-position HIGH tier adds to this list; it never removes from it.\n',
     'The agreed-position HIGH tier adds to this list; it never removes from it.\n' + DISPOSITIONS),
    ('- Two delivery routes have worked, and either installs the same bytes:\n'
     '  - **Overlay plus verifier** (used for Package 2 at `c542483` and the integration): a `repo_overlay/` folder the owner copies onto the repository root, a read-only `VERIFY_*.py` with `pre` / `post` / `committed` phases, and an optional `STAGE_EXACT_FILES.cmd`. The owner is familiar with this route.\n'
     "  - **`git diff --binary` patch** against the stated base, checked with `git apply --check`. This is the agreed position's proposed default; the owner has not yet ratified a transport choice (agreed position section 11). Ask before switching routes.\n",
     '- **Delivery method (owner decision, 27 October 2026; settles the transport question in agreed position section 11):** whole-file replacement through an overlay plus a read-only verifier: a `repo_overlay/` folder the owner copies onto the repository root, a `VERIFY_*.py` with `pre` / `post` / `committed` phases, and a `STAGE_EXACT_FILES.cmd`. The exact unified diff of every changed file always travels with the package as evidence. No hand edits to project files; any deletion is explicit, listed and checked by the verifier. Used for Package 2 (`c542483`), the integration (`ae76c29`), the transition (`d36735d`) and TH-1 (`744afea`). A `git diff --binary` patch is not used unless the owner decides otherwise.\n'),
    ("it uses `git --no-optional-locks` so that `git status` cannot rewrite `.git/index` (the reviewer's C-INSTALL-01).\n",
     "it uses `git --no-optional-locks` so that `git status` cannot rewrite `.git/index` (the reviewer's C-INSTALL-01). The latest example is `VERIFY_TH1_INSTALL.py` inside `review/TH1_Test_Hardening_v1r2.zip`, which also checks that guarded files are unchanged in Git.\n"),
    ("- **Process discipline:** propose before transforming; the owner ratifies. The owner's priority is **getting the project running**, not measuring the role change.\n",
     "- **Process discipline:** propose before transforming; the owner ratifies. The owner's priority is **getting the project running**, not measuring the role change.\n"
     "- **Package sizing (owner-confirmed 27 October 2026):** small packages for complex or HIGH work; a lead item that proves the pattern before a batch of similar items (for example, one lead method per family); heavy methods one at a time; ensembles last.\n"),
    ('| `RATIFICATION_REGISTER_v0_4.md` | `cdb8c24eeb1a855a042cfebed30a801e9e36a654ccc655b5a2b8cc4eba4585d7` (from `review/MR_Integration_Install_v1/INSTALL_MANIFEST_SHA256.txt`) | Lineage and status; its own hash lives outside it |\n',
     '| `RATIFICATION_REGISTER_v0_5.md` | `551c1b42e99b58ad313dabe7d533e5650db83edce58e04f954b2f616c77afb3f` | Lineage and status at the effective commit; superseded by v0.6 when that is ratified and installed |\n'),
    ('**The register edition installed at the transition commit supersedes v0.4** (it records the roles ratification, Package 2 acceptance and the effective commit). Use whichever is current.\n',
     "**Register v0.6, installed with this file, supersedes v0.5.** A register cannot contain its own hash; v0.6's is in that installation's manifest. Register v0.4 (`cdb8c24e...85d7`) and v0.5 are history. Use whichever edition is current.\n"),
    ('P3 v0.1; register v0.2-v0.3; TIE v0.1;', 'P3 v0.1; register v0.2-v0.5; TIE v0.1;'),
    ('(they describe other events and are corrected by the register edition at the transition, not by editing ratified files)',
     '(they describe other events; register v0.5 records the corrections, and the ratified files are not edited)'),
    ('the "ChatGPT implements, Claude reviews" role lines (Proposal section 0 and A-29; register "Change discipline"); the register\'s "Continuity documents" line.',
     'the "ChatGPT implements, Claude reviews" role lines (Proposal section 0 and A-29). (Register v0.5 itself updated its own "Change discipline" and "Continuity documents" lines.)'),
    ("the reader's symlink refusal there relies on `is_symlink()`. NTFS hard-link behaviour of `st_nlink` is TO-TEST.\n",
     "the reader's symlink refusal there relies on `is_symlink()`. **NTFS hard links (OWNER-REPORTED, 27 October 2026, Windows 11, Python 3.14.8):** the reader's refusal of a hard-linked master (`st_nlink != 1`) ran and passed in the offline suite on the owner's NTFS drive. Symlink refusal on Windows is still TO-TEST: the owner's account cannot create symlinks (WinError 1314), so those subtests skip there.\n"),
    ('tests.test_multigame_console_and_synthetic_scorer_v0_4`\nResult at `c542483`: 58 OK, 1 skip (the baseline-path AST test; P2-R1-O3).',
     'tests.test_multigame_console_and_synthetic_scorer_v0_4 tests.test_p2_r1_t05_hardening_v1`\n'
     'Windows CMD form: `set PYTHONPATH=src;src\\methods;tests`, then the same `python -m unittest ...` line, then `set PYTHONPATH=`.\n'
     'Result at `c542483` (six modules): 58 OK, 1 skip (the baseline-path AST test). Since TH-1 (seven modules, 60 tests): Linux (Claude, at `b14116b`; Python 3.13.17, NumPy 2.5.3, psutil 7.2.2) 60 OK, 0 skipped; Windows (owner-reported, Python 3.14.8) 60 OK, 2 skipped (the exit-receipt symlink test and the reader\'s symlink subtest, because the account cannot create symlinks).'),
    ('- **P2-R1-O1:** add an intermediate N and an equal-length rewritten-suffix variant to the automated T-05 test.\n'
     '- **P2-R1-O3:** make the 11-function AST regression find the committed v0.6 baseline and stop skipping.\n'
     '- Older optionals: resolved-path containment under `source_data`; NTFS `st_nlink` handling (Windows TO-TEST); a full review of `multigame_windows_lifecycle_v1.py` before any lifecycle gate.\n'
     '- **Owner decision (27 Oct):** O1 and O3 are not brought forward; they form the first package under the new roles (section 9 item 1).\n',
     '- **P2-R1-O1 and P2-R1-O3: done** in TH-1 at `744afea` (section 7.1A).\n'
     '- Older optionals still open: resolved-path containment under `source_data`; a full review of `multigame_windows_lifecycle_v1.py` before any lifecycle gate. NTFS `st_nlink` handling is now owner-evidenced (section 6).\n'),
    ('Windows wrappers, venv activation and exit flow, NTFS link semantics,',
     'Windows wrappers, venv activation and exit flow, NTFS symlink semantics,'),
    ('Python 3.14 specifically (Claude ran 3.13),',
     'Python 3.14 beyond the offline suite (the owner ran the suite on 3.14.8; Claude runs 3.13),'),
    ('The `DrawView` split is reviewed discipline, not OS sandboxing.\n\n### 7.2 Powerball E_1 (accepted; frozen)\n',
     'The `DrawView` split is reviewed discipline, not OS sandboxing.\n\n' + TH1_SECTION + '### 7.2 Powerball E_1 (accepted; frozen)\n'),
    ('- Git output such as "create mode 100644" can worry the owner; explain it in one line (it just records ordinary new files).\n',
     '- Git output such as "create mode 100644" can worry the owner; explain it in one line (it just records ordinary new files).\n'
     "- TH-1 v1 (the reviewer's TH1-C01): a synthetic \"longer\" row, made by padding the last field, was not a valid row, so a test could have passed for the wrong reason. Any fixture that is meant to be valid gets its own test proving the reader accepts it.\n"
     "- TH-1 v1 on Windows: a test that created a symlink before its hard-link check crashed on the owner's account (WinError 1314) and hid the hard-link result. Split platform-dependent checks into subtests and skip only the part that cannot run.\n"
     "- TH-1 install: the owner extracted an earlier revision's ZIP; Claude caught it from the install log before the commit, and the owner restored the tree. A revision's verifier checks that revision's own bytes, so it cannot detect the wrong revision. Give every revision a distinct ZIP and folder name, name the exact folder in the commands, ask the owner to clear superseded extracted folders, and read the install log's paths before saying it is safe to commit.\n"),
    ([l for l in t.splitlines(True) if l.startswith('1. **First package under the new roles: offline test hardening')][0],
     '1. **Done:** the first package under the new roles, TH-1 offline test hardening (P2-R1-O1, P2-R1-O3), HIGH tier, installed at `744afea` (section 7.1A).\n'),
    ('2. **E_2-readiness specification**', '2. **Next: the E_2-readiness specification**'),
    ('6. **Owner decisions still open from the agreed position (section 11):** the Git transport choice (before the first new implementation package); whether to scope the oracle prototypes.\n',
     '6. **Owner decision still open from the agreed position (section 11):** whether to scope the oracle prototypes. (The transport choice was decided on 27 October 2026; section 1.6.)\n'),
    ('*End of H-1.*\n', APPENDIX_B.rstrip('\n') + '\n\n*End of H-1.*\n'),
    ('| Committed coordinator v0.6 (AST anchor) |',
     '| Review-disposition procedure (owner-accepted 27 Oct 2026) | ' + PROC + ', `5067aa520990b8ccc8521a04f3581424100cdd94994f5b9e3cb9e37863685339` |\n'
     '| Effective-commit verification | `review/Claude_Verification_Transition_Commit_d36735d_v1.md`, `c76b3bb305fca61bec0b791e6d792bc5b33f46529df0222498cbc5669a9343a0` |\n'
     '| H-1 v1r1 (predecessor) | `doc/HANDOVER/Claude_Primary_Handover_H1_v1r1.md`, `3223c41732888ea56c5458b365488660d157c93902b3745ed71d7d300fc2751e` |\n'
     '| Committed coordinator v0.6 (AST anchor) |'),
    ('(in history before `c542483`) |', '(in history before `c542483`; since `744afea` also the test fixture of section 7.1A) |'),
    ('`ae76c29` integration installed; the transition commit (this file, H-2, H-3; recorded externally).',
     '`ae76c29` integration installed; `6460ae3` four history files from the transition manifest (owner, before the install); `d36735d` the effective commit (H-1 v1r1, H-2 v1r2, H-3 v1r1, register v0.5); `997ed46` transition install history; `151f393` TH-1 packages and reviews (history); `744afea` TH-1 installed; `b14116b` review-disposition procedure; the commit installing this file (recorded externally).'),
]

for old, new in EDITS:
    n = t.count(old)
    assert n == 1, (n, old[:80])
    t = t.replace(old, new)
assert all(ord(c) < 128 for c in t)
assert t.endswith('\n') and not t.endswith('\n\n')
out.write_bytes(t.encode('ascii'))
print(out, hashlib.sha256(t.encode()).hexdigest(), len(t.splitlines()), 'lines')
