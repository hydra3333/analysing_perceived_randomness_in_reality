# Predictive Randomness - P3 E_1 U-view / standalone boundary v0.1

**CLAUDE INDEPENDENT REVIEW ONLY. DO NOT INSTALL INTO THE LIVE REPOSITORY YET.**

**Baseline:** E_1 v0.3 accepted by Claude (package SHA-256 beginning `ebe864de`); the underlying E_1 source file is byte-identical to that accepted candidate, SHA-256 `e91a907b5bd59c429d0cdc35291a6ba5c193550b0d0350db88a10d931df9cc47`. Git code baseline reviewed at HEAD `18fa741353399241380cfc8f52e35cbcf01f9dd6`. The owner may have pushed later administrative changes, so do not overwrite working-tree files blindly.

**What is new:** the U-view CSV prefix loader, real/synthetic domain-separated training digests, standalone synthetic CLI, early durable status and no-clobber result plus success/failure manifest, fail-closed standalone result consumer, a separate shared owner-ratified D2 encoding note, nine synthetic contract tests, and a focused Claude review request. The existing pure E_1 v0.3 maths is deliberately unchanged.

**Tests:** `python -m unittest discover -s tests -p 'test_p3_e1_standalone_v0_1.py' -v`, with current directory set to this extracted package. The captured local test run passed **9 of 9** using invented synthetic CSVs. This was Python on Linux in an isolated container; it is *not* a Windows 11/.venv or Run_Experiment.bat acceptance result. The original real source files and holdout were never read in these tests.

**Real gate:** `ENABLE_REAL_HISTORICAL_DEVELOPMENT = False`. Real mode explicitly refuses before a source-file read. No script is authorised for real execution, holdout access, FINAL forecasting, coordinator invocation, timeouts, or termination. The user-approved D3 parallel-development decision remains conditional on an accepted loader/status/firewall implementation and a subsequent real gate.

**Known unresolved matter:** the worker's PASS manifest is self-reported before process exit and cannot prove Windows exit RC=0. It states `external_exit_code_verified=false`; Claude should decide the smallest independently observed process-completion receipt that is consistent with Architecture Option F before the real gate. This is explicit, not concealed as a PASS-equivalent to the coordinator.

**For Claude:** start with `review/CLAUDE_REVIEW_REQUEST.md` and `doc/experiments/P3_E1_Real_U_View_And_Standalone_Contract_v0_1_REVIEW_CANDIDATE.md`. Do not use the earlier v0.3 synthetic forecast digest as the new U-view production digest. This package contains no real lottery CSV.

**Content and SHA-256 identities:** see `SHA256_MANIFEST.json`; calculate and compare hashes independently. New files are additions against the Git HEAD anchor, with a complete byte-identical copy of the accepted E_1 pure module supplied for standalone reproducibility.
