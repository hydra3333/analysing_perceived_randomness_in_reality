# Independent Claude review request  -  P3 E_1 real U-view and standalone gate v0.1

Baseline: ratified E_1 v0.3 synthetic prototype, accepted by Claude (package SHA `ebe864de...`), against reviewed Git code HEAD `18fa741...`; administrative repository commits may have advanced afterward. All new files are review-candidate overlays, not yet installed.

**Primary review questions:**
1. Is the exact N-1 prefix cut-off robust against malformed/future CSV, and do historical target restrictions reliably prevent the original 1578-1587 holdout from being used?
2. Is the real E_1 canonical U-view (draw number, sorted seven-number set, Powerball only) sufficiently explicit and separated from synthetic/test data, including source schema and provenance?
3. Is the standalone early durable STARTED -> SUCCESS/FAILED lifecycle and no-clobber result+manifest defensible on Windows? Any status/manifest ordering race or late-publication failure that invalidates the firewall?
4. Does the consumer correctly refuse failed/orphan/unknown manifests **before opening** canonical results? Can forged or incomplete states evade the firewall?
5. Is the externally verified OS exit-status requirement important before real-data development, given no parent wrapper receipt in this version? Recommend a minimal Option-F-compatible fix if needed.
6. Assess all DECIDED/RECOMMENDED/OPEN classifications for accidental owner-authority overreach. The hard real-mode gate stays False; no real runs authorised by review alone.

**Reproduction:** run `python -m unittest discover -s tests -p 'test_p3_e1_standalone_v0_1.py' -v` from overlay root. Tests create synthetic temporary CSV files, and do not open `source_data`. Review code against ratified R2 section I-05/I-06/I-08 and section 9.2, R3 section 2.4, ratified Architecture v0.5 section 5C and D1-D3 owner decisions. E_1 v0.3 remains unchanged.

**Requested verdict:** blockers and nonblockers separately; clearly state whether an independently reviewed real-data Windows gate could proceed, or if a revised review candidate is needed. Reviewer must not authorise real-data runs, termination, holdout access or FINAL.
