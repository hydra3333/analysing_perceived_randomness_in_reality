# E_1: production U-view and standalone execution boundary  -  v0.1 REVIEW CANDIDATE

**Date:** 23 October 2026. **Authority:** Proposal v0.3, R1 v0.4, R2 v0.3 + approved erratum, R3 v0.2, Architecture v0.5, Task Spec v0.2, owner decisions D1/D2/D3 (23 Oct), and Claude's accepted E_1 v0.3 synthetic identity. **Source anchor:** developer-supplied repository snapshot, Git HEAD `18fa741353399241380cfc8f52e35cbcf01f9dd6` for the last reviewed E_1 package; housekeeping thereafter may change document HEAD without changing these code bases. **Status:** code candidate, not authorised for real-data execution. P2 coordinator v0.6 is outside this patch.

## 1. What is implemented

1. A target-bounded loader for E_1's unordered-set **U** view, with current-format seven distinct labels in 1..35, PB 1..20, consecutive 1144..N-1 and verified weekly date chronology. The dedicated source is the *unordered* history CSV with `Draw_Number,Date,Ball_1..Ball_7,Powerball`, NEVER the separate drawn-order CSV. The date is checked but omitted from E_1's fit view and content digest.
2. The loader iterates exactly `N-1144` accepted CSV rows and does **not parse** the outcome at N or any later CSV record. The underlying buffered text I/O may prefetch raw bytes; this is a logical access boundary, not a claim of zero physical read-ahead. Future fields cannot affect model content. Whole-file/source filename/time/provenance hashes are excluded from fit content identity.
3. A *different* real training-view domain, `E1_REAL_U_TRAINING_VIEW_V1`, and synthetic CSV domain `E1_SYNTHETIC_CSV_U_TRAINING_VIEW_V1`. Each has canonical JSON bytes (`ensure_ascii`, lexicographically sorted keys, compact separators, LF at end), schema/data_kind/records. Each record contains exactly `draw` (int), `main` (ascending seven-number list), `powerball` (int). `training_view_sha256` is SHA-256 of these bytes. No date, original ball-column order, drawn-order fields, full-source hash, outcome at N+, runtime ID, wall time, or process information enters the digest.
4. `FULL_HISTORY_RAW_COUNTS_V1` E_1 readout calls the independently accepted E_1 v0.3 `rank_counts`/`TIE_SHA256_V1` code. There are 35 main and 20 PB scores; TOP and WORST come from one ranking, with WORST an exact reversal. The result uses a **new review schema** `E1_HISTORICAL_DEVELOPMENT_FORECAST_V0_1_REVIEW`, not `E1_SYNTHETIC_FORECAST_V0_1_NOT_FINAL`. JSON score map keys are canonical decimal **strings** (JSON object key type) so serialization remains byte-stable after roundtrip. Neither schema is FINAL.
5. Standalone runner `E_1_Historical_Appearance_Frequency_Run.py` has an explicitly hardcoded real-mode gate **False**, not settable by environment or CLI. It refuses real mode before reading any source file. Synthetic contract mode may operate on temp created invented CSV fixtures only. A future reviewed patch is required to authorise real execution; D3 already grants the *conditional project sequencing exception*, not bypass of this gate.
6. The runner creates `status.json` STARTED with exclusive creation and fsync **before model or CSV loading**. On normal completion, creates `canonical_result.json` once (xb/fsync), publishes terminal SUCCESS status, then the `standalone_manifest.json` PASS as the last substantive step, with exact identities and two SHA-256 fingerprints. Failure generates a terminal FAILED status and a non-PASS manifest where possible; no result file alone conveys success. Re-use of run directory is forbidden. There is no child spawning or process killing, and the coordinator/`Run_Coordinator.bat` are not used.
7. The shared consumer `verify_and_consume` checks marker, manifest PASS, absence of orphan/marker-write-failure flags, run-ID/mode/target/method/variant identity, terminal status and its SHA-256, and matching data digest **before opening a result file**, then checks result hash and identity. It rejects a FAIL, orphan-suspected, absent/corrupt/mismatched manifest even if a canonical result exists. It never treats a standalone run as a coordinator group PASS.

## 2. Explicit safety limits

**Sealed historical holdout:** the original draw targets 1578-1587 are never opened, evaluated, selected or predicted in historical development. This candidate conservatively restricts ALL historical targets to **1145..1577**, and thereby cannot create a training prefix crossing 1577. Even a user requesting target 1588 in development is refused (would contain sealed holdout training). The FINAL `L+1` mode is not implemented, and is governed by separate owner authorisation; the genuine FINAL exception regarding holdout as *training* does NOT apply to these development runs.

**Real file trust:** future real mode accepts a regular nonsymlink file directly under project `source_data/` whose name exactly matches `australian_powerball_history_YYYYMMDD.csv`, with the specified U-only columns. User-provided arbitrary file outside source_data is not an authorised real source. Source timestamp and source snapshot digest are distinct future audit fields, **not model content**. Comprehensive post-cutoff source-audit validation and scraper reconciliation remain a separate workflow.

**Synthetic/real firewall:** the two data kinds have distinct digest domain IDs and output identity. The standalone synthetic test CLI refuses real source_data paths. Merely relabelling a synthetic result as real does not pass the consumer's identity checks (a fabricated canonical result and rewritten manifest are not cryptographic attestations; no adversarial signing system is claimed). Never ingest synthetic results into real performance tables.

**Hard gate:** `ENABLE_REAL_HISTORICAL_DEVELOPMENT = False` must remain False through this review. No destructive tests, coordinator timeout reliance, process signals, holdout reads, FINAL forecasts, or retrospective evaluations of reserved targets. The current P2 `ENABLE_PROCESS_TERMINATION` remains False and untouched. No automated Windows BAT test was conducted in this container.

**Important residual:** the standalone PASS manifest is a *self-reported completion* emitted by the worker before the Python process has actually exited; `external_exit_code_verified` is correctly recorded **False**. The verifier can prove internal consistency and fail closed on known FAIL/orphan states, but it cannot independently prove OS exit code or exclude a late exception after manifest publication. A separately designed external post-exit witness for real production acceptance must be reviewed; never represent this as a complete coordinator-equivalent exit proof. In synthetic tests the Python function return is independently asserted to be 0. This is an **OPEN production review issue**, not a silently waived safety requirement.

## 3. Tests (synthetic only)

`tests/test_p3_e1_standalone_v0_1.py` uses the previous invented v0.3 fixture to generate isolated CSVs in temporary directories and tests:

- Valid raw-count maths (56 main appearances, 8 PB; first three main labels 1,8,2).
- N and later mutation and even syntactically invalid future rows do not alter canonical bytes or the training-view digest; modifications to permitted pre-target rows DO change the training digest.
- Explicit source-kind separation and held-out/development target refusal.
- Wrong headers, drawn-order input, missing draws, invalid dates and Powerball labels rejected.
- Exclusive run IDs, terminal states, self-declared PASS, explicit result hashing, and tamper/refusal for FAIL, orphan flag, marker-write-failure, identity mismatch, missing manifest and changed result bytes.
- Real execution gate blocks before a non-existent source would be opened.

Tests do not read, inspect, evaluate or otherwise expose any real draw, including the original holdout. Test logs disclose invented synthetic values only. Running tests through `Run_Experiment.bat` on the owner's PC is a subsequent, separately reviewed Windows gate, not something this archive orders the owner to perform now.

## 4. Decisions and review requests

**OWNER-RATIFIED:** D1 first raw-frequency variant, D2 4-byte LE length + UTF-8 eight-field tuple, D3 real-data historical *development* may proceed in parallel after loader/status review, standalone only. R2/R3 N-1, holdout, synthetic firewall and rejected-group rule remain binding.

**DECIDED within implementation authority (subject to Claude's check):** exact canonical U-view representation/digest domain, dedicated target-bounded prefix loader, conservative target range 1145..1577, run folder isolation, starter status schema, provisional standalone result and manifest schemas, independent validator, hard real-mode code gate False, built-in `unittest` synthetic suite.

**RECOMMENDED for any approval needed:** before unblocking real mode, require an external observable OS exit-code/wrapper-completion acknowledgement and user-approved exact real source snapshot and target; decide whether an atomic final-success receipt from a launcher is necessary. Do not treat self-reported PASS as proof of clean Windows process exit.

**OPEN:** remote publication evidence and FINAL batch format; comprehensive source-data refresh validator; actual Windows `Run_Experiment.bat` synthetic test; exact final historical score/evaluator integration; operating procedure for reviewed real enablement; coordinator v0.7 and destructive gate; timestamp evidence for genuine FINAL. No E_1 method/result code is installed by merely opening this ZIP.

**Claude: please review the actual new source and tests for leakage, holdout isolation, source trust, race/atomicity, Windows file semantics, self-reported exit proof, failed-run firewall and owner-authority classifications.** Raise substantive issues (including if the conservative `target <=1577` gate is too restrictive). Do not accept real execution on the basis of synthetic Linux tests. Exact SHA manifest accompanies the package.
