# Claude independent review request — P1/P2 orphan interlock v0.6

Please inspect actual proposed source and supplied exact diffs. The reviewed v0.5 was NOT approved because of B2 (exit before capture, status identifies live process, but no interlock).

Verify that:
1. Exit-time checks run for all exit codes before further scheduling; captured liveness and matching run-ID status PID evidence are used appropriately, with confirmed-gone/reused PIDs not automatically triggering the interlock.
2. A match with missing creation time cannot cause silent continuation, but status never authorises any kill.
3. Console **and subsequent blocked launch** provide flushed, specific SAFETY STOP messages: worker/run/PID/creation-time, reason, marker path, recovery procedure.
4. Original no-status/no-kill policy and disabled owner switch are unchanged; no new process-kill path; no taskkill or Job Objects.
5. Durable marker publication, marker-write-failure handling, fail-closed startup, and multi-worker stop-launches semantics are correct. Evaluate any race or false-positive issues.
6. New v0.6 fake regressions are adequate; identify any important missing integration test.
7. Full source can be installed for **non-destructive Windows-only acceptance tests**, but do NOT authorise any switch-on or destructive test.

Please give concrete findings classified as BLOCKER, OPTIONAL, or ACCEPT. No source editing yet. Review exact paths and SHA-256 manifest. Note that repository snapshot (4).zip was v0.2 while user's current Windows coordinator was independently checked as v0.3.
