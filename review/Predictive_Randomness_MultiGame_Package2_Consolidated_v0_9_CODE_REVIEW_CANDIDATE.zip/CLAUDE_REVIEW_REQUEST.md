# Request for Claude — Package 2 consolidated review candidate v0.9

Review this full merged overlay, not the individual v0.1–v0.8 increments. Check:

1. All new Python source and test modules against current ratified Package 1 and the actual committed Git HEAD.
2. The *exact* v0.6-to-v0.9 coordinator diff: original process ownership, root capture, status orphan evidence, orphan-marker, termination, status_and_result and consumer firewall are unchanged; `ENABLE_PROCESS_TERMINATION=False`, `ENABLE_SCIENTIFIC_COORDINATION=False`, and new `ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE=False`. Review any new branch that could create a subprocess after a separately approved source-gate change.
3. Live-ancestry handshake: worker STARTED status is durable before release; coordinator validates root/descendant creation times *while alive*; no status-only ownership; no synthetic file may constitute exit proof; no-status/uncertain path leaves a persistent STOP marker when required; zero signal paths.
4. Console publication and final receipt bind exact single-read canonical bytes; coordinator private issuer imported without method path shadowing; create-only receipt and group PASS; consumer uses *returned verified object* and registry allowlist is still EMPTY.
5. Regression evidence (91 + 13 Linux), exact 1577 golden identity, no Powerball edits, no Oz Lotto holdout access. Independently verify tests on Windows after owner authorisation; no autonomous Windows lifecycle run has been performed by ChatGPT.
6. Source policy and data bounds: official Lotterywest pages, offline adapters and provenance modules, robots handling; no live requests; date mismatch warning, structural gaps FAIL.
7. Classification: synthetic result is NEVER `COORDINATED`/`FINAL`. It is still not a registered scientific result even if flags are stripped.
8. **Remaining blockers:** identify the minimum safe tests/refinements before the owner can authorise a narrowly enabled Windows synthetic run. Do not approve activation of scientific coordination, FINAL, termination, or live scraping from this review.

This is a candidate against the saved source baseline, not yet an installation or acceptance release. Report findings with severity and exact file/line ranges.
