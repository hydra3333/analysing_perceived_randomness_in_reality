# Package 2 — exact Windows synthetic lifecycle commands (v0.9)

**STATUS: NOT EXECUTED; AWAITS INDEPENDENT REVIEW AND SEPARATE OWNER AUTHORISATION.**

The commands below are for a *future* owner-authorised, controlled Windows test. They are **not** instructions to run now. This is a synthetic one-worker plumbing run, NOT lottery prediction, scoring, real-data collection or holdout evaluation. Both the termination and scientific coordination switches stay `False` throughout.

## Code gates

- `ENABLE_PROCESS_TERMINATION = False` — never change for this acceptance.
- `ENABLE_SCIENTIFIC_COORDINATION = False` — never change for this acceptance.
- `ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE = False` — new, independent source gate; separate owner consent and Claude review are required before permitting the controlled synthetic command. There is no CLI bypass.
- The synthetic launch supports only registered `E_1` / `SYNTHETIC_PLUMBING_V1`. The registered coordinated/FINAL scientific result allowlist remains empty.
- Only existing `Run_Experiment.bat` calls `POC_MultiGame_Synthetic_Worker.py`; no actual lottery files are accessed.

## Environment and identity evidence (CMD.exe, from repository root)

Only after explicit authorisation:

```bat
cd /d E:\SOFTWARE-Win11\powerball\analysing_perceived_randomness_in_reality
git rev-parse HEAD
git status --short
.venv\Scripts\python.exe --version
.venv\Scripts\python.exe -c "import psutil;print(psutil.__version__)"
.venv\Scripts\python.exe -m unittest discover -s tests -p "test_multigame_*.py" -v
.venv\Scripts\python.exe -m unittest discover -s tests -p "test_p3_e1_standalone_v0_1.py" -v
findstr /N "ENABLE_PROCESS_TERMINATION = False ENABLE_SCIENTIFIC_COORDINATION = False ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE" src\Powerball_Experiment_Coordinator.py
```

Verify the v0.6 committed coordinator baseline SHA-256 `2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b` by reviewing the included diff. Review `UNRESOLVED_ORPHAN.json` *before* any launch. If present or uncertain, **STOP**. Never delete the marker automatically; manual archival and PID-plus-creation-time inspection rules remain binding.

## Synthetic lifecycle command (DO NOT RUN until authorised and gate reviewed)

```bat
.venv\Scripts\python.exe -u src\Powerball_Experiment_Coordinator.py --synthetic-contract-test --game POWERBALL --target 1577 --timeout-seconds 25
```

With the shipped source (`ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE = False`) this command is **supposed to refuse** with exit code 3 *before any Popen*. Do not turn the new source gate on merely to make a test pass. Reviewers and the owner must separately authorise a narrowly limited test enablement, plus a restore-to-False step.

### What an authorised PASS must prove

1. STARTED status is persisted early by the synthetic worker; coordinator captures `cmd.exe` root PID+creation time and actual `python.exe` descendant PID+creation time while both are alive.
2. Coordinator writes its create-only `coordinator_ancestry_release.json` **only after** comparing run-matched STARTED status to captured ancestry. Worker waits for an exact identity-matched release (15-second bound), not a worker self-certification.
3. The reader captures exact ordered BEGIN/RESULT/DIGEST/FINISH publication and reaches EOF. `Popen` exit timestamp is captured at the first coordinator-observed exit. The independent v0.6 exited-worker orphan check runs again after EOF, before receipt issuance.
4. The coordinator's private receipt issuer reads canonical result bytes once, checks console publication against those same bytes, binds them plus worker status and manifest hashes, and writes `group/receipts/<run_id>.json` create-only.
5. The group manifest indicates synthetic plumbing only; a scientific consumer **must refuse** it even with a valid receipt. Both safety switches stay False; no signals are sent.
6. Preserve the exact CMD transcript, process identity evidence, source hashes, receipt/manifest hashes and environment details. Treat missing ancestry or any uncertain process as FAIL, with persistent interlock where needed.

### Cases NOT YET RUNNABLE / NOT AUTHORISED

Adversarial process-timeout, abrupt exit, missing status and orphan-suspicion cases require separately reviewed deterministic fixtures and explicit owner approval, as they can create a persistent orphan interlock. Do **not** invent CLI variants or simulate an orphan by killing arbitrary processes. An Oz Lotto Windows synthetic run is also not currently available: its real historical-development bound remains unsealed; the existing single-barrel tests run purely offline without needing to open that boundary.

No live scraping, real scoring, E_1 scientific coordination, prospective FINAL operation, process termination or holdout access is enabled by this document.
