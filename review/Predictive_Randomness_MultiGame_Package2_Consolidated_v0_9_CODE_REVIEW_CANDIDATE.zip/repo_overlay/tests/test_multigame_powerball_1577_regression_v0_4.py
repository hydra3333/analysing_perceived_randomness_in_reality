"""Exact authorized, prefix-only Powerball 1577 GOLDEN regression.

Reads historical training rows 1144..1576 (N-1) only, never target 1577,
sealed holdout 1578..1587, or subsequent outcomes. Tests the *accepted*
legacy schema and the new pure tie ranking, without executing real new methods.
"""
from __future__ import annotations
import hashlib
import sys
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'/'methods'))
from _common.e1_training_view_v0_1 import load_permitted_u_view,build_e1_forecast
from _common.e1_historical_appearance_frequency_v0_3 import canonical_bytes,tie_digest
from _common.multigame_e1_v1 import _digest as generic_tie_digest


class RealPowerballFrozenRegression(unittest.TestCase):
    def test_1577_authorised_training_prefix_exact_golden(self):
        source = ROOT/'source_data'/'australian_powerball_history_20261021.csv'
        prefix,digest = load_permitted_u_view(source,1577,
            source_kind='REAL_HISTORICAL_DEVELOPMENT',trusted_source_dir=source.parent)
        self.assertEqual(len(prefix),433)
        self.assertEqual([prefix[0]['draw'],prefix[-1]['draw']],[1144,1576])
        self.assertEqual(digest,'d47fbbd6e60e6abc429fb74f47d8bbeafc6560152c2ecddb3b75d79932df4339')
        old=build_e1_forecast(prefix,digest,1577,source_kind='REAL_HISTORICAL_DEVELOPMENT')
        self.assertEqual(hashlib.sha256(canonical_bytes(old)).hexdigest(),
                         '7f1130872b3afaa222ff4e8c2396cd2c2872583544dfa6b31cc5a07cd067164e')
        self.assertEqual(old['MAIN']['top'],[9,17,7,11,18,30,12])
        self.assertEqual(old['MAIN']['worst'],[31,13,8,29,26,33,35])
        self.assertEqual(old['POWERBALL']['top'],2)
        self.assertEqual(old['POWERBALL']['worst'],12)
        # Check the new *pure* deterministic ranking independently, without
        # passing real rows to any synthetic-labeled model runner.
        for barrel,record_key,labels in (('MAIN','main',range(1,36)),
                                         ('POWERBALL','powerball',range(1,21))):
            counts={n:0 for n in labels}
            for row in prefix:
                values = row[record_key] if barrel=='MAIN' else [row[record_key]]
                for n in values: counts[n]+=1
            ranking=sorted(counts,key=lambda n:(-counts[n],generic_tie_digest(digest,1577,barrel,n),n))
            self.assertEqual(ranking,old[barrel]['ranking'])
            self.assertEqual({str(n):counts[n] for n in labels},old[barrel]['scores'])
            for n in labels:
                self.assertEqual(generic_tie_digest(digest,1577,barrel,n),tie_digest(digest,1577,barrel,n))

if __name__=='__main__':unittest.main()
