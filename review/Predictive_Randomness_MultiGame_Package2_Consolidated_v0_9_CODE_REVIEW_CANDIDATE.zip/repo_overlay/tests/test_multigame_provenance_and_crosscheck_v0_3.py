"""Offline-only fixture tests for source provenance and bounded crosschecks."""
from __future__ import annotations

import hashlib
import json
import sys
import tempfile
import unittest
from dataclasses import replace
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'src' / 'methods'))

from _common.game_profiles_v1 import OZLOTTO, POWERBALL
from _common.multigame_source_policy_v1 import policy_for_offline_robots
from _common.multigame_source_plan_v1 import source_plan, SourcePage
from _common.multigame_offline_response_archive_v1 import archive_synthetic_responses
from _common.multigame_offline_source_adapters_v1 import OfflineDraw
from _common.multigame_bounded_crosscheck_v1 import compare_source_draws


ROBOTS = b'User-agent: *\nDisallow:\n'
USER_AGENT = 'AcademicRandomnessProject/1.0 (+local-research; no browser imitation)'


def draws(profile, *, end=1475):
    return [OfflineDraw('OZLOTTO', n, profile.derived_date(n),
                        (7,1,3,2,6,4,5), (8,10,9))
            for n in range(profile.first_draw, end + 1)]


class SourceProvenanceTests(unittest.TestCase):
    def test_robots_allow_empty_disallow_exact_origin(self):
        page = source_plan('OZLOTTO', last_draw=1474)[0]
        d = policy_for_offline_robots(source_id='LOTTERYWEST_RESULTS',
                page_url=page.url, robots_url='https://www.oz.lotterywest.com/robots.txt',
                robots_bytes=ROBOTS, user_agent=USER_AGENT)
        self.assertTrue(d.request_allowed)
        self.assertEqual(d.robots_sha256, hashlib.sha256(ROBOTS).hexdigest())

    def test_robots_specific_disallow_and_missing_fail_closed(self):
        page = source_plan('OZLOTTO', last_draw=1474)[0]
        kwargs = dict(source_id='LOTTERYWEST_RESULTS', page_url=page.url,
                      robots_url='https://www.oz.lotterywest.com/robots.txt', user_agent=USER_AGENT)
        self.assertFalse(policy_for_offline_robots(**kwargs, robots_bytes=None).request_allowed)
        self.assertFalse(policy_for_offline_robots(**kwargs,
                robots_bytes=b'User-agent: *\nDisallow: /oz-lotto/results/\n').request_allowed)
        self.assertFalse(policy_for_offline_robots(**kwargs, robots_bytes=b'').request_allowed)

    def test_robots_origin_credentials_and_wrong_path_rejected(self):
        page = source_plan('OZLOTTO', last_draw=1474)[0]
        kwargs = dict(source_id='LOTTERYWEST_RESULTS', page_url=page.url,
                      robots_url='https://www.oz.lotterywest.com/robots.txt',
                      user_agent=USER_AGENT, robots_bytes=ROBOTS)
        for key, bad in [('page_url', page.url.replace('https://','http://')),
                         ('robots_url', 'https://www.oz.lotterywest.com/policy'),
                         ('page_url','https://evil.org/oz-lotto/results/draw/1474'),
                         ('page_url','https://user@www.oz.lotterywest.com/oz-lotto/results/draw/1474')]:
            with self.subTest(key=key, url=bad), self.assertRaises(ValueError):
                policy_for_offline_robots(**(kwargs | {key:bad}))

    def test_plan_common_lotterywest_both_games_and_legacy_powerball(self):
        pb = source_plan('POWERBALL', last_draw=1145, source_id='LOTTERYWEST_RESULTS')
        self.assertEqual([p.key for p in pb], [1144,1145])
        self.assertEqual(pb[0].url, 'https://www.oz.lotterywest.com/powerball/results/draw/1144')
        self.assertEqual(source_plan('POWERBALL', last_year=2018)[0].source_type,
                         'POWERBALL_NET_YEAR_ARCHIVE_V03')
        with self.assertRaises(ValueError):
            source_plan('OZLOTTO',last_draw=1475, source_id='UNKNOWN')

    def test_offline_archive_create_only_and_content_hashes(self):
        plan = source_plan('OZLOTTO', last_draw=1475)
        bodies = {p.key: f'<h1>SYNTHETIC ONLY draw {p.key}</h1>'.encode('ascii') for p in plan}
        robots_hash = hashlib.sha256(ROBOTS).hexdigest()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            m = archive_synthetic_responses(game_id='OZLOTTO', source_pages=plan,
                  page_bodies=bodies, root=root, run_id='synthetic_run01', robots_sha256=robots_hash)
            d = root / 'SYNTHETIC_ONLY' / 'OZLOTTO' / 'synthetic_run01'
            self.assertEqual(m['page_count'],2)
            self.assertFalse(m['science_usable'])
            self.assertIsNone(m['retrieved_at_utc'])
            self.assertEqual(json.loads((d/'response_manifest.json').read_text('ascii')),m)
            for page in m['pages']:
                self.assertEqual(hashlib.sha256((d/page['relative_file']).read_bytes()).hexdigest(),page['sha256'])
            with self.assertRaises(FileExistsError):
                archive_synthetic_responses(game_id='OZLOTTO',source_pages=plan,
                      page_bodies=bodies,root=root,run_id='synthetic_run01',robots_sha256=robots_hash)
            self.assertFalse((root/'source_data').exists())

    def test_archive_rejects_unapproved_url_and_missing_or_invalid_capture(self):
        plan = source_plan('OZLOTTO', last_draw=1474)
        robots_hash = hashlib.sha256(ROBOTS).hexdigest()
        with tempfile.TemporaryDirectory() as tmp:
            root = Path(tmp)
            base = dict(game_id='OZLOTTO', root=root, run_id='synthetic_run02', robots_sha256=robots_hash)
            with self.assertRaises(ValueError):
                archive_synthetic_responses(**base, source_pages=plan, page_bodies={})
            with self.assertRaises(ValueError):
                archive_synthetic_responses(**base, source_pages=plan, page_bodies={1474:b''})
            with self.assertRaises(ValueError):
                archive_synthetic_responses(**base, source_pages=(replace(plan[0],url='https://bad.org/results/1474'),),
                                             page_bodies={1474:b'<x>'})
            with self.assertRaises(ValueError):
                archive_synthetic_responses(**(base | {'robots_sha256':'bad'}), source_pages=plan, page_bodies={1474:b'<x>'})
            self.assertFalse((root/'SYNTHETIC_ONLY').exists())

    def test_archive_powerball_plan_offline(self):
        plan = source_plan('POWERBALL', last_year=2018)
        with tempfile.TemporaryDirectory() as tmp:
            rec=archive_synthetic_responses(game_id='POWERBALL',source_pages=plan,
                page_bodies={2018:b'<html>synthetic year only</html>'}, root=Path(tmp),
                run_id='synthetic_pb01', robots_sha256=hashlib.sha256(ROBOTS).hexdigest())
            self.assertEqual(rec['pages'][0]['key'],2018)

    def test_crosscheck_agreement_reports_no_ball_values(self):
        a = draws(OZLOTTO)
        result = compare_source_draws(profile=OZLOTTO, primary_source='LOTTERYWEST_RESULTS',
            secondary_source='LOTTODRAW_ARCHIVE', primary=a, secondary=a, through_draw=1475)
        self.assertTrue(result['fully_agreed'])
        self.assertEqual(result['source_order_check'],'AGREED')
        self.assertFalse(result['physical_draw_order_proven'])
        for v in (7, 10, 9):
            self.assertNotIn(f': {v},',str(result))
        self.assertNotIn('winning_main',json.dumps(result))

    def test_crosscheck_detects_missing_and_draw_collision(self):
        a = draws(OZLOTTO)
        r = compare_source_draws(profile=OZLOTTO, primary_source='LOTTERYWEST_RESULTS',
            secondary_source='LOTTODRAW_ARCHIVE', primary=a, secondary=a[:1], through_draw=1475)
        self.assertFalse(r['fully_agreed'])
        self.assertEqual(r['errors'][0]['draw_number'],1475)
        with self.assertRaises(ValueError):
            compare_source_draws(profile=OZLOTTO, primary_source='LOTTERYWEST_RESULTS',
                secondary_source='LOTTERYWEST_RESULTS', primary=a, secondary=a, through_draw=1475)

    def test_crosscheck_sorted_source_does_not_invalidate_equal_set(self):
        a = draws(OZLOTTO)
        b = [replace(x, winning_main=tuple(sorted(x.winning_main)),
                     supplementary=tuple(sorted(x.supplementary))) for x in a]
        r=compare_source_draws(profile=OZLOTTO, primary_source='LOTTERYWEST_RESULTS',
             secondary_source='LOTTODRAW_ARCHIVE',primary=a,secondary=b,through_draw=1475)
        self.assertTrue(r['fully_agreed'])
        self.assertEqual(r['source_order_check'],'UNVERIFIED')
        self.assertEqual(r['order_warning_count'],4)
        self.assertEqual(r['error_count'],0)

    def test_crosscheck_disagreement_in_balls_rejected_without_values(self):
        a=draws(OZLOTTO)
        b=[replace(x,winning_main=(7,1,3,2,6,4,11)) for x in a]
        r=compare_source_draws(profile=OZLOTTO,primary_source='LOTTERYWEST_RESULTS',
             secondary_source='LOTTODRAW_ARCHIVE',primary=a,secondary=b,through_draw=1475)
        self.assertFalse(r['fully_agreed'])
        self.assertEqual(r['errors'][0]['field'],'MAIN')
        self.assertNotIn('11',json.dumps(r))

    def test_powerball_different_publication_order_is_not_false_content_error(self):
        first = POWERBALL.first_draw
        main = (7,1,3,2,6,4,5)
        original = [OfflineDraw('POWERBALL', n, POWERBALL.derived_date(n), main, (), 8)
                    for n in range(first, first + 2)]
        sorted_copy = [replace(v, winning_main=tuple(sorted(v.winning_main)))
                       for v in original]
        result = compare_source_draws(profile=POWERBALL,
                primary_source='LOTTERYWEST_RESULTS',
                secondary_source='POWERBALL_NET_ARCHIVE',
                primary=original, secondary=sorted_copy, through_draw=first + 1)
        self.assertTrue(result['fully_agreed'])
        self.assertEqual(result['source_order_check'],'UNVERIFIED')
        self.assertEqual(result['order_warning_count'],2)

    def test_crosscheck_no_supplementary_collision(self):
        a=draws(OZLOTTO)
        b=[replace(x,supplementary=(1,8,9)) for x in a]
        r=compare_source_draws(profile=OZLOTTO,primary_source='LOTTERYWEST_RESULTS',
             secondary_source='LOTTODRAW_ARCHIVE',primary=a,secondary=b,through_draw=1475)
        self.assertFalse(r['fully_agreed'])
        self.assertEqual(r['errors'][0]['field'],'SUPPLEMENTARY')


if __name__ == '__main__': unittest.main()
