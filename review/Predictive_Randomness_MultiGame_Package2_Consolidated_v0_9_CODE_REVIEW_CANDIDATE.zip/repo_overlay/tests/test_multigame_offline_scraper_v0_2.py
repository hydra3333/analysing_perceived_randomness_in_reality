"""Package-2 OFFLINE synthetic HTML fixtures only. No real-source access."""
from __future__ import annotations

import csv
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'))
sys.path.insert(0,str(ROOT/'src'/'methods'))

from _common.game_profiles_v1 import OZLOTTO, POWERBALL
from _common.multigame_offline_source_adapters_v1 import (
    parse_ozlotto_official_draw_html, parse_powerball_archive_html,
    canonical_csv_rows,
)
from _common.multigame_offline_source_pipeline_v1 import publish_offline_html_fixture
from _common.multigame_structural_audit_v1 import audit_snapshot_pair


def synthetic_oz_page(n, *, main=(1,2,3,4,5,6,7), supp=(8,9,10),
                      page_date=None, game='Oz Lotto',
                      drop_supp=False, extras='', use_packed=False):
    d=page_date or OZLOTTO.derived_date(n)
    date_text=f'{d.day} {d.strftime("%B %Y")}'
    def t(seq):
        return (f'<div>{" ".join(map(str,seq))}</div>' if use_packed else
                ''.join(f'<span>{v}</span>' for v in seq))
    suffix=('' if drop_supp else f'<h2>Supplementary</h2>{t(supp)}')
    return (f'<html><head><title>{game} — Synthetic Fixture</title></head>'
            f'<body><h1>{date_text} 10:30 am Draw {n}</h1>'
            f'<h2>Main Numbers</h2>{t(main)}{suffix}'
            f'<h2>Div</h2><p>1,000,000 fake winnings</p>{extras}</body></html>')


class OfflineScraperTests(unittest.TestCase):
    def test_oz_parse_labelled_result(self):
        draw=parse_ozlotto_official_draw_html(synthetic_oz_page(1474),expected_draw=1474)
        self.assertEqual(draw.game_id,'OZLOTTO')
        self.assertEqual(draw.draw_number,1474)
        self.assertEqual(draw.recorded_date.isoformat(),'2022-05-17')
        self.assertEqual(draw.winning_main,(1,2,3,4,5,6,7))
        self.assertEqual(draw.supplementary,(8,9,10))
        self.assertIsNone(draw.powerball)

    def test_numeric_grouped_section(self):
        draw=parse_ozlotto_official_draw_html(synthetic_oz_page(1476,use_packed=True),expected_draw=1476)
        self.assertEqual(len(draw.winning_main),7)
        self.assertEqual(len(draw.supplementary),3)

    def test_refuse_wrong_game_or_draw(self):
        with self.assertRaisesRegex(ValueError,'wrong or missing'):
            parse_ozlotto_official_draw_html(synthetic_oz_page(1475),expected_draw=1474)
        with self.assertRaisesRegex(ValueError,'not identified'):
            parse_ozlotto_official_draw_html(synthetic_oz_page(1474,game='Other Game'),expected_draw=1474)
        with self.assertRaises(ValueError):
            parse_ozlotto_official_draw_html(synthetic_oz_page(1474),expected_draw=1473)

    def test_refuse_missing_extra_duplicate_outofrange(self):
        variants=[{'drop_supp':True},{'main':(1,1,3,4,5,6,7)},
                  {'supp':(7,8,9)},{'supp':(8,9,48)},
                  {'main':(1,2,3,4,5,6,48)},
                  {'supp':(8,9,10,11)},{'main':(1,2,3,4,5,6)},
                  {'main':(1,2,3,4,5,6,7,8)}]
        for case in variants:
            with self.subTest(case=case):
                with self.assertRaises(ValueError):
                    parse_ozlotto_official_draw_html(synthetic_oz_page(1474,**case),expected_draw=1474)

    def test_stripped_scripts_not_used(self):
        page=synthetic_oz_page(1474,extras='<script>Main Numbers 21 33 Supplementary 42 31</script>')
        draw=parse_ozlotto_official_draw_html(page,expected_draw=1474)
        self.assertEqual(draw.winning_main,(1,2,3,4,5,6,7))

    def test_no_contents_in_parser_errors(self):
        page=synthetic_oz_page(1474,main=(1,2,3,4,5,6,48))
        with self.assertRaises(ValueError) as e:
            parse_ozlotto_official_draw_html(page,expected_draw=1474)
        self.assertNotIn('48',str(e.exception))
        self.assertNotIn('1474',str(e.exception))

    def test_powerball_legacy_archive_adapter(self):
        html='''<html><body><ol><li><a href="/australia/results/2018-04-19/">View</a>
           <span>Draw 1144 1 2 3 4 5 6 7 8</span></li></ol></body></html>'''
        out=parse_powerball_archive_html(html,year=2018)
        self.assertEqual(len(out),1)
        self.assertEqual(out[0].draw_number,1144)
        self.assertEqual(out[0].winning_main,(1,2,3,4,5,6,7))
        self.assertEqual(out[0].powerball,8)
        win,raw=canonical_csv_rows('POWERBALL',out)
        self.assertEqual(win,raw)
        self.assertEqual(len(win[0]),10)

    def test_offline_pipeline_pair_audit_and_no_supp_leak(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            pages={n:synthetic_oz_page(n,main=(7,3,2,4,1,6,5),supp=(10,8,9))
                   for n in range(1474,1488)}
            rec=publish_offline_html_fixture(profile=OZLOTTO,html_pages=pages,
                   run_root=root/'synthetic',run_id='fixture0001')
            self.assertEqual(rec['row_count'],14)
            self.assertEqual(rec['game_id'],'OZLOTTO')
            self.assertEqual(rec['accepted_as_real_scientific_source'],False)
            directory=root/'synthetic'/'OZLOTTO'/'fixture0001'
            self.assertEqual(json.loads((directory/'snapshot_record.json').read_text()) ,rec)
            win=directory/rec['winning_file'];raw=directory/rec['raw_file']
            report=audit_snapshot_pair(win,raw,OZLOTTO)
            self.assertTrue(report['structurally_accepted'],report)
            with win.open(newline='') as f:
                r=list(csv.reader(f))
            self.assertEqual(len(r[1]),9)
            self.assertEqual(r[1][2:],['1','2','3','4','5','6','7'])
            with raw.open(newline='') as f:
                rr=list(csv.reader(f))
            self.assertEqual(rr[1][-3:],['10','8','9'])
            with self.assertRaises(FileExistsError):
                publish_offline_html_fixture(profile=OZLOTTO,html_pages=pages,
                       run_root=root/'synthetic',run_id='fixture0001')

    def test_recorded_date_anomaly_audit_warns(self):
        from datetime import date
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            pages={n:synthetic_oz_page(n) for n in range(1474,1488)}
            pages[1476]=synthetic_oz_page(1476,page_date=date(2022,6,2))
            rec=publish_offline_html_fixture(profile=OZLOTTO,html_pages=pages,
                  run_root=root,run_id='fixture0002')
            self.assertEqual(rec['date_warning_count'],1)

    def test_first_drawoffset_or_gap_refused_without_publication(self):
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            pages={n:synthetic_oz_page(n) for n in range(1474,1488)}
            del pages[1478]
            with self.assertRaises(ValueError):
                publish_offline_html_fixture(profile=OZLOTTO,html_pages=pages,
                      run_root=root,run_id='fixture0003')
            self.assertFalse((root/'OZLOTTO'/'fixture0003').exists())

    def test_oversize_refusal(self):
        with self.assertRaises(ValueError):
            parse_ozlotto_official_draw_html('x'*1_000_001,expected_draw=1474)

    def test_bounded_offline_fetch_plans(self):
        from _common.multigame_source_plan_v1 import source_plan
        oz=source_plan('OZLOTTO',last_draw=1475)
        self.assertEqual([p.key for p in oz],[1474,1475])
        self.assertEqual(oz[0].url,'https://www.oz.lotterywest.com/oz-lotto/results/draw/1474')
        pb=source_plan('POWERBALL',last_year=2019)
        self.assertEqual([p.key for p in pb],[2018,2019])
        self.assertEqual(pb[0].url,'https://www.powerball.net/australia/archive/2018')
        for bad in [("OZLOTTO",{'last_draw':1473}),('OZLOTTO',{'last_draw':None}),
                    ('OZLOTTO',{'last_year':2026}),('POWERBALL',{'last_draw':1500}),
                    ('POWERBALL',{'last_year':2017}),('UNKNOWN',{'last_draw':1})]:
            with self.subTest(bad=bad),self.assertRaises(ValueError):
                source_plan(bad[0],**bad[1])

    def test_no_network_and_no_live_selection_in_pipeline(self):
        import inspect
        import _common.multigame_offline_source_pipeline_v1 as pipeline
        self.assertNotIn('requests.',inspect.getsource(pipeline))
        self.assertNotIn('urllib.request',inspect.getsource(pipeline))
        self.assertNotIn('socket.',inspect.getsource(pipeline))


if __name__=='__main__':unittest.main()
