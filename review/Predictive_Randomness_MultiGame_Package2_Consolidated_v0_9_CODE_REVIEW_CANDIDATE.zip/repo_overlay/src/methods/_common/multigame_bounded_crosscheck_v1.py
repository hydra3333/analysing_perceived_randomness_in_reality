"""OFFLINE source-to-source consistency checks, returning NO draw values.

Two independent source streams of OfflineDraw values may contain held-out
results. Nothing from those values is logged, repr'd, or placed into the
returned report. This is a privileged auditor, NEVER a method loader.
No HTTP, filesystem, or scientific selection occurs here.
"""
from __future__ import annotations

from collections.abc import Iterable
from typing import Any

from _common.game_profiles_v1 import GameProfile
from _common.multigame_offline_source_adapters_v1 import OfflineDraw


_ALLOWED_SOURCES = frozenset({
    'LOTTERYWEST_RESULTS', 'POWERBALL_NET_ARCHIVE', 'LOTTODRAW_ARCHIVE',
})


def compare_source_draws(*, profile: GameProfile,
                         primary_source: str, secondary_source: str,
                         primary: Iterable[OfflineDraw],
                         secondary: Iterable[OfflineDraw],
                         through_draw: int) -> dict[str, Any]:
    """Fail closed on incomplete data and compare numbers only in memory.

    Source-id separation is necessary, but does not prove upstream independence.
    Order agreement is reported separately from winning set agreement; this
    method cannot establish physical draw order merely from matching sources.
    """
    if (primary_source not in _ALLOWED_SOURCES or secondary_source not in _ALLOWED_SOURCES or
            primary_source == secondary_source):
        raise ValueError('distinct approved publication sources required')
    if (type(through_draw) is not int or through_draw < profile.first_draw or
            through_draw - profile.first_draw + 1 > 10_000):
        raise ValueError('invalid bounded draw range')
    a, b = list(primary), list(secondary)
    if len(a) > 10_000 or len(b) > 10_000:
        raise ValueError('too many source draws')

    # Collect only non-sensitive field labels; never echo malformed row values.
    errors: list[dict] = []
    def mapped(draws: list[OfflineDraw], side: str) -> dict[int, OfflineDraw]:
        out = {}
        for obj in draws:
            if (not isinstance(obj, OfflineDraw) or obj.game_id != profile.game_id or
                    type(obj.draw_number) is not int or
                    not profile.first_draw <= obj.draw_number <= through_draw):
                errors.append({'draw_number':None,'field':side+'_DRAW_ID','issue':'INVALID'})
                continue
            n = obj.draw_number
            if n in out:
                errors.append({'draw_number':n,'field':side+'_DRAW_ID','issue':'DUPLICATE'})
            out[n] = obj
        return out
    left, right = mapped(a, 'PRIMARY'), mapped(b, 'SECONDARY')
    matched = 0
    order_agreed = 0
    order_warnings: list[dict] = []
    for number in range(profile.first_draw, through_draw + 1):
        x, y = left.get(number), right.get(number)
        if x is None or y is None:
            errors.append({'draw_number':number,'field':'DRAW_ID','issue':'MISSING_SOURCE_DRAW'})
            continue
        matched += 1
        if x.recorded_date != y.recorded_date:
            errors.append({'draw_number':number,'field':'DATE','issue':'PUBLISHERS_DISAGREE'})
        main = profile.barrels[0]
        if not (len(x.winning_main) == len(y.winning_main) == main.selected and
                len(set(x.winning_main)) == len(set(y.winning_main)) == main.selected and
                all(type(v) is int and main.low <= v <= main.high
                    for v in x.winning_main + y.winning_main)):
            errors.append({'draw_number':number,'field':'MAIN','issue':'INVALID_SELECTION'})
        elif set(x.winning_main) != set(y.winning_main):
            errors.append({'draw_number':number,'field':'MAIN','issue':'PUBLISHERS_DISAGREE'})
        else:
            if x.winning_main == y.winning_main:
                order_agreed += 1
            else:
                # An ascending archive and a drawn-order publication can
                # represent the SAME winning set. Never reject the numbers
                # merely because sequence conventions differ.
                order_warnings.append({'draw_number':number,'field':'MAIN_ORDER',
                                       'issue':'SOURCE_SEQUENCES_DISAGREE'})
        if profile.game_id == 'OZLOTTO':
            if (len(x.supplementary) != 3 or len(y.supplementary) != 3 or
                    len(set(x.supplementary)) != 3 or len(set(y.supplementary)) != 3 or
                    set(x.supplementary).intersection(x.winning_main) or
                    set(y.supplementary).intersection(y.winning_main) or
                    any(type(v) is not int or not 1 <= v <= 47
                        for v in x.supplementary + y.supplementary)):
                errors.append({'draw_number':number,'field':'SUPPLEMENTARY','issue':'INVALID_SELECTION'})
            elif set(x.supplementary) != set(y.supplementary):
                errors.append({'draw_number':number,'field':'SUPPLEMENTARY',
                               'issue':'PUBLISHERS_DISAGREE'})
            elif x.supplementary != y.supplementary:
                order_warnings.append({'draw_number':number,'field':'SUPPLEMENTARY_ORDER',
                                       'issue':'SOURCE_SEQUENCES_DISAGREE'})
            if x.powerball is not None or y.powerball is not None:
                errors.append({'draw_number':number,'field':'POWERBALL', 'issue':'UNEXPECTED'})
        elif (type(x.powerball) is not int or type(y.powerball) is not int or
              not 1 <= x.powerball <= 20 or not 1 <= y.powerball <= 20 or
              x.powerball != y.powerball or x.supplementary or y.supplementary):
            errors.append({'draw_number':number,'field':'POWERBALL','issue':'PUBLISHERS_DISAGREE_OR_INVALID'})
    # NO disclosure of any ball number or unexpected object representation.
    return {'schema':'MULTIGAME_CROSS_SOURCE_AUDIT_V1',
            'game_id': profile.game_id,
            'first_draw': profile.first_draw, 'last_draw': through_draw,
            'primary_source': primary_source, 'secondary_source': secondary_source,
            'draws_compared':matched, 'error_count':len(errors),
            'fully_agreed':not errors,
            'sequence_agreement_count':order_agreed,
            'source_order_check':'AGREED' if not errors and not order_warnings and order_agreed == matched else 'UNVERIFIED',
            'order_warning_count':len(order_warnings),
            'order_warnings':order_warnings[:100],
            'physical_draw_order_proven':False,
            'errors':errors[:100]}
