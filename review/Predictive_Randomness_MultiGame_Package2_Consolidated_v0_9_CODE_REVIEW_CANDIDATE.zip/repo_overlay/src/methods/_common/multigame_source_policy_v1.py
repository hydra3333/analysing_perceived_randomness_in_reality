"""OFFLINE source access-policy evaluation; NO HTTP or browser operations.

A future network client must fetch robots.txt without bypassing protections,
fail closed when it cannot prove the policy, and re-check on each collection.
This module validates externally supplied policy BYTES, not network access.
"""
from __future__ import annotations

from dataclasses import dataclass
import hashlib
from urllib.parse import urlsplit
from urllib.robotparser import RobotFileParser

_ALLOWED_HOSTS = {
    'LOTTERYWEST_RESULTS': 'www.oz.lotterywest.com',
    'POWERBALL_NET_ARCHIVE': 'www.powerball.net',
    'LOTTODRAW_ARCHIVE': 'lottodraw.com.au',
}
_MAX_ROBOTS_BYTES = 100_000
_MAX_URL_LENGTH = 400


@dataclass(frozen=True)
class PolicyDecision:
    source_id: str
    robots_sha256: str
    request_allowed: bool
    reason: str


def policy_for_offline_robots(*, source_id: str, page_url: str,
                              robots_url: str, robots_bytes: bytes | None,
                              user_agent: str) -> PolicyDecision:
    """Fail-closed decision for exact origin, using supplied robots bytes.

    Successful fetch, current origin and truthful UA remain the caller's
    responsibilities. Does not assert legal permissions from robots alone.
    """
    host = _ALLOWED_HOSTS.get(source_id)
    if host is None or not user_agent or len(user_agent) > 160 or '\n' in user_agent:
        raise ValueError('unapproved source or user agent')
    for url in (page_url, robots_url):
        if not isinstance(url, str) or len(url) > _MAX_URL_LENGTH:
            raise ValueError('invalid source URL')
        p = urlsplit(url)
        if (p.scheme != 'https' or p.hostname != host or p.username is not None or
                p.password is not None or p.port not in (None, 443) or
                p.fragment or not p.path.startswith('/') or '\\' in url):
            raise ValueError('URL does not match approved HTTPS origin')
    if urlsplit(robots_url).path != '/robots.txt' or urlsplit(robots_url).query:
        raise ValueError('policy bytes not linked to origin robots.txt')
    if robots_bytes is None:
        return PolicyDecision(source_id, '', False, 'ROBOTS_UNAVAILABLE')
    if type(robots_bytes) is not bytes or len(robots_bytes) > _MAX_ROBOTS_BYTES:
        raise ValueError('invalid or oversized robots.txt')
    digest = hashlib.sha256(robots_bytes).hexdigest()
    try:
        text = robots_bytes.decode('utf-8-sig', errors='strict')
        if not text.strip():
            return PolicyDecision(source_id, digest, False, 'ROBOTS_EMPTY')
        parser = RobotFileParser()
        parser.parse(text.splitlines())
        # A website without applicable policy is not automatically approved.
        if not parser.default_entry and not parser.entries:
            return PolicyDecision(source_id, digest, False, 'ROBOTS_NO_RULES')
        permitted = parser.can_fetch(user_agent, page_url)
    except (ValueError, UnicodeError):
        return PolicyDecision(source_id, digest, False, 'ROBOTS_INVALID')
    return PolicyDecision(source_id, digest, permitted,
                          'ROBOTS_ALLOWED' if permitted else 'ROBOTS_DISALLOWED')
