"""Offline HTML-to-row source adapters; NO network operations or live scrape.

Oz parser targets the labelled Main Numbers / Supplementary sections on an
individual operator-style results page. Actual live DOM conformity remains
TO-VERIFY at a separately owner-authorised source review/intake gate.

Powerball adapter delegates archive parsing to the pre-existing v0.3 scraper;
therefore it does not replace or silently reinterpret existing draw-order data.
These adapters return PRIVATE drawn values to the bounded publisher, never to
public audit or log output.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date, datetime
import re
from typing import Iterable

from bs4 import BeautifulSoup

from _common.game_profiles_v1 import OZLOTTO, POWERBALL

_MAX_HTML = 1_000_000
_DRAW_ID = re.compile(r"\bDraw\s+(\d{4,9})\b", re.IGNORECASE)
_DATE = re.compile(
    r"\b(\d{1,2})\s+(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{4})\b",
    re.IGNORECASE,
)
_NUMBER_GROUP = re.compile(r"[0-9]{1,2}(?:\s+[0-9]{1,2})*\Z", re.ASCII)


@dataclass(frozen=True)
class OfflineDraw:
    game_id: str
    draw_number: int
    recorded_date: date
    winning_main: tuple[int, ...]
    supplementary: tuple[int, ...] = ()
    powerball: int | None = None


def _section_numbers(tokens: list[str], *, expected_count: int) -> tuple[int, ...]:
    numbers: list[int] = []
    for chunk in tokens:
        txt = " ".join(chunk.split())
        if not _NUMBER_GROUP.fullmatch(txt):
            raise ValueError("unexpected token in numbered result section")
        numbers.extend(int(part) for part in txt.split())
        if len(numbers) > expected_count:
            raise ValueError("too many labels in numbered result section")
    if len(numbers) != expected_count:
        raise ValueError("wrong number of labels in result section")
    return tuple(numbers)


def parse_ozlotto_official_draw_html(html: str, *, expected_draw: int) -> OfflineDraw:
    """Extract ONLY the exact requested draw from a supplied offline HTML string.

    Fixed errors intentionally disclose no ball values. Never fetch a URL.
    Year/name of the game, draw id and labelled sections are mandatory.
    """
    if type(html) is not str or len(html.encode("utf-8")) > _MAX_HTML:
        raise ValueError("offline HTML source missing or oversized")
    if type(expected_draw) is not int or expected_draw < OZLOTTO.first_draw:
        raise ValueError("requested draw outside current Oz Lotto era")
    soup = BeautifulSoup(html, "html.parser")
    for item in soup(["script", "style", "noscript"]):
        item.decompose()
    tokens = list(soup.stripped_strings)
    if len(tokens) > 4000:
        raise ValueError("offline HTML contains too many text tokens")
    headings = [i for i, t in enumerate(tokens) if t.strip().casefold() == "main numbers"]
    supplementaries = [i for i, t in enumerate(tokens) if t.strip().casefold() == "supplementary"]
    if len(headings) != 1 or len(supplementaries) != 1:
        raise ValueError("main/supplementary labels are not unique")
    first, second = headings[0], supplementaries[0]
    if first >= second or second - first > 20:
        raise ValueError("misordered or overly broad numbered sections")
    # Draw and date are taken from the result header, not the footer's next
    # draw/navigation labels. Their exact values are checked separately.
    prefix = " ".join(tokens[:first])
    if "oz lotto" not in prefix.casefold().replace("-", " "):
        raise ValueError("not identified as Oz Lotto result page")
    draw_matches = list(_DRAW_ID.finditer(prefix))
    if not draw_matches or int(draw_matches[-1].group(1)) != expected_draw:
        raise ValueError("wrong or missing page draw identity")
    dates = list(_DATE.finditer(prefix[:draw_matches[-1].start()]))
    if not dates:
        raise ValueError("result has no recorded draw date")
    match = dates[-1]
    try:
        recorded = datetime.strptime(" ".join(match.groups()), "%d %B %Y").date()
    except ValueError as exc:
        raise ValueError("invalid recorded draw date") from exc
    # Do not force weekly date equality here: the bounded audit reports
    # discrepancies as metadata warnings, not structural rejections.
    main = _section_numbers(tokens[first + 1:second], expected_count=7)
    following: list[str] = []
    for token in tokens[second + 1:]:
        normalized = " ".join(token.split())
        if not _NUMBER_GROUP.fullmatch(normalized):
            break
        following.append(token)
        if len(following) > 3:
            raise ValueError("too many supplementary labels")
    sup = _section_numbers(following, expected_count=3)
    if (len(set(main)) != 7 or len(set(sup)) != 3 or
            not all(1 <= n <= 47 for n in main + sup) or set(main).intersection(sup)):
        raise ValueError("invalid or duplicated Oz Lotto labels")
    return OfflineDraw("OZLOTTO", expected_draw, recorded, main, sup)


def parse_powerball_archive_html(html: str, *, year: int) -> tuple[OfflineDraw, ...]:
    """Reuse the original accepted Powerball 2018+ archive parser offline.

    This is not an official drawn-order parser. Its archive results are treated
    as unordered sorted MAIN with one POWERBALL label.
    """
    if type(html) is not str or len(html.encode("utf-8")) > _MAX_HTML:
        raise ValueError("offline Powerball archive missing or oversized")
    if type(year) is not int or not 2018 <= year <= 2200:
        raise ValueError("invalid Powerball archive year")
    from scrape_australian_powerball_history_from_2018_04_19_v0_3 import parse_archive

    seen: set[int] = set()
    rows = []
    for item in parse_archive(html, year):
        n, d, *labels = item
        if n in seen or n < POWERBALL.first_draw:
            raise ValueError("duplicate or out-of-era Powerball archive draw")
        seen.add(n)
        rows.append(OfflineDraw("POWERBALL", n, d, tuple(labels[:7]), (), labels[7]))
    return tuple(sorted(rows, key=lambda r: r.draw_number))


def canonical_csv_rows(profile_game: str, draws: Iterable[OfflineDraw]) -> tuple[list[list[str | int]], list[list[str | int]]]:
    """Pure shape conversion; no URLs, filesystem or public value logging."""
    if profile_game not in ("POWERBALL", "OZLOTTO"):
        raise ValueError("unsupported game")
    rows = []
    raw_rows = []
    seen: set[int] = set()
    for draw in draws:
        if draw.game_id != profile_game or draw.draw_number in seen:
            raise ValueError("mixed/duplicate game or draw")
        seen.add(draw.draw_number)
        base = [draw.draw_number, draw.recorded_date.isoformat(), *sorted(draw.winning_main)]
        if profile_game == "POWERBALL":
            if (len(draw.winning_main) != 7 or draw.supplementary or
                    draw.powerball is None or not 1 <= draw.powerball <= 20):
                raise ValueError("invalid Powerball adapter row")
            base.append(draw.powerball)
            raw = list(base)  # Archive contains sorted mains; no invented drawn order.
        else:
            if draw.powerball is not None or len(draw.winning_main) != 7 or len(draw.supplementary) != 3:
                raise ValueError("invalid Oz Lotto adapter row")
            raw = list(base) + list(draw.supplementary)
        rows.append(base)
        raw_rows.append(raw)
    rows_with_raw = sorted(zip(rows, raw_rows), key=lambda x: x[0][0])
    return [r for r, _ in rows_with_raw], [r for _, r in rows_with_raw]
