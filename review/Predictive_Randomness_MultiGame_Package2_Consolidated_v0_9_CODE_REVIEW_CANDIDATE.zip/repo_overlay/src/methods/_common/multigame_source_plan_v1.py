"""Pure approved-endpoint enumeration for a future scraper; NO HTTP I/O.

The first live acquisition needs a separate owner Package-3 go-ahead.
No claim is made that an endpoint will remain stable or that pages will
pass parsing: this is a strictly reviewable fetch PLAN, not a downloader.
"""
from __future__ import annotations

from dataclasses import dataclass
from datetime import date

from _common.game_profiles_v1 import OZLOTTO, POWERBALL


@dataclass(frozen=True)
class SourcePage:
    game_id: str
    source_type: str
    key: int
    url: str


def source_plan(game_id: str, *, last_draw: int | None = None,
                last_year: int | None = None, source_id: str | None = None) -> tuple[SourcePage, ...]:
    """Bounded caller-selected scope: no inference from live site content.

    One of last_draw/last_year is mandatory according to game. No live web
    request, no source-data open, no holdout inspection, no predictions.
    """
    if game_id == 'OZLOTTO':
        if source_id not in (None, 'LOTTERYWEST_RESULTS'):
            raise ValueError('unsupported Oz Lotto source')
        if last_year is not None or type(last_draw) is not int or not OZLOTTO.first_draw <= last_draw <= 999999:
            raise ValueError('explicit bounded Oz Lotto last_draw required')
        if last_draw - OZLOTTO.first_draw + 1 > 10_000:
            raise ValueError('source plan exceeds bound')
        return tuple(SourcePage('OZLOTTO', 'LOTTERYWEST_OFFICIAL_DRAW_PAGE_V1',n,
            f'https://www.oz.lotterywest.com/oz-lotto/results/draw/{n}')
            for n in range(OZLOTTO.first_draw,last_draw + 1))
    if game_id == 'POWERBALL' and source_id == 'LOTTERYWEST_RESULTS':
        if last_year is not None or type(last_draw) is not int or not POWERBALL.first_draw <= last_draw <= 999999:
            raise ValueError('explicit bounded Powerball drawn-order scope required')
        if last_draw - POWERBALL.first_draw + 1 > 10_000:
            raise ValueError('source plan exceeds bound')
        return tuple(SourcePage('POWERBALL', 'LOTTERYWEST_OFFICIAL_DRAW_PAGE_V1', n,
            f'https://www.oz.lotterywest.com/powerball/results/draw/{n}')
            for n in range(POWERBALL.first_draw, last_draw + 1))
    if game_id == 'POWERBALL':
        if source_id not in (None, 'POWERBALL_NET_ARCHIVE'):
            raise ValueError('unsupported Powerball source')
        if last_draw is not None or type(last_year) is not int or not 2018 <= last_year <= 2200:
            raise ValueError('explicit Powerball last_year required')
        return tuple(SourcePage('POWERBALL', 'POWERBALL_NET_YEAR_ARCHIVE_V03',year,
            f'https://www.powerball.net/australia/archive/{year}')
            for year in range(2018,last_year + 1))
    raise ValueError('unsupported game_id')
