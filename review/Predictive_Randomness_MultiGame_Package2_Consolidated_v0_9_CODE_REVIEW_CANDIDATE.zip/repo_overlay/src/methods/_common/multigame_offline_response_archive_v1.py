"""Create-only, offline response capture for SYNTHETIC pages (Package 2).

This is a provenance *prototype*: no network, real-source datasets, scraper
activation, result outputs or holdout access. Stored source pages are explicitly
synthetic and never meant for the public repository or a scientific view.

Future verified network acquisition must revalidate source policy and supply
real acquisition timestamps itself; this module never manufactures them.
"""
from __future__ import annotations

import hashlib
import json
import os
from pathlib import Path
import re
from typing import Mapping, Sequence
from urllib.parse import urlsplit

from _common.multigame_source_plan_v1 import SourcePage

_SAFE_ID = re.compile(r"[a-z0-9][a-z0-9_-]{7,95}\Z", re.ASCII)
_MAX_PAGE_BYTES = 1_000_000
_MAX_PAGES = 10_000
_ALLOWED_ORIGINS = frozenset({
    'www.oz.lotterywest.com', 'www.powerball.net',
})


def _create_new_file(path: Path, content: bytes) -> None:
    with path.open('xb') as f:
        f.write(content)
        f.flush()
        os.fsync(f.fileno())


def archive_synthetic_responses(*, game_id: str, source_pages: Sequence[SourcePage],
                                page_bodies: Mapping[int, bytes], root: Path,
                                run_id: str, robots_sha256: str) -> dict:
    """Record an exact plan + bytes without disclosing content in the report.

    No absolute or arbitrary URL is trusted without approved source-page
    location and source type. No parent directory is replaced or overwritten.
    Returns a metadata-only record, suitable for a separate provenance review.
    """
    if game_id not in {'POWERBALL', 'OZLOTTO'}:
        raise ValueError('unsupported game')
    if not isinstance(root, Path) or not _SAFE_ID.fullmatch(run_id):
        raise ValueError('invalid archive root or run ID')
    if (not isinstance(robots_sha256, str) or
            not re.fullmatch(r'[0-9a-f]{64}', robots_sha256, re.ASCII)):
        raise ValueError('missing or invalid approved robots.txt digest')
    if not (0 < len(source_pages) <= _MAX_PAGES) or len(page_bodies) != len(source_pages):
        raise ValueError('missing or excessive offline source pages')
    seen: set[int] = set()
    payloads: list[tuple[SourcePage, bytes, str]] = []
    for p in source_pages:
        if not isinstance(p, SourcePage) or p.game_id != game_id or type(p.key) is not int or p.key in seen:
            raise ValueError('duplicated or mixed source page')
        seen.add(p.key)
        parsed = urlsplit(p.url)
        if (parsed.scheme != 'https' or parsed.hostname not in _ALLOWED_ORIGINS or
                parsed.username is not None or parsed.password is not None or
                parsed.port not in (None, 443) or parsed.query or parsed.fragment):
            raise ValueError('unapproved source origin')
        # Only exact source-plan URLs are accepted, not caller-crafted paths.
        if p.source_type == 'LOTTERYWEST_OFFICIAL_DRAW_PAGE_V1':
            slug = 'oz-lotto' if game_id == 'OZLOTTO' else 'powerball'
            expected = f'https://www.oz.lotterywest.com/{slug}/results/draw/{p.key}'
        elif p.source_type == 'POWERBALL_NET_YEAR_ARCHIVE_V03' and game_id == 'POWERBALL':
            expected = f'https://www.powerball.net/australia/archive/{p.key}'
        else:
            raise ValueError('unknown source page type')
        if p.url != expected:
            raise ValueError('unapproved source URL')
        b = page_bodies.get(p.key)
        if type(b) is not bytes or not 0 < len(b) <= _MAX_PAGE_BYTES:
            raise ValueError('invalid offline response body')
        payloads.append((p, b, hashlib.sha256(b).hexdigest()))
    if seen != set(page_bodies):
        raise ValueError('source response keys do not match plan')

    # Archive contains no real draw data and is kept separately from the
    # science-selected source_data area. Existing records are never replaced.
    dst = root / 'SYNTHETIC_ONLY' / game_id / run_id
    dst.mkdir(parents=True, exist_ok=False)
    records = []
    for i, (p, raw, digest) in enumerate(payloads):
        name = f'page_{i:05d}.html'
        _create_new_file(dst / name, raw)
        records.append({'key': p.key, 'source_type': p.source_type, 'url': p.url,
                        'relative_file': name, 'sha256': digest, 'byte_length': len(raw)})
    record = {'schema': 'MULTIGAME_SYNTHETIC_RAW_RESPONSE_ARCHIVE_V1',
              'game_id': game_id, 'run_id': run_id,
              'kind': 'SYNTHETIC_FIXTURE_ONLY',
              'robots_sha256': robots_sha256, 'page_count': len(records),
              'retrieved_at_utc': None, 'science_usable': False,
              'pages': records}
    data = (json.dumps(record, sort_keys=True, separators=(',', ':')) + '\n').encode('ascii')
    _create_new_file(dst / 'response_manifest.json', data)
    return record
