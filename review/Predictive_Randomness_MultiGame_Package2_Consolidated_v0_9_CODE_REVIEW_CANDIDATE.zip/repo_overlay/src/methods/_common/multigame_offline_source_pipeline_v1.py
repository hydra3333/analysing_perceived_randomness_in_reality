"""Offline HTML-fixture -> bounded audit -> create-only synthetic snapshots.

NO HTTP client, NO real game source access, NO selection for training,
NO holdout sealing, NO forecast generation. This module is a Package-2
implementation/test component, not an authorised data-collection utility.
"""
from __future__ import annotations

import csv
import tempfile
from pathlib import Path
from typing import Mapping

from _common.game_profiles_v1 import GameProfile
from _common.multigame_offline_source_adapters_v1 import (
    canonical_csv_rows, parse_ozlotto_official_draw_html,
    parse_powerball_archive_html,
)
from _common.multigame_snapshot_publish_v1 import publish_synthetic_pair
from _common.multigame_structural_audit_v1 import raw_columns_for
from _common.multigame_u_view_v1 import columns_for


def _write_fixture(path: Path, columns: tuple[str, ...], rows: list[list[str | int]]) -> None:
    with path.open('x', newline='', encoding='utf-8') as f:
        writer = csv.writer(f, lineterminator='\n')
        writer.writerow(columns)
        writer.writerows(rows)


def publish_offline_html_fixture(*, profile: GameProfile, html_pages: Mapping[int, str],
                                 run_root: Path, run_id: str) -> dict:
    """Entire pipeline is in-memory/offline except isolated temp and run-root files.

    Parsed pages MUST represent the complete current era from its first draw,
    because the audit forbids holes. Never pass an actual trusted-source path:
    fixture source material is not production input and the published record
    remains SYNTHETIC_ONLY.
    """
    if not html_pages or len(html_pages) > 10_000:
        raise ValueError('offline fixture page set missing or too large')
    if not isinstance(run_root, Path):
        raise ValueError('run root must be a Path')
    if profile.game_id == 'OZLOTTO':
        draws = [parse_ozlotto_official_draw_html(html, expected_draw=n)
                 for n, html in sorted(html_pages.items())]
    elif profile.game_id == 'POWERBALL':
        draws = []
        for year, html in sorted(html_pages.items()):
            draws.extend(parse_powerball_archive_html(html, year=year))
    else:
        raise ValueError('unsupported game')
    winning, raw = canonical_csv_rows(profile.game_id, draws)
    # Holdout audit only occurs in isolated synthetic fixture namespace here.
    with tempfile.TemporaryDirectory(prefix='mg_offline_html_fixture_') as tmp:
        work = Path(tmp)
        winning_csv = work / 'winning_fixture.csv'
        raw_csv = work / 'raw_fixture.csv'
        _write_fixture(winning_csv, columns_for(profile), winning)
        _write_fixture(raw_csv, raw_columns_for(profile), raw)
        return publish_synthetic_pair(winning_fixture=winning_csv,
                                      raw_fixture=raw_csv, profile=profile,
                                      run_root=run_root, run_id=run_id)
