# Predictive Randomness — Document Tree Impact Assessment v0.2

**Date:** 25 October 2026. **Revision:** v0.2 (supersedes v0.1 assessment). **Status:** assessment and ratification-candidate planning, **not** document ratification, code execution authority or a complete checkout audit. **Basis:** seven previously ratified Package 1 files; earlier repository snapshot document tree; Claude's current 25 October v3 review. Live `doc/` directory listing was not fully retrievable; validate `git ls-files doc` and original-file hashes against the latest HEAD before installation. No direct inspection of the currently committed Oz Lotto master/ledger bytes has occurred in this analysis.

## Executive findings and recommended precedence

Eight **candidate** documents accompany this assessment (five versioned normative successors, a register candidate, two new focused records), plus a new ChatGPT continuity handover. New provisions use `§0B` or `ERR-R2-06` to supersede conflicting historical narratives **only after owner ratification**. Retain old ratified files byte-identical. No mass rewrite of E-method mathematics or R1 research history.

| Priority | Current `doc/` file(s) / family | Risk of leaving stale | Proposed action |
|---|---|---|---|
| Critical | `Predictive_Randomness_Research_Project_Proposal_v0_4.md` | Old 1578/1695 holdouts, old snapshot/scraper, old access assumptions; charter precedence | Candidate **v0.5** new §0B: 1 Aug boundary, pinned masters, acquisition already done, approved upgrade and normal refit principles; ratify first |
| Critical | `Predictive_Randomness_R2_v0_3_Erratum_Record_v0_3.md` | Old sealer, method/view registry and loader assumptions inconsistent with N−1 safety; too-easy accidental suffix access | Candidate **v0.4 / ERR-R2-06**: byte-owning read views, ledger SHA/prefix filter, representation choice, opt-in dates and digest, holdout forecast-only exception; ratify after charter |
| Critical | `Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_3.md` | Wrong first ten, ambiguity about forecast 1577 and later Mode H | Candidate **v0.4** new §0B: precise first ten, forecast-only golden, no Mode H access and no whole-master hash in seed |
| Critical | `Predictive_Randomness_Software_Architecture_Discussion_v0_6.md` | Old `Run_Scraper.bat`, dual/snapshot CSVs, pending Oz seal, date/time assumptions, duplicate entitlement; installer prior default; safety may be obscured | Candidate **v0.7**, complete document preserving §5C safety; new §0B masters/ledgers, source, reader boundary and copy, human-speed polling, upgrade default and review gates |
| High | `Predictive_Randomness_MultiGame_Infrastructure_P3_Task_Specification_v0_1.md` | Asks to scrape/DEV_BUILD and seal Oz although masters already INIT and owner has moved boundaries | Candidate **v0.2**: acquisition DONE; ChatGPT v0.11 delta review next; actual Windows tests, Mode H and FINAL separately gated |
| High | `RATIFICATION_REGISTER_v0_2.md` | New decisions not indexed; could mistake a decision for a ratified document | Candidate **v0.3** lists pending new versions clearly; verify source hashes against current Git HEAD; fill final SHA table after owner ratification |
| High | None — new `HOLDOUT_EXPOSURE_RECORD_v0_1.md` | Reviewer exposure and superseded files/commit could be forgotten; unsound assurance of no effect | New **value-free factual record**, with neither numbers nor claims about influence; ratify/approve as provenance, not a test |
| High | None — new `NUMERICAL_INTEGRITY_AND_RETRAINING_POLICY_v0_1.md` | Owner upgrade/precision/refitting philosophy may otherwise be misapplied to 62 methods | New narrowly scoped **candidate**; type choices, stable algorithms, version evidence, N−1 refit, selective intermediate retention; method-specific formulas stay separately governed |
| Maintain | `Predictive_Randomness_Experimental_Methods_Research_R1_v0_4.md` | Risk of accidental changes to 62 hypotheses | **Do not edit**. Use in numerical/method implementation review; new E_63 still separate owner decision |
| Maintain | `Predictive_Randomness_Experimental_Method_Specifications_R2_v0_3.md` | Body historical, but contract authority retained | **Do not edit**; use ratified errata rather than rewriting original |
| Maintain | `doc/contracts/TIE_SHA256_V1_Ratified_Encoding_v0_2.md` | Bitwise tie identity may be damaged by well-meant cleanup | **Do not edit**. E_1 goldens remain frozen |
| Maintain | `Predictive_Randomness_Windows_POC_Implementation_Task_Specification_v0_2.md` (if installed) and historical v0.1 | P0–P2 original scope and historical evidence | **Leave historical**, add a supersession pointer in current P3 / Architecture only |
| Maintain | `doc/HANDOVER/` and any root `Claude_Reviewer_Handover_*` | Multiple superseded operational handovers lead to old orphan-marker/run-state assumptions | New ChatGPT v0.6 handover; Claude updating its own. Keep old files labelled historical; no forced deletion or mass rename |
| Maintain | Proposal v0.3; R2 approved erratum v0.2; R3 v0.1/v0.2; Architecture v0.2/v0.3/v0.4/v0.5; older review evidence | Historical decisions/test provenance | **Preserve byte-for-byte**, document supersession in current register instead of editing |
| Related outside `doc/` | `README.md`, `requirements.txt`, `.gitignore`, `.gitattributes`, root batch wrappers | They may still describe abandoned scraper/installer pattern; source_data line-endings and secrets protection matter | **Separate code/repository follow-up** after v0.11 review; do not quietly modify source in documentation ZIP |

## Cross-document conflicts for Claude to inspect

1. The exact master names, current ledger schemas and `INIT` hashes must be cross-checked in HEAD; only the Powerball master SHA was provided in full in Claude v3.
2. Ratified v0.6 §§5C.2–5C.3 process-safety content must remain byte-identical in the new architecture candidate. The new polling diff does **not** permit kill/ownership/orphan logic changes.
3. Reader C1/C2 are **unfixed in installed code** as of Claude v3; document them as **requirements/no-go**, not a successfully implemented feature. The candidate Package 2 v0.11 must be independently reviewed first.
4. Whole-master identity SHA cannot become a fit/readout seed when the master later grows. Each scientific view digest is based on the allowed prefix.
5. The owner decided against duplicated per-method reader entitlements but **not** against per-method mathematical review or the scientific-result consumer allowlist.
6. Published order is assumed, never labelled physically verified; current ISO dates do not imply known draw time or timezone.
7. `results_master update` and `HOLDOUT_OPENED_*` have explicit future gates; Phase H storage/opening design is **proposed**, not ratified now.
8. The owner expressly approved dependency auto-upgrade; post-upgrade numerical regression is prudent, but changing a library must not silently rewrite frozen forecast identities.

## Recommended ratification/installation order

Charter v0.5 → R2 erratum v0.4 and R3 v0.4 → Architecture v0.7 and P3 v0.2 → numerical policy and value-free exposure record → register v0.3. Claude independent review first, owner ratification second, commit/install third. Package 2 code v0.11 is a **separate** review and gate. No Mode H, FINAL, Windows synthetic execution, source-data updates or holdout reads are approved by this document set.


## Addendum v0.2 — owner-decided numerical width, upgrades and scratch-refit rule

- **No compact internal types:** all numeric integer fields in **both the internal development table and returned scientific views** are `numpy.int64`; floating fields are `numpy.float64`. `int8`/`int32` are *not* accepted as ball-storage shortcuts. Date columns remain ISO date / `datetime64[D]`; plain lists contain Python `int`. Overflow beyond signed int64 requires Python big ints or a reviewed exact method. This supersedes the prior assessment's implicit tolerance of compact storage.
- **Reader acceptance:** C1-owned byte-backed N−1 arrays retain wide dtype and do not expose suffix bytes. Tests inspect dtype, `.base` type/byte length and prove `47*47 == 2209` on a view. Canonical E_1 hash encoding is independent of NumPy dtypes and remains frozen. C2 ledger/prefix-only and static-method isolation tests are separate mandatory gates.
- **Default upgrades deliberately retained:** after any change to dependencies run all applicable offline suites, numerical boundaries, and the E_1 forecast-only target-1577 view/result goldens *before science resumes*. No upgrade between freeze and score or within an R3-T50-pinned Mode H study.
- **Fresh fitting:** every target N is fitted from eligible draws `< N` under its fixed window. Future incremental fitting/cache requires **byte-identical** to-from-scratch fit verification before scientific use, unless a separately reviewed/ratified exception is granted. Save frozen evidence, not every intermediate state by default.
- The code implementing these numerical view guarantees **has not been built or independently reviewed yet**. It belongs to Package 2 v0.11; these documents are review candidates, not operational proof.
