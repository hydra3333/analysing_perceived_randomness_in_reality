# Predictive Randomness — Holdout Exposure Record v0.1 (CANDIDATE)

**Status:** factual, value-free candidate for independent review and owner ratification. No outcome values, computations or claims about experimental influence are made.

1. On **25 October 2026**, a reviewer chat displayed published results for Powerball draws **1585–1588**.
2. Historical Powerball `*_20261021.csv` files contained draws now in the quarantined range. They were removed from the active working tree and remain recoverable in Git history. The owner/Claude-side development-master tools use a raw **first-field draw-number filter** before parsing any subsequent field (draw < 1577).
3. Git commit `9b78b8f` contained a saved results page showing recent quarantined draws; a later commit removed it from the active tree. It remains in Git history.

**Interpretation:** This record documents exposure and historical file presence only. It must not be used as an input to method fitting, scoring, tuning or selection. No winning numbers are reproduced.
