"""E_2-readiness contract (E2R-1 v0.3r3): installed declarations, registry entries and release policy checks.

Stage-1 contract library (E2R-CODE-1). The only file access is a read-only load of this package's
own data under contract_data/ (canonical JSON, one file per declaration and per registry entry).
Nothing is dispatched here: the dispatch gate (E2R-R57, T14) is wired into the launchers by CODE-2.
The revision-rollover check (E2R-R14A, T13) is a package-time governance check over identities;
it is not a run-time hashing or code-recording mechanism.
"""
from __future__ import annotations

import json
from pathlib import Path
from types import MappingProxyType
from collections.abc import Mapping

import _common.contract_vocab as V
from _common.contract_records import (
    canonical, record_digest, validate_declaration, validate_entry_declaration_pair,
    validate_registry_chain,
)

DATA_ROOT = Path(__file__).resolve().parent / 'contract_data'
REGISTERED_METHODS = tuple(f'E_{i}' for i in range(1, 63))   # E_1..E_62 stay registered (E2R-R19)
STRUCTURAL_EXCEPTIONS = MappingProxyType({                       # E2R-R14A; E1A-D1 (register v0.8)
    'NAMES-1': 'one-off rename to stable file names',
    'E1-ALIGN': 'E_1 modules into src/methods/E_001 and the shared canonical encoding',
})


def _load_canonical(path: Path) -> dict:
    # A Windows checkout with core.autocrlf may give the data files CRLF line endings; the
    # canonical form is the LF bytes, so they are compared after CRLF -> LF (README v0.4 rule).
    raw = path.read_bytes().replace(b'\r\n', b'\n')
    rec = json.loads(raw.decode('ascii'))
    if canonical(rec) != raw:
        raise ValueError(f'{path.name}: not stored as canonical bytes')
    return rec


class InstalledRegistry:
    """Every installed declaration and registry chain, validated on load; read-only afterwards."""

    def __init__(self, root: Path = DATA_ROOT):
        decls, chains = {}, {}
        for path in sorted((root / 'declarations').glob('*/*/*/r*.json')):
            d = validate_declaration(_load_canonical(path))
            game, method, variant = path.parts[-4:-1]
            if (d['game_id'], d['method_id'], d['variant_id'], f'r{d["method_revision"]}.json') != (
                    game, method, variant, path.name):
                raise ValueError(f'{path}: file location does not match the declaration')
            dig = record_digest(d)
            if dig in decls:
                raise ValueError('duplicate declaration')
            decls[dig] = d
        for folder in sorted({p.parent for p in (root / 'registry').glob('*/*/*/entry_*.json')}):
            files = sorted(folder.glob('entry_*.json'))
            entries = [_load_canonical(p) for p in files]
            for i, (p, e) in enumerate(zip(files, entries), start=1):
                if p.name != f'entry_{i:04d}.json':
                    raise ValueError(f'{p}: registry entry files must be entry_0001.json, entry_0002.json, ...')
                if (e['game_id'], e['method_id'], e['variant_id']) != tuple(folder.parts[-3:]):
                    raise ValueError(f'{p}: file location does not match the entry')
            active = validate_registry_chain(entries)
            for e in entries:
                validate_entry_declaration_pair(e, decls.get(e['declaration_digest']) if e['declaration_digest'] else None)
            chains[tuple(folder.parts[-3:])] = (tuple(MappingProxyType(e) for e in entries), MappingProxyType(active))
        self.declarations = MappingProxyType({k: MappingProxyType(v) for k, v in decls.items()})
        self.chains = MappingProxyType(chains)
        for game in ('POWERBALL', 'OZLOTTO'):
            listed = {m for (g, m, _v) in chains if g == game}
            if listed != set(REGISTERED_METHODS):
                raise ValueError(f'{game}: every method E_1..E_62 must stay registered (E2R-R19)')

    def active_entry(self, game_id: str, method_id: str, variant_id: str) -> Mapping:
        key = (game_id, method_id, variant_id)
        if key not in self.chains:
            raise ValueError('no registry chain for this method variant')
        return self.chains[key][1]

    def declaration(self, digest: str) -> dict:
        """A fresh copy, so a caller can never alter the installed record."""
        if digest not in self.declarations:
            raise ValueError('no installed declaration with this digest')
        return json.loads(canonical(dict(self.declarations[digest])))


# ---------------------------------------------------------------- revision rollover (E2R-R14A, E2R-T13)

def revision_rollover_findings(baseline: Mapping, successor: Mapping, *, package_id: str) -> list[str]:
    """Check a package's identities against the rule that a behaviourally relevant change needs a successor revision.

    `baseline` and `successor` are synthetic identity manifests:
      {'helpers': {name: revision}, 'methods': {method_id: {'revision', 'helpers': {name: revision},
                                                             'implementation_changed': bool, 'runnable': bool}}}
    A runnable method whose own implementation, or any shared helper it uses, changed must have a new
    revision, unless the package is the one structural exception that names itself. Unaffected
    methods keep their revisions, with a recorded finding. Raises ValueError on a violation.
    """
    findings = []
    old_helpers, new_helpers = baseline['helpers'], successor['helpers']
    for mid, new in sorted(successor['methods'].items()):
        old = baseline['methods'].get(mid)
        if old is None:
            findings.append(f'{mid}: new method at revision {new["revision"]}')
            continue
        changed = sorted(h for h, rev in old['helpers'].items() if new_helpers.get(h) != old_helpers.get(h))
        touched = bool(changed) or new['implementation_changed']
        if not touched:
            if new['revision'] != old['revision']:
                findings.append(f'{mid}: revision {old["revision"]} -> {new["revision"]} with no recorded change')
            else:
                findings.append(f'{mid}: unaffected by this package; keeps revision {old["revision"]}')
            continue
        if new['revision'] == old['revision']:
            if not new['runnable']:
                findings.append(f'{mid}: not runnable; no revision needed yet')
            elif package_id in STRUCTURAL_EXCEPTIONS and successor.get('structural_only') is True:
                findings.append(f'{mid}: keeps revision under the {package_id} structural exception')
            else:
                raise ValueError(f'{mid}: behaviourally relevant change ({changed or "own implementation"}) '
                                 f'without a successor revision (E2R-R14A)')
        else:
            if int(new['revision']) <= int(old['revision']):
                raise ValueError(f'{mid}: a successor revision must be a higher number')
            stale = sorted(h for h, rev in new['helpers'].items() if new_helpers.get(h) != rev)
            if stale:
                raise ValueError(f'{mid}: successor revision still names superseded helpers {stale}')
            findings.append(f'{mid}: successor revision {new["revision"]} for {changed or "own implementation"}')
    return findings
