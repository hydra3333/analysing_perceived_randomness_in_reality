# Package 2 scraper/source increment v0.3 — engineering CHECKPOINT

**STATUS:** NOT independently reviewed, NOT ratified, NOT a complete Package 2 delivery. This ZIP contains new incremental files since the previously supplied Foundation v0.1 checkpoint, *not* a replacement of that checkpoint. It is for the owner's Review folder / future consolidated Claude package, NOT direct installation or running.

## Scope and decisions

- Source-selection findings: Claude source research v2 supersedes v1. Lotterywest is the proposed official primary for Oz Lotto, with lottodraw.com.au as verifier; the existing Powerball powerball.net archive + Lotterywest drawn-order process and its accepted snapshots remain unchanged.
- The owner expressly regards published draw results as public information. We consequently focus on trustworthy capture and validation, while still respecting a site's robots directives and avoiding protected/undocumented endpoints. No programme contacts The Lott's undocumented API, imitates a browser, or accesses either site here.
- The Package 1 ratified doc baseline was owner-reported as commit 057fd8c618c00d162324149e949fc71ab72ca3ce. Work used the locally reconstructed source tree and the previous v0.1 checkpoint. The owner's current Git HEAD after committing the review ZIP has NOT been independently inspected.

## What is added since Foundation v0.1

1. **Pure offline Powerball and Oz Lotto source parsers:** label-bound Oz Lotto synthetic HTML parser (7 MAIN, 3 supplementary), reuse existing Powerball yearly archive parsing; no supplementary columns in the winning-only CSV, no fabricated draw-order certainty.
2. **Offline structural pipeline:** synthetic HTML fixtures -> isolated winning/raw pair -> bounded structural audit -> create-only synthetic snapshot. Date anomalies are warnings; number/count/era/gaps block acceptance.
3. **Fetch plan for both games:** exact URL plans for Oz Lotto Lotterywest pages, Powerball's existing powerball.net yearly archive, and optional Lotterywest Powerball drawn-order pages. Zero network operations.
4. **Robots/access-policy evaluation:** pure supplied-bytes checker with origin-specific HTTPS checks, SHA-256 policy digest, deny if unavailable/disallowed. It is not a production network client and does not confer legal permissions.
5. **Bounded cross-publisher comparison:** matches by (game,draw), checks label sets, supplementary/Powerball field and dates; detects missing draws and mismatches. When published order differs but the winning set agrees, results can still agree with a separate unverified-order warning. Reports never return winning numbers. Identical sequences are not asserted to prove the physical draw order.
6. **Synthetic-only raw-response archival:** exact URL/response bytes + SHA-256 manifest, create-only under SYNTHETIC_ONLY; no invented retrieval timestamps or scientific source acceptance; no external response bytes included in this checkpoint.
7. **Test coverage:** 42 multi-game offline tests PASS, plus the unchanged 13 legacy E_1 standalone synthetic tests PASS (Linux Python 3.13 locally). Increments include invalid robots, malformed/duplicate source rows, gap, malicious mismatched URI, no-number-logging, no-collision overwrite, order/winning-set distinction and full synthetic fixture publication.

## Still NOT done

- NO live scraper/HTTP client, live Oz page verification, acceptance/seal ledger, actual Oz Lotto first data collection, real results or holdout access. `Run_Scraper.bat` from the foundation checkpoint continues to REFUSE live scraping.
- Package 2 W4 method-generic BEGIN/FINISH/RESULT/DIGEST coordinator console protocol, run/root handshake, trusted coordinator-owned exit receipt and failure firewall synthetic integration remain incomplete.
- W5 shared barrel-aware synthetic scorer, exact new profile-driven Powerball golden regeneration and full Windows tests remain incomplete.
- Existing Powerball E_1 runner, source history and coordinator are NOT changed in this checkpoint. Process termination remains disabled. The original Powerball history/drawn-order CSVs are not included.
- Date/time profile settings for prospective FINAL remain OPEN; the separately authorised Package 3 structural-only Oz Lotto scrape has NOT been initiated.

**NEXT:** implement the remaining generic runtime and synthetic scoring boundary; consolidate with this checkpoint and Foundation v0.1 into one independently reviewable code package for Claude. Only after independent review and owner approval should any live source adapter be enabled and run.
