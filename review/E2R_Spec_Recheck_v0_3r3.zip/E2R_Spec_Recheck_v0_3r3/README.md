# E2R-1 - E_2-readiness specification v0.3r3 - handback for focused recheck

| Field | Value |
|---|---|
| Item | E2R-1: the stage-1 contract-field schema and acceptance list before E_2 |
| Author / reviewer | Claude / ChatGPT reviewer chat |
| Base commit | `be185485693f29cf9ab28292dc6eebad00bbc32c` |
| Inputs | v0.3r2 `2c69a9a8469ef1415b90d15e48d9de490310cfebe18d8be8694d0eb5483da115`; recheck `Independent_ChatGPT_E2R_v0_3r2_Focused_Recheck_v0_1.md` `865edd97b97b06a5975b3ddc037dc5d3053e1f563cd1f295857a7a9d7623def2` |
| Scope | One specification document; changes limited to E2R-R63, the version label, D-11, the new scenario E2R-T18 and Appendix C |
| Risk tier | HIGH (fit seeds: always-review) |
| Evidence state | IMPLEMENTED (draft); mechanically checked; not yet REVIEWED |

**Date:** 28 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears in or was used for this document. No beacon pulse was fetched.

| File | SHA-256 |
|---|---|
| `Predictive_Randomness_E2_Readiness_Method_Contract_Specification_v0_3r3.md` (ASCII, LF) | `0a73c92d757f9adbe1e6933e95778e10e27532b31a755f2453afca9895b3a954` |
| `evidence/spec_v0_3r2_to_v0_3r3.diff` | `054f9517fe383d6acdca928f073934242fce9c8aecd5acb3786b782436bec7ec` |
| `evidence/make_v03r3.py` (7 counted replacements) | `7f23a1302e9bd8d2bf15e61c721611f46d797ff193cbcd1634aada7e67cef9fa` |

## Response matrix (also spec Appendix C)

| Finding | Response |
|---|---|
| R2-F-C01 (RECHECK) | E2R-R63 now covers each of the reviewer's points: <ul><li>the root is seed entropy, not data;</li><li>three separate stages: announce the selection rule (NIST beacon version 2.0, chain, exact pulse and output field, no fallback); retrieve by hand, with the value checked independently against NIST's public archive; approve into an immutable reviewed policy before anything can be `SUPPORTED`;</li><li>null-policy declarations are never edited, and a move to a reviewed policy is a new declaration under a new revision or variant;</li><li>timing per the owner's decision **D-11** (the owner chose your option of a retrospective, labelled later root, over requiring a pulse to predate each historical target): prospective forecasts may use only an already-approved root, and retrospective development may use a later root, described as randomness chosen for the experiment;</li><li>reproducibility is qualified to matched inputs, configuration and environment (R2 9.3, E2R-T12);</li><li>new scenario test E2R-T18.</li></ul> |
| R2-F-C02 (FIX AND PROCEED) | The label is corrected. Because the edition is now v0.3r3, it reads `v0.3r3 DRAFT for focused recheck`, not the `v0.3r2` your finding specified for v0.3r2. This is within this edition's RECHECK and shown in the diff. |

*End of handback.*
