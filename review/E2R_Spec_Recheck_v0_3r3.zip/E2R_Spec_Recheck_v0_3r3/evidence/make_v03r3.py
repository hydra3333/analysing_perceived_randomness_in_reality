"""Spec v0.3r2 -> v0.3r3: answer the second focused recheck (R2-F-C01 RECHECK, R2-F-C02 FIX AND PROCEED)
and record owner decision D-11. Counted replacements; each old string must occur exactly once; ASCII.
Usage: python3 -I make_v03r3.py IN_v0_3r2 OUT_v0_3r3
"""
import hashlib, sys

src, out = sys.argv[1], sys.argv[2]
t = open(src, encoding='ascii').read()
assert hashlib.sha256(t.encode()).hexdigest() == '2c69a9a8469ef1415b90d15e48d9de490310cfebe18d8be8694d0eb5483da115'

R63_SOURCE_OLD = ("  - **Source (D-9):** a seed policy's root comes from the NIST Randomness Beacon. It is the single pulse at a time stated in the "
                  "policy **before** that time arrives, fetched once by hand after it is published, and recorded in the policy with its pulse "
                  "identifier. Runs never fetch anything. The root and the per-target derivation are fixed for that policy, so every run under it "
                  "is exactly reproducible.\n")

R63_SOURCE_NEW = """  - **What a root is (R2-F-C01):** seed entropy for a fitting algorithm. It is **not** data: not an observational input, a covariate or a draw-history feature, and it carries no information about any draw. The N-1 rule and every suffix test apply to the draw data exactly as before.
  - **Source (D-9), in three separate stages:**
    1. **Announce.** Before the pulse exists, a provisional, non-runnable seed policy fixes the selection rule: the service and version (the NIST Randomness Beacon, version 2.0), the chain and the exact pulse (by its timestamp or pulse index), and which output field becomes the root. There is no "latest available", "next best" or fallback pulse.
    2. **Retrieve.** After the pulse is published, the owner fetches that one pulse by hand. Its value and identifiers are recorded and checked against NIST's public archive by someone other than the person who fetched it (the reviewer or Claude, reading the public page). Runs never fetch anything.
    3. **Approve.** The verified value is bound into the reviewed, immutable seed policy. Only then may a declaration name that policy, and only then may its method become `SUPPORTED`. A missing, wrong or substituted pulse means the policy is not approved. Nothing falls back.
  - **Declarations stay immutable:** a declaration that carries a null `fit_seed_policy_id` is never edited. Moving to a reviewed policy means a new declaration under a new revision or variant (E2R-R21).
  - **Timing (owner decision D-11):**
    - **Real forecasts made before a draw** (prospective / FINAL, separately gated): the root must already have been fetched, verified and approved before that forecast is frozen. Otherwise the run is refused.
    - **Retrospective development walk-forward:** a root published after the historical targets is allowed. It is described as randomness chosen for the experiment, never as something that was available when those draws happened. Root trials are labelled, preserved and counted (below). These records are already labelled retrospective development evidence (`DEVELOPMENT_WF_EXPLORATORY`), and the root changes nothing about that.
  - **Reproducibility:** a fixed root and derivation make deterministic replay **possible**, given the same inputs, configuration and computing environment and the validation requirements of R2 9.3 and E2R-T12. It is not an unconditional promise.
"""

T18 = ("| E2R-T18 | Seed-policy stages and timing (R2-F-C01; specification-level scenarios, synthetic only, no real beacon fetch) | "
       "A provisional policy whose pulse is not yet published cannot be approved and cannot make a method `SUPPORTED`. A correctly retrieved "
       "and verified pulse can be approved. A missing or mismatched pulse is refused, with no fallback. A historical target that predates the "
       "root is accepted only as labelled retrospective development. A prospective request whose root is not yet approved is refused. A new "
       "root is a new policy ID under a new revision or variant, and the earlier root's records stay intact. In stage 1, no stochastic "
       "`SUPPORTED` entry can exist |")

EDITS = [
    ('# Predictive Randomness - E_2-readiness method-generic contract specification, v0.3r2\n',
     '# Predictive Randomness - E_2-readiness method-generic contract specification, v0.3r3\n'),
    ('**Version:** v0.3r1 DRAFT for focused recheck, 28 October 2026 (Adelaide, UTC+10:30). v0.3r2 answers',
     '**Version:** v0.3r3 DRAFT for focused recheck, 28 October 2026 (Adelaide, UTC+10:30). v0.3r3 answers the reviewer\'s second focused recheck (`Independent_ChatGPT_E2R_v0_3r2_Focused_Recheck_v0_1.md`, `865edd97...def2`: R2-F-C01 on seed roots, and R2-F-C02 on this version label), and records owner decision D-11; Appendix C maps both. v0.3r2 answered'),
    ('(section 14; none remain at v0.3r2).', '(section 14; none remain at v0.3r3).'),
    (R63_SOURCE_OLD, R63_SOURCE_NEW),
    ('- **D-10:** the owner may switch roots ("another universe") as a new revision or variant; every root tried is logged and counted in reports (E2R-R63).\n',
     '- **D-10:** the owner may switch roots ("another universe") as a new revision or variant; every root tried is logged and counted in reports (E2R-R63).\n'
     '- **D-11:** a root published after the historical targets may be used for retrospective development runs, described as randomness chosen for the experiment; a real forecast made before a draw may use only a root already fetched, verified and approved (E2R-R63). The owner chose this over requiring each historical target to have its own earlier pulse.\n'),
    ('\n\n- **R-4 oracle (agreed roles position', '\n' + T18 + '\n\n- **R-4 oracle (agreed roles position'),
    ('*End of specification draft v0.3r2.*',
     """## Appendix C. Resolution of the second focused recheck (of v0.3r2)

| Finding | Class / disposition | Resolution in v0.3r3 |
|---|---|---|
| R2-F-C01 seed roots: time of availability, stages, reproducibility | CORRECTION / RECHECK | E2R-R63 now: the root is seed entropy, not data; three stages (announce the selection rule, retrieve by hand with independent verification against the public archive, approve into an immutable policy before `SUPPORTED`); no fallback pulse; null-policy declarations never edited (a new declaration under a new revision or variant); timing per owner decision D-11 (prospective: the root must already be approved; retrospective development: a later root allowed, labelled); reproducibility qualified to matched inputs and environment. New scenario test E2R-T18 |
| R2-F-C02 version label | CORRECTION / FIX AND PROCEED | The front-matter label is corrected. Because this edition is v0.3r3, the label reads `v0.3r3 DRAFT for focused recheck` rather than the `v0.3r2` text the finding specified for v0.3r2; the version sentence records both editions. The change is visible in the exact diff and is under this edition's RECHECK anyway |

*End of specification draft v0.3r3.*"""),
]

for old, new in EDITS:
    n = t.count(old)
    assert n == 1, (n, old[:90])
    t = t.replace(old, new)
assert all(ord(c) < 128 for c in t) and t.endswith('\n')
open(out, 'w', encoding='ascii', newline='\n').write(t)
print(hashlib.sha256(t.encode()).hexdigest())
