# P1/P2 orphan interlock v0.4 — owner/Claude review candidate

**Baseline:** reviewed v0.3 coordinator SHA-256 `a2402175eaf22bf9d0293b49a6d1c91b48fe20d26866cf5d096dcfae6a95a58b`.  
**Status:** implementation proposed; **NOT approved for destructive tests**.  
**Scope:** one replacement coordinator Python file and one additive, wholly synthetic regression test; no P0 files, batch runners, dependencies or scientific data changed.  
**Mandatory:** `ENABLE_PROCESS_TERMINATION = False` remains unchanged. Any future change to process ownership / kill path must undergo independent review before exercise/acceptance.

## Scope, rationale and operating policy

The owner ratified strict **no-status/no-kill**: if the coordinator cannot positively match the experiment's PID and creation time with its verified ancestry/status, it must not terminate it. This v0.4 patch does **not** change that rule.

Architecture v0.4 §5C.2 separately requires that a later coordinator run must not silently ignore unresolved/suspected orphans. This package adds a persistent, no-clobber `transitory_data/poc_runs/UNRESOLVED_ORPHAN.json` interlock:

1. The coordinator checks for this marker BEFORE making a group directory or launching workers; any existing marker, including malformed contents, blocks launching.
2. When a stop cannot confirm cleanup (timeout, interrupt, memory guard or coordinator error), it immediately publishes a durable JSON marker containing the group, reason and observed worker/process identities. An unclosed output reader also triggers marking.
3. Marker publication writes an exclusive temporary file, flushes and `fsync`s it, then uses the existing Windows `os.rename` no-overwrite semantics. Existing marker data are never overwritten.
4. **No automatic acknowledgement path** is implemented. After separately verifying that all suspected processes have exited, the owner/operator must archive the marker with the run evidence and remove it from the active path to allow another coordinator run. Do not merely delete or rename without inspecting the listed PIDs **and creation times**. This manual acknowledgement procedure is **RECOMMENDED, pending owner approval**.
5. The previously recommended one-line hardening is included: ancestry capture builds its known-parent set only from verified members where `_member_alive(...) is True`; an uncertain parent provides no ownership authority.

**Limitations:** An unexpected power loss or coordinator process kill before the marker is written can evade this best-effort warning. The marker is not a Windows Job Object or an exclusive cross-process coordinator lock. If disk persistence fails (disk full / permission error), no reliable orphan gate can be promised; such errors must be treated as critical. A second unresolved incident retains the first marker; other details remain in the coordinator's manifest/log. The switch-off coordinator never kills processes, including suspected orphans. No code in this package authorises changing the switch.

## Existing flush/atomic guarantees

`src/methods/_common/experiment_console_and_file_output.py` already uses temporary-file writes, `flush`, `os.fsync`, and atomic `os.replace` for mutable `status.json`; the coordinator's `save_new` already flushes/fsyncs immutable records. Safety console statements use `flush=True`. We do **not** add expensive `fsync` to every progress-log line. A **future implementation contract** requires STARTED publication before heavy imports, model initialisation or significant computation; it is not falsely claimed as already implemented for every program.

## Evidence

- On a disposable source copy: existing `p0_static_checks.py`, `p1p2_static_checks.py`, `p1p2_non_destructive_safety_checks.py`, `p1p2_safety_regression_v0_3.py` all PASS (Linux/static/fakes; no Windows action).
- New `p1p2_orphan_interlock_v0_4.py` synthetic test PASS: marker absent allows preflight, durable marker created, marker refuses next start, no-clobber preservation, malformed marker refuses next start, owner switch still False.
- **NOT TESTED:** real Windows marker publication and refusal, repeat Ctrl+C, hard process termination, protection under disk faults, fully clean recovery from abrupt crashes, production Option F acceptance.

## DECIDED / RECOMMENDED / OPEN

**DECIDED:** The owner ratified strict no-status/no-kill (23 Oct 2026). Design patch keeps it; kill switch remains false. Add marker and positive-live parent check as reviewed implementation candidates, not final acceptance.

**RECOMMENDED — owner approval requested:** For first release, require an explicit **manual** acknowledgement: inspect original PID+creation-time identities and evidence, archive the marker, then remove marker from active path; do not implement a casual `--ignore-orphan` bypass.

**OPEN:** Owner acceptance of synthetic N2/N3 forged/stale-status evidence; requirement to archive per-destructive-test evidence under `results/architecture_poc/<date>_<test>/`; independent safety review/Windows test gates before any switch change. Before production, consider additional crash-recovery protection if sudden coordinator death becomes a realistic case.

## Installation safety

**Do not install until independent Claude review and owner approval** for the scope/acknowledgement policy. On Windows compare the old coordinator SHA-256 first, then extract ZIP in repository root; one existing file should be replaced, one test file added. Verify the new hash in the package manifest. Run the five listed non-destructive tests and then a synthetic marker refusal check; **do not run timeout/kill/Ctrl+C cleanup tests or flip the switch**.
