# Documentation Refresh v0.3 — focused Claude spot-check (NOT RATIFIED)

**Purpose:** bounded R1–R5 and D1/D3 correction set requested by Claude review v1 of documentation refresh v0.2. This package is based on the v0.2 candidate archive SHA-256 `4508268d5de9d822fb14e05f27cd9cbab102205cdc2462d296a55bb64de87324`. It is **not** an installation ZIP and contains no authority to execute software, open holdouts, change safety switches or score results.

**Scope:** seven existing candidate documents amended (Proposal, R2 Erratum, R3, Architecture, P3 Task Spec, exposure record, technical numerical reference); ratification register candidate carried forward unchanged from v0.2. Review metadata updates: full Oz SHA, HEAD and interim handover.

**Claude checks:** inspect every `diff_from_v0_2/` diff; confirm R1 withdrawn rules named exactly, R2 raw-byte hashing versus future-row parsing, full Oz SHA `4a6cecc27fb6a5b8aafc0451858f1ea00f31c0eaf83c15c6ba66a0940e83f93f`, R4 Proposal header, R5 factual exposure, D1 precedence and D3 `PAIRED_DIAGNOSTIC`. Check that the preserved Architecture §5C and all frozen E_1 and TIE text are unchanged; reconcile file versions and all register hashes against actual current Git HEAD. Confirm no unintended substantive delta.

**Owner workflow after spot-check:** (1) owner ratifies in this order: Proposal v0.5 → R2 erratum v0.4 and R3 v0.4 → Architecture v0.7 and P3 v0.2 → exposure record and technical numerical reference → register v0.3; (2) a **new final installation ZIP** is made (candidate suffixes/status removed, exact hashes and paths recorded); (3) owner installs, commits, pushes and gives actual HEAD; (4) ChatGPT creates **a definitive self-contained new-conversation coder handover**, based on committed files. This interim v0.6r2 handback is not that final document.

**Roles:** ChatGPT coder, Claude independent reviewer, owner sole ratifier/installer. Always-review rules, independent-review latitude, DECIDED/RECOMMENDED/OPEN labels and holdout seal unchanged. Package 2 v0.11 is pending code, not part of this documentation package. Scientific use of the new reader stays NO-GO until N−1 C1/C2 fixes independently reviewed.
