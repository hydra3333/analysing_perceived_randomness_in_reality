# Predictive Randomness — Holdout Exposure Record v0.1 (CANDIDATE)

**Status:** factual, value-free candidate for independent review and owner ratification. No outcome values, computations or claims about experimental influence are made.

1. On **25 October 2026**, a reviewer chat displayed published results for Powerball draws **1585–1588**.
2. Historical Powerball `*_20261021.csv` files contained draws now in the quarantined range. They were removed from the active working tree and remain recoverable in Git history. The owner/Claude-side development-master tools use a raw **first-field draw-number filter** before parsing any subsequent field (draw < 1577).
3. Git commit `9b78b8f` contained a saved results page showing recent quarantined draws; a later commit removed it from the active tree. It remains in Git history.
4. Results pages saved by the owner from The Lott in October 2026 for the cross-checks also carried that site's latest-draw panel, showing then-recent draws of both games in the quarantined range. The pages were kept outside the repository, and some were attached to the reviewer chat as files. The Claude-side tools never parsed that panel; apart from item 1, no values were displayed.

**Interpretation:** This record documents exposure and historical file presence only. It must not be used as an input to method fitting, scoring, tuning or selection. No winning numbers are reproduced.
