"""Independent T-05 probe for Package 2 v0.11-r1 (Claude reviewer; not project code).

Designed from R2 T-05 / the B1 rule, not from the coder's test: for real development
masters (Powerball 1144-1576, Oz Lotto 1474-1693; no quarantined rows exist in them),
load DrawView at several targets N, then rewrite EVERY row with draw number >= N
(both a valid-looking variant and an undecodable-bytes variant), re-pin the ledger and
INIT record to the new whole-file SHA-256, reload, and require every DrawView slot,
array byte, dtype, shape, simple_rows() and e1_view_digest() to be identical. Also scan
every slot (recursively) for any orchestration hash. Prints hashes/counts only, never
draw values.
Usage: python -I t05_real_prefix_probe.py TREE_ROOT SOURCE_DATA_DIR
"""
import sys, os, json, csv, io, hashlib, shutil, tempfile
from pathlib import Path
tree, srcdata = Path(sys.argv[1]), Path(sys.argv[2])
sys.path[:0] = [str(tree / 'src' / 'methods')]
import numpy as np
from collections.abc import Mapping
from _common.game_draws_reader_v1 import load_pinned_draw_view, DrawView
from _common.game_profiles_v1 import get_profile

def sha(b): return hashlib.sha256(b).hexdigest()
def files(game): return (f'{game}_results_master.csv', f'{game}_results_master_ledger.csv',
                         f'{game}_results_master_init_verification.json')

def repin(folder, game, raw):
    m, l, e = files(game)
    (folder / m).write_bytes(raw); s = sha(raw)
    rows = list(csv.DictReader(io.StringIO((folder / l).read_text(encoding='ascii'))))
    rows[0]['master_sha256'] = s
    out = io.StringIO(); w = csv.DictWriter(out, fieldnames=list(rows[0].keys()), lineterminator='\n')
    w.writeheader(); w.writerows(rows); (folder / l).write_text(out.getvalue(), encoding='ascii')
    ev = json.loads((folder / e).read_text()); ev['master_sha256'] = s
    (folder / e).write_text(json.dumps(ev))
    return s

def perturb(raw, target, mode):
    lines = raw.split(b'\n'); out = [lines[0]]
    for ln in lines[1:]:
        if not ln: out.append(ln); continue
        first = ln.split(b',', 1)[0]
        if int(first) >= target:
            if mode == 'garbage':
                ln = first + b',\xff\x00not-a-row'
            else:  # valid-looking but different numbers (fixed rotation of label values)
                f = ln.split(b',')
                game_max = 35 if len(f) == 10 else 47
                rot = [str((int(x) % game_max) + 1).encode() for x in f[2:9]]
                if len(set(rot)) != 7: rot = [str(k).encode() for k in (1, 2, 3, 4, 5, 6, 7)]
                tail = f[9:]
                if len(f) == 10: tail = [str((int(f[9]) % 20) + 1).encode()]
                ln = b','.join(f[:2] + rot + tail)
        out.append(ln)
    return b'\n'.join(out)

def snapshot(view, forbidden):
    snap = []
    def scan(o, field):
        if isinstance(o, str):
            for h in forbidden:
                if h in o: raise AssertionError(f'{field} carries an orchestration hash')
        elif isinstance(o, Mapping):
            for k, v in o.items(): scan(k, field); scan(v, field)
        elif isinstance(o, (list, tuple)):
            for v in o: scan(v, field)
        elif isinstance(o, np.ndarray):
            if o.dtype.kind in 'US': scan(o.tolist(), field)
    for f in DrawView.__slots__:
        v = getattr(view, f); scan(v, f)
        if isinstance(v, np.ndarray):
            assert type(v.base) is bytes and not v.flags.writeable
            snap.append((f, 'arr', str(v.dtype), v.shape, v.tobytes()))
        elif isinstance(v, Mapping):
            snap.append((f, 'map', tuple(sorted(v.items()))))
        else:
            snap.append((f, 'val', v))
    return tuple(snap), view.e1_view_digest(), json.dumps(view.simple_rows())

checks = 0
for game in ('POWERBALL', 'OZLOTTO'):
    p = get_profile(game)
    last = p.holdout_first - 1
    targets = sorted({p.first_draw + 2, (p.first_draw + last) // 2, last - 1, last})
    for target in targets:
        if not p.historical_development_target_allowed(target):
            print(game, target, 'not an allowed development target; skipped'); continue
        for kind in ('UNORDERED_SET', 'OPERATOR_DRAWN_ORDER', 'PAIRED_DIAGNOSTIC'):
            for dates in (False, True):
                with tempfile.TemporaryDirectory() as td:
                    root = Path(td); folder = root / 'source_data'; folder.mkdir()
                    for n in files(game): shutil.copy2(srcdata / n, folder / n)
                    base_raw = (folder / files(game)[0]).read_bytes()
                    s0 = sha(base_raw)
                    forb = {sha((folder / n).read_bytes()) for n in files(game)}
                    pin = lambda s: {'schema': 'DEVELOPMENT_MASTER_PIN_V1_REVIEW', 'game_id': game,
                                     'method_id': 'E_2', 'variant_id': 'PROBE_VARIANT', 'draw_number': target,
                                     'view_kind': kind, 'include_dates': dates,
                                     'master_file': files(game)[0], 'ledger_version': 1, 'master_sha256': s}
                    a = snapshot(load_pinned_draw_view(repo_root=root, run_manifest=pin(s0)), forb)
                    for mode in ('valid', 'garbage'):
                        s1 = repin(folder, game, perturb(base_raw, target, mode))
                        assert s1 != s0
                        forb |= {sha((folder / n).read_bytes()) for n in files(game)}
                        b = snapshot(load_pinned_draw_view(repo_root=root, run_manifest=pin(s1)), forb)
                        if a != b: raise AssertionError(f'T-05 FAIL {game} N={target} {kind} dates={dates} {mode}')
                        checks += 1
                    nrows = len(json.loads(a[2]))
        print(f'{game} N={target}: prefix rows={nrows}; 3 kinds x 2 date modes x 2 suffix variants identical')
print('PASS', checks, 'perturbation comparisons; no orchestration hash in any DrawView slot')
