# Package 2 v0.10 — DELTA against v0.9 — CLAUDE REVIEW ONLY

Status: **not ratified, not installable as a release, not executed on Windows; no Lotterywest network requests or holdout access.** This ZIP contains only changed/new files relative to the v0.9 review candidate, not a complete repository, plus explicit retirement instructions, independent document-amendment drafts, and offline evidence.

Baseline: Predictive_Randomness_MultiGame_Package2_Consolidated_v0_9_CODE_REVIEW_CANDIDATE.zip (SHA-256 a14af81be9f99e623d453930ce59c2e396fc8f775f037c0cb7b633ee68ead46a). Repository source HEAD 06f6e0f **reported by Claude**, not independently fetched. Exact coordinator v0.6 source SHA 2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b verified.

`delta_overlay/` is intended for merging into a **scratch copy** of the v0.9 candidate only. `RETIRE_FROM_V09_REVIEW_BASE.txt` describes old v0.9 reviewer-only modules/tests now superseded by the one-file layout and fixed Oz boundary; do not delete ratified historical source data through this ZIP.

The detached `proposed_doc_amendments/` require owner ratification and are **not** current project authority. No Powerball CSV was deleted or modified in this ZIP; only the owner will remove the two obsolete working-tree CSVs after review, keeping their exact Git history and hashes.

Offline tests: 76/76 PASS in a disposable Linux environment (64 applicable multi-game tests + 12 legacy E_1 synthetic tests, see `evidence/FULL_OFFLINE_TEST_TRANSCRIPT_v0_10.txt`). Previous v0.9 suites that require `with_sealed_holdout` or the two-file source layout were retired, not silently ignored. The actual real-data 1577 regression was NOT run and must be completed only AFTER approved DEV_BUILD. Exact Powerball accepted golden identities are `d47fbbd6e60e6abc429fb74f47d8bbeafc6560152c2ecddb3b75d79932df4339` (view) and `7f1130872b3afaa222ff4e8c2396cd2c2872583544dfa6b31cc5a07cd067164e` (result).

The API-order field and saved-page parser remain unverified against current real payloads, by design under the no-live-request instruction. `HOLDOUT_FETCH` and `UPDATE` stubs refuse; 3 safety switches False; scientific coordinated result allowlist empty. Exact coordinator source and immutable safety-function comparisons are in evidence.

See `REVIEW_REQUEST_CLAUDE_v0_10.md` for an explicit known-gap inventory. No owner action required before independent review.
