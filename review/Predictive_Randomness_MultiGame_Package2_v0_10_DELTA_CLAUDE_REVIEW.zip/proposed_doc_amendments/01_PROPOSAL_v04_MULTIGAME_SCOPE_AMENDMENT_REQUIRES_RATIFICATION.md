# Proposed amendment to ratified Project Proposal v0.4 — REQUIRES OWNER RATIFICATION

**Status:** DRAFT ONLY. Does not replace the ratified Proposal v0.4. Derived from owner decisions 24–25 October 2026 and Claude Package 2 review v2. **No live activity authorised.**

## Proposed replacement clauses for §0A / data and holdout provisions

1. The two lottery games remain `POWERBALL` and `OZLOTTO`; authoritative draw identity is `(game_id, draw_number)`. Both retain separate model, hypothesis, fit, and reporting identities; no pooled science is authorised.
2. Both games use one canonical drawn-order development CSV per game, accompanied by metadata-only provenance. The common, read-only NumPy reader supplies method-authorised `SORTED`, `DRAWN`, or `PAIRED` N−1 views. Raw Oz supplementary numbers are archived in the canonical source CSV for audit; **no scientific method may observe or score them** under current scope.
3. Lotterywest's public JSON search results API is the common source for the new development base, with owner-saved Lotterywest `.mhtml` results pages a fallback. The former Powerball snapshot source and script remain historical provenance, never overwritten or silently repurposed.
4. **Calendar-aligned quarantine begins on 8 August 2026:** Powerball first quarantined draw 1578 (13 August); Oz Lotto first quarantined draw 1695 (11 August). Final holdouts are Powerball 1578–1587 (unchanged) and Oz Lotto 1695–1704 (new fixed ten-draw set). Later draws are also quarantined pending a separately authorised phase.
5. The initial development datasets must terminate at Powerball 1577 (6 August) and Oz Lotto 1694 (4 August), with the acquisition date cap 7 August 2026. All subsequent historical-development and walk-forward targets remain below the respective holdout; prospective post-holdout FINAL operation is **not** globally capped and requires its own authorisation, outcome timing, N−1 and freeze safeguards.
6. Phase sequence: (I) obtain, inspect and verify pre-holdout DEV_BUILD source data; (II) a separately authorised Mode H, with pre-registered frozen methods and sequential forecast-before-outcome disclosure; (III) separately authorised ongoing production UPDATE and FINAL. `HOLDOUT_FETCH` and `UPDATE` remain disabled in Package 2 v0.10.

## Installation and disposition

On ratification, incorporate these provisions into a new self-contained proposal or a numbered erratum without modifying previous ratified bytes. Preserve the historical source hashes in archived provenance; remove their designation as *active development bases*. Do not change the existing no-signal/no-status and global orphan interlock.
