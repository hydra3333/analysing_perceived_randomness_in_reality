# Proposed R2 Erratum amendment — REQUIRES OWNER RATIFICATION

**Status:** DRAFT, no authority. Affected baseline: R2 Erratum Record v0.3 / ERR-R2-05 and original R2 provisions. This is not an independent modification of scientific registrations.

## Replacement of Oz holdout selection

Replace the previous Oz first-accepted-snapshot / ten-highest-draw rule with a **fixed calendar-aligned** boundary: Oz first quarantined 1695 (11 August 2026), Oz FINAL_HOLDOUT_10 = 1695–1704. Historical development ends at 1694 inclusive. Powerball first quarantined 1578 and FINAL_HOLDOUT_10 1578–1587 remain unchanged. An outcome's quarantine status does not expire merely because the calendar advances. No data-bearing rows at or above the boundary may enter a development base or diagnostic. Later quarantined draws require a future protocol.

## Permitted views and registration

The new common reader stores each game's single development table with drawn order and a derived sorted array. It supports `SORTED`, `DRAWN` and `PAIRED`, returning read-only, prefix-only rows strictly before target N. A variant must be **expressly registered** for each requested view kind and game; availability of a reader implementation never grants scientific entitlement. E_1 `FULL_HISTORY_RAW_COUNTS_V1` remains `SORTED` only and preserves `E1_REAL_U_TRAINING_VIEW_V1` and all Powerball tie domains and digests. Ordered and paired hypotheses (notably portions of E_29–E_32 and certain later variants) remain `FORMULA_OPEN` until independently reviewed and ratified. Cross-game views remain out of scope.

Oz supplementaries are visible only to structural auditing; scientific views never include them. New view schemas for either game bind `game_id`, era, profile version and representation (`SORTED`, `DRAWN` or `PAIRED`). The permitted-view digest includes every field actually consumed (or profile binding of deterministically derived dates). No mixing ordered/unordered views under one scientific identity.

## Date deviations, snapshots and N−1

Every source row is structurally validated for canonical ISO date; a deviation from the fixed weekly derived date is a warning that blocks only date-dependent methods E_14/E_54, not acceptance of a numbers-valid snapshot. Per-game development targets and entire table contents terminate strictly below their holdout; per-target slices stop at N−1. Later prospective operation follows a separately reviewed FINAL contract, not the retrospective development cap.
