# Independent review request — Package 2 v0.10 DELTA against v0.9

**Status: CODE REVIEW ONLY. NOT INSTALLED, NOT RATIFIED, NOT CLEARED FOR LIVE ACQUISITION OR WINDOWS EXECUTION.**

Authority: `Claude_Review_Package2_Consolidated_v0_9_v2.md`, SHA-256 prefix `bd5665e0`, superseding prior reviewer drafts, and the owner's decision to offer `SORTED`, `DRAWN`, `PAIRED` view interfaces with explicit per-(game, method, variant) scientific entitlements. Delta baseline is `Predictive_Randomness_MultiGame_Package2_Consolidated_v0_9_CODE_REVIEW_CANDIDATE.zip` SHA `a14af81b...68ead46a`, backed by Git HEAD `06f6e0f` per Claude. Existing coordinator v0.6 SHA `2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b` independently verified from an archived repository source.

### Focus areas

- Part A: one output-waking, human-speed queue helper, `--poll-seconds`, 0.5/1/5s constants, line-buffered logs, no protected-function AST change, no unsafe process signalling, create-only ancestry release and the missing-status retry that does not skip timeout.
- Part B/D: Lotterywest API query construction with `lotterywest_game_code` 5132/5130, approval of robots for the exact origin, honest UA, rate limit, hard 2026-08-07 date cap, strict pagination; Powerball 434/434 historical *pre-holdout* comparison chooses order field; Oz cannot guess. API record-array key, date formats, order interpretation and real saved-page layout have **not** been verified live by ChatGPT.
- Part C: only one development CSV per game; full pre-holdout audits, copied read-only NumPy arrays, sorted/drawn/paired N−1 views and no Oz supplementary scientific views. E_1 compatibility bridge is pure; accepted real draw-1577 regression **cannot yet run on the new file**, and is a post-DEV_BUILD acceptance gate.
- Part E: Powerball 1578–1587 unchanged; Oz 1695–1704 fixed. Owner must separately ratify relevant documentation amendments. Old Powerball files are not removed by this review ZIP. `HOLDOUT_FETCH` and `UPDATE` remain disabled; no holdout content touched.
- Result and receipt hardening: contract modules SHA-256 bound to receipts; scientific allowlist remains empty. Pure synthetic worker remains distinct from science. Prior 2-read, fake synthetic-flag and path-shadowing issues remain resolved.
- Superseded v0.9 modules/tests enumerated in `RETIRE_FROM_V09_REVIEW_BASE.txt`; verify no new runtime imports rely on them. Existing comprehensive legacy v0.9 test totals cannot be compared directly to v0.10 because those tests enforce old data/holdout contracts.

### Explicit known gaps / reviewer judgement required

1. Actual public Lotterywest API payload was **not** retrieved; parser uses the documented field/pagination shapes from Claude's structural inspection and fails closed on unfamiliar forms.
2. Saved `.mhtml` extraction uses strict label-oriented synthetic fixtures; real Lotterywest saved-page compatibility is unproven.
3. E_1 pure bridge exists, but wiring to the currently committed historical-development CLI must be checked against HEAD. The old runner's exact HEAD bytes were not provided in the v0.9 overlay. Real golden `d47f...`/`7f113...` validation awaits the newly built Powerball development base.
4. The `requirements.txt` and `.gitignore` housekeeping patches must be reconciled with current HEAD before installation; only archived versions were available. The installer already lists NumPy in the archived edition.
5. Git HEAD `06f6e0f` and full current repo content were reported by Claude; no independent GitHub fetch was undertaken by ChatGPT under the no-live-request instruction.
6. **N−1 isolation review:** Part C builds a single complete pre-holdout in-memory table. For a retrospective target N within that development base, the table itself can contain the outcome row N, although `view()` returns exclusively slices ending at N−1 and the E_1 engine receives only the resulting copy/list. Please explicitly assess consistency with the earlier "loader never parses row N" direction and whether orchestration must keep the table strictly outside method code. Do not silently waive N−1 or feed the table to scientific method implementations.
7. The above gaps must not be misrepresented as passing Windows or live acceptance. Separate owner approval remains mandatory for the first DEV_BUILD and Windows synthetic lifecycle.

Return numbered BLOCKER / CORRECTION / OPTIONAL findings and an explicit go/no-go assessment for v0.10 review progression; do not perform any live result retrieval, Windows run, source-data exposure or process termination.
