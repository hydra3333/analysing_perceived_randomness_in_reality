"""E_1 retrospective compatibility bridge to the new immutable common reader.

Pure calculation only. Does not start workers, access outcomes, or grant a
coordinated/FINAL schema. Only the accepted legacy E_1 SORTED view is used.
"""
from __future__ import annotations

from .game_draws_reader_v1 import DevelopmentDrawTable
from .e1_training_view_v0_1 import build_e1_forecast


def prepared_e1_forecast(table: DevelopmentDrawTable, target: int) -> tuple[dict,str]:
    if not isinstance(table, DevelopmentDrawTable) or table.game_id!='POWERBALL':
        raise ValueError('legacy E_1 forecast bridge only accepts Powerball')
    view=table.view('E_1','FULL_HISTORY_RAW_COUNTS_V1',target,kind='SORTED')
    digest=view.e1_view_digest(data_kind='REAL_HISTORICAL_DEVELOPMENT')
    # Legacy canonical fields, tie version and set ordering stay unchanged.
    forecast=build_e1_forecast(view.simple_rows(),digest,target,
                              source_kind='REAL_HISTORICAL_DEVELOPMENT')
    return forecast,digest
