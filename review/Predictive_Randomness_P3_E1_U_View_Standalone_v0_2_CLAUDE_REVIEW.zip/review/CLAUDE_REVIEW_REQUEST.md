# Claude independent review request: E_1 U-view + standalone v0.2

**Review anchor:** Previously reviewed E_1 U-view v0.1 package SHA `3ef73801...` and repo baseline `18fa741...`, with the owner's later administrative commits potentially changing HEAD; compare actual bytes before installation. Owner decisions D1/D2/D3 ratified; new real gate NOT authorised. No real source data or holdout were accessed.

**Claude blocker:** New E_001 uses the repository's shared ProbeStatus, schema ENGINEERING_POC_STATUS_V1, with actual PID/create time/sys.prefix at STARTED, and perf_counter/process_time/labelled memory at terminal. Optional `identity` and `terminal_fields` parameters preserve existing POC behaviour. Is the status now compliant with Architecture v0.5 §5C and consistent across standalone/coordinator?

**Filename correction:** Single executable E_001_Historical_Appearance_Frequency.py; accepted pure maths moved byte-identically beneath _common. Verify no second E_1 executable, method ID unaffected.

**Review together:**
1. Exact code and full SHA manifest; 12 synthetic Linux tests, including interrupt and early status, complete unchanged golden vectors.
2. The proposed **ONE LINE ONLY** gate patch in `review/PROPOSED_REAL_GATE_ONE_LINE_ONLY.diff`. It is not applied; hard flag remains False in executable.
3. The Windows synthetic-only `Run_Experiment.bat` procedure (no modification to BAT). Review possible CMD argument/relative-path issues and output safety.
4. Mandatory unresolved-orphan marker refusal for real consumers, ignored dev result location `.gitignore` append, schema/manifest hash binding, no externally witnessed exit in standalone (reviewer already accepted only for this mode).
5. Independently review added shared-helper changes for POC compatibility and residual Windows `os.replace` sharing violations. Optional bounded retries may be deferred if no substantive blocker.

**Please return:** blockers first, any refinements (safety/significant first), owner decisions (if needed), whether v0.2 is ready for approved Windows synthetic tests, and the conditions required before owner may authorise the exact first real historical run. Do not authorise real, FINAL, holdout, termination, or destructive tests.
