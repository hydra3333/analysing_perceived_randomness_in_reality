# Windows 11 non-destructive synthetic verification (review before running)

Prerequisites: owner has a clean, hash-verified installation of this candidate accepted by Claude, the project .venv including psutil, and `ENABLE_REAL_HISTORICAL_DEVELOPMENT = False`. The existing `Run_Experiment.bat` remains byte-identical and is the sole launch interface. No run if `transitory_data\poc_runs\UNRESOLVED_ORPHAN.json` or any marker-path entry exists. Do NOT install the proposed True switch diff for these tests.

In an ordinary CMD at the repository root:

```bat
.venv\Scripts\python.exe tests\prepare_p3_e1_synthetic_csv_v0_1.py
.venv\Scripts\python.exe -m unittest discover -s tests -p test_p3_e1_standalone_v0_1.py -v
Run_Experiment.bat E_001_Historical_Appearance_Frequency.py --mode synthetic-contract --target 1152 --source ..\..\transitory_data\p3_synthetic_fixtures\e1_synthetic_u_1152.csv --synthetic-run-root ..\..\transitory_data\p3_synthetic_runs
echo RC=%ERRORLEVEL%
if exist "transitory_data\poc_runs\UNRESOLVED_ORPHAN.json" (echo SAFETY STOP: ORPHAN MARKER EXISTS) else (echo NO ORPHAN MARKER)
```

`Run_Experiment.bat` changes its working directory to `src\methods`, hence both relative `..\..\` paths. The run prints its generated `e1-...` run ID immediately after status STARTED. Expect exit RC=0, terminal status `SUCCESS`, standalone manifest `PASS`, and `external_exit_code_verified=false`. Verify generated files in `transitory_data\p3_synthetic_runs\<run-id>`. Save console transcript and status+manifest+result SHA-256 for review. NO lottery `source_data` input, no reserved holdout, no FINAL, no coordinator termination. On any refusal, FAILED or missing exit-status evidence, stop and preserve artifacts.

If the real historical gate is later enabled, a distinct owner-approved Windows procedure and exact source/target must be supplied. This procedure does NOT authorise that mode.
