# Predictive Randomness — Software Architecture v0.5 Safety Clarification Erratum

**Version:** v0.1 — REVIEW CANDIDATE, not ratified. **Applies exclusively to:** `Predictive_Randomness_Software_Architecture_Discussion_v0_5_REVIEW_CANDIDATE.md`, which explicitly references this exact filename. **No standalone authority without that reference and subsequent owner approval.**

## E-01 — Strict experiment identity prerequisite for termination

Architecture v0.4 §5C.2 already demands verified wrapper ancestry and identity; the owner has since explicitly ratified an **additional restrictive gate**: no termination of the experiment or its process tree unless the experiment PID **and creation time** are positively matched to its status data **and** the verified launched ancestry. If status is missing, malformed, late, or uncertain, do not terminate (even if hung); leave it and require manual intervention. Status identity may only **restrict** authority; it never supplies a kill target. Durable STARTED status should be published as early as practicable, before heavy imports. `ENABLE_PROCESS_TERMINATION = False` remains in force until a separately reviewed and owner-approved destructive gate.

## E-02 — Persistent unresolved-orphan interlock and operator recovery

Any observed alive/uncertain descendant on wrapper exit, or switch-False timeout/interrupt, requires a persistent no-overwrite fsynced marker at `transitory_data/poc_runs/UNRESOLVED_ORPHAN.json` and halts further launches. Any existing marker entry blocks new coordinator starts; no command-line bypass or automatic clearance. Operator must inspect original PID **with creation time**, not kill a listed PID from its number, preserve original marker bytes/SHA-256 and logs, verify all recorded identities exited, then run a narrowly scoped reviewed manual clearance with durable audit record. Alive/uncertain identities -> retain marker and escalate. Marker-write failure must be CRITICAL and must not be portrayed as protected interlock state.

## E-03 — No FAIL/orphan result consumption

An output file created after failure or a suspected orphan is not an authorised forecast: later tooling must exclude results of groups whose manifest is FAIL or orphan-suspected even if `canonical_result.json` exists. Preserve FAILED status; do not conflate successful archive with successful experiment.

## E-04 — Status and scope

These are owner-ratified constraints being recorded, not relaxation of v0.4 or approval for destructive tests. This candidate and companion Architecture v0.5 require review/owner ratification together; old ratified v0.4 governs until then.
