# Installation and scope manifest — documentation-only recovery candidate

Do NOT unpack to repository root until review and owner ratification. The `doc/` files below are candidates and deliberately retain `_REVIEW_CANDIDATE`. Versioned older sources remain untouched. The approved final filenames and the cross-reference in Architecture v0.5 must be made consistent together at ratification.

- Handback v0.4 incorporates Claude C1–C5 and the still-active real marker observation.
- POC spec v0.2 removes the taskkill fallback and records accepted safety/testing state, with historical baseline qualified rather than erased.
- Architecture v0.5 is a proposed version retaining v0.4 material, explicitly referencing a separately versioned safety erratum v0.1. Both are inseparable for approval; no orphaned erratum.
- All source/batch/experiment files are unchanged. No marker, safety switch, or scientific dataset files are included.
- Proposed later housekeeping NOT executed: place Claude v5 under `doc/HANDOVER/`; relocate old root-level handbacks/patch ZIP only after mapping references; remove `results/dummy.txt` after review; force-add exactly the archived `worker_001.stdout.log` with verified bytes rather than broadly unignore all logs.
- No file is claimed to be ratified/committed. No automation or destructive tests are run.
