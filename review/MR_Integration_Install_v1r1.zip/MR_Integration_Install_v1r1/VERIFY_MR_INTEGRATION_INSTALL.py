#!/usr/bin/env python3
"""Read-only installation verifier for the ratified method-ranking integration (Claude, 27 Oct 2026; r1).

Standard library only. Does not import project code, run tests, change files or touch Git state.
Phases:
  pre        clean tree; HEAD descends from the base commit; every new path absent;
             ratified predecessor editions unchanged at HEAD.
  post       after copying the overlay: every new file has the expected bytes (CRLF tolerated in
             the working copy; Git stores LF); predecessors unchanged; only the 10 expected
             paths are new or changed.
  committed  after the commit: clean tree; every expected file is in HEAD with the exact
             expected Git blob bytes; HEAD's parent commit changed exactly these 10 paths (all added).
Usage: python VERIFY_MR_INTEGRATION_INSTALL.py --repo . --phase pre|post|committed
"""
import argparse, hashlib, os, subprocess, sys
from pathlib import Path

HERE = Path(__file__).resolve().parent
BASE = 'c5424839d8fc9d620bae132873e8594b5651d2ce'
PREDECESSORS = {  # ratified editions that must stay byte-identical in Git (LF content SHA-256)
    'doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_4.md': '78e2818ab71f6fce68cf1b39b24f5d0f2ad5563f7143b4358a3bcf5b6d49c752',
    'doc/Predictive_Randomness_Experimental_Method_Specifications_R2_v0_4.md': '1a1853570197a4a62a7d5695417848aac2de65b5fc83c25a931d936c84e05ef4',
    'doc/Predictive_Randomness_Software_Architecture_Discussion_v0_7.md': '6c7ba2bc1da0d7b1f81e6e2e62e7c1e69448122bdf149399ae560f0c361b7218',
    'doc/Predictive_Randomness_Research_Project_Proposal_v0_5.md': '834c0a8e738979ae5bed3527fd946d4f9b0f6a4d77dcbf6d087f1437db731d58',
    'doc/RATIFICATION_REGISTER_v0_3.md': '99e75fbe1bc5cea34a7d2b1c456633815b88e340c4a05aab5fb671d624c7ec37',
    'doc/Predictive_Randomness_Method_Ranking_Measures_Proposal_v0_5.md': 'c6ca2cb2174ee2963a6fe33347820c80b92e6dd1eda518a1f0c8e3254d67ab19',
    'review/Predictive_Randomness_MR_Integration_Candidates_v3.zip': 'af0e3b81d4c8deb5c818ac47c47ac8498059628b66dd681cdd9cc1c43d9d5324',
}
MANIFEST = 'review/MR_Integration_Install_v1/INSTALL_MANIFEST_SHA256.txt'
# r1 (C-INSTALL-01): every Git call uses --no-optional-locks and GIT_OPTIONAL_LOCKS=0, so that
# 'git status' never refreshes or rewrites .git/index (git-status docs, BACKGROUND REFRESH).
GIT_ENV = dict(os.environ, GIT_OPTIONAL_LOCKS='0')


def sha(b):
    return hashlib.sha256(b).hexdigest()


def git(repo, *args):
    r = subprocess.run(['git', '--no-optional-locks', '-C', str(repo), *args],
                       stdout=subprocess.PIPE, stderr=subprocess.PIPE, env=GIT_ENV)
    if r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed: {r.stderr.decode(errors="replace")[:300]}')
    return r.stdout


def need(cond, msg):
    if not cond:
        raise RuntimeError('FAIL: ' + msg)


def expected():
    """Path -> SHA-256: the manifest's installed-file list, plus the manifest's own bytes."""
    raw = (HERE / 'repo_overlay' / MANIFEST).read_bytes()
    exp = {}
    for line in raw.decode('ascii').splitlines():
        if line and not line.startswith('#'):
            h, p = line.split('  ', 1)
            exp[p] = h
    exp[MANIFEST] = sha(raw)
    need(len(exp) == 10, f'expected 10 files in the package manifest, found {len(exp)}')
    for p, h in exp.items():  # the package itself must be intact
        need(sha((HERE / 'repo_overlay' / p).read_bytes()) == h, f'package file damaged: {p}')
    return exp


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--repo', type=Path, required=True)
    ap.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    a = ap.parse_args()
    repo = a.repo.resolve()
    need((repo / '.git').exists(), f'not a Git checkout: {repo}')
    exp = expected()
    head = git(repo, 'rev-parse', 'HEAD').decode().strip()
    anc = subprocess.run(['git', '--no-optional-locks', '-C', str(repo), 'merge-base', '--is-ancestor', BASE, 'HEAD'],
                         env=GIT_ENV)
    need(anc.returncode == 0, f'HEAD {head} does not descend from base {BASE}; STOP')
    print('HEAD:', head, '(descends from base', BASE[:7] + ')')
    status = git(repo, 'status', '--porcelain', '--untracked-files=all').decode(errors='replace')
    for p, h in PREDECESSORS.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'ratified predecessor changed in Git: {p}')
    print(f'{len(PREDECESSORS)} ratified predecessor files unchanged in Git HEAD')

    if a.phase == 'pre':
        need(not status.strip(), 'working tree or index not clean:\n' + status[:600])
        for p in exp:
            need(not (repo / p).exists(), f'new path already exists: {p}; STOP, do not overwrite')
        print('PRE PASS: clean tree; all 10 new paths absent. Nothing was changed.')
        return

    if a.phase == 'post':
        changed = set()
        for line in status.splitlines():
            path = line[3:].strip().strip('"')
            changed.add(path.replace('\\', '/'))
        need(changed == set(exp), 'unexpected changed paths: ' + ', '.join(sorted(changed ^ set(exp))))
        for p, h in exp.items():
            f = repo / p
            need(f.is_file() and not f.is_symlink(), f'missing or symlink: {p}')
            need(sha(f.read_bytes().replace(b'\r\n', b'\n')) == h, f'wrong bytes: {p}')
        print('POST PASS: exactly the 10 expected new files, all with the expected bytes.')
        return

    need(not status.strip(), 'working tree or index not clean after commit:\n' + status[:600])
    for p, h in exp.items():
        need(sha(git(repo, 'show', f'HEAD:{p}')) == h, f'wrong Git blob in HEAD: {p}')
    names = git(repo, 'diff', '--name-status', 'HEAD~1', 'HEAD').decode().splitlines()
    got = {ln.split('\t', 1)[1]: ln.split('\t', 1)[0] for ln in names if ln}
    need(set(got) == set(exp) and set(got.values()) == {'A'},
         'the last commit did not add exactly the 10 expected paths: ' + repr(sorted(got.items()))[:600])
    print('COMMITTED PASS: the last commit added exactly the 10 files; all 10 Git blobs match.')


if __name__ == '__main__':
    try:
        main()
        print('Read-only: no project code imported, nothing run, nothing changed.')
    except Exception as exc:
        print('VERIFICATION STOP:', exc, file=sys.stderr)
        sys.exit(2)
