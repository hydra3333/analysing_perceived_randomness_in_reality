@echo off
setlocal
rem OPTIONAL owner-run staging of exactly the 10 installation files. No commit, push or deletion.
git add -- ^
  "doc\HANDOVER\Claude_Checkpoint_v2.md" ^
  "doc\Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md" ^
  "doc\Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md" ^
  "doc\Predictive_Randomness_Research_Project_Proposal_v0_6.md" ^
  "doc\Predictive_Randomness_Software_Architecture_Discussion_v0_8.md" ^
  "doc\RATIFICATION_REGISTER_v0_4.md" ^
  "review\Independent_ChatGPT_Focused_Review_MR_Integration_Candidates_v3.md" ^
  "review\MR_Integration_Install_v1\INSTALL_MANIFEST_SHA256.txt" ^
  "review\MR_Integration_Install_v1\install_status_edits.py" ^
  "review\MR_Integration_Install_v1\v3_to_installed.diff"
if errorlevel 1 (echo STAGING FAILED & exit /b 1)
git status --short
endlocal
