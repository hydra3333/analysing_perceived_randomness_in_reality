# Method ranking integration - installation package v1r1

**Prepared by Claude, 27 October 2026. r1:** the verifier alone changed, applying the ChatGPT reviewer's C-INSTALL-01: every Git call now uses `--no-optional-locks` (and `GIT_OPTIONAL_LOCKS=0`), so `git status` cannot refresh `.git/index`. The 10 overlay files, the manifest and every hash are unchanged from v1 (`154924d8...ab36`).

**Earlier note:** The owner ratified integration candidates v3 (`af0e3b81...5d324`) on 27 October 2026. The owner copies, stages, commits and pushes; Claude then verifies against Git. Nothing here authorises any run, test, holdout access, switch change or code change.

## 1. What this ZIP holds

- `repo_overlay/`: **10 new files**, no changes to existing files, no deletions.
  - `doc/`: the five ratified editions (R3 v0.5, R2 v0.5, Architecture v0.8, Proposal v0.6, register v0.4). Each is the reviewed v3 candidate plus **status edits only** (section 2).
  - `review/Independent_ChatGPT_Focused_Review_MR_Integration_Candidates_v3.md`: the ChatGPT reviewer's v3 PASS, as received.
  - `review/MR_Integration_Install_v1/`: the external manifest (`INSTALL_MANIFEST_SHA256.txt`, which holds the register's own SHA-256), the script that made the status edits, and the exact v3-to-installed diff.
  - `doc/HANDOVER/Claude_Checkpoint_v2.md`: Claude's running checkpoint (not authoritative).
- `VERIFY_MR_INTEGRATION_INSTALL.py`: a read-only checker (standard library only; changes nothing).
- `STAGE_EXACT_FILES.cmd`: optional; stages exactly the 10 files. It does not commit or push.

## 2. The status edits (all of them are in `v3_to_installed.diff`)

37 lines change across the five files; no line outside these changes:

- **Edition headers:** "RATIFICATION CANDIDATE ... until then X governs" becomes "OWNER-RATIFIED 27 October 2026; X is historical" (version, date and status lines).
- **Present-authority pointers:** the lines and table rows that name the governing editions now name R2 v0.5, R3 v0.5, Architecture v0.8 and Proposal v0.6, with their predecessors marked historical. These are: the R3 header and section 0.1 rows; the R2 header; the Architecture section 0 sentence and section 0.2 rows (the separate v0.7 and v0.8 rows become one v0.8 row); the Proposal section 0 sentence; and the shared "Current development data" paragraph's final sentence (4 identical copies, kept identical).
- **R3 17.13 stage 0:** "integration ... in progress" becomes "integrated ..., owner-ratified 27 October 2026".
- **Register v0.4:** its version line, the integration table (status and the four recomputed hashes), the MR v0.5 and register v0.3 rows, and the dated "On owner ratification" and interpretation lines. The reviewer's verbatim texts (C-03 and C-v2-01) are kept word for word.

Protected blocks (R3 0.4, 2.4, 3; R2 7 and 4.1; Architecture 5C; Proposal E_1-E_6) are byte-identical. Every inserted character is ASCII.

**Deliberately not edited** (they describe other events, not this integration; the next register edition records them at the transition commit): the Package 2 "pending/outstanding" statements, the "ChatGPT implements, Claude reviews" role statements, and the register's "Continuity documents" line.

## 3. Install (Windows CMD, repository root)

**First, make the tree clean.** Move every untracked file out of the repository (for example to `E:\TEMP\keep`): `git status --short` must print nothing. In particular `review\Independent_ChatGPT_Focused_Review_MR_Integration_Candidates_v3.md` is supplied by the overlay itself, so your own copy must not be in the tree. The ChatGPT install review, the v1 ZIP and this ZIP are committed later, with the transition commit.

Extract this ZIP into `E:\TEMP`; that creates `E:\TEMP\MR_Integration_Install_v1r1\`. Then:

```bat
git rev-parse HEAD
git status --short
python "E:\TEMP\MR_Integration_Install_v1r1\VERIFY_MR_INTEGRATION_INSTALL.py" --repo . --phase pre
```

Expected: `PRE PASS`. If anything else, **stop** and send Claude the output.

Copy the **contents** of `repo_overlay` (the `doc` and `review` folders) onto the repository root. Accept merging into the existing `doc`, `doc\HANDOVER` and `review` folders; there should be **no** "replace file" prompt. If one appears, cancel and send Claude a note.

```bat
python "E:\TEMP\MR_Integration_Install_v1r1\VERIFY_MR_INTEGRATION_INSTALL.py" --repo . --phase post
call "E:\TEMP\MR_Integration_Install_v1r1\STAGE_EXACT_FILES.cmd"
git diff --cached --name-status
```

Expected: `POST PASS`; then ten lines starting with `A`. Git may print "LF will be replaced by CRLF" warnings; they are harmless (Git stores LF).

Commit with a message of your choice, for example `Install ratified method-ranking integration (R3 v0.5, R2 v0.5, Architecture v0.8, Proposal v0.6, register v0.4)`, then push. Then:

```bat
python "E:\TEMP\MR_Integration_Install_v1r1\VERIFY_MR_INTEGRATION_INSTALL.py" --repo . --phase committed
git rev-parse HEAD
```

Expected: `COMMITTED PASS`. Send Claude the commit ID; Claude then verifies every blob independently from GitHub.
