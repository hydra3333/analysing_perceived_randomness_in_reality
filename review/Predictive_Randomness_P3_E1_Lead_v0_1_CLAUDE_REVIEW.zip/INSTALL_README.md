# P3 E_1 lead v0.1 - REVIEW ONLY

This is a candidate review overlay against repository baseline 18fa741353399241380cfc8f52e35cbcf01f9dd6. No existing file is replaced. It is NOT an installation/production approval. Use fresh scratch extraction for Claude. No real draws or holdout are included.

Files:
- doc/experiments/P3_E1_Lead_Method_Design_v0_1_REVIEW_CANDIDATE.md
- doc/experiments/P3_Forecast_Store_And_Score_Last_Draw_v0_1_REVIEW_CANDIDATE.md
- src/methods/E_1_Historical_Appearance_Frequency.py (synthetic-only importable prototype; no CLI)
- tests/fixtures/p3_e1_synthetic_v0_1.json
- tests/p3_e1_synthetic_contract_v0_1.py
- review/P3_E1_Lead_Claude_Review_Request_v0_1.md
- TEST_OUTPUT.txt, SHA256_MANIFEST.json

Optional synthetic-only independent execution, from the extracted repository overlay (no venv activation required for the standard-library test):
  python tests/p3_e1_synthetic_contract_v0_1.py

This does NOT run the existing Windows coordinator, launch methods via BAT, read any real draw CSV, or write prediction data. Every actual P3 operational gate remains closed pending further review and approval.
