"""Independent, synthetic-only E_1 contract tests. Never touches real draws."""
from __future__ import annotations
import copy
import hashlib
import importlib.util
import json
from pathlib import Path
import sys

ROOT = Path(__file__).resolve().parents[1]
MOD_FILE = ROOT / 'src' / 'methods' / 'E_1_Historical_Appearance_Frequency.py'
SPEC = importlib.util.spec_from_file_location('p3_e1_synthetic_candidate', MOD_FILE)
assert SPEC and SPEC.loader
E1 = importlib.util.module_from_spec(SPEC)
sys.modules[SPEC.name] = E1
SPEC.loader.exec_module(E1)
F = json.loads((ROOT / 'tests' / 'fixtures' / 'p3_e1_synthetic_v0_1.json').read_text(encoding='utf-8'))
assert F['source_kind'] == 'SYNTHETIC_TEST_ONLY'
TARGET = F['target']


def independent_midrank(scores: dict[int, int], label: int) -> float:
    s = scores[label]
    higher = sum(v > s for v in scores.values())
    tied = sum(v == s for v in scores.values())
    return 1 + higher + (tied - 1) / 2


def evaluate_separately(frozen: dict, actual: dict, group_status: str) -> dict:
    # A FAILED or orphan-suspected group must never be consumed.
    if group_status != 'PASS':
        raise ValueError('FAILED/ORPHAN result firewall')
    if actual['draw'] != frozen['target_draw']:
        raise ValueError('outcome target mismatch')
    m, p = frozen['MAIN'], frozen['POWERBALL']
    actual_set = set(actual['main'])
    return {
        'main_top_matches': len(actual_set.intersection(m['top'])),
        'main_worst_matches': len(actual_set.intersection(m['worst'])),
        'powerball_top_hit': int(p['top'] == actual['powerball']),
        'powerball_worst_hit': int(p['worst'] == actual['powerball']),
        'mean_rank_main': sum(independent_midrank(m['scores'], j)
                              for j in actual_set) / 7,
        'rank_powerball': independent_midrank(p['scores'], actual['powerball']),
    }


def run() -> None:
    src = F['rows']
    f = E1.candidate_forecast(src, TARGET)
    assert f['last_training_draw'] == 1151
    mc = f['MAIN']['scores']
    pc = f['POWERBALL']['scores']
    for key, expected in F['hand_checked_counts'].items():
        kind, label = key.rsplit('_', 1)
        assert (mc if kind == 'main' else pc)[int(label)] == expected, key
    assert sum(mc.values()) == 56 and sum(pc.values()) == 8
    assert set(f['MAIN']['ranking']) == set(range(1, 36))
    assert set(f['POWERBALL']['ranking']) == set(range(1, 21))
    assert set(f['MAIN']['top']).isdisjoint(f['MAIN']['worst'])
    assert f['MAIN']['worst'] == list(reversed(f['MAIN']['ranking']))[:7]
    assert f['POWERBALL']['worst'] == f['POWERBALL']['ranking'][-1]
    assert f['MAIN']['ranking'][:3] == [1, 8, 2]
    assert f['POWERBALL']['ranking'][0] == 1
    assert f['MAIN']['ranking'][3:10] == sorted(
        f['MAIN']['ranking'][3:10],
        key=lambda j: (-mc[j], E1.tie_digest(f['training_view_sha256'], TARGET, 'MAIN', j), j))
    baseline = E1.canonical_bytes(f)
    gold = F['candidate_golden_vectors_not_yet_ratified']
    assert f['training_view_sha256'] == gold['training_view_sha256']
    assert E1.tie_digest(f['training_view_sha256'], TARGET, 'MAIN', 3) == gold['tie_main_label_3_sha256']
    assert hashlib.sha256(baseline).hexdigest() == gold['canonical_forecast_sha256']
    assert f['MAIN']['top'] == gold['main_top']
    assert f['MAIN']['worst'] == gold['main_worst']
    assert f['POWERBALL']['top'] == gold['pb_top']
    assert f['POWERBALL']['worst'] == gold['pb_worst']
    # Reordering within draws does not change unordered E_1.
    shuffled = copy.deepcopy(src)
    for row in shuffled:
        row['main'] = list(reversed(row['main']))
    assert E1.canonical_bytes(E1.candidate_forecast(shuffled, TARGET)) == baseline
    # Target and post-target mutations do not enter training view or seed.
    changed = copy.deepcopy(src)
    changed.extend([copy.deepcopy(F['future_actual_for_evaluator_only']),
                    {'draw':1153,'main':[2,6,9,11,14,18,33],'powerball':19}])
    assert E1.canonical_bytes(E1.candidate_forecast(changed, TARGET)) == baseline
    changed[-2]['main'] = [2,4,10,15,21,31,35]
    changed[-2]['powerball'] = 'POISONED_FUTURE_OUTCOME'
    changed[-2]['main'] = ['NOT_VALID', 'SHOULD_BE_IGNORED']
    assert E1.canonical_bytes(E1.candidate_forecast(changed, TARGET)) == baseline
    # A change to an allowed training draw MUST change the digest.
    changed = copy.deepcopy(src)
    changed[0]['main'] = [1,2,3,4,5,6,35]
    assert E1.candidate_forecast(changed, TARGET)['training_view_sha256'] != f['training_view_sha256']
    # Tests must refuse a missing training draw, duplicate, illegal main, and
    # attempts to relabel synthetic implementation as real production.
    for invalid in (src[:-1], src + [src[-1]],
                    [{**src[0], 'main':[1,1,2,3,4,5,6]}] + src[1:]):
        try:
            E1.candidate_forecast(invalid, TARGET)
        except ValueError:
            pass
        else:
            raise AssertionError('malformed prefix was accepted')
    try:
        E1.candidate_forecast(src, TARGET, source_kind='REAL')
    except ValueError:
        pass
    else:
        raise AssertionError('synthetic/real firewall absent')
    actual = F['future_actual_for_evaluator_only']
    scores = evaluate_separately(f, actual, 'PASS')
    assert scores['main_top_matches'] in range(8)
    assert scores['main_worst_matches'] in range(8)
    assert scores['powerball_top_hit'] == 1
    assert scores['mean_rank_main'] >= 1
    for invalid in ('FAIL', 'ORPHAN_SUSPECTED'):
        try:
            evaluate_separately(f, actual, invalid)
        except ValueError:
            pass
        else:
            raise AssertionError('failed-group result was consumed')
    # Different readout version is allowed to change ordering, never the
    # native appearance-count score vectors.
    score_copy = copy.deepcopy(f['MAIN']['scores'])
    E1.rank_counts(score_copy, f['training_view_sha256'], TARGET, 'MAIN')
    assert score_copy == f['MAIN']['scores']
    print('PASS: synthetic-only E_1 counts, N-1 perturbation, readout reversal,')
    print('      rank scoring separation, failed-group firewall, real-data refusal')
    print('FORECAST_SHA256:', hashlib.sha256(baseline).hexdigest())
    print('TOP_MAIN:', f['MAIN']['top'], 'WORST_MAIN:', f['MAIN']['worst'])
    print('TOP_PB:', f['POWERBALL']['top'], 'WORST_PB:', f['POWERBALL']['worst'])
    print('SCORING_SYNTHETIC_ONLY:', scores)
    print('NOT TESTED: real dataset, holdout, Windows .bat, status lifecycle,')
    print('            immutable publication, coordinator, actual forecasts')


if __name__ == '__main__':
    run()
