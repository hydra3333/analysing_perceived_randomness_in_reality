# Predictive Randomness - frozen forecast store and score-last-draw - v0.1 REVIEW CANDIDATE

**Date:** 23 October 2026. **Status:** DESIGN ONLY; NOT a ratified production schema. Governing R2 v0.3 + approved erratum and R3 v0.2 remain authoritative.

## Purpose

Make the eventual recurring operator workflow reliable: `refresh scraper(s) -> validate chronology -> score ONLY the previously frozen forecast for the newly known draw -> extend allowable training history -> fit all runnable methods -> freeze and publish the next draw's complete batch`. Scoring never computes a new forecast for the draw being evaluated. This weekly cycle begins only after the owner decides development is sufficiently complete.

## Proposed append-only file responsibilities

**Real draw history:** validated source CSVs with the original set and drawn-order representations, same draw identities, current rules 1144 onward. A scraper output must be validated for duplicate/gap/mismatch/format before any scorer or trainer uses a new draw. A stale or partial scrape must not trigger publish.

**Pre-draw FINAL frozen batch** (suggested namespace only; exact paths to approve): `results/forecasts/FINAL/target_N/batch_manifest.json`, separate per-method forecast artifacts and SHA-256 inventory. Manifest identifies target N, last training draw N-1, method and variant catalogue, actual usable/unavailable/failed entries, permitted-training-view digest per method, frozen TOP/WORST and full scores/rankings, engine/spec/readout versions, and an explicit `forecast_content_sha256` based on admissible inputs only. Whole source CSV hash, run ID, local timestamps and Git commit/push evidence belong in separate audit provenance, not as forecast-content seed inputs.

**Remote proof:** preserve commit+push evidence showing the COMPLETE batch was public before its target draw. A generated file saved locally is not enough to claim a prospective forecast. Files are created once (`O_EXCL` / equivalent no-clobber, fsync, directory flush when supported); never overwrite frozen target artifacts. Any post-result reconstruction is labelled RETROSPECTIVE, stored separately, and cannot enter the previously frozen batch.

**After-draw immutable score** (suggested): `results/scores/FINAL/target_N/score_manifest.json` plus keyed tracks. The scorer gets the archived immutable frozen batch for target N and *only after that* validated actual result N. It checks source draw identity, frozen full ranking, selection readout version and parent frozen content hashes, then computes: main TOP matches, main WORST matches (0..7 each); PB TOP and WORST hit (0/1); evaluator-only mean mid-rank of seven actual main labels (1..35), actual PB mid-rank (1..20). Never update the original forecast. Preserve independent method/variant/barrel/readout performance tracks and coverage/failure denominators.

## Critical group firewall (OWNER-RATIFIED 23 Oct)

Before **any downstream consumer** opens a worker `canonical_result.json`, it MUST first verify the corresponding coordinator group manifest exists, has `PASS` and has no orphan-suspected or marker-write-failed condition. If it reports `FAIL`/`ORPHAN_SUSPECTED`, or the status is absent, corrupt or mismatched, **do not consume** even if `canonical_result.json` exists. The group and worker identity must match the result. For standalone operation, define an equivalent independently verified run-success manifest and validator; never pretend an uncoordinated run is a coordinator PASS.

A later `canonical_result.json` publication by an experiment after timeout must NOT be interpreted as successful completion. The prior real timeout incident remains FAILED permanently. Tests must try to trick each consumer with an orphan-marked result and verify refusal.

## Proposed weekly command-line shape (NOT IMPLEMENTED)

`python src/refresh_and_validate_draw_history.py` (may invoke existing scraper(s))

`python src/score_frozen_last_draw.py --target=N` (requires exact archived frozen target N)

`python src/train_and_freeze_next_draw.py --target=N+1` (gated FINAL batch, all registered methods)

Any eventual umbrella `.bat` may wrap these steps, but separate failure and audit reports are required; no current file/command claims to exist. Do not assume every method's fit updates incrementally; some re-fit from full eligible history, while others use a declared rolling state. Do not automatically run FINAL while only a partial method catalogue is implemented.

## Recommended tests before any operational use

- Poison historical target N outcome and all future rows: earlier forecast bytes unchanged (T-05).
- Change source whole-file filename/hash but preserve permitted rows: model content unchanged; audit may differ.
- Replace prior frozen batch content after proof: scorer detects hash mismatch and refuses.
- Supply a FAIL or ORPHAN manifest with a valid-looking `canonical_result.json`: all consumers refuse.
- Actual draw target != frozen target: refuse; incomplete source update: refuse.
- Duplicate target score: refuse without mutating old score.
- Native-score mid-rank uses tie groups, not digest tie ordering.
- Crashed/NOT_IMPLEMENTED method remains counted in method registry and batch coverage.
- No `FINAL` batch is called prospective unless genuinely committed/pushed before actual draw.

**DECIDED:** explicitly separate immutable prediction and later evaluation; report TOP/WORST/mid-ranks; keep target IDs and method tracks; fail closed on corrupted provenance.

**RECOMMENDED:** proposed store namespaces, required status+hash fields, CLI workflow split, create-only writes and remote publication evidence.

**OPEN:** exact canonical schemas, CLI arguments, staged/atomic publication protocol, rollback/retry without overwriting, Git push proof representation, method registry enumerations, where the shared production group-status validator is located.
