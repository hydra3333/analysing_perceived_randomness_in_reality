# Claude - independent review request: P3 E_1 synthetic lead v0.1

**Baseline:** owner-reported clean pushed HEAD `18fa741353399241380cfc8f52e35cbcf01f9dd6`, with ratified Architecture v0.5, R2 v0.3 + erratum, R3 v0.2 and Task Spec v0.2. These files in the package are all **new additions**: no source code or ratified docs replaced.

Please independently review the exact proposed formulas, hand-check fixture, candidate length32 canonical tie encoding, N-1/future-data noninterference, SOURCE_KIND barrier, TOP/WORST exact reversal, evaluator-only rank position, result firewall and future store/scoring protocol. Pay particular attention to whether any **DECIDED** line should be **RECOMMENDED** instead, any leakage through whole-file hashes/target outcomes, and any mismatch against the governing docs.

Review synthetic test output and source. Recompute the fixture's hand-check count identities and canonical tie SHA vectors independently where practical. Explicitly distinguish test PASS from untested Windows/production/real-data behaviours. We request no permission to enable termination, launch real E-methods, unseal holdout, perform destructive tests, or begin genuine forecasts. E_1 first formula and concrete tie-key byte encoding are left RECOMMENDED pending owner ratification.

Optional short paste-ready verdict should include BLOCKERS vs DEFERRABLE and any owner decisions needing ratification.
