# Transition documents for review - package v1

**Work-item card**

| Field | Value |
|---|---|
| Item | TRANS-1: H-1, H-3 and register v0.5 for the AI roles transition commit; Claude's fact check of H-2 |
| Author chat | Claude (new Claude chat) |
| Reviewer chat | ChatGPT reviewer chat |
| Base commit | `ae76c29783856dbb9bf0076fabe0c3612340314e` (integration installed; Claude-verified) |
| Scope | Three new documents (H-1, H-3, register v0.5); no change to any existing file |
| Risk tier | HIGH (authority text; the register) |
| Owner gate | The owner ratifies H-1, H-2, H-3 and register v0.5, then installs all four in one transition commit |
| Evidence state | IMPLEMENTED (drafts); not reviewed |

**Date:** 27 October 2026 (Adelaide). **Holdout statement:** no draw outcome appears in or was used for these files. The only number lists are the frozen E_1 forecast outputs, in H-1 section 7.2.

## Contents

| File | Proposed repository path | SHA-256 of this file / of its Git (LF) content where different |
|---|---|---|
| `Claude_Primary_Handover_H1_v1.md` (ASCII, CRLF) | `doc/HANDOVER/Claude_Primary_Handover_H1_v1.md` | `9944be3550dd9039f2bd4798bbfd1616cf27d37af8c78c6bf32be3f85301156a` / `4f26603038b5b38f61047a74b2b2afcd75e7a099770b3120d6542cfe91371055` |
| `AI_Roles_Transition_Record_H3_v1.md` (ASCII, CRLF) | `doc/HANDOVER/AI_Roles_Transition_Record_H3_v1.md` | `10bc0f17cbcda2d4b593f865d6b1e6afc74305c587c648cca597a4cc6c341ccd` / `84e3455f64f9f4609f37c886c0d39d78ce653b377483010430ec305f20cc1226` |
| `RATIFICATION_REGISTER_v0_5.md` (UTF-8, LF, as its lineage) | `doc/RATIFICATION_REGISTER_v0_5.md` | `799452eac38b3dcb5f356bce1c906115a408d1385e228179f6c94bf355b6ebf5` |
| `register_v0_4_to_v0_5.diff` | (review evidence) | `01ae586f6337077ee7700a4fc570846822f7b47db9d7b8df0de0b381ec55be08` |
| `make_register_v05.py` | (review evidence) | `0bb63d4f3bacce1a67f89b8ac194e438ee145d6ff108ff5f3290183d0e072c55` |
| `Claude_Fact_Check_H2_v1_v1.md` (ASCII, CRLF) | `review/Claude_Fact_Check_H2_v1_v1.md` | `a170a16d37a8eebc80fb28661709abae09368bc174fb5938749800b0dccedb40` / `f1fce84c6e6c922b1340a6a7dcb1430a581677467e595f5ad181e92de65ea131` |


## What each is

- **H-1:** Claude's handover as primary designer and coder (agreed position 9.4). Self-contained; replaces, for future roles, reviewer handover v10, coder handover v1.1r1, the interim note and checkpoint v2.
- **H-3:** the transition record: the effective commit decision, the agreed sequence as carried out with evidence, retirements, supersession, the Package 2 erratum, the transition commit's contents and a ratification checklist.
- **Register v0.5:** made from installed register v0.4 by `make_register_v05.py` (counted, in-place replacements; inserted text ASCII). It records the roles ratification, the effective commit (described, since it cannot name itself), Package 2 acceptance at `c542483`, the integration installation at `ae76c29`, supersessions, and the out-of-date statements in the ratified editions (the register prevails; the files are not edited). Protected text untouched: only six existing lines change, plus one new section.
- **Fact check of H-2:** facts PASS with 3 CORRECTION and 3 OPTIONAL; the rights block is byte-identical to the agreed position. The rights themselves are for the owner alone.

## Placeholders (filled mechanically at installation, after review and ratification)

- Register v0.5: `[H1-SHA]`, `[H2-SHA]`, `[H3-SHA]`, the Git-content SHA-256 of the final H-1, H-2, H-3. The status cells read RATIFICATION CANDIDATE until the owner ratifies.
- H-3: `[REVIEW]` (this review's file name and verdict) and `[H-2 REVISION]` (the H-2 revision that applies the fact-check corrections).
The register's own SHA-256 goes in the transition install manifest, never in the register.

## What to review

1. Facts and chronology in H-1 and H-3 against the repository at `ae76c29` and the cited files.
2. Register v0.5: each changed line and the new section; that no historical row or hash changed; that nothing adds authority.
3. That H-1 supports, and nowhere narrows, the reviewer's rights.
4. Anything a cold-start Claude would need that H-1 lacks.

*End of README.*
