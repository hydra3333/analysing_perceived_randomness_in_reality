"""Offline-only Package 2 foundations; NEVER reads actual lottery sources."""
from __future__ import annotations

import csv
import hashlib
import json
import sys
import tempfile
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'src' / 'methods'))

from _common.game_profiles_v1 import POWERBALL, OZLOTTO, get_profile
from _common.multigame_u_view_v1 import columns_for, read_u_training_prefix
from _common.multigame_structural_audit_v1 import (
    audit_snapshot_pair, proposed_oz_holdout_metadata, raw_columns_for,
)


def make_rows(p, count=14):
    winning, raw = [], []
    for i in range(count):
        n = p.first_draw + i
        winning_balls = []
        for barrel in p.barrels:
            winning_balls.extend(range(barrel.low, barrel.low + barrel.selected))
        w = [n, p.derived_date(n).isoformat(), *winning_balls]
        extra = []
        if p.raw_supplementary_count:
            main = p.barrels[0]
            extra = list(range(main.low + main.selected, main.low + main.selected + p.raw_supplementary_count))
        winning.append(w)
        raw.append(w + extra)
    return winning, raw


def write_csv(path, columns, rows):
    with path.open('w', encoding='utf-8', newline='') as f:
        w = csv.writer(f)
        w.writerow(columns)
        w.writerows(rows)


class ProfileTests(unittest.TestCase):
    def test_profile_schema(self):
        self.assertEqual(get_profile('POWERBALL'), POWERBALL)
        self.assertEqual(POWERBALL.draw_key(1577), 'POWERBALL_1577')
        self.assertEqual(OZLOTTO.draw_key(1577), 'OZLOTTO_1577')
        self.assertNotEqual(POWERBALL.draw_key(1577), OZLOTTO.draw_key(1577))
        with self.assertRaises(ValueError): get_profile('powerball')
        self.assertEqual(len(POWERBALL.barrels), 2)
        self.assertEqual(len(OZLOTTO.barrels), 1)
        self.assertEqual(OZLOTTO.barrels[0].high, 47)

    def test_holdout_only_historical(self):
        self.assertTrue(POWERBALL.historical_development_target_allowed(1577))
        self.assertFalse(POWERBALL.historical_development_target_allowed(1578))
        self.assertFalse(OZLOTTO.historical_development_target_allowed(1475))
        sealed = OZLOTTO.with_sealed_holdout(1696,1705)
        self.assertTrue(sealed.historical_development_target_allowed(1695))
        self.assertFalse(sealed.historical_development_target_allowed(1696))
        self.assertIsNone(OZLOTTO.holdout_first)

    def test_derived_date(self):
        self.assertEqual(POWERBALL.derived_date(1145).isoformat(), '2018-04-26')
        self.assertEqual(OZLOTTO.derived_date(1474).isoformat(), '2022-05-17')
        self.assertEqual(OZLOTTO.derived_date(1475).isoformat(), '2022-05-24')

    def test_oz_raw_and_winning_columns(self):
        self.assertEqual(columns_for(OZLOTTO), ('Draw_Number','Date','Ball_1','Ball_2','Ball_3','Ball_4','Ball_5','Ball_6','Ball_7'))
        self.assertEqual(len(raw_columns_for(OZLOTTO)), 12)
        self.assertEqual(columns_for(POWERBALL)[-1], 'Powerball')

    def test_metadata_audit_oz(self):
        with tempfile.TemporaryDirectory() as temp:
            tmp=Path(temp)
            win, raw=make_rows(OZLOTTO)
            w=tmp/'w.csv'; r=tmp/'r.csv'
            write_csv(w, columns_for(OZLOTTO),win)
            write_csv(r, raw_columns_for(OZLOTTO),raw)
            report=audit_snapshot_pair(w,r,OZLOTTO)
            self.assertTrue(report['structurally_accepted'],report)
            self.assertEqual(report['row_count'],14)
            self.assertEqual(report['date_warnings'],[])
            self.assertEqual(report['last_draw'],1487)
            holdout=proposed_oz_holdout_metadata(report)
            self.assertEqual((holdout['holdout_first'],holdout['holdout_last']),(1478,1487))
            self.assertEqual(holdout['status'],'PROPOSED_ONLY_NOT_SEALED')
            # No ball values exposed in the public audit report.
            self.assertNotIn('Ball_1', str(report))
            self.assertNotIn('winning_numbers',str(report))

    def test_date_anomaly_is_warning(self):
        with tempfile.TemporaryDirectory() as temp:
            tmp=Path(temp);win,raw=make_rows(OZLOTTO)
            win[5][1]='2022-07-04'; raw[5][1]='2022-07-04'
            w=tmp/'w.csv';r=tmp/'r.csv'
            write_csv(w,columns_for(OZLOTTO),win)
            write_csv(r,raw_columns_for(OZLOTTO),raw)
            report=audit_snapshot_pair(w,r,OZLOTTO)
            self.assertTrue(report['structurally_accepted'])
            self.assertEqual(report['date_warnings'],[{'draw_number':1479,'field':'Date','issue':'DERIVED_DATE_MISMATCH_OR_INVALID'}])

    def test_supplementary_invalid_fails_without_values(self):
        with tempfile.TemporaryDirectory() as temp:
            tmp=Path(temp);win,raw=make_rows(OZLOTTO)
            raw[11][-1]=raw[11][2]
            w=tmp/'w.csv';r=tmp/'r.csv'
            write_csv(w,columns_for(OZLOTTO),win)
            write_csv(r,raw_columns_for(OZLOTTO),raw)
            report=audit_snapshot_pair(w,r,OZLOTTO)
            self.assertFalse(report['structurally_accepted'])
            self.assertIn({'draw_number':1485,'field':'SUPPLEMENTARY','issue':'INVALID_OR_NOT_DISTINCT'}, report['errors'])

    def test_bad_or_truncated_source(self):
        with tempfile.TemporaryDirectory() as temp:
            tmp=Path(temp);win,raw=make_rows(OZLOTTO)
            win.pop(2)
            w=tmp/'w.csv';r=tmp/'r.csv'
            write_csv(w,columns_for(OZLOTTO),win)
            write_csv(r,raw_columns_for(OZLOTTO),raw)
            report=audit_snapshot_pair(w,r,OZLOTTO)
            self.assertFalse(report['structurally_accepted'])

    def test_generic_e1_legacy_powerball_rank_regression(self):
        # Reuse the original 1577 view digest, NEVER inspect real outcomes.
        from _common.multigame_e1_v1 import _digest
        from _common.e1_historical_appearance_frequency_v0_3 import tie_digest
        digest='d47fbbd6e60e6abc429fb74f47d8bbeafc6560152c2ecddb3b75d79932df4339'
        for barrel,labels in (('MAIN',range(1,36)),('POWERBALL',range(1,21))):
            for label in labels:
                self.assertEqual(_digest(digest,1577,barrel,label),tie_digest(digest,1577,barrel,label))

    def test_one_barrel_forecast_pb_absent(self):
        from _common.multigame_e1_v1 import forecast
        p=OZLOTTO.with_sealed_holdout(1484,1493)
        rows=[{'draw':1474+i,'MAIN':list(range(1,8))} for i in range(4)]
        result=forecast(p,rows,'0'*64,1478,data_kind='SYNTHETIC_CONTRACT_TEST')
        self.assertEqual(list(result['barrels']),['MAIN'])
        self.assertNotIn('POWERBALL', result['barrels'])
        self.assertEqual(result['barrels']['MAIN']['scores']['1'],4)
        self.assertEqual(len(result['barrels']['MAIN']['ranking']),47)
        self.assertEqual(result['draw_key'],'OZLOTTO_1478')
        with self.assertRaises(ValueError):
            forecast(p,rows,'0'*64,1478,data_kind='REAL_HISTORICAL_DEVELOPMENT')

    def test_method_registry_full_and_conservative(self):
        from _common.multigame_method_registry_v1 import all_statuses, method_status
        for game in ('POWERBALL','OZLOTTO'):
            self.assertEqual(len(all_statuses(game)),62)
            self.assertEqual(method_status(game,'E_1'),'SUPPORTED')
            self.assertEqual(method_status(game,'E_54'),'FORMULA_OPEN')
        with self.assertRaises(ValueError): method_status('OZLOTTO','E_63')

    def test_method_generic_synthetic_status_and_firewall(self):
        from _common.multigame_e1_v1 import forecast
        from _common.multigame_standalone_contract_v1 import (
            begin_synthetic,publish_synthetic_success,verify_synthetic_and_consume,
        )
        p=OZLOTTO.with_sealed_holdout(1484,1493)
        rows=[{'draw':1474+i,'MAIN':list(range(1,8))} for i in range(4)]
        result=forecast(p,rows,'0'*64,1478,data_kind='SYNTHETIC_CONTRACT_TEST')
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp)
            run_id='mg-testidentity001'
            run,status=begin_synthetic(root,run_id=run_id,profile=p,target=1478,
                                       method_id='E_1',variant_id='FULL_HISTORY_RAW_COUNTS_V1')
            manifest=publish_synthetic_success(run,status,result)
            marker=root/'UNRESOLVED_ORPHAN.json'
            loaded=verify_synthetic_and_consume(run,run_id=run_id,profile=p,
                method_id='E_1',variant_id='FULL_HISTORY_RAW_COUNTS_V1',
                target=1478,global_orphan_marker=marker)
            self.assertEqual(loaded,result)
            self.assertEqual(manifest['state'],'PASS')
            marker.write_text('{}')
            with self.assertRaises(ValueError):
                verify_synthetic_and_consume(run,run_id=run_id,profile=p,
                    method_id='E_1',variant_id='FULL_HISTORY_RAW_COUNTS_V1',
                    target=1478,global_orphan_marker=marker)
            marker.unlink()
            with self.assertRaises(FileExistsError):
                begin_synthetic(root,run_id=run_id,profile=p,target=1478,
                                method_id='E_1',variant_id='FULL_HISTORY_RAW_COUNTS_V1')
            # Untrusted manifest cannot promote a FAILED run to success.
            f=run/'standalone_manifest.json';raw=f.read_bytes()
            f.write_bytes(raw.replace(b'"PASS"',b'"FAIL"'))
            with self.assertRaises(ValueError):
                verify_synthetic_and_consume(run,run_id=run_id,profile=p,
                    method_id='E_1',variant_id='FULL_HISTORY_RAW_COUNTS_V1',
                    target=1478,global_orphan_marker=marker)

    def test_create_only_synthetic_snapshot_pair(self):
        from _common.multigame_snapshot_publish_v1 import publish_synthetic_pair
        with tempfile.TemporaryDirectory() as temp:
            tmp=Path(temp); win,raw=make_rows(OZLOTTO)
            w=tmp/'winning.csv';r=tmp/'raw.csv'
            write_csv(w,columns_for(OZLOTTO),win)
            write_csv(r,raw_columns_for(OZLOTTO),raw)
            root=tmp/'output'
            rec=publish_synthetic_pair(winning_fixture=w,raw_fixture=r,
                profile=OZLOTTO,run_root=root,run_id='synthetic0001')
            self.assertFalse(rec['accepted_as_real_scientific_source'])
            self.assertEqual(rec['winning_sha256'],hashlib.sha256(w.read_bytes()).hexdigest())
            with self.assertRaises(FileExistsError):
                publish_synthetic_pair(winning_fixture=w,raw_fixture=r,
                    profile=OZLOTTO,run_root=root,run_id='synthetic0001')
            self.assertTrue((root/'OZLOTTO'/'synthetic0001'/'snapshot_record.json').exists())

    def test_new_view_prefix_only_oz_synthetic(self):
        p=OZLOTTO.with_sealed_holdout(1484,1493)
        with tempfile.TemporaryDirectory() as temp:
            src=Path(temp)/'test.csv'
            win,_=make_rows(OZLOTTO)
            write_csv(src,columns_for(OZLOTTO),win)
            a,d,anom=read_u_training_prefix(src,p,1478,source_kind='SYNTHETIC_CONTRACT_TEST')
            self.assertEqual([r['draw'] for r in a], [1474,1475,1476,1477])
            self.assertEqual(len(d),64)
            # Target/future poisoned; target prefix MUST be identical.
            win[4][:]=['POISON']*len(win[4]); win[6][:]=['POISON']*len(win[6])
            write_csv(src,columns_for(OZLOTTO),win)
            b,e,_=read_u_training_prefix(src,p,1478,source_kind='SYNTHETIC_CONTRACT_TEST')
            self.assertEqual(a,b)
            self.assertEqual(d,e)
            with self.assertRaises(ValueError):
                read_u_training_prefix(src,p,1484,source_kind='SYNTHETIC_CONTRACT_TEST')

    def test_new_real_u_mode_hard_disabled(self):
        p=OZLOTTO.with_sealed_holdout(1484,1493)
        with tempfile.TemporaryDirectory() as temp:
            path=Path(temp)/'unused.csv'
            with self.assertRaisesRegex(ValueError,'hard-disabled'):
                read_u_training_prefix(path,p,1478,source_kind='REAL_HISTORICAL_DEVELOPMENT',trusted_source_dir=Path(temp))

    def test_no_date_in_new_u_digest(self):
        p=OZLOTTO.with_sealed_holdout(1484,1493)
        with tempfile.TemporaryDirectory() as temp:
            src=Path(temp)/'test.csv';win,_=make_rows(OZLOTTO)
            write_csv(src,columns_for(OZLOTTO),win)
            _,d,_=read_u_training_prefix(src,p,1477,source_kind='SYNTHETIC_CONTRACT_TEST')
            win[1][1]='2022-09-01'
            write_csv(src,columns_for(OZLOTTO),win)
            _,e,an=read_u_training_prefix(src,p,1477,source_kind='SYNTHETIC_CONTRACT_TEST')
            self.assertEqual(d,e)
            self.assertEqual(an,(1475,))


if __name__=='__main__':
    unittest.main()
