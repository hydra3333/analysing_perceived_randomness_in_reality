"""Package-2 review candidate, OFFLINE fixture-only scraper entry.

The future Run_Scraper.bat uses this entry, but no live collection is
possible here until the independently reviewed source adapters and separate
owner-operated Package-3 scrape. This is not a replacement for existing
Powerball historical scraper.
"""
from __future__ import annotations
import argparse
import sys
from pathlib import Path


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--game',required=True,choices=('POWERBALL','OZLOTTO'))
    args=p.parse_args(argv)
    # Deliberate refusal BEFORE any model/data/network import.
    print(f'[SCRAPER] {args.game} live collection is DISABLED; Package 3 owner authorisation required',
          file=sys.stderr,flush=True)
    return 2

if __name__=='__main__':
    sys.exit(main())
