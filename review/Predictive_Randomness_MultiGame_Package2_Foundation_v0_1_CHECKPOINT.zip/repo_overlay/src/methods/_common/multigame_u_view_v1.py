"""Prefix-only, profile-driven NEW U view; legacy E_1 loader is untouched.

Read ONLY source header and rows in [first_draw, target-1]; never look ahead
or hash/stat the complete source. Date anomalies are metadata warnings and
block date-using methods elsewhere; they do not change the U-view digest.
"""
from __future__ import annotations

import csv
import hashlib
import re
from datetime import date
from pathlib import Path

from _common.game_profiles_v1 import GameProfile
from _common.e1_historical_appearance_frequency_v0_3 import canonical_bytes

_CANON = re.compile(r'(0|[1-9][0-9]*)\Z', re.ASCII)


def columns_for(profile: GameProfile) -> tuple[str, ...]:
    columns = ('Draw_Number', 'Date')
    for barrel in profile.barrels:
        if barrel.barrel_id == 'MAIN':
            columns += tuple(f'Ball_{k}' for k in range(1, barrel.selected + 1))
        elif barrel.selected == 1:
            columns += (barrel.barrel_id.title(),)
        else:
            columns += tuple(f'{barrel.barrel_id}_{k}' for k in range(1, barrel.selected + 1))
    return columns


def safe_snapshot_name(profile: GameProfile, name: str) -> bool:
    if profile.game_id == 'POWERBALL':
        # Legacy source basename remains accepted; never modify archived bytes.
        return re.fullmatch(r'australian_powerball_history_[0-9]{8}\.csv', name, re.ASCII) is not None
    return re.fullmatch(r'australian_ozlotto_winning_[0-9]{8}\.csv', name, re.ASCII) is not None


def _num(value: str, lo: int, hi: int, field: str) -> int:
    if not _CANON.fullmatch(value):
        raise ValueError(f'{field}: noncanonical decimal')
    x = int(value)
    if not lo <= x <= hi:
        raise ValueError(f'{field}: outside profile range')
    return x


def read_u_training_prefix(source: Path, profile: GameProfile, target: int, *,
                           source_kind: str, trusted_source_dir: Path | None = None):
    if source_kind not in ('SYNTHETIC_CONTRACT_TEST', 'REAL_HISTORICAL_DEVELOPMENT'):
        raise ValueError('unsupported mode')
    if source_kind == 'REAL_HISTORICAL_DEVELOPMENT':
        # PACKAGE-2 REVIEW GATE: never substitute this new unreviewed loader
        # for the independently accepted legacy Powerball real E_1 loader;
        # first Oz Lotto scientific execution needs its own owner authorisation.
        raise ValueError('new multi-game real U view is hard-disabled')
    if not profile.historical_development_target_allowed(target):
        raise ValueError('target outside currently authorised development range')
    if not isinstance(source, Path):
        raise ValueError('source must be an explicit Path')
    if source_kind == 'REAL_HISTORICAL_DEVELOPMENT':
        if (trusted_source_dir is None or
                source.parent.resolve(strict=True) != trusted_source_dir.resolve(strict=True) or
                source.is_symlink() or not source.is_file() or
                not safe_snapshot_name(profile, source.name)):
            raise ValueError('untrusted real winning-only snapshot')
    else:
        if trusted_source_dir is not None and source.resolve().is_relative_to(trusted_source_dir.resolve()):
            raise ValueError('synthetic source in real directory')
    rows = []
    date_anomalies: list[int] = []
    with source.open(encoding='utf-8-sig', newline='') as stream:
        reader = csv.reader(stream, strict=True)
        try:
            header = next(reader)
        except StopIteration as exc:
            raise ValueError('empty CSV') from exc
        if tuple(header) != columns_for(profile):
            raise ValueError('wrong winning-only columns or supplementary columns present')
        for expected in range(profile.first_draw, target):
            try:
                row = next(reader)
            except StopIteration as exc:
                raise ValueError('required training draw missing') from exc
            if len(row) != len(header) or _num(row[0], profile.first_draw, target - 1, 'Draw_Number') != expected:
                raise ValueError('missing, duplicated or out-of-order training draw')
            try:
                observed = date.fromisoformat(row[1])
                if observed.isoformat() != row[1]:
                    raise ValueError('noncanonical date')
            except ValueError as exc:
                raise ValueError('unparseable date metadata') from exc
            if observed != profile.derived_date(expected):
                date_anomalies.append(expected)
            offset = 2
            record = {'draw': expected}
            for barrel in profile.barrels:
                labels = [_num(v, barrel.low, barrel.high, barrel.barrel_id)
                          for v in row[offset:offset + barrel.selected]]
                offset += barrel.selected
                if len(labels) != barrel.selected or len(set(labels)) != len(labels):
                    raise ValueError('invalid distinct-ball selection')
                record[barrel.barrel_id] = sorted(labels)
            rows.append(record)
        # Intentional: no next(reader), no file stat, no whole-file hash.
    schema = f'{profile.game_id}_{profile.era_id}_{profile.version}_U_VIEW_V1'
    payload = {'schema': schema, 'game_id': profile.game_id, 'era': profile.era_id,
               'profile_version': profile.version, 'data_kind': source_kind, 'records': rows}
    digest = hashlib.sha256(canonical_bytes(payload)).hexdigest()
    return rows, digest, tuple(date_anomalies)
