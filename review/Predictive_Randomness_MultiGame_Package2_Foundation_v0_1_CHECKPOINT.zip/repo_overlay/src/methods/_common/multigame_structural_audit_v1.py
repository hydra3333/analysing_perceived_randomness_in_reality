"""Bounded, metadata-only structural audit for game winning/raw CSVs.

This privileged AUDIT (never a training/model loader) may inspect complete
sources including held-out rows. Returned data contain NO drawn ball labels,
not even in error messages or exceptions. Oz holdout selection is a
PREDECLARED RULE; writing a seal requires a later owner-authorised step.
"""
from __future__ import annotations

import csv
import hashlib
import re
from datetime import date
from pathlib import Path

from _common.game_profiles_v1 import GameProfile
from _common.multigame_u_view_v1 import columns_for

_CANON = re.compile(r'(0|[1-9][0-9]*)\Z', re.ASCII)


def raw_columns_for(profile: GameProfile) -> tuple[str, ...]:
    return columns_for(profile) + tuple(
        f'Supplementary_{i}' for i in range(1, profile.raw_supplementary_count + 1)
    )


def _read_rows(path: Path, header: tuple[str, ...]):
    """Private audit-only material, never returned to unprivileged callers."""
    if path.is_symlink() or not path.is_file():
        raise ValueError('audit input is not a regular file')
    if path.stat().st_size > 8_000_000:
        raise ValueError('audit source too large')
    rows = []
    with path.open('r', encoding='utf-8-sig', newline='') as stream:
        r = csv.reader(stream, strict=True)
        try:
            actual = next(r)
        except StopIteration as exc:
            raise ValueError('audit file has no header') from exc
        if tuple(actual) != header:
            raise ValueError('audit file has invalid columns')
        for row in r:
            if len(rows) >= 10_000:
                raise ValueError('audit exceeds row bound')
            rows.append(row)
    return rows


def _integer(value: str, lo: int, hi: int) -> int:
    if not _CANON.fullmatch(value):
        raise ValueError('not canonical integer')
    n = int(value)
    if not lo <= n <= hi:
        raise ValueError('number outside allowed range')
    return n


def _public_error(draw: int | None, field: str, issue: str) -> dict:
    # NEVER interpolate CSV values, exception messages or field contents.
    return {'draw_number': draw, 'field': field, 'issue': issue}


def audit_snapshot_pair(winning_csv: Path, raw_csv: Path, profile: GameProfile) -> dict:
    """Return a strict metadata-only report, not source rows.

    Date mismatches are WARNINGS, not acceptance blockers. Both files must be
    separate regular files; byte hashes are computed for archival provenance.
    """
    errors: list[dict] = []
    date_warnings: list[dict] = []
    win_rows = []
    raw_rows = []
    win_digest = raw_digest = None
    try:
        if winning_csv.resolve() == raw_csv.resolve():
            raise ValueError('input files must be distinct')
        win_rows = _read_rows(winning_csv, columns_for(profile))
        raw_rows = _read_rows(raw_csv, raw_columns_for(profile))
        win_digest = hashlib.sha256(winning_csv.read_bytes()).hexdigest()
        raw_digest = hashlib.sha256(raw_csv.read_bytes()).hexdigest()
    except (ValueError, OSError, UnicodeError, csv.Error) as exc:
        # Catch and discard error text; audit may receive malicious holdout values.
        return {'schema': 'MULTIGAME_STRUCTURAL_AUDIT_V1',
                'game_id': profile.game_id, 'profile_version': profile.version,
                'structurally_accepted': False, 'row_count': 0,
                'first_draw': None, 'last_draw': None,
                'winning_sha256': None, 'raw_sha256': None,
                'errors': [_public_error(None, 'FILE_OR_SCHEMA', 'INVALID')],
                'error_count':1, 'date_warning_count':0, 'date_warnings': []}
    if len(win_rows) != len(raw_rows):
        errors.append(_public_error(None, 'DRAW_COUNT', 'DIFFERENT_FILE_ROW_COUNTS'))
    if not win_rows:
        errors.append(_public_error(None, 'DRAW_COUNT', 'EMPTY'))
    expected_len = len(columns_for(profile))
    seen: set[int] = set()
    last = None
    for i, row in enumerate(win_rows):
        expected = profile.first_draw + i
        draw = expected  # The expected draw is safe audit metadata.
        if len(row) != expected_len:
            errors.append(_public_error(draw, 'WINNING_COLUMN_COUNT', 'INVALID'))
            continue
        try:
            number = _integer(row[0], profile.first_draw, 999999999)
        except ValueError:
            errors.append(_public_error(draw, 'Draw_Number', 'INVALID'))
            continue
        if number in seen:
            errors.append(_public_error(draw, 'Draw_Number', 'DUPLICATE'))
        seen.add(number)
        if number != expected:
            errors.append(_public_error(draw, 'Draw_Number', 'NOT_CONSECUTIVE_FROM_ERA_START'))
        last = number
        try:
            d = date.fromisoformat(row[1])
            if d.isoformat() != row[1] or d != profile.derived_date(number):
                raise ValueError('bad date')
        except ValueError:
            date_warnings.append(_public_error(draw, 'Date', 'DERIVED_DATE_MISMATCH_OR_INVALID'))
        ofs = 2
        all_selected = []
        for barrel in profile.barrels:
            fields = row[ofs:ofs + barrel.selected]
            ofs += barrel.selected
            try:
                vals = [_integer(v, barrel.low, barrel.high) for v in fields]
                if len(vals) != barrel.selected or len(set(vals)) != barrel.selected:
                    raise ValueError('invalid selection')
                # R2 applies to set of winning labels for the U view.
                if vals != sorted(vals):
                    raise ValueError('noncanonical order')
                all_selected.extend(vals)
            except ValueError:
                errors.append(_public_error(draw, barrel.barrel_id, 'INVALID_WINNING_SELECTION'))
        if i < len(raw_rows):
            raw = raw_rows[i]
            if len(raw) != len(raw_columns_for(profile)):
                errors.append(_public_error(draw, 'RAW_COLUMN_COUNT', 'INVALID'))
                continue
            # Disclose no values; raw must contain identical base fields.
            if raw[:expected_len] != row:
                errors.append(_public_error(draw, 'RAW_WINNING_FIELDS', 'DISAGREE'))
            if profile.raw_supplementary_count:
                # Oz supplementary labels excluded from every winning/model view.
                main = profile.barrels[0]
                try:
                    supp = [_integer(s, main.low, main.high) for s in raw[expected_len:]]
                    if (len(supp) != profile.raw_supplementary_count or
                            len(set(supp)) != len(supp) or set(supp).intersection(all_selected)):
                        raise ValueError('invalid supplemental')
                except ValueError:
                    errors.append(_public_error(draw, 'SUPPLEMENTARY', 'INVALID_OR_NOT_DISTINCT'))
    return {'schema': 'MULTIGAME_STRUCTURAL_AUDIT_V1',
            'game_id': profile.game_id, 'profile_version': profile.version,
            'structurally_accepted': not errors, 'row_count': len(win_rows),
            'first_draw': profile.first_draw if win_rows else None,
            'last_draw': last,
            'winning_sha256': win_digest, 'raw_sha256': raw_digest,
            'error_count':len(errors), 'date_warning_count':len(date_warnings),
            'errors': errors[:100], 'date_warnings': date_warnings[:100]}


def proposed_oz_holdout_metadata(report: dict) -> dict:
    """Metadata ONLY; does not create/seal a holdout (Package 3)."""
    if (report.get('schema') != 'MULTIGAME_STRUCTURAL_AUDIT_V1' or
            report.get('game_id') != 'OZLOTTO' or
            report.get('structurally_accepted') is not True or
            type(report.get('row_count')) is not int or report['row_count'] < 10):
        raise ValueError('no eligible Oz Lotto first snapshot')
    last = report['last_draw']
    return {'schema': 'OZLOTTO_FIRST_SNAPSHOT_HOLDOUT_RULE_V1',
            'game_id': 'OZLOTTO', 'holdout_first': last - 9,
            'holdout_last': last, 'winning_sha256': report['winning_sha256'],
            'raw_sha256': report['raw_sha256'], 'date_anomaly_count': report['date_warning_count'],
            'status': 'PROPOSED_ONLY_NOT_SEALED'}
