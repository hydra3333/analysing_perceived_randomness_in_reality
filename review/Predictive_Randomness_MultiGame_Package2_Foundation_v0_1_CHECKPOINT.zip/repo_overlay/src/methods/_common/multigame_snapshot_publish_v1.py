"""Create-only, audit-first offline PAIR publishing for synthetic sources.

NOT a live scraper or selected scientific source. This publisher is
limited to an isolated synthetic namespace until Package 3's distinct
operator/data-source authorisation and a reviewed network/parser adapter.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
from pathlib import Path

from _common.game_profiles_v1 import GameProfile
from _common.multigame_structural_audit_v1 import audit_snapshot_pair

_SAFE_RUN = re.compile(r'[a-z0-9][a-z0-9_-]{7,95}\Z', re.ASCII)


def _new(path: Path, raw: bytes) -> None:
    with path.open('xb') as f:
        f.write(raw)
        f.flush()
        os.fsync(f.fileno())


def publish_synthetic_pair(*, winning_fixture: Path, raw_fixture: Path,
                           profile: GameProfile, run_root: Path, run_id: str) -> dict:
    if not _SAFE_RUN.fullmatch(run_id):
        raise ValueError('invalid safe run ID')
    # Structural checker audits complete synthetic fixture data. No publication
    # on invalid structure. This never opens the official source directory.
    report = audit_snapshot_pair(winning_fixture, raw_fixture, profile)
    if report['structurally_accepted'] is not True:
        raise ValueError('fixture structural audit failed; no snapshot created')
    destination = run_root / profile.game_id / run_id
    destination.mkdir(parents=True, exist_ok=False)
    win_name = ('australian_powerball_history_SYNTHETIC.csv'
                if profile.game_id == 'POWERBALL' else 'australian_ozlotto_winning_SYNTHETIC.csv')
    raw_name = (f'australian_{profile.game_id.lower()}_raw_SYNTHETIC.csv')
    win = winning_fixture.read_bytes()
    raw = raw_fixture.read_bytes()
    _new(destination / win_name, win)
    _new(destination / raw_name, raw)
    record = {
        'schema': 'MULTIGAME_SYNTHETIC_SNAPSHOT_V1',
        'game_id': profile.game_id,'profile_version':profile.version,
        'run_id':run_id,'source_kind':'SYNTHETIC_ONLY',
        'winning_file':win_name,'raw_file':raw_name,
        'winning_sha256':hashlib.sha256(win).hexdigest(),
        'raw_sha256':hashlib.sha256(raw).hexdigest(),
        'row_count':report['row_count'],
        'date_warning_count':len(report['date_warnings']),
        'accepted_as_real_scientific_source':False,
    }
    blob=(json.dumps(record,sort_keys=True,separators=(',',':'))+'\n').encode('ascii')
    _new(destination/'snapshot_record.json',blob)
    return record
