@echo off
setlocal DisableDelayedExpansion
rem Package-2 REVIEW CANDIDATE. Live scrapes HARD DISABLED in Python.
rem Only a single literal POWERBALL or OZLOTTO argument is accepted.
set "ROOT=%~dp0"
set "PY=%ROOT%.venv\Scripts\python.exe"
set "VENV_ACTIVATE=%ROOT%.venv\Scripts\activate.bat"
set "RC=2"
if not exist "%PY%" goto :venv_missing
if not exist "%VENV_ACTIVATE%" goto :venv_missing
if "%~2" NEQ "" goto :usage
if /I "%~1"=="POWERBALL" goto :powerball
if /I "%~1"=="OZLOTTO" goto :ozlotto
goto :usage
:powerball
set "GAME=POWERBALL"
goto :check_venv
:ozlotto
set "GAME=OZLOTTO"
:check_venv
for %%I in ("%ROOT%.venv\.") do set "EXPECTED_ENV=%%~fI"
if defined VIRTUAL_ENV goto :check_active
call "%VENV_ACTIVATE%"
if errorlevel 1 goto :activation_failed
if not defined VIRTUAL_ENV goto :activation_failed
goto :check_python
:check_active
for %%I in ("%VIRTUAL_ENV%\.") do set "ACTIVE_ENV=%%~fI"
if /I not "%ACTIVE_ENV%"=="%EXPECTED_ENV%" goto :wrong_venv
:check_python
"%PY%" -c "import sys,pathlib;sys.exit(0 if pathlib.Path(sys.prefix).resolve()==pathlib.Path(sys.argv[1]).resolve() else 12)" "%EXPECTED_ENV%"
if errorlevel 1 goto :prefix_failed
"%PY%" -u "%ROOT%src\multigame_scraper_entry_v0_1.py" --game "%GAME%"
set "RC=%ERRORLEVEL%"
goto :finish
:venv_missing
echo [SCRAPER] ERROR: project .venv missing. >&2
goto :finish
:wrong_venv
echo [SCRAPER] ERROR: another virtual environment is active. >&2
goto :finish
:activation_failed
echo [SCRAPER] ERROR: venv activation failed. >&2
goto :finish
:prefix_failed
echo [SCRAPER] ERROR: Python does not match the expected sys.prefix. >&2
goto :finish
:usage
echo Usage: Run_Scraper.bat POWERBALL^|OZLOTTO >&2
:finish
endlocal & exit /b %RC%
