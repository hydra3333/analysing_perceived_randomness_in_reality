# Package 2 foundation v0.1 — intermediate engineering checkpoint

**AUTHORISATION:** owner authorised resuming Package 2 development. This is **NOT** the completed, independently reviewed Package 2, NOT an installation release, and grants NO additional execution authority.

**Provenance:** user-reported ratified-document Git HEAD `057fd8c618c00d162324149e949fc71ab72ca3ce`. Foundation authored using earlier repository snapshot + byte-identical reviewed E_1 overlays + ratified Package 1 documents. Exact complete HEAD tree was not downloaded; these files are all NEW, with no edits to existing checked-in files. The accepted E_1 runner has independently matched SHA-256 `9ce866e44c7e8e13a3c245a7fa800d1c2a8d6c6b7ca311e4c9f8ec0fbe309a45` in the reconstructed test tree. Nothing was committed to GitHub.

## Implemented here

- W1: immutable `POWERBALL` and `OZLOTTO` profiles, compound `(game_id, draw_number)`, derived dates, exact barrel structures, Oz currently **unsealed**; historical-only holdout cap. Unknown official nominal/closing clock times remain `None`, not invented.
- W1/W4: conservative complete method registry E_1..E_62 (only E_1 `SUPPORTED`, others `FORMULA_OPEN` pending method review); E_63 not silently registered.
- W1: NEW synthetic U-view domain, game/era/profile-bound digest; reads only pre-target rows. New real modes HARD DISABLED. Existing Powerball E_1 source/result identities remain unchanged.
- W3: private complete-data structural auditor returns metadata only, including field-level issues and date warnings; date deviations do not block number-structural acceptance. Audit bounded (8 MB per file / 10,000 rows, first 100 detailed entries), 10-highest Oz *proposed* seal metadata only; **no actual seal creation**.
- W4: new synthetic-only generic E_1 maths and method-generic status/manifest consumer; shared `ProbeStatus` with PID/creation-time/CPU/memory; failure/orphan marker checks before result read. No coordinator launch, `exit_receipt`, or FINAL permitted.
- W2: `Run_Scraper.bat` human interface + dispatcher **LIVE SCRAPING HARD DISABLED**, with venv/Python prefix checks; synthetic audited pair publisher creates immutable test artifacts, never approved training data.
- Exact original E_1 little-endian tie-digest calculation matches generic equivalent for EVERY label in Powerball MAIN/PB using the accepted draw-1577 training digest. 16 new synthetic tests pass; 13 earlier E_1 tests pass.

## NOT complete — mandatory before consolidated Claude review / install

- Real Oz Lotto operator source adapter/HTML parser + confirmed operator provenance; current entry point intentionally exits 2 without network use. Build and offline-test a real adapter; DO NOT initiate Package-3 collection in Package 2.
- Powerball scraper refactor to immutable destination without touching historical CSV/source or weakening existing validation. Integrate both scrapers and snapshot hashes/acceptance ledger. One `Run_Scraper.bat` command for each game.
- Freeze the actual first Oz holdout in a separate operator-authorised Package-3 procedure; profile cannot unilaterally seal it.
- Production method-generic runner integration and new schema, method console `BEGIN`/`FINISH`/`RESULT`/`DIGEST` with v0.6 coordinator validation, trusted coordinator-owned `exit_receipt`, run-folder handshake, authoritative method registry applicability checks. **Existing E_001 is unchanged.**
- Full barrel-aware shared scoring/evaluation with synthetic goldens, *never* Oz real scoring/holdout. Profile-parameterised scientific implementation is presently SYNTHETIC ONLY.
- Exact Powerball draw-1577 legacy forecast and SHA regeneration under a new profile-driven implementation plus comprehensive synthetic peer review and Windows checks.
- Actual Windows `.bat` execution/venv-restoration tests (not possible in this Linux runner). No Python source in this checkpoint has been tested against real game data.
- Separate coordinator v0.7 safety work remains ongoing, outside Package 2; this checkpoint neither edits it nor enables termination.

## Authority/safety

The pre-existing `ENABLE_REAL_HISTORICAL_DEVELOPMENT = True` applies ONLY to the prior, already-authorised E_1 standalone Powerball experiment; it is NOT copied to new multi-game paths. The added multi-game scientific path refuses REAL data. Legacy Powerball holdout remains sealed, Oz unsealed, no FINAL. Global orphan marker is checked by new generic consumer; process termination untouched.

**DO NOT extract the overlay into the live repo as an approved installation yet.** Continue Package 2 coding and consolidate for Claude review in one audited code package. The owner decides installation/testing after review.

## DECIDED / RECOMMENDED / OPEN

- DECIDED under ratified specification: narrow immutable profiles; game-specific display draw key; conservative METHOD registry; date fields excluded from U-view digest; synthetic-only gates; fail-closed snapshots and consumer; no custom Task Manager binaries.
- RECOMMENDED: keep explicit synthetic-only wrapper while the operator source parser remains unverified; do not claim scraping completion.
- OPEN: verified live Oz Lotto HTML/API contract; official era first-draw confirmation; recorded nominal draw/closing times; complete snapshot-selection ledger; `exit_receipt` handoff with coordinator v0.7; any future additional game; FINAL operation.
