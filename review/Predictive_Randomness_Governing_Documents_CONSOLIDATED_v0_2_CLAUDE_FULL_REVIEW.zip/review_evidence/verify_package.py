#!/usr/bin/env python3
"""Reproduce candidate manifest/protected-block validation. Python stdlib only."""
import json,hashlib,pathlib,sys
root=pathlib.Path(__file__).resolve().parent.parent
manifest=json.loads((root/'review_evidence/SHA256_MANIFEST.json').read_text())
fail=[]
for item in manifest['files']:
 p=root/item['path']
 if not p.is_file() or hashlib.sha256(p.read_bytes()).hexdigest()!=item['sha256']:fail.append(item['path'])
protected=json.loads((root/'review_evidence/VERBATIM_BLOCK_SHA256.json').read_text())
for item in protected:
 p=root/'review_overlay/doc'/item['destination']
 # Stored original protected bytes in protected-block references; check substring.
 original=(root/'review_evidence/verbatim_source'/ (item['block']+'.bin')).read_bytes()
 if original not in p.read_bytes():fail.append('protected '+item['block'])
 if hashlib.sha256(original).hexdigest()!=item['old_sha256']:fail.append('source sha '+item['block'])
print('MANIFEST',len(manifest['files']),'PROTECTED',len(protected),'FAILURES',fail)
sys.exit(bool(fail))
