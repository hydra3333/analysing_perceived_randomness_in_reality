# Predictive Randomness — Experimental Method Specifications R2 v0.4 (CONSOLIDATED REVIEW CANDIDATE)

> **REVIEW CANDIDATE — NOT RATIFIED.** Owner decision is required before replacing the ratified original. This consolidation is not a run approval, Mode H opening, FINAL activation, process-termination permission or source updater instruction. Historical sources remain unchanged in Git.

**Date:** 25 October 2026. **Source:** ratified R2 v0.3, owner-approved ERR-R2-01–05, owner-decided ERR-R2-06 as reviewed v0.3 candidate, and frozen owner decisions of 25 October. This edition will replace the companion erratum only **after owner ratification**; the erratum remains historical in Git.

## 0. Authority and erratum index

**Authority and status labels.** Existing ratified specifications remain in force until this whole edition is ratified. **DECIDED** = owner decision or still-operative earlier ratified scientific requirement. **RECOMMENDED** = design guidance, not automatically an implementation gate. **OPEN** = requires separate explicit owner decision. A reviewed candidate is not execution authority. Document roles: Proposal = research charter; R1 v0.4 = permanent method research catalogue; R2 = scientific inputs/methods and N−1; R3 = scoring/evaluation/freezing; Architecture = Windows implementation/safety; P3 = staged work; ratification register = authority ledger. `TIE_SHA256_V1` note v0.2 remains authoritative unchanged.

| Historical decision ID | Operative destination in this candidate | Status |
|---|---|---|
| ERR-R2-01 | §§1, 6–7 (1 vs configured maximum; initial 1–6) | DECIDED |
| ERR-R2-02 | §8 and Architecture §5C (Option F via batch; Windows test gate) | DECIDED PROVISIONALLY; **not production-accepted** |
| ERR-R2-03 | §8 and Architecture §5A (single batch dependency authority; resolved version snapshots) | DECIDED |
| ERR-R2-04 | §§4–5 and unchanged R3 §0.4 (fit selection model versus readout seed) | DECIDED |
| ERR-R2-05 | §§1–5, 9–10 (per-game inputs, contracts and OPENs) | DECIDED where owner-approved; historical sealing replaced |
| ERR-R2-06 | §§2–4, 9–10 (new quarantine, prefix-only wide reader and environment) | OWNER-DECIDED; candidate integration pending ratification |

The old 1578–1587 Powerball holdout/development cap 1577; Oz first-snapshot highest-ten seal; and `DEV_TO_DATE=2026-08-07` are **withdrawn**. The old Powerball operator-order verification was an owner assumption; its exact status is `OPERATOR_DRAWN_ORDER_ASSUMED_OWNER_DECISION`.

## 1. Scientific invariants and method availability

**DECIDED.** Strict N−1, evidence integrity, a complete method inventory E_1–E_62, scientific neutrality, two simultaneously frozen directions TOP/WORST where native, post-outcome rank-position evaluation, per-game real/synthetic separation, non-exclusion for costs or conventional randomness expectations, and immutable genuine forecast batches remain operative. All registered methods remain permanently available for legitimate study; structural support `SUPPORTED`, `FORMULA_OPEN`, `UNSUPPORTED_FOR_GAME` is explicit and never a performance veto. One executable experiment per E-number, testable directly or through a reviewed coordinator. Any future change to method/formula, operating restrictions, or worker limit requires explicit owner approval.

Method interfaces must be game-qualified; they cannot assume Oz has Powerball. Powerball current era MAIN 7-of-35, PB 1-of-20; Oz current era MAIN 7-of-47, supplementaries excluded from scientific views. Changing model design after looking at a holdout removes that holdout's claim of independence for that method. **I-07 retained:** disclose any previous holdout use; a method exposed to its outcomes may not later claim those draws as pristine.

## 2. Versioned accepted datasets and sealed boundaries

- **POWERBALL**: approved current-era draws **1144–1576**, 433 development observations; first quarantined draw 1577; `FINAL_HOLDOUT_10` **1577–1586**. Accepted source `source_data/POWERBALL_results_master.csv`, version 1, SHA-256 `ce0ae7e77e09e5a93389eb98191b455926ec44c0bb38dda0ef721b9f710d66b8`.
- **OZLOTTO**: approved current-era draws **1474–1693**, 220 development observations; first quarantined draw 1694; `FINAL_HOLDOUT_10` **1694–1703**. Accepted source `source_data/OZLOTTO_results_master.csv`, version 1, SHA-256 `4a6cecc27fb6a5b8aafc0451858f1ea00f31c0eaf83c15c6ba66a0940e83f93f`.
- The development/quarantine split is **calendar-based** (draws from **2026-08-01** onward quarantined); these fixed exact ranges control and do not silently slide. Master integrity, version and provenance are established by the matching append-only `source_data/_results_master_ledger.csv` `INIT` rows and `source_data/_results_master_init_verification.json`. The hashes/row counts were independently cross-checked by Claude at Git HEAD `3ddb8a6`; subsequent HEADs require identity re-verification. All source acceptance is owner-run; the accepted version-1 masters are not pending source confirmation.

This boundary **does not slide silently**. Any opening or altered eligibility requires a separately approved protocol, manifest, owner action and appropriate value-free exposure disclosure. Ordinary development sees no quarantined outcomes. The owner-approved E_1 target-1577 forecast-only regression uses only pretarget rows and is *not* a holdout result. All method-scientific inputs/paths and fixtures must remain separate by game and by synthetic, real, holdout, scored and prospective mode. Methods must not be offered underlying audited decoded holdout buffers.

## 3. N−1, source integrity, immutable views and numeric width

1. **DECIDED — pinned source.** A scientific run specifies exact game, accepted master version and matching SHA-256 from the committed append-only ledger. **Computing the SHA-256 reads all bytes without decoding them; the prohibition is on parsing or converting any field of a row whose first field is >= N.** Read/parse the raw first `Draw_Number` field as a guarded pre-filter; never decode/convert a suffix field or row-N outcome. Check master file linkage and reject symlinks or files with `st_nlink > 1`. A whole-master hash is metadata/provenance only, *never* used as scientific feature, tie/fit seed or method selection.
2. **DECIDED — per-run loader.** At each run bind the recorded master identity before creating method inputs; parse *only* rows with `draw_number < target`, perform required prefix/schema validation and give methods **only** safe `DrawView`/ordinary Python-int list representations. Methods cannot receive the unrestricted table, a master path or an auditor's decoded data. Restrict imports/access in code and verify by static and adversarial tests.
3. **DECIDED — owned memory.** Every NumPy scientific view is an *owned, readonly byte-backed prefix-only copy*; its `.base` (and reachable base chain) is bytes of exactly its own permitted prefix × item width. Mutating/inserting poisonous row-N and later values, even via underlying arrays, must not affect or expose the view. Do not rely on `.flags.writeable=False` alone.
4. **DECIDED — wide arithmetic.** Internal numeric table and every exported integer NumPy field (`draw_number`, `main`, `powerball`, `drawn_main`) are `int64`. Floating fields `float64`. For genuinely larger exact counts, use Python's arbitrary-size `int`. Plain-list views contain ordinary Python integers. Verify view `47*47==2209` (no int8 wrap), type, base length, negative/missing data and extreme numerical behaviour; the `int64` policy does not license unchecked overflow of unbounded accumulations.
5. **DECIDED — dates.** Masters retain audited ISO **calendar dates**, not invented local/UTC instants. Default `include_dates=False`. Any date feature uses a new explicitly named schema and training-view digest including date data and profile version; date-only anomalies block relevant date-dependent methods pending review, not automatically all U-view models. No time-zone extrapolation from calendar dates alone.
6. **DECIDED — order semantics.** Views are `UNORDERED_SET`, `OPERATOR_DRAWN_ORDER`, or `PAIRED_DIAGNOSTIC` (both representations of identical events, no double-counting). Unordered U is a sorted copy of the accepted drawn-order master, not a second draw collection. Published drawn order is **assumed physical operator order by owner decision**, never independently video-verified. Supplementaries may be checked structurally but are never method input.
7. **DECIDED — scientific result firewall.** A result consumer uses a separate schema/data-kind/variant allowlist (currently **empty**). Never promote a synthetic/diagnostic result to scientific status by a cosmetic flag change; a FAILED/orphan-suspected group's output is never eligible regardless of disk presence. Method view choice belongs in immutable method configs, log/manifest and tests; no redundant per-method view entitlement registry.
8. **DECIDED — per-target fitting.** Fit each target N afresh from strictly prior eligible rows and method-specified window; incremental caching is **OPEN** until a reviewed byte-for-byte equivalence test proves same result as from-scratch fitting. Keep frozen fit/view/config/version identities; transient parameter arrays are retained only when necessary.

## 4. Ordered/unordered observation, legacy digests and tie identity

The probability distinctions in the protected §4.1 immediately below are preserved exactly from ratified R2 v0.3. A chosen pair is **one draw** even in `PAIRED_DIAGNOSTIC`; do not score as two independent samples. `selection_model_version` refers to a sampling/observation model that alters fitting, not downstream TOP/WORST readout; stochastic fitting seeds and readout/tie seeds are independent. The unchanged `TIE_SHA256_V1` note v0.2 governs little-endian tie encoding; do not introduce a second tie contract. Legacy E_1 `E1_REAL_U_TRAINING_VIEW_V1` identity and the original canonical result remain unmodified; new game-qualified wrappers must have new schema IDs.

### 4.1 Ordered and unordered seven-number probabilities

For positive sequential selection weights `w_1 ... w_35`, the probability of a complete ordered selection `a_1, ..., a_7` with no repeated labels is:

```text
P(a_1,...,a_7 | w) = PRODUCT over r=1..7 of
                     w[a_r] / SUM_{j not previously selected} w[j]
```

The probability of the corresponding **unordered** seven-number set S is the sum of those ordered probabilities over all `7! = 5040` permutations of S, or a validated equivalent expression for the particular sequential-selection model. An unordered DPP likelihood **is not** the same model as this sequential weighting rule. Powerball uses a one-of-20 categorical distribution. The software should expose both views without assuming they are interchangeable or that an operator-labelled sequence is 444 independent additional observations.


## 5. Frozen E_1 numerical and forecast regression identities

**DECIDED — immutable acceptance goldens:**
- Synthetic permitted-view training SHA-256: `df21871f8067e5405b4fdb1eec50c65dddbaa35958872bad3230d3c10a791fd4`.
- Synthetic MAIN label-3 tie SHA-256: `7ce5ab1bae014adf61f1f02dd152d4b500cb405b65cb3886cdcee8dd9e2c9932`.
- Synthetic canonical forecast SHA-256: `7b43d659d611791deb14d106a72984f153d9f79cc63b3d25000365de4c811d1e`.
- Real E_1 forecast-only target `POWERBALL/1577`, trained only on 1144–1576: permitted-view SHA-256 `d47fbbd6e60e6abc429fb74f47d8bbeafc6560152c2ecddb3b75d79932df4339`; legacy canonical result SHA-256 `7f1130872b3afaa222ff4e8c2396cd2c2872583544dfa6b31cc5a07cd067164e`.
- Frozen E_1 forecast outputs for this regression are **TOP** main `[9,17,7,11,18,30,12]`, Powerball `2`; **WORST** main `[31,13,8,29,26,33,35]`, Powerball `12`. **These are forecast outputs, not published outcomes.** No row-1577 outcome may be read or scored during this test.

Any new wrapper schema must report a distinct version and distinct hash without silently rewriting legacy frozen evidence. Offline synthetic E_1 mathematical/tie checks and the forecast-only real 1577 check are gates after dependency upgrades and before scientific acceptance. The real v0.11 offline test may retrieve legacy pre-boundary rows from Git `06f6e0f` **only after filtering raw first-field draw number to `<1577` before decoding other fields**, or use the accepted version-1 master; it must never read/score outcome 1577.

## 6. Timing-only benchmarks and deterministic worker equality

**DECIDED — current benchmark targets.** B1 target POWERBALL **1576**, fit rows 1144–1575 (432); if W=100, use 1476–1575. B10 targets **1567–1576**, each fitted from strictly earlier rows (423–432 prior eligible rows). Timed variations compare run duration, CPU/RAM, failures and environment only, never forecasting success or holdout results. No target in these benchmarks crosses the 1 August quarantine.

**DECIDED — worker cap.** Initial one method per worker and configured **1–6** simultaneous workers, default and maximum **six**; single-thread numerical libraries within worker. Required bit-identical canonical prediction content for one versus configured max (initial one vs six), including complete TOP/WORST/rankings/availability; rerun in identical pinned environment. Different scheduling order cannot change fits or readouts. Worker count increases, 12/24 trial and experiment-created subprocesses require new owner approval and tests. Do not use wall clock, full source SHA or worker count to seed scientific computation.

## 7. Method inventory — all 62 identities retained

**R2-C13 [PROPOSED]:** The registry must contain **every** E_1–E_62 identity from the ratified R1 catalogue at startup even if no forecasting code is present. Default registry status may be `FORMULA_OPEN` or `RESEARCH_CANDIDATE`. A running implementation is never presumed from its presence in this table. New ideas may extend through E_106 under the current research allowance, but no empty placeholders are required and identifiers are not assigned casually.

### 7.1 Exact names and source capabilities

| ID | Exact R1 concept name | R1 indicated inputs | Effort noted in R1 | Spec status in this R2 candidate |
|---|---|---|---|---|
| **E_1** | Historical Appearance Frequency | `U` | L | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_2** | Expected Recurrence-Interval Alignment | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_3** | Occurrence-Curve Endpoint Forecast | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_4** | Occurrence-Curve Gradient Forecast | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_5** | Shared Population/Draw Distribution Model | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_6** | Per-Number Fitted Distribution Models | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_7** | Bayesian Frequency Shrinkage | `U` | L | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_8** | Hierarchical Dirichlet–Multinomial Propensity | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_9** | Exponentially Decayed Occurrence Rates | `U` | L | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_10** | Multi-Horizon Frequency Contrasts | `U` | L | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_11** | Change-Point Segmented Propensities | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_12** | Hidden Markov Propensity Regimes | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_13** | Latent State-Space Drift | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_14** | Calendar-Phase Conditional Patterns | `U` | L | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_15** | Historical Epoch Hierarchies | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_16** | Biased Without-Replacement Urn Model | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_17** | Discrete Recurrence Hazard Curves | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_18** | Mixtures of Recurrence Modes | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_19** | Periodic Recurrence-Hazard Peaks | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_20** | Self-Exciting or Self-Inhibiting Occurrence | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_21** | Cross-Number Recurrence Synchrony | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_22** | Lagged Event-Trigger Matrices | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_23** | Pair Co-Occurrence Propensities | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_24** | Higher-Order Triplet Interactions | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_25** | Graph-Based Number Association | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_26** | Draw-Level Geometry and Summary States | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_27** | Nearest Neighbour of Historical Draw Sets | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_28** | Markov Transitions of Draw Summaries | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_29** | Physical Draw Position Preferences | `O` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_30** | Draw-Order Transition Signatures | `O` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_31** | Plackett–Luce Sequential Selection | `O` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_32** | Permutation/Ordinal Structure of Draw Order | `O` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_33** | Fourier and Harmonic Occurrence Forecasts | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_34** | Wavelet-Localized Cycles | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_35** | Singular Spectrum Analysis | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_36** | Gaussian-Process Next-Step Curves | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_37** | Spline and Local-Polynomial Extrapolation | `U` | L | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_38** | Empirical Mode Decomposition | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_39** | Detrended Fluctuation and Long-Memory Features | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_40** | Nonlinear Phase and Periodicity Maps | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_41** | Context-Tree and Compression Prediction | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_42** | Conditional Mutual Information Features | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_43** | Transfer-Entropy Directional Signals | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_44** | Recurrence-Plot Analogue Prediction | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_45** | Delay-Embedded Nearest-Analogue Forecast | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_46** | Local S-Map Nonlinear State Forecast | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_47** | Lyapunov-Style Instability Conditioning | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_48** | Cross-Mapping of Potentially Connected Processes | `U+X` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_49** | Regularized Logistic Event Forecasts | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_50** | Random-Forest Conditional Patterns | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_51** | Boosted-Tree Interaction Discovery | `U` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_52** | Reservoir Computing for Latent Dynamics | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_53** | Evolutionary Symbolic Regression | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_54** | External-Date Covariate Synchrony | `U+X` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_55** | Complementarity-Aware Multi-Method Combination | `R` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_56** | Adaptive Temporal Method Mixtures | `R` | M | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_57** | Fixed-Size Determinantal Seven-Set Model (C-PW1) | `U (main)` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_58** | Unconditioned Coupled Latent-Wave Field (C-PW2) | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_59** | Draw-Conditioned Coupled Latent-Wave Field (C-PW3) | `U` | H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_60** | Post-Change Non-Equilibrium Relaxation Analogue (C-PW4) | `U, optional X` | M/H | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_61** | Guided-Particle Circulation Model (C-PW5A) | `U, optional drawn-order O` | Very high | Proposed profile; formula/details still subject to R2 method-level approval |
| **E_62** | Guided-Particle Circulation with Reinjection (C-PW5B) | `U, optional drawn-order O` | Very high | Proposed profile; formula/details still subject to R2 method-level approval |
`U` = unordered draws; `O` = operator-labelled drawn order; `X` = optional external observations; `R` = prior method predictions/rankings. `U+X` is conditional on actual external observations and correct release-time provenance. **The input codes reproduce the R1 concept; they are not newly ratified declarations of algorithm availability.** Pilot-wave-inspired analogies are *models for testing*, not evidence of quantum effects in the draw machine.

### 7.2 Per-method specification profiles — interpretation

For each registered method below, the first phrase is its retained scientific purpose from R1. The second phrase lists the **initial operational contract or mathematical decision that must be frozen before coding**. The third lists **output type** and/or special constraint. These are implementation planning notes; they do **not** assert that an arbitrary estimator, package, fitting regime or hyperparameter value has been user-approved. All variants, including currently non-identifiable ones, remain eligible for research.

### 7.1 Original six user-designed methods (E_1–E_6)

**E_1 — Historical Appearance Frequency**  
- **Hypothesis retained:** Raw occurrence counts/rates for each eligible number.  
- **Implementation choice to settle:** Choose full/rolling history, smoothing, how ties resolve and whether rankings use counts or rates.  
- **Contract/output:** MAIN_RANK and POWERBALL_RANK.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_2 — Expected Recurrence-Interval Alignment**  
- **Hypothesis retained:** Projected recurrence interval at target N, not simply how overdue.  
- **Implementation choice to settle:** Define gap as next-draw projected interval; mean/median/mode/hazard/mixture are distinct named variants; handle never-seen values.  
- **Contract/output:** Two independent barrel rankings; retain estimator provenance.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_3 — Occurrence-Curve Endpoint Forecast**  
- **Hypothesis retained:** Fit occurrence indicator histories and extrapolate level to next draw.  
- **Implementation choice to settle:** Specify curve family, fitting window, regularisation/boundary extrapolation and binary-response interpretation.  
- **Contract/output:** Number rankings from next-point fitted value.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_4 — Occurrence-Curve Gradient Forecast**  
- **Hypothesis retained:** Fit occurrence history curves and extrapolate their gradient.  
- **Implementation choice to settle:** Specify derivative point, curve family, temporal units, scale and boundary handling.  
- **Contract/output:** Number rankings from extrapolated signed slope.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_5 — Shared Population/Draw Distribution Model**  
- **Hypothesis retained:** Learn shared population/draw propensity or distribution.  
- **Implementation choice to settle:** Choose a legally normalised seven-without-replacement model distinct from Powerball categorical model.  
- **Contract/output:** Set/marginal/rank output, chosen model declared.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_6 — Per-Number Fitted Distribution Models**  
- **Hypothesis retained:** Fit distribution/recurrence process separately for each label.  
- **Implementation choice to settle:** Specify target random variable, distribution family, sparse-data treatment and normalisation.  
- **Contract/output:** Rankings or probabilities only if justified.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

### 7.7 Frequency, Bayesian and regime (E_7–E_16)

**E_7 — Bayesian Frequency Shrinkage**  
- **Hypothesis retained:** Regularised Bayesian item-frequency estimates.  
- **Implementation choice to settle:** Set prior family/concentration and fitting window; avoid unapproved pooling with next draw.  
- **Contract/output:** Marginal scores/probabilities with declared 7-set reconciliation.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_8 — Hierarchical Dirichlet–Multinomial Propensity**  
- **Hypothesis retained:** Shared hierarchical propensity across labels and periods.  
- **Implementation choice to settle:** Define hierarchy, hyperprior, link to without-replacement likelihood, identifiability.  
- **Contract/output:** Main and Powerball outputs separately.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_9 — Exponentially Decayed Occurrence Rates**  
- **Hypothesis retained:** Recent appearance with exponential decay.  
- **Implementation choice to settle:** Freeze decay definition, time units and parameter policy at each origin.  
- **Contract/output:** Scores/ranks, not automatically probabilities.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_10 — Multi-Horizon Frequency Contrasts**  
- **Hypothesis retained:** Contrast multiple past windows/horizons.  
- **Implementation choice to settle:** Define all horizons, scale factors and combination formula before target.  
- **Contract/output:** Ranks/scores, stable feature extraction.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_11 — Change-Point Segmented Propensities**  
- **Hypothesis retained:** Regime-specific propensities after inferred change points.  
- **Implementation choice to settle:** Freeze change-detection algorithm and timeline admissibility; no future-inferred breaks.  
- **Contract/output:** Next-regime ranks/probabilities or explicit signal.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_12 — Hidden Markov Propensity Regimes**  
- **Hypothesis retained:** Latent switching regime model.  
- **Implementation choice to settle:** Define hidden states, transition law, observation likelihood and state estimation.  
- **Contract/output:** Filtered next-step propensities/diagnostics.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_13 — Latent State-Space Drift**  
- **Hypothesis retained:** Drifting latent state over time.  
- **Implementation choice to settle:** Define process/observation model, update schedule and legal set link.  
- **Contract/output:** Next-state forecasts and barrel outputs.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_14 — Calendar-Phase Conditional Patterns**  
- **Hypothesis retained:** Conditional signals based on calendar phase.  
- **Implementation choice to settle:** Choose eligible date-indexed phases, avoid hindsight date transforms.  
- **Contract/output:** Number ranks or conditional diagnostics.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_15 — Historical Epoch Hierarchies**  
- **Hypothesis retained:** Share information across declared historical epochs.  
- **Implementation choice to settle:** Define epoch boundaries as known at forecast time or inferred from preceding data.  
- **Contract/output:** Epoch-adjusted scores/ranks.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_16 — Biased Without-Replacement Urn Model**  
- **Hypothesis retained:** Unequal item weights in without-replacement draws.  
- **Implementation choice to settle:** Choose sequential Wallenius-like versus other weighted-set law; do not equate to diagonal DPP.  
- **Contract/output:** Legal unordered set / optional ordered likelihood.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

### 7.17 Recurrence and event-process (E_17–E_22)

**E_17 — Discrete Recurrence Hazard Curves**  
- **Hypothesis retained:** Discrete hazard of appearance by absence age.  
- **Implementation choice to settle:** Define hazard regularisation, censoring, first-occurrence conventions.  
- **Contract/output:** Projected-age next-target inclusion scores.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_18 — Mixtures of Recurrence Modes**  
- **Hypothesis retained:** Multiple recurrence modes.  
- **Implementation choice to settle:** Specify mixture family, parameter constraints and sparse-number fitting.  
- **Contract/output:** Projected next-draw hazard ranks.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_19 — Periodic Recurrence-Hazard Peaks**  
- **Hypothesis retained:** Periodically varying recurrence-hazard peaks.  
- **Implementation choice to settle:** Specify periods, phase, basis, search range and temporal fitting.  
- **Contract/output:** Projected next-draw inclusion scores.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_20 — Self-Exciting or Self-Inhibiting Occurrence**  
- **Hypothesis retained:** Self-excitation and inhibition after appearances.  
- **Implementation choice to settle:** Specify Hawkes-like or other discrete lag kernel and valid probability mapping.  
- **Contract/output:** Next-step ranks and lag diagnostics.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_21 — Cross-Number Recurrence Synchrony**  
- **Hypothesis retained:** Cross-number synchronised recurrence.  
- **Implementation choice to settle:** Define shared-lag/coherence features and information available at N−1.  
- **Contract/output:** Ranks or diagnostic-to-predictive adapter.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_22 — Lagged Event-Trigger Matrices**  
- **Hypothesis retained:** Lagged number-to-number triggers.  
- **Implementation choice to settle:** Define lag grid, direction, regularisation and prediction aggregation.  
- **Contract/output:** Separate barrel rankings; avoid same-draw target leaks.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

### 7.23 Within-draw, set structure and drawn order (E_23–E_32)

**E_23 — Pair Co-Occurrence Propensities**  
- **Hypothesis retained:** Within-draw pair attraction/repulsion.  
- **Implementation choice to settle:** Define interactions and legal seven-set joint model or marginal adapter.  
- **Contract/output:** Whole-set scores plus optional marginals.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_24 — Higher-Order Triplet Interactions**  
- **Hypothesis retained:** Higher-order triplet associations.  
- **Implementation choice to settle:** Specify interaction representation, sparsity and computational budget.  
- **Contract/output:** Legal set scores or declared feature adapter.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_25 — Graph-Based Number Association**  
- **Hypothesis retained:** Number co-occurrence graph patterns.  
- **Implementation choice to settle:** Define graph construction using preceding draws, graph features and forecast mapping.  
- **Contract/output:** Diagnostic graph features / ranks.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_26 — Draw-Level Geometry and Summary States**  
- **Hypothesis retained:** Geometry/summary of recent draw sets.  
- **Implementation choice to settle:** Specify legal features (sum, gaps, parity, spatial index) and mapping to numbers.  
- **Contract/output:** Diagnostic or forecast adapter; no information about target.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_27 — Nearest Neighbour of Historical Draw Sets**  
- **Hypothesis retained:** Closest historical draw analogues.  
- **Implementation choice to settle:** Define set distance and recency window, neighbour count and tie policy.  
- **Contract/output:** Next-step forecast from successors that are already known.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_28 — Markov Transitions of Draw Summaries**  
- **Hypothesis retained:** Markov patterns between draw-level summaries.  
- **Implementation choice to settle:** Define state discretisation/transition fitting and legal-set decoder.  
- **Contract/output:** State distribution + rank/set adapter.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_29 — Physical Draw Position Preferences**  
- **Hypothesis retained:** Differences by actual physical draw position.  
- **Implementation choice to settle:** Use `OPERATOR_DRAWN_ORDER` only; define position-wise features/model.  
- **Contract/output:** Position-aware predictions and ranks.  
- **Inputs:** `O`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_30 — Draw-Order Transition Signatures**  
- **Hypothesis retained:** Transitions between consecutive ordered draw sequences.  
- **Implementation choice to settle:** Define order features/lags and conditional forecast scheme.  
- **Contract/output:** Ordered or unordered forecast with explicit mapping.  
- **Inputs:** `O`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_31 — Plackett–Luce Sequential Selection**  
- **Hypothesis retained:** Sequential Plackett–Luce choices without replacement.  
- **Implementation choice to settle:** Specify 35 weights, likelihood, updates and separate Powerball model.  
- **Contract/output:** Valid ordered 7-tuple distribution plus set marginals.  
- **Inputs:** `O`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_32 — Permutation/Ordinal Structure of Draw Order**  
- **Hypothesis retained:** Permutation/ordinal pattern transitions.  
- **Implementation choice to settle:** Define pattern coding robust to different number identities and tie-free order.  
- **Contract/output:** Order-oriented diagnostic or forecast.  
- **Inputs:** `O`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

### 7.33 Spectral, curve fitting and long memory (E_33–E_40)

**E_33 — Fourier and Harmonic Occurrence Forecasts**  
- **Hypothesis retained:** Harmonic periodic occurrence components.  
- **Implementation choice to settle:** Define spectral estimation, phase extrapolation and selection of frequency bins.  
- **Contract/output:** Next-step level/score ranking.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_34 — Wavelet-Localized Cycles**  
- **Hypothesis retained:** Wavelet-scale localised periodic signals.  
- **Implementation choice to settle:** Choose wavelet family, boundary correction, prediction transform.  
- **Contract/output:** Ranks/diagnostic by scale.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_35 — Singular Spectrum Analysis**  
- **Hypothesis retained:** Singular-spectrum decomposition.  
- **Implementation choice to settle:** Choose embedding dimension, components and forecast recurrence rule.  
- **Contract/output:** Next-step scores/ranks.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_36 — Gaussian-Process Next-Step Curves**  
- **Hypothesis retained:** Gaussian-process time-series patterns.  
- **Implementation choice to settle:** Choose kernel, time coordinates, likelihood and computational approximation.  
- **Contract/output:** Probabilities only if derived coherently.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_37 — Spline and Local-Polynomial Extrapolation**  
- **Hypothesis retained:** Splines and local polynomial extrapolation.  
- **Implementation choice to settle:** Choose spline order/window/penalty and endpoint derivative rules.  
- **Contract/output:** Forecast scores/ranks.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_38 — Empirical Mode Decomposition**  
- **Hypothesis retained:** Empirical-mode decomposition signals.  
- **Implementation choice to settle:** Specify decomposition algorithm, mode forecast/extrapolation, endpoint treatment.  
- **Contract/output:** Scores/diagnostics with explicit boundary checks.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_39 — Detrended Fluctuation and Long-Memory Features**  
- **Hypothesis retained:** Long-range fluctuation and memory conditioning.  
- **Implementation choice to settle:** Select detrending scales and feature-to-prediction adapter.  
- **Contract/output:** Diagnostic signal until adapter frozen.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_40 — Nonlinear Phase and Periodicity Maps**  
- **Hypothesis retained:** Phase-space maps and nonlinear periodicity.  
- **Implementation choice to settle:** Define state representation, phase features, evolution and mapping.  
- **Contract/output:** State/rank outputs; no gratuitous chaos claim.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

### 7.41 Information theory and nonlinear dynamics (E_41–E_48)

**E_41 — Context-Tree and Compression Prediction**  
- **Hypothesis retained:** Variable-order symbol/context predictors.  
- **Implementation choice to settle:** Define symbolisation, context tree, smoothing and legal draw decoding.  
- **Contract/output:** Forecast set/categorical distribution or ranked adapter.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_42 — Conditional Mutual Information Features**  
- **Hypothesis retained:** Information-theoretic conditional features.  
- **Implementation choice to settle:** Specify variables, conditioning set, estimator and predictive-head mapping.  
- **Contract/output:** Diagnostic only until forecast adapter defined.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_43 — Transfer-Entropy Directional Signals**  
- **Hypothesis retained:** Directional transfer entropy.  
- **Implementation choice to settle:** Define lag/history embedding, conditional estimator and model mapping.  
- **Contract/output:** Diagnostic-only or declared predictive adapter.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_44 — Recurrence-Plot Analogue Prediction**  
- **Hypothesis retained:** Recurrence-plot similarity in reconstructed state.  
- **Implementation choice to settle:** Define embedding, recurrence radius, feature aggregation, future forecast.  
- **Contract/output:** Next-step scores / recurrence indicators.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_45 — Delay-Embedded Nearest-Analogue Forecast**  
- **Hypothesis retained:** Nearest analogues in delay-embedded trajectories.  
- **Implementation choice to settle:** Specify lag dimension, metric and successor observations permitted.  
- **Contract/output:** Forecast state and legal-number adapter.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_46 — Local S-Map Nonlinear State Forecast**  
- **Hypothesis retained:** Local S-map state dynamics.  
- **Implementation choice to settle:** Choose embedding, localisation parameter, regularisation and decoder.  
- **Contract/output:** Predicted state/ranks.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_47 — Lyapunov-Style Instability Conditioning**  
- **Hypothesis retained:** Instability/Lyapunov-style conditioning.  
- **Implementation choice to settle:** Define estimation and how instability drives a forecast.  
- **Contract/output:** Diagnostic or gated predictive head.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_48 — Cross-Mapping of Potentially Connected Processes**  
- **Hypothesis retained:** Cross-mapping with external/connected series.  
- **Implementation choice to settle:** External `X` must be time-available; define lag embedding, test and forecast use.  
- **Contract/output:** Conditional diagnostic/forecast without target-time hindsight.  
- **Inputs:** `U+X`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

### 7.49 Machine learning, external signals and ensembles (E_49–E_56)

**E_49 — Regularized Logistic Event Forecasts**  
- **Hypothesis retained:** Regularised Bernoulli/inclusion classifiers.  
- **Implementation choice to settle:** Define labels, lag features, imbalance and 7-set reconciliation.  
- **Contract/output:** Predictive scores/marginals with validity checks.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_50 — Random-Forest Conditional Patterns**  
- **Hypothesis retained:** Random forest conditional patterns.  
- **Implementation choice to settle:** Choose features, split policy, origin-specific fit and without-replacement adapter.  
- **Contract/output:** Number ranks and possible uncertainty.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_51 — Boosted-Tree Interaction Discovery**  
- **Hypothesis retained:** Gradient-boosted interaction models.  
- **Implementation choice to settle:** Define feature matrix, hyperparameters and legal selection adapter.  
- **Contract/output:** Scores/ranks; candidate dependency later.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_52 — Reservoir Computing for Latent Dynamics**  
- **Hypothesis retained:** Reservoir recurrent state model.  
- **Implementation choice to settle:** Specify reservoir weights, echo-state dynamics, training and legal output decoding.  
- **Contract/output:** Latent sequence forecasts and rankings.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_53 — Evolutionary Symbolic Regression**  
- **Hypothesis retained:** Evolutionary symbolic formula discovery.  
- **Implementation choice to settle:** Define grammar, variables, fitness training subperiod, search budget.  
- **Contract/output:** Frozen formula plus predictions; no hindsight target.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_54 — External-Date Covariate Synchrony**  
- **Hypothesis retained:** Date-aligned external environmental or other covariates.  
- **Implementation choice to settle:** Specify `X` series source/availability time, lag use and fitting.  
- **Contract/output:** External-conditional score/rank or diagnostic.  
- **Inputs:** `U+X`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_55 — Complementarity-Aware Multi-Method Combination**  
- **Hypothesis retained:** Combine methods by complementarity.  
- **Implementation choice to settle:** Only prior-time frozen constituent forecasts; define combination and weights in later R3.  
- **Contract/output:** ENSEMBLE_RESULT; new permanent E identity already present.  
- **Inputs:** `R`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_56 — Adaptive Temporal Method Mixtures**  
- **Hypothesis retained:** Time-varying selection/mixture of forecasting methods.  
- **Implementation choice to settle:** Define switching rule learned without target outcome; avoid holdout selection.  
- **Contract/output:** ENSEMBLE_RESULT with policy version, R3 selection.  
- **Inputs:** `R`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

### 7.57 Pilot-wave-inspired mathematical family (E_57–E_62)

**E_57 — Fixed-Size Determinantal Seven-Set Model (C-PW1)**  
- **Hypothesis retained:** Seven-set determinantal point process with fixed cardinality.  
- **Implementation choice to settle:** Specify symmetric PSD 35x35 L, seven-set partition Z_7(L); uniform L=I; fit regularised restricted L.  
- **Contract/output:** MAIN_SET_DISTRIBUTION and optional main marginals; Powerball separately modelled.  
- **Inputs:** `U (main)`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_58 — Unconditioned Coupled Latent-Wave Field (C-PW2)**  
- **Hypothesis retained:** Unconditioned complex latent-wave field.  
- **Implementation choice to settle:** Specify norm-preserving U, restricted degrees, historical fit and lawful 7-of-35 selection adapter.  
- **Contract/output:** Rank/set and Powerball outputs; no observation-conditioned state correction.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_59 — Draw-Conditioned Coupled Latent-Wave Field (C-PW3)**  
- **Hypothesis retained:** Conditioned complex latent-wave field.  
- **Implementation choice to settle:** Specify preceding-draw state update, norm preservation, same legal observation model as E_58.  
- **Contract/output:** Forecast after state update using at most N-1.  
- **Inputs:** `U`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_60 — Post-Change Non-Equilibrium Relaxation Analogue (C-PW4)**  
- **Hypothesis retained:** Transient post-change relaxation model.  
- **Implementation choice to settle:** Specify eligible known/inferred change dates, decay law, base propensity and legal seven-set model.  
- **Contract/output:** Next-step transient score/propensities; apparatus optional.  
- **Inputs:** `U, optional X`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_61 — Guided-Particle Circulation Model (C-PW5A)**  
- **Hypothesis retained:** Deterministic hidden ring particles with shared wave guidance.  
- **Implementation choice to settle:** Reference K small, beta=2alpha, epsilon=0, node-free, no independent noise; explicit weighted selection.  
- **Contract/output:** Legal ordered or unordered likelihood; hidden order diagnostic not gate.  
- **Inputs:** `U, optional drawn-order O`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

**E_62 — Guided-Particle Circulation with Reinjection (C-PW5B)**  
- **Hypothesis retained:** Guided ring particles with outcome-dependent reinjection.  
- **Implementation choice to settle:** Specify reinsertion/reinitialisation map and time-order of post-draw state changes; preserve E_61 reference distinctions.  
- **Contract/output:** Legal set/ordered forecasts; feedback affects only future draws.  
- **Inputs:** `U, optional drawn-order O`. **Status:** candidate; all unratified numerical sub-variants remain documented rather than silently accepted or rejected.

### 7.9 Method-family invariants and additional E_57–E_62 details

**R2-C14 [PROPOSED]:** Where a method supports both barrels, it shall operate on two separately labelled target domains, even if the fit can share research code. A method designed only for main seven-sets (especially E_57) must not pretend to provide a full independent Powerball model; it can expose a main-only output and, if required, a separately identified one-ball companion/combination method.

**DPP distinction for E_57:** A fixed-size determinantal point process has `P(S) = det(L[S,S])/Z_7(L)` with **symmetric positive-semidefinite L**, and uniform legal sets when `L=I`. A diagonal L yields a fixed-size product-weight subset law, **not** the same distribution as sequential weighted Wallenius draws. R2 must preserve this distinction in method metadata and tests. Off-diagonal DPP structure is diversity/repulsion, not arbitrary positive association.

**E_58/E_59:** For a norm-conserved 35-component complex state `psi`, the value `|psi_i|^2` is at most a categorical-style propensity; it does not by itself form an exact seven-number draw. Both must specify a **valid without-replacement selection mechanism**. E_58 evolves a previously fitted field without per-draw state correction; E_59 updates latent state after each *already observed* result and then advances. Neither's quantum inspiration is physical evidence.

**E_60:** Time-since-change models may use dated observed apparatus changes **if records exist**, or controlled change-point inference from history available at each origin. No apparatus metadata is mandatory. The beginning of the new rules is an eligible epoch boundary, but there are no preceding same-configuration outcomes before Draw 1144 to estimate a direct pre/post baseline there.

**E_61 reference mathematics (preserved from R1):**

```text
psi(theta,t) = SUM_{k=-K..K} c_k exp(i[k*theta - alpha*k^2*t])
SUM_{k=-K..K} |c_k|^2 = 1
|c_0| > SUM_{k != 0} |c_k|                 # sufficient node-free condition
beta = 2*alpha ; epsilon = 0
velocity(theta,t) = beta * Im(conj(psi)*dpsi/dtheta) / |psi|^2
w_j(t) = exp(kappa*cos(theta_j(t)-theta_capture))
```

Here `theta_capture = 0` can fix rotational gauge. Particle labels 1–35 (and separately 1–20) occupy positions on a ring, evolved by the common smooth field. At the main draw, seven distinct labels are selected sequentially without replacement using the positive weights. `kappa=0` nests the uniform legal outcome model. A nonzero Fourier truncation `K=1` does **not** force rigid rotation because it can include `-1,0,1` simultaneously; a single occupied mode gives constant velocity. A node-free exactly guided one-dimensional reference has order-preserving deterministic trajectories, **not a claim of chaos**. Standing-wave or frozen dynamics is a legitimate fitted outcome, not itself a predictive discovery. Allow non-node-free/epsilon-regularised, free-beta, independent-noise, shared-noise, 2D torus and other variants as separate precisely labelled future specifications. An unconstrained variant's numerical difficulty is no grounds for deletion.

**E_61 inference:** Fit unknown coefficients, positions, capture sharpness and dispersion **before** each target, using a declared method such as windowed multistart optimisation, MCMC or sequential Monte Carlo with rejuvenation. A naïve high-dimensional particle filter is not assumed to work. Synthetic identifiability studies can diagnose ordering recovery and own-model forecasting ability, but **never veto a real-history evaluation**. If synthetic self-recovery fails yet real outcomes appear predictive, report that the proposed particle explanation is unconfirmed even if forecasts perform well.

**E_62 feedback:** State a deterministic/stochastic reinjection rule for labels already drawn **only after their draw has occurred**. The rule can alter latent ordering and must not quietly inherit E_61's strict order-conservation claim. Reinjection may create genuine feedback dynamics unlike E_61's unconditioned reference. Forecasting still stops at N−1.

**R2-C15 [PROPOSED]:** No arbitrary `E_x` is automatically duplicated solely to switch between `UNORDERED_SET` and `OPERATOR_DRAWN_ORDER`. Maintain one project-wide observation policy, retain separately named variants and allocate a new E-number only where the scientific hypothesis itself materially changes and the user approves.

---

## 8. Windows launcher, environment and acceptance gates

**DECIDED/PROVISIONAL.** First architecture uses standalone E-method `.py` programs and a coordinator provisionally launching through protected `Run_Experiment.bat` (Option F); acceptance remains conditional on real Windows review. The launcher preserves expected `.venv` interpreter, temporary activation/restore and numerics thread controls; manual and coordinated paths must produce identical canonical bytes. The root batch `install_upgrade_dependencies_into_venv.bat` is **the sole human-maintained authoritative dependency list**, defaulting to install **and upgrade** at operator invocation; an experiment/forecast launcher never upgrades implicitly. Generate resolved Python and PyPI versions, installation-script revision/digest and Git identity for every consequential benchmark and genuine FINAL batch.

After **every package upgrade** STOP before work until full applicable offline, boundary, numerical precision and E_1 synthetic/real golden tests pass. Do not change dependencies between freezing and scoring a forecast or within Mode H; its manifest pins exact environment (R3-T50). Separate future Python interpreter/numerical library versions need explicit evidence where deterministic numeric behaviour can differ.

**Mandatory gates (not passed merely by writing a test):** one vs six bit equality; stand-alone/launcher equivalence; CMD quoting, exit-code propagation, Ctrl+C, streams, auto-run/environment behaviour; `psutil` process tree/creation-time identity and orphan handling; no unsupported Windows redirector PID identity assumption; bounded memory and six-worker concurrency; stale/missing receipt rejection and result firewall; suffix poisoning; `.base` isolation; derived date metadata; game-ID collision; exact E_1 goldens. All dangerous process termination switches remain FALSE until a separate approval. A later change to experiment-spawned subprocesses or worker cap is **OPEN** pending owner authorisation.

## 9. Scientific result and evaluation interface

Frozen forecasts include game/draw key, method E-number, variant, selected allowed view/schema/digest, profile/era, training bound, model config, fit seed and readout/tie version, numerical environment, canonical prediction content and explicit TOP/WORST/native joint-set/unavailable statuses. Native ranking outputs must not be fabricated for inapplicable methods. Frozen outputs may not change when a later result is scored. Rank position is computed only by the separately controlled R3 evaluator after the appropriate actual outcome becomes eligible. Real/synthetic datasets, results, evaluation, holdout and prospective tracks use game-qualified disjoint namespaces. Outcome auditors permitted to inspect quarantined fields output only bounded pass/fail/counts/draw key/field name—never values in logs, charts, fixtures, diagnostics or dumps. A scorer must verify manifest/game/target/receipt/freeze status and global orphan interlock **before** accessing one authorised target outcome.

## 10. Decision ledger, open items and execution stop

**DECIDED:** ERR-R2-01, ERR-R2-03, ERR-R2-04 and ERR-R2-05 approved constraints; ERR-R2-02 Option F remains *provisional*. The reviewed §5C safety boundary is not relaxed. **OPEN, not assumed:** E_54 external-feed contract and historical availability; per-method FORMULA_OPEN; first Oz scientific experiment; start of each game's FINAL track; cross-game features; walk-forward target windows (POWERBALL proposed 1145–1576, OZLOTTO proposed 1475–1693); owner-supplied pre-boundary real fixture (optional); Mode H outcome-storage and release protocol; any E_63 extension.

**No authorisation:** Consolidation does **not** authorise Oz scientific model fit/prediction/scoring, recalculation/modification of frozen Powerball E_1 outputs, Mode H opening, FINAL, live acquisition/update, changing process kill gates, or unreviewed Windows tests. Keep all methods' independent science eligibility distinct from engineering statuses.


## 11. Required acceptance tests (updated from ratified R2 T-01–T-39)

These named tests remain individually auditable. References to FINAL operations are **conditional scenarios**, never authorisation to execute them. A listed test must PASS, or remain explicitly PENDING, under its applicable gate.

| T-01 | Out-of-range ball, duplicate main number, wrong count | Rejected/quarantined with exact reason |
| T-02 | Pre-era draw (Powerball <1144 or Oz <1474) or older game-matrix rule injected | Excluded; explicit policy violation if used as actual eligible observation |
| T-03 | Master drawn-order set and independently checked provenance disagree on balls/barrel | Halt/quarantine affected draw; no silent preference |
| T-04 | Unordered sorted U-view treated as physically verified extraction positions | Must fail view-type assertion |
| T-05 | **MANDATORY adversarial leakage test:** run a stochastic and deterministic historical target N, then modify N and every later row (and append later rows), with training rows `<N` unmodified | Identical complete canonical prediction bytes, rankings, TOP, WORST, content IDs and seeds; only external provenance metadata may change. Fail if a whole-file seed, cache or warm start introduces change |
| T-06 | Post-draw external datum with earlier event date | Not admitted if publication time is after cutoff |
| T-07 | Fake synthetic source flagged as REAL | Namespace/provenance check rejects it |
| T-08 | Synthetic fit checkpoint offered to real predictor | Rejected; no latent state can cross namespace boundary |
| T-09 | Probability with negative entries/invalid sum | Numeric validation failure, not an invented winner |
| T-10 | Main set contains repeat/incorrect count | Forecast validation failure |
| T-11 | Order view absent for ordered-only method | `UNSUPPORTED_INPUT_VIEW`, not method deletion |
| T-12 | Warm start derived from a future target | Reject dependency lineage |
| T-13 | One vs configured maximum six workers, same job identities | Bit-identical canonical forecast bytes by default |
| T-14 | Worker timeout/crash/out-of-memory | Explicit status with no fabricated duration |
| T-15 | Benchmark report generation | Contains only resource/timing/status/digest fields; no scores or predicted numbers |
| T-16 | Repeated source with altered bytes | Full source digest/run provenance reflects changed snapshot. If alteration is only at/after target N, unchanged permitted training implies **unchanged forecast content/seed**; never silently overwrite the archived original |
| T-17 | Permitted FINAL real next-draw run | Only after explicitly authorised prospective opening: uses all then-permitted game-history through `L` with governed holdout release and forecasts `L+1`; archives immutable pre-draw evidence |
| T-18 | Holdout evaluation attempted from development mode | Denied with auditable status |
| T-19 | Each E-method registration E_1–E_62 | Exact names/IDs present, including unimplemented and blocked candidates |
| T-20 | E_57 diagonal DPP treated as sequential weighted draw | Distinct-law check FAIL until corrected |
| T-21 | E_58/59 raw `|psi|²` treated as valid seven-set probability | Invalid; must specify lawful seven-number selection |
| T-22 | E_61 κ=0 legal sequence/set model | Equal-probability seven-of-35 model, independent of hidden trajectories |
| T-23 | Historical prediction target N | Method receives only its game-era eligible rows strictly before N, then independent evaluator compares frozen forecast with actual N |
| T-24 | Owner-approved master update adds validated draw L+1 | Only an independently authorised next FINAL run may forecast L+2; prior L+1 forecast and evaluation remain unmodified |
| T-25 | Synthetic diagnostics or apparent low chance cited as reason to label a real forecast a bug/coincidence | Label remains provisional unless specific supporting evidence exists; verified code faults distinctly recorded |
| T-26 | Optional external features absent | Core draw-number-only forecasting still runs; no exact timestamp requirement |
| T-27 | `transitory_data/` files left from a prior run | No automatic read/reuse as authoritative inputs; scratch isolation and Git ignore verified |
| T-28 | Method fit state written to scratch and another run starts | No implicit intermediate-state reuse; any authorised checkpoint requires explicit lineage and configuration |
| T-29 | Repeated real FINAL forecasts and later known results | All pre-draw TOP/WORST forecasts archived intact, outcomes and later rank-position scores added separately, unsuccessful/failed targets retained |
| T-30 | Ranking-capable method freezes full main/Powerball rankings | All 35 and all 20 labels respectively in complete deterministic order, with tie metadata and no missing/duplicate labels |
| T-31 | TOP/WORST prediction generation for an ordinary marginal-ranking method | TOP uses highest seven/highest one; WORST is obtained by **exactly reversing the same frozen complete ranking** and selecting its first seven/first one, under the separately declared prediction-time tie policy; no refit or rerank is permitted |
| T-32 | Joint-set TOP model with available marginals | Preserve native TOP set; WORST uses seven lowest marginal ranks, **not** a fabricated minimum-probability joint set; native TOP/WORST overlap is permitted |
| T-33 | Diagnostic/set-only method with no genuine full ranking | Explicit per-barrel `INVERSE_UNAVAILABLE` with reason; no fabricated marginal, result or missing-method suppression |
| T-34 | After actual draw, calculate rank-position mean using tied frozen scores | Mid-rank applied only in evaluator; TOP/WORST archived canonical content stays byte-identical before and after revealing actual target |
| T-35 | One real target run with all registered runnable variants | Exactly one frozen complete pre-draw batch; all TOP/WORST or unavailable/failure records present; pushed remotely before draw and auditable as such |
| T-36 | Attempt post-result insert/replace in the prospective batch | Immutable batch rejects mutation; later changes recorded as labelled retrospective reruns with distinct lineage |
| T-37 | Serial-versus-six-worker TOP/WORST stochastic run | Identical complete canonical bytes, including full frozen rankings and inverse status, for matched environment and seed identity |
| T-38 | Report a successful prospective TOP/WORST hit | Preserve separate track for each method/variant/selection rule; report reference chance rate as comparison, never automatic coincidence verdict; keep rank-position metric post-draw and separate |
| T-39 | Weekly live-cycle start before scoring definitions are ratified | Block prospective production mode until R3 predeclares TOP, WORST and rank-position evaluation and reporting rules; do not replace a scheduled actual draw with retrospective predictions |


### 11.2 Method-specific mathematical and failure fixtures

Each implemented method needs an independently calculable small numerical fixture, no-look-ahead, stochastic-seed (where applicable), invalid-numeric and result-type tests. Diagnostic-only outputs are validated as diagnostics without fabricating winners. Retain specific E_57 DPP PSD/Z7/identity, E_31/E_61 ordered/sequential likelihood normalisation, E_58/E_59 lawful fixed-size-set distributions, and E_61/E_62 noise/reference dynamics tests. Do not interpret synthetic failures as automatic method exclusion. Full original test catalogue is traceable from ratified R2 §11.

## Appendix S — Superseded provisions (historical only; no operative authority)

- Former Powerball 1578–1587 holdout and development cap 1577, former Oz “ten highest draws in the first accepted snapshot” rule and seal step, and `DEV_TO_DATE = 2026-08-07`: withdrawn; see R2 §2 and R3 §6 for fixed August-1 quarantine.
- Earlier two-CSV Powerball source model, 444-row snapshots, separate Oz winning/raw CSV, provisional scraper/API and `Run_Scraper.bat`: historical only; versioned owner-run results masters and ledger are authoritative now.
- Earlier mandatory one-versus-twelve testing, optional twenty-four-worker initial trial and maintained `requirements.txt`: withdrawn by ERR-R2-01/03; current 1–6 worker acceptance and one batch-file dependency authority apply.
- Old discussion chronology and conditional statements saying R2/R3 are not yet ratified, no E_1 code exists, or development source acceptance is outstanding: historical only.
- This Appendix S is a short provenance index, not a second operational procedure. The exact old source texts are retained unchanged in Git.
