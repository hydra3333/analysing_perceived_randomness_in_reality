# Predictive Randomness — Ratification Register

**Register version:** v0.3 CONSOLIDATED REVIEW CANDIDATE / NOT RATIFIED; v0.2 OWNER-RATIFIED 24 October 2026; first register issued for repository installation. Earlier administrative v0.1 was reviewed/proposed but was **not present in HEAD `1c7cfced`**. Historical ratifications themselves remain valid and do not depend on installing this index.  
**Basis:** the historical owner decisions and approved handovers, with current committed files cross-checked by Claude at GitHub HEAD `1c7cfced` (24 October 2026). Ten other content hashes matched that HEAD; the Architecture hash below is explicitly corrected to the **actually committed** v0.5 content (unfixed §5C heading). The separately proposed one-line heading change and register v0.1 were **not committed**. New multi-game documents below remain review candidates and are not approved.  
**Authority:** This register records approvals; it does **not** independently ratify any document, authorise an experiment, or supersede an operative specification. If a historic document still says “draft”, “review candidate” or “not ratified”, its status at the time of drafting is historical. The later owner approval recorded here determines its current status.

## Current and historical ratification identities

SHA-256 below is computed from **UTF-8 Git-stored file content with LF line endings** (the canonical content represented by the source GitHub ZIP and ratified install artifacts), *not* from a Windows working copy whose checkout may have CRLF endings. The Architecture v0.5 hash below represents **actual Git-committed v0.5 content**, including the historical §5C heading. The corrected-heading version (`2d57f59afbd152ae80720e117dab5b9749ab3a611bf32ab1b14d3ed1be478acd`) was only proposed, never committed; Architecture v0.6 would replace it after ratification, without changing the v0.5 historical bytes. Hashes are immutable document-content identities, not Git commit IDs.

| Document (under `doc/`) | Authority and status | Owner approval date | Superseded by / qualifier | Git-content SHA-256 |
|---|---|---|---|---|
| `Predictive_Randomness_Research_Project_Proposal_v0_3.md` | Historical — OWNER-RATIFIED | 21 Oct 2026 | Proposal v0.4 | `04e061d13b69e49c0dc227b7093570e96598d4c416952ac6092af4d3d14d4b64` |
| `Predictive_Randomness_Experimental_Methods_Research_R1_v0_4.md` | Current — OWNER-RATIFIED | 21 Oct 2026 | — | `19809ae8a1aca716c6c6a4de71a37b705129304894a2b382036d51b76575b99f` |
| `Predictive_Randomness_Experimental_Method_Specifications_R2_v0_3.md` | Current — OWNER-RATIFIED | 22 Oct 2026 | — (R2 approved erratum v0.2 also applies) | `7ec4bad9ab00a619a42cedc4abbe4bec393589563d3bc3061ab4737525259d71` |
| `Predictive_Randomness_R2_v0_3_Approved_Erratum_v0_2.md` | Historical — OWNER-APPROVED narrow erratum | 22 Oct 2026 | — (ERR-R2-02 remains provisional pending P2) | `a08b4e7620be8cb32142b23146c5f82c415a50e56cba0b2ea3bed6e1a4b80d5e` |
| `Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_2.md` | Historical — OWNER-RATIFIED | 22 Oct 2026 (ratified handback v0.2) | R3 v0.3 | `dd0b5243ad8f93a0de7c502e2e6ce54a99c5e427063ce7b3e49313fb18975800` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_4.md` | Historical — previously OWNER-RATIFIED | 23 Oct 2026 | Architecture v0.5 | `7526e381be93caa68ce8f8a6b90f135748925f1c0b080e171e1ef18cd771f257` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_5.md` | Historical — OWNER-RATIFIED | 23 Oct 2026 | Architecture v0.6 | `9889617f39be766a167856fdd171896c1ffb712aae8db4e78d6f3d861a345502` |
| `Predictive_Randomness_Windows_POC_Implementation_Task_Specification_v0_1.md` | Historical — OWNER-RATIFIED for P0–P2 | By 23 Oct 2026; precise date not independently established | Windows POC Task Spec v0.2 | `deeae27f846061d51555c3d89a77c8199941b74456520a98aa6501c504b85e5e` |
| `Predictive_Randomness_Windows_POC_Implementation_Task_Specification_v0_2.md` | Current — OWNER-RATIFIED | 23 Oct 2026 | — | `ca5e89dde7e9927974e759f1df115eefca03144de45e073c240aa9e13f24ebf1` |
| `HANDOVER/Predictive_Randomness_ChatGPT_Continuation_Handback_v0_2.md` | Historical — OWNER-RATIFIED | By 23 Oct 2026; precise date not independently established | Handback v0.4 | `53b33b6ddec5b874725b195d4c45e3295351915a6e8331e2d2eb56d4b8a28140` |
| `HANDOVER/Predictive_Randomness_ChatGPT_Continuation_Handback_v0_4.md` | Current — OWNER-RATIFIED | 23 Oct 2026 | — | `5093e446fb14bc281fecea1e722ee2bea366614dac9fb5192e36b96b63e603db` |

## Multi-game documents ratified 24 October 2026

| Ratified document | Authority and supersession | Git-content SHA-256 (UTF-8/LF) |
|---|---|---|
| `Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_3.md` | OWNER-RATIFIED; supersedes R3 v0.2 for multi-game evaluation extensions | `69d61d162d8d46094c02c1aca36ba53b47e6aec56fe5552f3ef39687f07d0826` |
| `Predictive_Randomness_R2_v0_3_Erratum_Record_v0_3.md` | OWNER-APPROVED ERR-R2-05; preserves earlier errata, ERR-R2-02 still provisional | `f3be1b28bb156ec68207ad6cd614972bedcd2409519c9e8dd6a8751c41a5768e` |
| `Predictive_Randomness_Software_Architecture_Discussion_v0_6.md` | OWNER-RATIFIED; supersedes Architecture v0.5; existing safety conditions preserved | `99b8222b0d905fc45eda7723997aa9cfcbe7ba09a5b0b8d322b9eea3e766cea7` |
| `Predictive_Randomness_Research_Project_Proposal_v0_4.md` | OWNER-RATIFIED; supersedes Proposal v0.3 for multi-game scope | `1749889d4f02825b15a8f317e9620b2ab8b26908c41eda8611157c1675f089b5` |
| `Predictive_Randomness_MultiGame_Infrastructure_P3_Task_Specification_v0_1.md` | OWNER-RATIFIED new task specification; POC task v0.2 retained separately | `86c4d062cafab07595953e5447ec5ae5b287e0d98e2fa4ec35c1015e0fa052f4` |
| `contracts/TIE_SHA256_V1_Ratified_Encoding_v0_2.md` | OWNER-RATIFIED multi-game applicability; encoding unchanged | `045b784d16a4611ac4ba5e8af063733e957b0b9359882d52b7143b912a65a0b6` |

**Register identity:** this register cannot include its own SHA-256 without a self-reference. Its final file hash is provided in the enclosing installation manifest; update the register only in a later version after a corresponding owner decision.


## Interpretation and verification

- The **current** governing set is Proposal v0.4, R1 v0.4, R2 v0.3 as modified by approved erratum record v0.3 (including prior errata), R3 v0.3, Architecture v0.6, Windows POC Task Specification v0.2 and Multi-Game P3 Task Specification v0.1. ChatGPT Handback v0.4 records continuity, not a replacement for these specifications.
- ERR-R2-02 / Option F is **provisional for production** pending the P2 test evidence and owner disposition, even though the Architecture and POC Task Specification are ratified.
- The **failed/orphan-group result firewall** is OWNER-RATIFIED on 23 October 2026. Never consume downstream results from failed or orphan-suspected groups, even when a canonical result file exists.
- **Later owner report (23 October 2026):** the reviewed, incident-specific orphan-clearance utility completed `CHECK PASS` and `MANUAL CLEARANCE PASS`, preserving the archived FAILED evidence and writing a clearance record; a subsequent one-worker P2 canonical fixture passed and left no marker. The repository is not itself live-state proof; always recheck the current global marker before any future launch. These observations do not close P2 or authorise destructive tests.
- This register does not authorise process termination, destructive testing, holdout unsealing, Oz Lotto scraping or Oz science. Previously authorised Powerball E_1 historical development and the verified draw-1577 run are historical facts, not permission for new Oz runs. The current multi-game development pause remains binding. The historic-development draw ceiling is not a permanent constraint on later authorised prospective FINAL prediction, normal retraining, operation or maintenance; the holdout remains governed by its separate protections.
- To verify a Git-stored file hash on Windows CMD after committing, substitute the path and run: `git show HEAD:doc/EXAMPLE.md | python -c "import sys,hashlib;print(hashlib.sha256(sys.stdin.buffer.read()).hexdigest())"`. Git may normalise checkout line endings; `certutil -hashfile` on a CRLF working file can legitimately differ.
- Where an exact historic ratification day is not independently substantiated, the register says so rather than assigning a date without evidence. Improve those entries only when a documentary decision record supports the update.

## Change discipline

This owner-ratified v0.2 is intended as the first committed register; the earlier v0.1 and single-line Architecture heading fix were uncommitted administrative housekeeping. They do not alter technical policy, scientific method contracts, executable code, or experiment evidence. Preserve earlier document versions. Future substantive changes still follow ChatGPT draft → Claude review at the required gates → owner ratification.


## Proposed consolidated current editions — NOT RATIFIED

This register preserves the **17 previous ratified-file SHA-256 entries unchanged** in the tables above. Those are historical authority evidence, not hashes of the proposed new editions. Following the owner's decision to consolidate, the new candidate documents are the following **self-contained normative versions**, rather than layering amendments 0A/0B or retaining a separate operative R2 erratum:

| Proposed current edition | Historical governing predecessor | Current proposal status |
|---|---|---|
| Proposal v0.5 (CONSOLIDATED) | Ratified Proposal v0.4 | CANDIDATE, not ratified |
| R2 v0.4 (CONSOLIDATED) | R2 v0.3 + previously approved ERR-R2-01..05 + proposed ERR-R2-06 | CANDIDATE; ERR-R2-02 Option F remains PROVISIONAL pending Windows gates |
| R3 v0.4 (CONSOLIDATED) | Ratified R3 v0.3 | CANDIDATE, not ratified |
| Architecture v0.7 (CONSOLIDATED) | Ratified Architecture v0.6 | CANDIDATE, not ratified |
| P3 v0.2 (CONSOLIDATED) | Ratified multi-game P3 v0.1 | CANDIDATE, not ratified |
| Holdout Exposure Record v0.1 | new, factual and value-free | CANDIDATE |
| Numerical Integrity and Retraining Technical Reference v0.1 | new, NON-NORMATIVE; operative requirements in R2/R3/Architecture | CANDIDATE |
| Ratification Register v0.3 | owner-ratified v0.2 | CANDIDATE, not ratified |

**Owner-decided changes awaiting this ratification:** fixed 1 August 2026 quarantine and first-ten holdouts, versioned development masters with ledgers, source and provenance, assumed published order, free choice of safe reader representations, byte-owning prefix views, full-width `int64`/`float64` numeric types, opt-in date digests, default install-and-upgrade with mandatory regression tests, fresh per-target fitting and fixed safety gates. See candidate normative source sections and the cross-document requirement disposition matrix; do not treat this register as an independent authorisation for Mode H, scoring, scientific coordination or process termination.

**Historical handovers:** ChatGPT handbacks v0.6 and v0.6r1 were reported committed and are historical, not the accepted replacement new-coder handover. Exact HEAD bytes must be independently checked at final installation. A definitive handover will be prepared and independently reviewed only after these consolidated governing documents are ratified, installed and pushed.

**After ratification only:** update this register with actual installed canonical file SHA-256s, owner approval dates, the final Git HEAD and exact supersession. Do not insert self-referential register SHA into its contents; carry it in the enclosing installation manifest. Historical ratified documents, R1 v0.4 and TIE note v0.2 remain intact.

## Consolidated v0.2 candidate source dispositions (informational; NOT RATIFIED)

| Source / status | Treatment |
|---|---|
| R1 v0.4 | Unchanged operative method-catalogue source; may contain historical Powerball 1587 results; exposure recorded; no edits |
| TIE_SHA256_V1 v0.2 | Unchanged operative tie contract |
| R2 v0.3 + ERR-R2-01..06 | Historical sources; proposed replacement consolidated R2 v0.4 (pending owner ratification) |
| Architecture v0.6, R3 v0.3, Proposal v0.4, P3 v0.1 | Remain ratified until candidate consolidated editions are approved |
| `doc/experiments/P3_E1_..._REVIEW_CANDIDATE` | Historical review candidate, not a replacement governing spec |
| Windows POC Task Specifications v0.1 / v0.2 | Historical engineering planning, superseded by approved §5C and current architecture |
| ChatGPT handovers v0.6 and v0.6r1 | Historical/previous continuity snapshots, not normative and due to be superseded after ratification |
| Claude reviewer handovers v2–v8 | Historical prior-state snapshots; Claude plans current v9 after owner commit |
| Repository root `README.md` | **TO UPDATE LATER**, not adopted as scientific authority in this consolidation |
| Exposure record and numerical technical reference | New candidates, factual or non-normative; not ratified |

The exact Git HEAD, acceptance hashes and installation authority must be reconciled upon the actual owner ratification and commit. No candidate becomes ratified automatically.
