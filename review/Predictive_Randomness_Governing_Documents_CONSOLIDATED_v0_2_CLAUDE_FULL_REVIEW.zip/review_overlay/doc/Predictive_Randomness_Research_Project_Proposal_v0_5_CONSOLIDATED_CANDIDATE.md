# Predictive Randomness — Research Project Proposal v0.5 (CONSOLIDATED REVIEW CANDIDATE)

> **REVIEW CANDIDATE — NOT RATIFIED.** Owner decision is required before replacing the ratified original. This consolidation is not a run approval, Mode H opening, FINAL activation, process-termination permission or source updater instruction. Historical sources remain unchanged in Git.

**Date:** 25 October 2026. **Predecessor:** owner-ratified Proposal v0.4 and documented owner decisions through 25 October 2026. This is a **clean current-state charter**, not an amendment layered above an old body.

## 0. Scope, authority, decision rules

**Authority and status labels.** Existing ratified specifications remain in force until this whole edition is ratified. **DECIDED** = owner decision or still-operative earlier ratified scientific requirement. **RECOMMENDED** = design guidance, not automatically an implementation gate. **OPEN** = requires separate explicit owner decision. A reviewed candidate is not execution authority. Document roles: Proposal = research charter; R1 v0.4 = permanent method research catalogue; R2 = scientific inputs/methods and N−1; R3 = scoring/evaluation/freezing; Architecture = Windows implementation/safety; P3 = staged work; ratification register = authority ledger. `TIE_SHA256_V1` note v0.2 remains authoritative unchanged.

The owner is sole ratifier/committer. ChatGPT implements and Claude independently reviews; the always-review list, `DECIDED` / `RECOMMENDED` / `OPEN` labels, holdout seal, reviewer latitude, global orphan safety interlock and result firewall are unchanged. A reviewed package does not imply a run.

## 1. Purpose and philosophy

**DECIDED.** Study whether disciplined statistical and computational analysis can find reproducible predictive structure in perceived physical randomness. Independently investigate hypotheses that classical models predict should fail; neither rule them out on orthodox grounds nor claim that chance matches prove an anomaly. Separate coding/data defects from interpretations of unusual empirical outcomes; require prospective frozen evidence. Include negative and inconclusive results. Control selective reporting, hindsight and the multiple-investigations problem. Researching the possibility of predictability does not assert that lotteries are predictable.

## 2. Current observational domain and accepted masters

- **POWERBALL**: approved current-era draws **1144–1576**, 433 development observations; first quarantined draw 1577; `FINAL_HOLDOUT_10` **1577–1586**. Accepted source `source_data/POWERBALL_results_master.csv`, version 1, SHA-256 `ce0ae7e77e09e5a93389eb98191b455926ec44c0bb38dda0ef721b9f710d66b8`.
- **OZLOTTO**: approved current-era draws **1474–1693**, 220 development observations; first quarantined draw 1694; `FINAL_HOLDOUT_10` **1694–1703**. Accepted source `source_data/OZLOTTO_results_master.csv`, version 1, SHA-256 `4a6cecc27fb6a5b8aafc0451858f1ea00f31c0eaf83c15c6ba66a0940e83f93f`.
- The development/quarantine split is **calendar-based** (draws from **2026-08-01** onward quarantined); these fixed exact ranges control and do not silently slide. Master integrity, version and provenance are established by the matching append-only `source_data/_results_master_ledger.csv` `INIT` rows and `source_data/_results_master_init_verification.json`. The hashes/row counts were independently cross-checked by Claude at Git HEAD `3ddb8a6`; subsequent HEADs require identity re-verification. All source acceptance is owner-run; the accepted version-1 masters are not pending source confirmation.

Powerball current era begins draw 1144 on 2018-04-19, seven distinct MAIN labels 1–35 plus one POWERBALL label 1–20. Oz Lotto current era begins draw 1474 on 2022-05-17, seven distinct MAIN labels 1–47; three supplementaries are provenance-only, never prediction barrels. Do not mix eras or infer a fictitious Oz Powerball barrel. The datum identity is `(game_id, draw_number)`; collisions in numeric draw IDs between games are legitimate.

The master contains the officially published **drawn sequence** accepted under the owner assumption `OPERATOR_DRAWN_ORDER_ASSUMED_OWNER_DECISION`, **not independently verified physical ball-extraction order**. The scientific views are `UNORDERED_SET`, `OPERATOR_DRAWN_ORDER` and `PAIRED_DIAGNOSTIC` (same events, not two likelihood observations). Raw master supplementary fields are never exposed to methods. The dates are ISO calendar dates; do not invent UTC draw timestamps. Date-consuming methods opt in to an explicitly versioned, digested view.

## 3. Scientific research contract

1. **DECIDED — N−1**: for each target N, fit afresh using eligible game history strictly before N. Changes to N and later raw rows must be incapable of altering method inputs, fit, seeds or predictions. Later observations never enter historical target features by accident.
2. **DECIDED — frozen genuine predictions**: after separately authorised prospective execution, freeze the complete pre-result TOP/WORST and explicit failure/unavailable roster, with code, inputs, provenance, numerical environment and publication proof; then score outcomes separately. Do not backfill, revise or erase failures.
3. **DECIDED — protected quarantine**: fixed per-game windows above are excluded from ordinary development, tuning, benchmark features and model choice. They do not slide as weekly results arrive. Once results have influenced the design/tuning of a method, those results are no longer an independent pristine holdout for that method. Exposure must be disclosed, not silently discarded.
4. **DECIDED — E_1 exception**: the accepted Powerball target-1577 **forecast-only regression** is permitted on pretarget draws 1144–1576, with its frozen hashes, without reading/using/scoring outcome 1577. It is not a Mode H result or proof of holdout performance.
5. **DECIDED — independent streams**: real, synthetic null, planted-effect, benchmark, holdout and (when separately opened) FINAL are distinct scientific identities, storage namespaces and evidence standards. Synthetic investigations may inform disclosed method design but never enter real fitted histories as actual observations. Benchmarks quantify runtime, not predictive merit.
6. **DECIDED — method retention**: all E_1–E_62 identities and variants stay registered; no rejection solely for expense, unconventional hypothesis, overlap/correlation, poor result or inability to form every barrel. Unsupported-for-game and FORMULA_OPEN are explicit, reviewable statuses, not a veto of a hypothesis.
7. **DECIDED — no implicit shared fits**: method-specific fitted parameters are independent. Combination methods can consume approved frozen forecasts, never silently a live peer's mutable fitting state.
8. **DECIDED — views and numerical integrity**: all internal and scientific NumPy integer arrays are `int64`, floating arrays `float64`; Python `int` supports larger exact accumulations. Views are readonly, owned byte-backed pretarget copies. The whole master SHA is provenance only, not a model input or random seed. For implementation details and authoritative tests consult R2 §§3–4 and Architecture §§3–4.

## 4. Two-barrel and single-barrel predictions

Powerball predictions and scoring have MAIN seven-of-35 and POWERBALL one-of-20 channels. Oz Lotto has MAIN seven-of-47 only and POWERBALL **ABSENT** (never fake null or zero channel). Every ranking-capable method preserves its native TOP and WORST outputs simultaneously from the same pre-draw fit; unavailable outputs are declared rather than fabricated. Post-draw hit counts and mean native-score mid-ranks are evaluation only. Scientific meanings of ordered and unordered set observations are governed by R2 §4 and unchanged R2 §4.1 probability mathematics; reporting and tie results by R3.

## 5. Permanent method programme

R1 v0.4 retains the complete research catalogue of E_1–E_62, including the unconventional E_57–E_62 mathematical family. No individual method is removed on statistical orthodoxy or retrospective underperformance. Each method has an immutable identity, documented assumptions, registered variants, appropriate game applicability and separately reviewable formula. Any expansion (including a possible E_63) requires owner review. The owner has not decided the detailed formulas for every experimental method.

## 7. The initial six user-proposed experimental methods

The identifiers and descriptive titles below are a **proposed initial registry**; the underlying six ideas are agreed, but formal mathematics, exact ranking direction, hyperparameters and tie-breaking still require design review.

### E_1 — Historical Appearance Frequency

**Core question:** Have numbers drawn more often in the observed history tended to be drawn more often subsequently?

For each eligible historical interval, count how many draws contain each main number and how many times each Powerball value appeared. Convert counts to percentages or comparable scores and rank candidates, initially favouring the most frequently observed values.

**Potential variations:** Full-history frequencies; recent-window frequencies; decayed frequencies; smoothed frequencies; Bayesian shrinkage; frequency changes over successive periods.

**Interpretation caution:** Frequency differences will occur even when draws have identical underlying probabilities. Unequal sample counts are observations, not on their own evidence of unequal future probabilities.

**Standalone status:** Simple, directly testable baseline and potentially useful component of future ensembles.

### E_2 — Expected Recurrence-Interval Alignment

**Core question:** Which numbers are approaching their own characteristic or optimal recurrence interval **in the next draw**?

For each number, obtain historical gaps between its successive appearances. Estimate one or more characteristic intervals, then compare the projected age of the number **at the target draw** with that interval.

**Critical agreed interpretation:** This is **not** merely “choose whichever numbers are most overdue.” A number may rank most highly when its next-draw age is **near** its fitted characteristic interval, even if other numbers have been absent for longer.

Illustrative possibility — not an approved formula:

- If a number typically recurs at an interval of about five draws and the last appearance was four draws before the proposed next draw, its interval-alignment score might be high.
- Alternatives might use the mean, median, mode, robust centre, a fitted waiting-time likelihood, a harmonic/seasonal recurrence model, or individual multiple characteristic intervals.
- A sensible experiment could compare a **peak-at-the-expected-interval** formulation against an **overdue** formulation as separate parameterised variants or distinct method IDs if conceptually different.

**Technical question to settle:** Whether to measure the interval in draw-number differences, the count of intervening nonappearances, or projected target-draw age. These are offset by one; the chosen convention must be unambiguous and tested.

**Interpretation caution:** Under an ideal independent model, a past absence does not increase or decrease a number’s next-draw inclusion probability; the present experiment tests whether actual data depart from that model or exhibit useful structure.

### E_3 — Occurrence-Curve Endpoint Forecast

**Core question:** If each number’s appearance history is represented as a binary time series, do fitted curves predict which numbers are most likely to appear next?

Represent each draw as `1` if a candidate number appears and `0` otherwise. Fit a curve or time-series function to that historical sequence, and **evaluate it at the next, unobserved draw**, not merely at the last observed draw. Rank numbers by the resulting next-step forecast score.

**Possible families to research:** Polynomial and spline smoothing; constrained smooth curves; regularised regression; local regression; harmonic fits; parametric curves; state-space models and other nonlinear curve fitting.

**Critical safeguard:** A fitted curve can easily interpolate noise and produce edge artefacts. Any tuning of curve family, order, smoothing strength or fit window must respect the walk-forward training boundary.

**Status:** Legitimate as an experiment. Its mathematical fit quality on the training history is **not** proof of next-draw predictive ability.

### E_4 — Occurrence-Curve Gradient Forecast

**Core question:** Does a positive or increasing *slope* in each candidate’s fitted occurrence curve signal a higher probability of appearance at the next draw?

Fit a curve to each candidate’s prior binary sequence, estimate its derivative/gradient at or approaching the forecast point, and rank by an agreed direction and magnitude of the predicted trend.

The endpoint value in E_3 and the derivative in E_4 carry different information and should remain independently testable, even if they share curve-fitting utilities.

**Possible extensions:** First and second derivatives, rate-of-change normalisation, local versus global slope, robust smoothers, slope confidence/stability, and slope-plus-level combinations (which would become separate combination methods).

**Cautions:** Gradients of fits to short, noisy binary series can be extremely sensitive to model order and boundary choice. A rising fitted curve need not continue rising in the next unseen draw.

### E_5 — Shared Population/Draw Distribution Model

**Core question:** Can one selected statistical distribution or stochastic model for the **population of candidate numbers** support meaningful next-draw probability/ranking estimates?

Identify appropriate *discrete* sampling or probability models for the observed phenomenon. Fit their parameters using eligible historical data and derive next-draw rankings separately for the main and Powerball barrels.

**Candidate mathematical constructs to research:** Categorical/multinomial families (for Powerball), finite-population selection structures (for main-ball sets), hierarchical Bayesian models, models of heterogeneous inclusion probabilities, temporal mixtures, and variants that allow drift or dependence.

The question is **not** “which arbitrary continuous curve fits a histogram best?” A Gaussian is usually inappropriate as a literal model for numbered-ball categorical draws, although continuous functions might legitimately appear in an auxiliary smoothing or latent-variable model.

**Cautions:** Distinguish fitting the historical marginal frequency distribution from fitting a predictive *time-conditioned* model. One distribution across the 35 main numbers does not by itself account for the seven-without-replacement structure.

### E_6 — Per-Number Fitted Distribution Models

**Core question:** Can a different estimated distribution or waiting-time process for **each number** yield next-draw ranking information missed by a shared model?

For each candidate number, estimate its historical inclusion process and fit candidate distributions or stochastic process models. Use each model to estimate a next-draw score, propensity, hazard, or appropriately defined appearance probability.

**Candidate constructs to research:** Bernoulli/Beta-Bernoulli models, geometric waiting times, discrete survival/hazard models, renewal processes, mixtures, time-varying inclusion probabilities, and per-number latent states.

**Cautions:** The observation count per number is small. Flexible distribution fitting can badly overfit; an apparent “best distribution” chosen after inspecting many alternatives is itself a selection process that must be tested outside its fitting observations.

### 7.1 No premature verdicts on the six methods

All six will be preserved as distinct conceptual starting methods. They are **not guaranteed to be equally predictive**, and some may turn out to be mostly descriptive or systematically misleading. That possibility does not justify deleting them or preventing their use in later combinations.

### 7.2 Design questions still open within these methods

- Historical fit horizon: all available prior draws, a sliding window, or multiple horizons?
- Which summary statistics and model families are compared?
- Whether scores are raw, normalised, or calibrated as probabilities?
- How are tied scores handled?
- Does an algorithm train one independent model per number or a coordinated multivariate model?
- How do we distinguish a new experimental method from a parameter variant or version change?
- Which outputs are useful to preserve for later ensemble studies?

Those matters must be resolved in the detailed experimental-method design, not silently decided in the first implementation.

---
### 7.3 Refinement of E_2 and relationships among E-methods

**E_2** retains the user’s original *next-draw alignment with a characteristic recurrence interval* as its primary definition. A general **gap-dependent occurrence hazard** is a further candidate parameterisation, permitting peaked, decreasing, rising, bimodal, or irregular dependence on elapsed time since last appearance. A flat hazard describes the conventional reference; it is a comparator rather than an exclusion principle. Mode, median, mean, quantile, robust fitting and fitted gap distributions may each imply different candidate forecasts, and these differences should be recorded as distinct evaluated variants. None is assumed superior before testing.

Several proposed approaches may be mathematically related—for example, decayed frequencies, smoothed occurrence-curve extrapolations and some conjugate-probability updates can all produce different weighted summaries of recent binary history. **Method-family labels, ranking correlation and error-correlation analyses are desirable as reports, not as deletion, implementation-deprioritisation or ensemble-ineligibility rules.** Subtly distinct related methods may still produce useful conditional or ensemble information. Any suggestion of inversion or combination must be tested under its own independently recorded definition.


## 8. Training, benchmarks and evidence

**DECIDED.** For target N, independent fit uses draws `< N`. For genuine future predictions after an independently approved FINAL opening, use all then-eligible valid draws through the latest completed L, subject to each method's declared window; frozen old forecasts are never re-fitted in place. Incremental state reuse requires a **byte-identical comparison with from-scratch fitting** before being accepted. Retain source view digest, model/config revision, package versions, frozen forecast and evidence; keep full transient fit arrays only for a documented scientific/reproducibility reason.

**Computational B1/B10** are strictly timing-only under the new boundary: B1 POWERBALL target **1576** trained 1144–1575 (432 rows), W=100 slice **1476–1575**; B10 targets **1567–1576** with 423–432 preceding rows. Neither benchmark may inspect a result or fit from draw 1577 onward. R2 §6 defines benchmarks and resource reporting. Walk-forward windows remain **OPEN to pre-registration**: proposed Powerball 1145–1576, Oz Lotto 1475–1693; no retrospective window is automatically authorised just by naming it.

## 9. Source provenance and evaluation integrity

The accepted owner-run acquisition tools are `src/two_site_results_check_v0_7.py`, `src/results_master_v0_1.py`, `Run_Results_Updater.bat` and `install_upgrade_dependencies_into_venv.bat`. The Lotterywest results-search browser workflow and optional private Lott hand-saved verification produced version-1 masters. ChatGPT must not replicate or invoke acquisition/update in Package 2. The live `update` path has no automatic authority. Preserve ledger versions, sha256, owner-run evidence, create-only source/raw/backup records and full-file source provenance. Any independent structural auditor observing quarantined records reports only bounded pass/fail, counts, draw keys and field names, never ball values in logs, charts, fixtures or exception dumps.

Never treat Git commit timestamps alone as independent proof of forecast publication before an actual draw. R3 specifies the pre-result freeze and scoring gate. The current Mode H plan remains **OPEN**; specifically, whether the store includes all outcomes or isolates one at a time must be reviewed before any opening. Do not take document ratification as authority to expose, fit or score held-out values.

## 10. Development status and approvals

**DECIDED/DONE:** E_1 accepted standalone Powerball forecast and mathematical/tie goldens; owner-created version-1 two-game masters; documented source validation evidence; protected coordinator v0.6 remains committed. **PENDING CODE:** Package 2 v0.11 reader prefix isolation C1/C2, date digest C3, exact coordinator diff C4, E_1 regressions C5, timing C6. **PENDING REVIEW:** formal Claude review, Windows acceptance gates, scientific result allowlist (currently empty), Mode H and FINAL. Experiment coding occurs in a fresh ChatGPT chat after this documentation set is ratified/pushed and a definitive coder handover independently reviewed by Claude. Roles unchanged.

**OPEN**: E_54 external feed and publication availability, method-specific FORMULA_OPEN cases, first Oz scientific execution, each game's FINAL opening, cross-game features, walk-forward pre-registration and future instrumentation-derived covariates. No unapproved extension can be inferred from the development roadmap.

## 11. Outcome interpretation and project success

Success means a rigorous, reproducible and falsifiable research process with transparent discoveries, failures and uncertainty, not a pre-committed promise of unusual results. Report negative results and uncertainty honestly. No unexplained numerical behaviour, data leakage or non-reproducibility may be relabelled a scientific discovery. 

## Appendix S — Superseded provisions (historical only; no operative authority)

- Former Powerball 1578–1587 holdout and development cap 1577, former Oz “ten highest draws in the first accepted snapshot” rule and seal step, and `DEV_TO_DATE = 2026-08-07`: withdrawn; see R2 §2 and R3 §6 for fixed August-1 quarantine.
- Earlier two-CSV Powerball source model, 444-row snapshots, separate Oz winning/raw CSV, provisional scraper/API and `Run_Scraper.bat`: historical only; versioned owner-run results masters and ledger are authoritative now.
- Earlier mandatory one-versus-twelve testing, optional twenty-four-worker initial trial and maintained `requirements.txt`: withdrawn by ERR-R2-01/03; current 1–6 worker acceptance and one batch-file dependency authority apply.
- Old discussion chronology and conditional statements saying R2/R3 are not yet ratified, no E_1 code exists, or development source acceptance is outstanding: historical only.
- This Appendix S is a short provenance index, not a second operational procedure. The exact old source texts are retained unchanged in Git.
