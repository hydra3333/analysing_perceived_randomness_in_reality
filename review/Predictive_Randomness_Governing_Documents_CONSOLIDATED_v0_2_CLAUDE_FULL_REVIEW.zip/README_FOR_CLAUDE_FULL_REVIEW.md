# Governing Documents — Clean Consolidation v0.2 — Independent Full Review

**NOT RATIFIED. NO CODE/RUN AUTHORITY.** Second candidate responding to Claude's formal v0.1 review (3 blockers, C1–C6). The v0.1 draft is superseded as candidate, not installed. The ratified originals remain untouched in the repository.

## Packaging / scope

`review_overlay/doc/` contains the five revised governing editions, candidate ratification register, a value-free holdout exposure record, and a non-normative numerical reference. R1 v0.4 and TIE_SHA256_V1 v0.2 remain unchanged, stored in the existing repository and not reissued.

`review_evidence/` contains all baseline-to-new and v0.1-to-v0.2 unified diffs (redaction of historical 1587 result lines where necessary), requirement/decision-level disposition matrix, exact preserved-block SHA values and source bytes, a stale-phrase report, a reproducible stdlib checker, and a full-file SHA-256 manifest. The old repository documents are deliberately NOT included: an older Proposal contains displayed quarantined result numbers and this review ZIP must not duplicate them. Claude should compare independently to HEAD.

## Change discipline and specific v0.1 review findings

- **B1**: Proposal, R2 and Architecture rewritten as concise **operative current** specifications; old contradictory body and proposals not carried forward. Historical conflicts reside only in Appendix S, with one-line withdrawals. Retained byte-protected science/safety blocks are distinguishable.
- **B2**: restored exact E_1 synthetic/real goldens, TOP/WORST forecasts, --game; process-label warning; method-generic runtime contract; game namespaces; value-free audits; launcher/Windows/extension gates; environment snapshots with consequential benchmarks/FINAL; no-silent-shift/pristine holdout; ERR-R2-05 OPEN+no authority; I-07 disclosure.
- **B3**: B1 1576, W100=1476..1575; B10 1567..1576. E_1 1577 forecast-only remains separate.
- **C1–C6**: value-free exposure item 5, explicit-source mapping, errata index in R2 §0, extended protected list plus checker, out-of-scope register statuses, and normative homes (R2 data and views, R3 evaluation/freeze, Architecture implementation). The Proposal summarises rather than restating operational design. Optional O1–O3 covered.

## Caveats and review requests

The source/disposition matrix gives the exact governing destination for each old top-level section and an item-level mapping for `I-xx`, named A-xx rows, ERR table entries, §0A and the important test/decision items; Claude must still independently verify semantic completeness and flag any requirement not reconstructed adequately. The historical R2 method inventory and the specific protected mathematics were copied exactly, but surrounding section order differs from R2 v0.3. The R3 candidate preserves much of the accepted v0.1 candidate and is due a full reread. **Do not treat a mechanical PASS or a traceability row as proof of correctness.**

The `OPERATIVE_STALE_PHRASE_SCAN.json` explicitly classifies every searched occurrence and any unresolved hits. Claude is invited to propose additional forbidden/ambiguous vocabulary. No scientific or process switches changed; Package 2 C1–C6 still not implemented.

**Requested reviewer verdict:** BLOCKER / CORRECTION / OPTIONAL, then owner ratification only after a clean independent review.
