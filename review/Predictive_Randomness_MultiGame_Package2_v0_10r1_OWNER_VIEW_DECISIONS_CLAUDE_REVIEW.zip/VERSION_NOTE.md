# v0.10-r1 scope and precedence

This ZIP is the updated Package 2 v0.10 code-review **delta relative to the unchanged v0.9 package**, superseding the earlier first v0.10 ZIP for review. Its specific extra content addresses the owner's reader-view/no-duplicate-registry decision and reviewer-risk handoff. The existing v0.9 and original v0.10 ZIPs remain historical evidence.

Start review with `CLAUDE_HANDOFF_OWNER_READER_DECISIONS_v0_10r1.md`, then `REVIEW_REQUEST_CLAUDE_v0_10.md`. The only changed source files since the initial v0.10 are listed in the `V010_TO_V010R1_*` evidence diffs. **No Python/Windows scripts executed live; all coordinator source gates remain False.**

Ratified project documents were NOT modified in the repo. Proposed amendments in `proposed_doc_amendments/` are standalone owner-ratification candidates, not authoritative until the owner ratifies.
