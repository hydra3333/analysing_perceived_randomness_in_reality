# Proposed Architecture v0.6 multi-game revision — REQUIRES OWNER RATIFICATION

**Status:** DRAFT. Subject to independent review and owner ratification, then must be incorporated into a new self-contained Architecture revision. All existing §5C safeguards, global unresolved-orphan interlock, non-termination policy, ownership capture and result firewall remain binding; no switches are enabled by this amendment.

## Immutable profiles and data layout

Powerball current era: draw 1144 (2018-04-19), 7-of-35 and one-of-20, DEV last 1577, holdout 1578–1587. Oz current era: draw 1474 (2022-05-17), 7-of-47 plus three raw supplementaries, DEV last 1694, holdout 1695–1704. The common drawn-order CSV is named `australian_powerball_drawn_YYYYMMDD.csv` with `Draw_Number,Date,Drawn_1..Drawn_7,Powerball`, or `australian_ozlotto_drawn_YYYYMMDD.csv` with `Draw_Number,Date,Drawn_1..Drawn_7,Supp_1..Supp_3`. No separate raw/winning pair or sorted CSV. Each create-only file has its own metadata-only provenance and SHA-256.

The common NumPy reader validates every row (era, unique consecutive draw numbers, ranges/distinctness, raw supplementary uniqueness, ISO date) and blocks development bases containing any quarantined draw. Arrays are byte-backed read-only. It provides caller-requested `UNORDERED_SET`, `OPERATOR_DRAWN_ORDER` or `PAIRED_DIAGNOSTIC` prefix N−1 views. The accepted E_1 variant continues to request `UNORDERED_SET`. The reader does not duplicate per-method view entitlements; method configuration, review, tests, logging and manifests identify actual scientific usage. Unverified operator order must not be presented as verified or used for order-dependent scientific claims. Derived weekly-date discrepancies produce warnings and prohibit date-dependent methods only; recorded dates remain provenance. No raw supplementaries in method views. Legacy E1 Powerball view digest and canonical result must remain identical.

## Results source and operator tools

Shared owner-operated `Run_Scraper.bat <GAME> DEV_BUILD` uses Lotterywest's public JSON search endpoint under `www.lotterywest.wa.gov.au`, with source codes `lotterywest_game_code=5132` Powerball and `5130` Oz, not the project's string `game_id`. Request windows are at most a calendar year and end no later than **2026-08-07**. Pagination is complete and checked; main drawn-order field must be established by **434/434** agreement of 1144–1577 with both archived Powerball reference CSVs, not guessed. Oz must use the same verified field. Source responses are SHA-256 archived locally in a git-ignored folder. HTTP uses an honest project User-Agent, robots policy for the exact origin, default 2-second pauses before every request (min 1, adjusted for Crawl-delay and Request-rate); no browser impersonation.

Owner-saved Lotterywest `.mhtml` pages are an offline fallback. `HOLDOUT_FETCH` (Mode H) and `UPDATE` (production) exist as disabled stubs only. `UPDATE` will eventually require overlap with the approved prior snapshot, exact equality of overlaps, and a new create-only base; no automatic holdout opening. Date anomalies never invalidate otherwise structurally valid draws. Only the owner may run any acquisition after code review and approval.

## Coordinator polling and synthetic lifecycle

Single `--poll-seconds` option, default **1.0**, permitted **0.5–5.0**, applies to engineering POC and disabled synthetic path. The queue blocks on output or interval and drains pending messages without extra delays. Capture throttle uses the same interval; a forced scan follows process creation. All process logs are line-buffered. Pipe EOF cap **5.0** seconds; stuck pipe uses the existing orphan marker, no signal. Worker ancestry-release poll 0.5 seconds and deadline 15 seconds; missing STARTED is 'not yet'; atomic create-only release is bound to status creation time. The synthetic timeout must be at least 15 + 2 × poll seconds and at most 60. All execution switches remain source-constant False until separately reviewed/authorised Windows tests. The registered-scientific-contract allowlist remains empty.

### Compatibility and installation order

Existing source CSVs with quarantined rows must be withdrawn from the *working tree before DEV_BUILD*, while being retained in Git history for bounded Powerball prefix comparison and later authorised Mode H cross-checks. Do not erase committed history; do not reveal any quarantined row. The first DEV_BUILD must yield exact accepted Powerball 1577 E_1 digest and forecast before any other method. The owner alone approves installation and collection.
