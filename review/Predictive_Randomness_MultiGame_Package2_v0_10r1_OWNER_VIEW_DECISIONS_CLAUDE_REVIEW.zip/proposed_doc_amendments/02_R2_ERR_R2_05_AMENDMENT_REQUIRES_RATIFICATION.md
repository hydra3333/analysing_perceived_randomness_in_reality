# Proposed R2 Erratum amendment — REQUIRES OWNER RATIFICATION

**Status:** DRAFT, no authority. Affected baseline: R2 Erratum Record v0.3 / ERR-R2-05 and original R2 provisions. This is not an independent modification of scientific registrations.

## Replacement of Oz holdout selection

Replace the previous Oz first-accepted-snapshot / ten-highest-draw rule with a **fixed calendar-aligned** boundary: Oz first quarantined 1695 (11 August 2026), Oz FINAL_HOLDOUT_10 = 1695–1704. Historical development ends at 1694 inclusive. Powerball first quarantined 1578 and FINAL_HOLDOUT_10 1578–1587 remain unchanged. An outcome's quarantine status does not expire merely because the calendar advances. No data-bearing rows at or above the boundary may enter a development base or diagnostic. Later quarantined draws require a future protocol.

## Observation views and scientific accountability — owner's decision (REQUIRES RATIFICATION where R2 wording conflicts)

The common reader maintains **one** immutable pre-holdout drawn-order development table per game, and offers read-only, N−1 prefix views on caller request:

- `UNORDERED_SET`: seven sorted main labels, representing the unordered winning set.
- `OPERATOR_DRAWN_ORDER`: seven main labels in source-provided order, with explicit provenance/status. Actual operator-drawn-order status is NOT inferred merely from being unsorted. An ordered scientific result must not claim verified order until a separately documented comparison proves it.
- `PAIRED_DIAGNOSTIC`: **one paired observation object** containing both views of each same draw, never two independent draws. Joint predictive models using both require an explicitly described and reviewed mathematical treatment; do not multiply the same event's likelihood twice without a valid factorisation.

The common reader SHALL NOT maintain or consult a separate per-(game, method, variant) view-entitlement/permissions registry. **The experiment is the scientific authority for the representation it elects to consume**, declaring it in immutable model configuration; code review, tests, debug logs, forecast manifests and representation-specific digests establish what it actually used. Existing R2 requirements for scientific method identity, approval, valid ordered likelihoods, R2-C04 provenance and the N−1 firewall remain binding. The strict SCIENTIFIC RESULT consumer allowlist is a separate security control and is retained unchanged.

The frozen Powerball `E_1`/`FULL_HISTORY_RAW_COUNTS_V1`/`UNORDERED_SET` continues to use the exact unchanged `E1_REAL_U_TRAINING_VIEW_V1` payload/digest (`d47fbbd6...4339`) and result (`7f113087...164e`). All ordered/paired/new-variant views use newly named schemas binding game, era, profile version and view choice, and include the exact records consumed. E_1 may not be silently changed. Oz supplementaries are structural-audit data only, not scientific inputs.

## Draw timestamp precision — owner preference; unresolved until reliable metadata

Prefer a timezone-aware **actual/official datetime** (and retain source-raw timestamp provenance) **if the source gives reliable time and timezone semantics**. Current API and Lotterywest webpage time displays have not yet established that meaning or timezone. Keep the ISO draw date and derived weekly calendar identity; do not invent a time, default to midnight, or alter E_1's training-view digest. Claude should advise on an optional `draw_datetime` and timestamp evidence contract, including how date-consuming views would digest any *actually consumed* timestamp without changing E_1. Adoption of datetime as a canonical scientific field is a separate reviewed/ratified decision.

## Date deviations, snapshots and N−1

Every source row is structurally validated for canonical ISO date; a deviation from the fixed weekly derived date is a warning that blocks only date-dependent methods E_14/E_54, not acceptance of a numbers-valid snapshot. Per-game development targets and entire table contents terminate strictly below their holdout; per-target slices stop at N−1. Later prospective operation follows a separately reviewed FINAL contract, not the retrospective development cap.
