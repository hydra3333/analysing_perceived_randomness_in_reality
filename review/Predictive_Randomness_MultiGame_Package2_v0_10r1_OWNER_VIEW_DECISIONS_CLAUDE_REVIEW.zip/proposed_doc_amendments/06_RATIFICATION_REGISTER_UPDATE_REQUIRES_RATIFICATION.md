# Proposed Ratification Register change — REQUIRES OWNER RATIFICATION

**Status:** DRAFT; not an independent ratification event. Affects ratified `doc/RATIFICATION_REGISTER_v0_2.md`.

- Preserve the ratification dates, original SHA-256s and historical status of Proposal v0.4, R2 erratum v0.3, R3 v0.3, Architecture v0.6, P3 Task Spec v0.1, tie note v0.2 and earlier scientific contracts. They stay part of the project's history.
- Record new change requests separately (Proposal scope/data change, R2 ERR-R2-05 amendment, R3 holdout phase, Architecture API/one-file/reader/timing, P3 new DEV_BUILD plan) as **PENDING OWNER RATIFICATION** until each is explicitly approved.
- Record `POWERBALL` development draw cap 1577 and fixed holdout 1578–1587, and `OZLOTTO` development cap 1694 and fixed holdout 1695–1704 **only as proposed changes** prior to ratification.
- The 20261021 Powerball source hashes are retained as immutable historical evidence but are **not active development-base identifiers** after the proposed new DEV_BUILD is accepted. Record the new base CSV/provenance hashes only after owner operation and external verification; do not invent them in documentation.
- Preserve publication freeze, N−1, group-failure firewall, orphan-interlock and no-status/no-kill decisions without amendment.
- No change to E_63 or calendar nominal time (both unresolved); no implied authority to use draw 1588+, 1705+ or the quarantined ranges.
