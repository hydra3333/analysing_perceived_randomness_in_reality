# Proposed R3 Evaluation and Reporting v0.3 amendment — REQUIRES OWNER RATIFICATION

**Status:** DRAFT ONLY. No permission to open holdouts or score outcomes.

### Oz Lotto fixed holdout

Replace any relative selection based on the first accepted Oz snapshot with `OZLOTTO` `FINAL_HOLDOUT_10` = draws **1695–1704** (inclusive; 11 August–13 October 2026). The corresponding Powerball holdout remains draws **1578–1587**. Both are calendar-aligned to the same week and remain quarantined from retrospective development, tuning, trial execution and logging.

### Evaluation phases

Phase I DEV_BUILD produces only pre-holdout bases and cannot access quarantined outcomes. Phase II Mode H requires, **before any outcome is made available to an experiment**, an immutable freeze manifest, approved score definitions, a create-only holdout-opening record and an environment record. Each target in increasing draw order is forecast and receipted using all eligible preceding draws; only then is its outcome handed to a scorer and recorded in an append-only ledger. The ten-draw holdout becomes used after Mode H and cannot be treated as untouched for future model changes. Fate of later quarantined results remains OPEN.

Phase III production UPDATE and FINAL runs are separately approved and not subject to the historical-development target cap. Freeze/publication deadlines use the approved closing-time criterion pending resolution of nominal draw-time/timezone. Each game's scores use only its actual barrels; Powerball has two, Oz Lotto one (Powerball channel ABSENT), and scores are not pooled without explicit advance registration.
