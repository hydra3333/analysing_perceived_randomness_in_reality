# Proposed P3 multi-game task specification revision — REQUIRES OWNER RATIFICATION

**Status:** DRAFT. Supersedes the original Package-3 first-Oz-scrape-and-seal outline only if separately ratified.

### New Package 3: owner-operated development-base creation

1. Owner ratifies data/scope amendments and installs reviewed Package 2 v0.10 code. Verify SHA-256 identities; do not install unreviewed coordinator safety changes.
2. Owner removes the two legacy Powerball CSVs from the working tree **without rewriting Git history**: `source_data/australian_powerball_history_20261021.csv` and `source_data/australian_powerball_draw_order_20261021.csv`. The repo's archived commit (`06f6e0f` or owner-verified exact reference) remains the read-only comparison source. No old holdout rows enter the new development base.
3. Owner runs `Run_Scraper.bat POWERBALL DEV_BUILD`, checked for date cap **2026-08-07**, exact Powerball reference agreement **434/434** (date, unordered set, drawn sequence and PB), consecutive 1144–1577, create-only `australian_powerball_drawn_YYYYMMDD.csv` and provenance SHA. STOP on any mismatch without publishing an accepted base.
4. Owner runs `Run_Scraper.bat OZLOTTO DEV_BUILD` using the previously proven source order field, checking consecutive draws 1474–1694, 7 main plus 3 supplementary in 1..47, and the same hard date cutoff, then create-only Oz CSV and provenance.
5. Owner provides **value-free** console output, hashes, completeness/date-warning counts, order-field proof, and provenance to Claude. Neither owner nor AI pastes any ball numbers or raw responses from quarantined ranges.
6. Owner performs the common-reader E_1 1577 regression: `d47fbbd6...4339` U-view, `7f113087...164e` result, accepted TOP/WORST selections. The new base is not adopted if this fails.

**Non-goals:** No Mode H, no live holdout fetch, no production UPDATE, no automatic weekly collection, no FINAL science, and no Windows synthetic Popen execution without separate authorisation. The latter receives a separate owner command list and lifecycle acceptance gate.

**Fallback:** `OFFLINE_SAVED_PAGES` uses owner-saved Lotterywest drawn-mode `.mhtml` pages, with the same hard boundaries and validations. Compatibility with a real saved page is a future owner-gated acceptance test, not assumed from synthetic fixtures.

**Owner's reader/timestamp refinement for review:** The common reader supports all three R2-C08 representations on caller request, without a per-method view-entitlement table. Tests must establish alignment, N−1 isolation, read-only arrays and the legacy E_1 digest. Preserve source-provided timestamp strings for provenance where available; expose an actual timezone-aware instant only after source semantics are independently established.
