# Windows owner acceptance commands — PROPOSED ONLY, NOT EXECUTED

**Gate:** These commands are provided for review and later explicit owner authorisation. The author has not run any command on Windows or started any worker, fetched any live result or read any holdout. The three source constants `ENABLE_PROCESS_TERMINATION`, `ENABLE_SCIENTIFIC_COORDINATION`, and `ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE` are **False**. No command-line override exists.

Run in the project root using ordinary Windows CMD, after applying a reviewed candidate in an isolated working copy and confirming no unresolved-orphan marker:

```bat
.venv\Scripts\python.exe tests\p1p2_static_checks.py
.venv\Scripts\python.exe tests\p1p2_non_destructive_safety_checks.py
.venv\Scripts\python.exe tests\p1p2_safety_regression_v0_3.py
.venv\Scripts\python.exe tests\p1p2_orphan_interlock_v0_6.py
Run_Coordinator.bat --poc --case canonical-fixture --workers 1 --count 1 --poll-seconds 1.0
```

**Initial synthetic gate pre-check, required to fail closed with exit 3 and no new group/worker:**

```bat
Run_Coordinator.bat --synthetic-contract-test --game POWERBALL --target 1577 --timeout-seconds 25 --poll-seconds 1.0
```

The synthetic lifecycle execution requires a **separate post-review owner decision**. Only after that approval, in an uncommitted disposable copy, change exactly one line of `src\Powerball_Experiment_Coordinator.py`: `ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE = False` -> `True`. Record that modified file's SHA-256 before a **single** run of the exact command above. Restore the line to False immediately afterwards and verify that the restored SHA-256 equals the reviewed SHA-256. Never flip `ENABLE_PROCESS_TERMINATION` or `ENABLE_SCIENTIFIC_COORDINATION`. Never remove/bypass an unresolved-orphan marker automatically or attempt to kill an uncertain process. A timeout leaves the marker and requires manual review.

The human-speed policy is: coordinator default/one CLI setting `--poll-seconds 1.0` (allowed 0.5..5.0), reader wait/periodic check once per interval; worker release file polling every 0.5 seconds for at most 15 seconds; minimum wrapper timeout `15 + 2 x poll`; pipe EOF cap 5 seconds. Logs are line-buffered. A stuck pipe, uncertain ancestry, or suspect status is an orphan SAFETY STOP with **no signal**.

Once reviewed and authorised, perform Windows synthetic and full P1/P2 non-destructive acceptance in the documented order; all observations remain operator-owned evidence and must be independently reviewed. This page is not authorisation to run them.
