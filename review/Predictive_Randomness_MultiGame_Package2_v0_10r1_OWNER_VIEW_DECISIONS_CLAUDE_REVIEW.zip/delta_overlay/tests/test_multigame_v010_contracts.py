"""v0.10 OFFLINE synthetic contracts. NO network, no archived draw data."""
from __future__ import annotations

from datetime import date, timedelta
from pathlib import Path
import csv
import json
import os
import sys
import tempfile
import unittest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'src'/'methods'))
sys.path.insert(0,str(ROOT/'src'))
from _common.game_profiles_v1 import POWERBALL,OZLOTTO
from _common.game_draws_reader_v1 import load_development_base,header_for
from _common.lotterywest_results_v1 import Draw,parse_api_page,audit_complete_development
from _common.multigame_results_build_v1 import (
  audited_development_csv,publish_dev_snapshot,legacy_powerball_comparison)
from _common.lotterywest_api_client_v1 import years_for,api_url,effective_pause,fetch_dev_pages
from _common.multigame_source_policy_v1 import PolicyDecision
from coordinator_private.multigame_windows_lifecycle_v1 import parse_synthetic_args


def mock_draws(profile):
    draws=[]
    for number in range(profile.first_draw,profile.holdout_first):
        hi=profile.barrels[0].high
        k=(number-profile.first_draw)%hi
        # Reverse order to prove actual drawn order is preserved.
        main=tuple(reversed([((k+i)%hi)+1 for i in range(7)]))
        if profile.game_id=='POWERBALL':
            sec=(number%20+1,)
        else:
            sec=tuple(((k+7+i)%hi)+1 for i in range(3))
        draws.append(Draw(number,profile.derived_date(number).isoformat(),main,sec,'FIXTURE'))
    return draws

class V010ContractTests(unittest.TestCase):
    def test_fixed_boundary_and_later_final_not_bounded_here(self):
        self.assertEqual((POWERBALL.holdout_first,OZLOTTO.holdout_first),(1578,1695))
        self.assertTrue(POWERBALL.historical_development_target_allowed(1577))
        self.assertFalse(POWERBALL.historical_development_target_allowed(1578))
        self.assertTrue(OZLOTTO.historical_development_target_allowed(1694))
        self.assertFalse(OZLOTTO.historical_development_target_allowed(1695))
        self.assertEqual(len(mock_draws(OZLOTTO)),221)
    def test_caller_selects_all_three_readonly_views(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'australian_ozlotto_drawn_20260807.csv'
            data,_=audited_development_csv('OZLOTTO',mock_draws(OZLOTTO))
            path.write_bytes(data)
            table=load_development_base(path,'OZLOTTO')
            self.assertFalse(table.drawn.flags.writeable)
            self.assertFalse(table.sorted.flags.writeable)
            self.assertFalse(table.draw_date.flags.writeable)
            with self.assertRaises(ValueError):table.drawn.setflags(write=True)
            sorted_view=table.view('E_1','FULL_HISTORY_RAW_COUNTS_V1',1480)
            self.assertEqual(sorted_view.kind,'UNORDERED_SET')
            self.assertEqual(len(sorted_view.simple_rows()),6)
            self.assertEqual(sorted_view.simple_rows()[0]['main'],sorted(mock_draws(OZLOTTO)[0].main))
            drawn_view=table.view('E_1','FULL_HISTORY_RAW_COUNTS_V1',1480,kind='OPERATOR_DRAWN_ORDER')
            paired_view=table.view('E_1','FULL_HISTORY_RAW_COUNTS_V1',1480,kind='PAIRED_DIAGNOSTIC')
            self.assertEqual(drawn_view.simple_rows()[0]['main'],list(mock_draws(OZLOTTO)[0].main))
            self.assertEqual(paired_view.simple_rows()[0]['main'],sorted(mock_draws(OZLOTTO)[0].main))
            self.assertEqual(paired_view.simple_rows()[0]['drawn_main'],list(mock_draws(OZLOTTO)[0].main))
            self.assertEqual(drawn_view.order_verification_status,'SOURCE_ORDER_UNVERIFIED')
            self.assertFalse(drawn_view.main.flags.writeable)
            self.assertFalse(paired_view.drawn_main.flags.writeable)
            self.assertEqual(len(paired_view.simple_rows()),6)
            with self.assertRaises(ValueError):
                table.view('E_1','FULL_HISTORY_RAW_COUNTS_V1',1695)
    def test_no_holdout_data_in_any_development_base(self):
        for profile in (POWERBALL,OZLOTTO):
            with self.subTest(game=profile.game_id):
                seq=mock_draws(profile)
                candidate=Draw(profile.holdout_first,
                        profile.derived_date(profile.holdout_first).isoformat(),seq[-1].main,
                        seq[-1].secondary,'FIXTURE')
                with self.assertRaises(ValueError):audited_development_csv(profile.game_id,seq+[candidate])
                with self.assertRaises(ValueError):audited_development_csv(profile.game_id,seq[:-1])
    def test_date_warning_not_block(self):
        src=mock_draws(OZLOTTO)
        item=src[14];src[14]=Draw(item.number,'2022-01-01',item.main,item.secondary,item.order_source)
        _,warning=audited_development_csv('OZLOTTO',src)
        self.assertEqual(warning,(1488,))
    def test_publish_create_only_and_value_free(self):
        seq=mock_draws(OZLOTTO)
        with tempfile.TemporaryDirectory() as td:
            dest=Path(td)
            path,meta=publish_dev_snapshot(output_dir=dest,game_id='OZLOTTO',mode='OFFLINE_SAVED_PAGES',
                         draws=seq,order_field='MHTML_DRAWN_ATTESTED',response_meta=[{'sha256':'c'*64}],
                         started_utc='2026-10-24T00:00:00+00:00',stamp='20261025')
            self.assertTrue(path.exists())
            self.assertEqual(path.read_bytes().split(b'\n',1)[0].decode(),','.join(header_for('OZLOTTO')))
            self.assertEqual(meta['date_warning_count'],0)
            self.assertNotIn('main',json.dumps(meta))
            self.assertNotIn('supplementary',json.dumps(meta))
            with self.assertRaises(ValueError):
                publish_dev_snapshot(output_dir=dest,game_id='OZLOTTO',mode='OFFLINE_SAVED_PAGES',
                     draws=seq,order_field='MHTML_DRAWN_ATTESTED',response_meta=[],
                     started_utc='2026-10-24T00:00:00+00:00',stamp='20261025')
    def test_api_parses_labels_and_rejects_holdout(self):
        d=mock_draws(POWERBALL)[0]
        record={'draw_num':d.number,'draw_date':d.date,
                'winning_numbers':list(d.main),'winning_numbers_display':sorted(d.main),
                'supplementary_numbers':list(d.secondary)}
        wrapper={'data':{'draw_records':[record],
                'total_records':1,'page':1,'total_pages':1,'page_start':1,
                'page_end':1,'records_this_page':1}}
        raw=json.dumps(wrapper).encode()
        parsed,meta=parse_api_page(raw,'POWERBALL',order_field='winning_numbers')
        self.assertEqual(parsed[0].main,d.main)
        self.assertEqual(meta['page'],1)
        record['draw_num']=1578
        with self.assertRaises(ValueError):parse_api_page(json.dumps(wrapper).encode(),'POWERBALL',order_field='winning_numbers')
    def test_api_fixed_windows_and_pause(self):
        self.assertEqual(len(list(years_for('POWERBALL'))),9)
        self.assertEqual(len(list(years_for('OZLOTTO'))),5)
        with self.assertRaises(ValueError):api_url('POWERBALL',date(2026,8,7),date(2026,8,8),1)
        with self.assertRaises(ValueError):api_url('OZLOTTO',date(2022,12,31),date(2023,1,1),1)
        decision=PolicyDecision('LOTTERYWEST_JSON_API','a'*64,True,'ROBOTS_ALLOWED',3.0,(1,5))
        self.assertEqual(effective_pause(2.0,decision),5.0)
        with self.assertRaises(ValueError):effective_pause(.4,decision)
        deny=PolicyDecision('LOTTERYWEST_JSON_API','a'*64,False,'DISALLOWED')
        with self.assertRaises(ValueError):effective_pause(2.0,deny)
    def test_api_first_robots_and_no_host_fallthrough(self):
        urls=[];sleeps=[]
        def fake(u, **kwargs):
            urls.append(u)
            return b'User-agent: *\nDisallow: /api/\n' if u.endswith('robots.txt') else b'{}'
        with self.assertRaises(ValueError):fetch_dev_pages('POWERBALL',fetch=fake,sleep=sleeps.append)
        self.assertEqual(len(urls),1)
        self.assertEqual(sleeps,[2.0])
    def test_synthetic_timeout_floor_and_bounds(self):
        with self.assertRaises(SystemExit):parse_synthetic_args(['--synthetic-contract-test','--game','POWERBALL','--target','1577','--timeout-seconds','16','--poll-seconds','1'])
        parsed=parse_synthetic_args(['--synthetic-contract-test','--game','POWERBALL','--target','1577','--timeout-seconds','25','--poll-seconds','1'])
        self.assertEqual(parsed.poll_seconds,1.0)
    def test_old_comparison_winning_set_and_order(self):
        draws=mock_draws(POWERBALL)[:2]
        head='Draw_Number,Date,Ball_1,Ball_2,Ball_3,Ball_4,Ball_5,Ball_6,Ball_7,Powerball\n'
        order='Draw_Number,Date,Drawn_1,Drawn_2,Drawn_3,Drawn_4,Drawn_5,Drawn_6,Drawn_7,Powerball,Official_Source_URL\n'
        hist=head; drawn=order
        for d in draws:
            hist+=','.join(map(str,(d.number,d.date,*sorted(d.main),d.secondary[0])))+'\n'
            drawn+=','.join(map(str,(d.number,d.date,*d.main,d.secondary[0],'https://example.test')))+'\n'
        result=legacy_powerball_comparison(current=draws,history_raw=hist.encode(),drawn_raw=drawn.encode(),start=1144,end=1145)
        self.assertEqual(result['agreement_count'],2)
        bad=draws.copy();d=bad[0];bad[0]=Draw(d.number,d.date,tuple(reversed(d.main)),d.secondary,d.order_source)
        with self.assertRaises(ValueError):legacy_powerball_comparison(current=bad,history_raw=hist.encode(),drawn_raw=drawn.encode(),start=1144,end=1145)

    def test_paired_view_needs_no_independent_entitlement(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'australian_powerball_drawn_20261025.csv'
            raw,_=audited_development_csv('POWERBALL',mock_draws(POWERBALL))
            path.write_bytes(raw)
            table=load_development_base(path,'POWERBALL')
            both=table.view('E_32','UNRATIFIED_DIAGNOSTIC_FIXTURE',1146,
                            kind='PAIRED_DIAGNOSTIC')
            self.assertEqual(both.kind,'PAIRED_DIAGNOSTIC')
            self.assertEqual(len(both.simple_rows()),2)
            self.assertNotEqual(both.simple_rows()[0]['main'],both.simple_rows()[0]['drawn_main'])
            self.assertFalse(both.drawn_main.flags.writeable)
            self.assertEqual(both.order_verification_status,'SOURCE_ORDER_UNVERIFIED')
            self.assertNotEqual(both.e1_view_digest(),
                 table.view('E_32','UNRATIFIED_DIAGNOSTIC_FIXTURE',1146,
                            kind='UNORDERED_SET').e1_view_digest())

    def test_legacy_e1_domain_applies_only_to_original_view_and_variant(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/'australian_powerball_drawn_20261025.csv'
            path.write_bytes(audited_development_csv('POWERBALL',mock_draws(POWERBALL))[0])
            table=load_development_base(path,'POWERBALL')
            base=table.view('E_1','FULL_HISTORY_RAW_COUNTS_V1',1146)
            ordered=table.view('E_1','FULL_HISTORY_RAW_COUNTS_V1',1146,
                               kind='OPERATOR_DRAWN_ORDER')
            new_variant=table.view('E_1','UNRATIFIED_DIAGNOSTIC_FIXTURE',1146)
            self.assertNotEqual(base.e1_view_digest(),ordered.e1_view_digest())
            self.assertNotEqual(base.e1_view_digest(),new_variant.e1_view_digest())
            self.assertEqual(base.order_verification_status,'SOURCE_ORDER_UNVERIFIED')

    def test_raw_archive_refuses_mismatch_or_collision(self):
        from _common.multigame_results_build_v1 import archive_dev_responses,sha
        with tempfile.TemporaryDirectory() as td:
            root=Path(td)
            raw=b'AN INVENTED OFFLINE RESPONSE WITH NO BALL VALUES'
            with self.assertRaises(ValueError):archive_dev_responses(
                raw_folder=root,game_id='POWERBALL',pages=[(raw,{'sha256':'0'*64})])
            files=archive_dev_responses(raw_folder=root,game_id='POWERBALL',pages=[
                (raw,{'sha256':sha(raw)})])
            self.assertEqual(len(files),1)
            with self.assertRaises(ValueError):archive_dev_responses(
                raw_folder=root,game_id='POWERBALL',pages=[(raw,{'sha256':sha(raw)})])

    def test_public_robots_allow_and_crawl_delay(self):
        from _common.multigame_source_policy_v1 import policy_for_offline_robots
        p=policy_for_offline_robots(source_id='LOTTERYWEST_JSON_API',
             page_url='https://www.lotterywest.wa.gov.au/api/games/draws/search',
             robots_url='https://www.lotterywest.wa.gov.au/robots.txt',
             robots_bytes=b'User-agent: *\nDisallow:\nCrawl-delay: 4\n',
             user_agent='analysing_perceived_randomness_in_reality/0.10')
        self.assertTrue(p.request_allowed)
        self.assertGreaterEqual(effective_pause(2.0,p),4.0)

    def test_future_modes_are_disabled_before_io(self):
        import multigame_results_tool_v1 as tool
        self.assertEqual(tool.main(['--game','POWERBALL','--mode','UPDATE']),3)
        self.assertEqual(tool.main(['--game','OZLOTTO','--mode','HOLDOUT_FETCH']),3)
        self.assertFalse(tool.ENABLE_UPDATE)
        self.assertFalse(tool.ENABLE_HOLDOUT_FETCH)

    def test_no_fast_poll_and_safety_switches(self):
        import queue
        import Powerball_Experiment_Coordinator as coord
        self.assertFalse(coord.ENABLE_PROCESS_TERMINATION)
        self.assertFalse(coord.ENABLE_SCIENTIFIC_COORDINATION)
        self.assertFalse(coord.ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE)
        q=queue.Queue();q.put((1,'INVENTED OUTPUT'))
        self.assertEqual(list(coord.receive_messages(q,poll_seconds=1.0)),[(1,'INVENTED OUTPUT')])
        with self.assertRaises(ValueError):list(coord.receive_messages(q,poll_seconds=.04))

    def test_e1_bridge_agrees_with_common_reader_synthetic_standin(self):
        from _common.e1_historical_appearance_frequency_v0_3 import canonical_bytes
        from _common.e1_training_view_v0_1 import build_e1_forecast
        from _common.e1_common_reader_bridge_v1 import prepared_e1_forecast
        import hashlib
        with tempfile.TemporaryDirectory() as td:
            file=Path(td)/'australian_powerball_drawn_20261025.csv'
            file.write_bytes(audited_development_csv('POWERBALL',mock_draws(POWERBALL))[0])
            table=load_development_base(file,'POWERBALL')
            view=table.view('E_1','FULL_HISTORY_RAW_COUNTS_V1',1577)
            expected=hashlib.sha256(canonical_bytes({
               'schema':'E1_REAL_U_TRAINING_VIEW_V1',
               'data_kind':'REAL_HISTORICAL_DEVELOPMENT',
               'records':view.simple_rows()})).hexdigest()
            self.assertEqual(view.e1_view_digest(),expected)
            forecast, observed=prepared_e1_forecast(table,1577)
            self.assertEqual(observed,expected)
            pure=build_e1_forecast(view.simple_rows(),expected,1577,
                                   source_kind='REAL_HISTORICAL_DEVELOPMENT')
            self.assertEqual(forecast,pure)
            self.assertEqual(forecast['MAIN']['ranking'],pure['MAIN']['ranking'])

if __name__=='__main__':unittest.main()
