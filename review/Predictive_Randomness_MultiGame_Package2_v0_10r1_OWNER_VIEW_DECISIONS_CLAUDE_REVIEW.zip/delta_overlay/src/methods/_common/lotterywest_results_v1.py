"""Value-free parsing/validation primitives for Lotterywest development results.

No network calls. API response format variations fail closed; drawn order must be
identified from the original Powerball historical comparison before publishing.
Never pass holdout/quarantined records to a caller or expose numbers in errors.
"""
from __future__ import annotations

from datetime import date, datetime
import json
import re
from dataclasses import dataclass
from _common.game_profiles_v1 import get_profile

LOTTERYWEST_GAME_CODES = {'POWERBALL': 5132, 'OZLOTTO': 5130}
API_ORDER_FIELDS = frozenset({'winning_numbers', 'winning_numbers_display'})
DEV_TO_DATE = date(2026, 8, 7)

@dataclass(frozen=True)
class Draw:
    number: int
    date: str
    main: tuple[int, ...]
    secondary: tuple[int, ...]
    order_source: str


def _date(raw):
    if type(raw) is not str:
        raise ValueError('invalid draw date field')
    value = raw.strip()
    try:
        # Records may contain ISO date or ISO timestamp, possibly with space separator.
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}', value):
            return date.fromisoformat(value).isoformat()
        if re.fullmatch(r'\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2})?([+-]\d{2}:\d{2}|Z)?', value):
            return date.fromisoformat(value[:10]).isoformat()
        if re.fullmatch(r'\d{2}/\d{2}/\d{4}', value):
            return datetime.strptime(value, '%d/%m/%Y').date().isoformat()
    except ValueError as exc:
        raise ValueError('invalid draw date field') from exc
    raise ValueError('unrecognised draw date format')


def _numbers(raw, count, lo, hi, field):
    if type(raw) is list:
        tokens = raw
    elif type(raw) is str and re.fullmatch(r'\s*\d+(\s*[,| ]\s*\d+)*\s*', raw):
        tokens = re.findall(r'\d+', raw)
    else:
        raise ValueError(f'{field} has unrecognised number representation')
    if len(tokens) != count:
        raise ValueError(f'{field} incorrect number count')
    if any(type(x) not in (int, str) or type(x) is bool or
           not re.fullmatch(r'(0|[1-9][0-9]*)', str(x), re.ASCII) for x in tokens):
        raise ValueError(f'{field} noncanonical number')
    nums = tuple(int(v) for v in tokens)
    if any(x < lo or x > hi for x in nums) or len(set(nums)) != len(nums):
        raise ValueError(f'{field} range or distinctness invalid')
    return nums


def parse_api_page(raw: bytes, game_id: str, *, order_field: str) -> tuple[list[Draw], dict]:
    """Parse a single page; never guess source order and never display labels."""
    profile = get_profile(game_id)
    if order_field not in API_ORDER_FIELDS or type(raw) is not bytes or len(raw) > 4_000_000:
        raise ValueError('unsupported Lotterywest API order field or response')
    try:
        doc = json.loads(raw)
    except (ValueError, UnicodeDecodeError) as exc:
        raise ValueError('invalid Lotterywest response JSON') from exc
    if type(doc) is not dict or type(doc.get('data')) is not dict:
        raise ValueError('missing Lotterywest data container')
    data = doc['data']
    # The array key was unknown in the initial browser research. Discover by
    # structural signature only; reject multiple possibilities and page shape changes.
    arrays = [(name, records) for name, records in data.items()
              if type(records) is list and records and
              all(type(x) is dict and 'draw_num' in x and 'draw_date' in x for x in records)]
    if len(arrays) != 1:
        raise ValueError('ambiguous or absent Lotterywest draw record array')
    record_key, records = arrays[0]
    pagination = {}
    for field in ('total_records','page','total_pages','page_start','page_end','records_this_page'):
        val = data.get(field)
        if type(val) is not int or val < 0:
            raise ValueError('invalid API pagination field: ' + field)
        pagination[field] = val
    if pagination['records_this_page'] != len(records) or not pagination['total_pages']:
        raise ValueError('API pagination does not match records')
    if pagination['page'] > pagination['total_pages'] or pagination['page'] < 0:
        raise ValueError('invalid API page index')
    parsed = []
    for record in records:
        n = record['draw_num']
        if type(n) not in (str,int) or not re.fullmatch(r'(0|[1-9][0-9]*)', str(n), re.ASCII):
            raise ValueError('invalid draw number')
        draw = int(n)
        if draw < profile.first_draw or draw >= profile.holdout_first:
            raise ValueError('quarantined or wrong-era draw in DEV_BUILD response')
        main = _numbers(record.get(order_field), 7, 1, profile.barrels[0].high, 'main')
        extra_count = 1 if game_id == 'POWERBALL' else 3
        sec = _numbers(record.get('supplementary_numbers'), extra_count,
                       1, 20 if game_id == 'POWERBALL' else 47, 'supplementary')
        if game_id == 'OZLOTTO' and set(main).intersection(sec):
            raise ValueError('main and supplementary collision')
        parsed.append(Draw(draw, _date(record['draw_date']), main, sec, order_field))
    return parsed, {'record_key':record_key, **pagination}


def audit_complete_development(draws, game_id):
    """No values returned in messages; reject ALL quarantined rows BEFORE save."""
    profile = get_profile(game_id)
    if len(draws) != profile.holdout_first - profile.first_draw:
        raise ValueError('DEV_BUILD has missing or extra draws')
    warnings = []
    for n, item in enumerate(draws, profile.first_draw):
        if type(item) is not Draw or item.number != n or n >= profile.holdout_first:
            raise ValueError('draw identity/order or holdout boundary failure')
        if _date(item.date) != item.date:
            raise ValueError('noncanonical date')
        high = profile.barrels[0].high
        if len(item.main) != 7 or len(set(item.main)) != 7 or any(x < 1 or x > high for x in item.main):
            raise ValueError('invalid main count/range')
        extra = 1 if game_id == 'POWERBALL' else 3
        if len(item.secondary) != extra:
            raise ValueError('invalid supplementary count')
        if game_id == 'OZLOTTO' and len(set(item.main + item.secondary)) != 10:
            raise ValueError('invalid Oz Lotto supplementary uniqueness')
        if item.date != profile.derived_date(n).isoformat():
            warnings.append(n)
    return tuple(warnings)
