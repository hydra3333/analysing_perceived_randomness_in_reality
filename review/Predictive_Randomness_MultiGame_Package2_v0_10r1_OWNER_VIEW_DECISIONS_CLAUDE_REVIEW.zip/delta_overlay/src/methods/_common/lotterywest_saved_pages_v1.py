"""Strict offline Lotterywest saved MHTML/HTML parser.

This candidate accepts labelled, owner-saved HTML fixture structure only.
The first *real* saved-page compatibility check must occur under the later
owner-authorised dev-build procedure, never by scraping fallback automatically.
"""
from __future__ import annotations
from email import policy
from email.parser import BytesParser
from bs4 import BeautifulSoup
from _common.lotterywest_results_v1 import Draw, _date, _numbers
from _common.game_profiles_v1 import get_profile


def html_from_saved_page(raw: bytes) -> str:
    if type(raw) is not bytes or len(raw) > 12_000_000:
        raise ValueError('oversized or invalid saved page')
    if raw.lstrip().lower().startswith(b'<!doctype html') or raw.lstrip().lower().startswith(b'<html'):
        return raw.decode('utf-8-sig')
    message = BytesParser(policy=policy.default).parsebytes(raw)
    if not message.is_multipart():
        raise ValueError('not HTML or multipart MHTML')
    candidates = [part.get_content() for part in message.walk()
                  if part.get_content_type() == 'text/html' and not part.is_multipart()]
    if len(candidates) != 1 or type(candidates[0]) is not str:
        raise ValueError('saved page must contain exactly one HTML part')
    return candidates[0]


def parse_saved_page(raw: bytes, game_id: str, *, drawn_selected: bool) -> list[Draw]:
    if drawn_selected is not True:
        raise ValueError('saved-page Drawn order toggle not attested')
    profile = get_profile(game_id)
    soup = BeautifulSoup(html_from_saved_page(raw), 'html.parser')
    rows = soup.select('[data-draw-number][data-draw-date]')
    if not rows:
        raise ValueError('saved-page draw rows not recognised; inspect owner-saved fixture')
    result = []
    for row in rows:
        n = row.get('data-draw-number')
        if not str(n).isdecimal():
            raise ValueError('invalid saved-page draw number')
        number = int(n)
        if number < profile.first_draw or number >= profile.holdout_first:
            raise ValueError('quarantined or old-era draw in saved-page DEV_BUILD')
        # The explicit labels, not text position/number guesses, are required.
        main_els = row.select('[data-result-kind="main"]')
        extra_els = row.select('[data-result-kind="supplementary"]')
        main = _numbers([el.get_text(strip=True) for el in main_els], 7, 1,
                        profile.barrels[0].high, 'saved main')
        extra = _numbers([el.get_text(strip=True) for el in extra_els],
                         1 if game_id == 'POWERBALL' else 3, 1,
                         20 if game_id == 'POWERBALL' else 47, 'saved supplementary')
        if game_id == 'OZLOTTO' and set(main).intersection(extra):
            raise ValueError('overlapping supplementary and main numbers')
        result.append(Draw(number, _date(row['data-draw-date']), main, extra,
                           'MHTML_DRAWN_ATTESTED'))
    return result
