"""Package 2 v0.10: one immutable drawn-order development CSV per game.

Validation reads the COMPLETE development base ONLY (must stop before holdout).
Scientific access is N-1 prefix-only and cannot expose supplementaries or
undocumented data representations. No use of user-supplied barrel configuration.
The sealed/quarantined outcomes are not an input to this module.
"""
from __future__ import annotations

import csv
from datetime import date
import hashlib
from pathlib import Path
import re
from types import MappingProxyType

import numpy as np
from _common.game_profiles_v1 import get_profile

_DIGIT = re.compile(r'(0|[1-9][0-9]*)\Z', re.ASCII)
_NAMES = {'POWERBALL': re.compile(r'australian_powerball_drawn_[0-9]{8}\.csv\Z', re.ASCII),
          'OZLOTTO': re.compile(r'australian_ozlotto_drawn_[0-9]{8}\.csv\Z', re.ASCII)}
_REAL = 'REAL_HISTORICAL_DEVELOPMENT'
_E1_VARIANT = 'FULL_HISTORY_RAW_COUNTS_V1'
VIEW_KINDS = frozenset(('UNORDERED_SET', 'OPERATOR_DRAWN_ORDER', 'PAIRED_DIAGNOSTIC'))
_METHOD = re.compile(r'E_[1-9][0-9]*\Z', re.ASCII)
# The reader does not duplicate per-method view permissions. Experiments must
# declare what they consume; scientific review and manifests verify that choice.
# Source-order rows are NOT claimed verified merely by appearing in a CSV.


def header_for(game_id: str) -> tuple[str, ...]:
    get_profile(game_id)
    common = ('Draw_Number', 'Date') + tuple(f'Drawn_{i}' for i in range(1, 8))
    return common + (('Powerball',) if game_id == 'POWERBALL' else ('Supp_1', 'Supp_2', 'Supp_3'))


def _int(raw: str, low: int, high: int, field: str) -> int:
    if not _DIGIT.fullmatch(raw):
        raise ValueError(field + ': noncanonical decimal')
    number = int(raw)
    if not low <= number <= high:
        raise ValueError(field + ': out of range')
    return number


def _readonly(values, dtype):
    # A bytes buffer cannot be made writeable even via ndarray.setflags().
    arr = np.asarray(values, dtype=dtype)
    return np.frombuffer(arr.tobytes(), dtype=dtype).reshape(arr.shape)


class DevelopmentDrawTable:
    """Immutable in-memory table; its private supplementaries never enter views."""
    __slots__ = ('game_id', 'source', 'draw_number', 'draw_date', 'drawn', 'sorted',
                 'powerball', '_supplementary', 'date_warning_draws', 'order_verification_status')

    def __init__(self, game_id, source, rows, date_warning_draws):
        self.game_id = game_id
        self.source = source
        self.draw_number = _readonly([r[0] for r in rows], np.int32)
        self.draw_date = _readonly([np.datetime64(r[1], 'D') for r in rows], 'datetime64[D]')
        self.drawn = _readonly([r[2] for r in rows], np.int8).reshape(-1, 7)
        self.sorted = _readonly(np.sort(self.drawn, axis=1), np.int8)
        self.powerball = _readonly([r[3] for r in rows], np.int8) if game_id == 'POWERBALL' else None
        self._supplementary = (_readonly([r[3] for r in rows], np.int8).reshape(-1, 3)
                               if game_id == 'OZLOTTO' else None)
        self.date_warning_draws = tuple(date_warning_draws)
        # A later provenance-bound verification can promote this status, but
        # no caller-selected flag is accepted as evidence of operator order.
        self.order_verification_status = 'SOURCE_ORDER_UNVERIFIED'

    def view(self, method_id: str, variant_id: str, target: int,
             kind: str = 'UNORDERED_SET'):
        """One N-1 slice; representation choice belongs to the experiment.

        This function deliberately has NO per-method view-entitlement registry.
        All returned NumPy arrays are byte-backed, intrinsically read-only.
        The order_verification_status field must be checked before an ordered
        scientific hypothesis treats source order as proven operator order.
        """
        profile = get_profile(self.game_id)
        if (not profile.historical_development_target_allowed(target) or
                target > int(self.draw_number[-1]) + 1 or
                type(method_id) is not str or not _METHOD.fullmatch(method_id) or
                type(variant_id) is not str or not variant_id or
                not variant_id.isascii()):
            raise ValueError('invalid method identity, variant or development target')
        if kind not in VIEW_KINDS:
            raise ValueError('invalid requested observation view')
        count = target - profile.first_draw
        main = self.drawn if kind == 'OPERATOR_DRAWN_ORDER' else self.sorted
        return DrawView(self.game_id, method_id, variant_id, target, kind,
                        self.draw_number[:count], self.draw_date[:count], main[:count],
                        self.powerball[:count] if self.powerball is not None else None,
                        self.drawn[:count] if kind == 'PAIRED_DIAGNOSTIC' else None,
                        self.order_verification_status)


class DrawView:
    __slots__ = ('game_id', 'method_id', 'variant_id', 'target', 'kind',
                 'draw_number', 'draw_date', 'main', 'powerball', 'drawn_main',
                 'order_verification_status')

    def __init__(self, game_id, method_id, variant_id, target, kind, draw_number, draw_date, main, powerball, drawn_main=None, order_verification_status="SOURCE_ORDER_UNVERIFIED"):
        self.game_id, self.method_id, self.variant_id = game_id, method_id, variant_id
        self.target, self.kind = target, kind
        self.draw_number, self.draw_date, self.main, self.powerball = draw_number, draw_date, main, powerball
        self.drawn_main = drawn_main
        self.order_verification_status = order_verification_status
        for arr in (draw_number, draw_date, main, powerball, drawn_main):
            if arr is not None and arr.flags.writeable:
                raise RuntimeError('mutable ndarray escaped')

    def simple_rows(self) -> list[dict]:
        result = []
        for i, number in enumerate(self.draw_number):
            record = {'draw': int(number), 'main': [int(n) for n in self.main[i]]}
            if self.kind == 'PAIRED_DIAGNOSTIC':
                record['drawn_main'] = [int(n) for n in self.drawn_main[i]]
            if self.powerball is not None:
                record['powerball'] = int(self.powerball[i])
            result.append(record)
        return result

    def e1_view_digest(self, *, data_kind: str = _REAL) -> str:
        """Legacy Powerball U digest is frozen; no profile identity injected."""
        from _common.e1_historical_appearance_frequency_v0_3 import canonical_bytes
        rows = self.simple_rows()
        if self.game_id == 'POWERBALL' and self.method_id == 'E_1' and self.variant_id == _E1_VARIANT and self.kind == 'UNORDERED_SET':
            schema = 'E1_REAL_U_TRAINING_VIEW_V1'
            payload = {'schema': schema, 'data_kind': data_kind, 'records': rows}
        else:
            profile = get_profile(self.game_id)
            payload = {'schema': f'{profile.game_id}_{profile.era_id}_{profile.version}_{self.kind}_VIEW_V1',
                       'data_kind': data_kind, 'game_id': profile.game_id,
                       'era_id': profile.era_id, 'profile_version': profile.version,
                       'records': rows}
        return hashlib.sha256(canonical_bytes(payload)).hexdigest()


def load_development_base(source: Path, game_id: str, *, allow_fixture_name: bool = False) -> DevelopmentDrawTable:
    """Requires the complete pre-holdout base; does not access any other file."""
    profile = get_profile(game_id)
    if (not isinstance(source, Path) or source.is_symlink() or not source.is_file() or
            (not allow_fixture_name and not _NAMES[game_id].fullmatch(source.name))):
        raise ValueError('untrusted development snapshot path')
    rows, warnings = [], []
    with source.open('r', encoding='utf-8-sig', newline='') as stream:
        reader = csv.reader(stream, strict=True)
        if tuple(next(reader, [])) != header_for(game_id):
            raise ValueError('incorrect drawn-order CSV header')
        for row in reader:
            expected = profile.first_draw + len(rows)
            if expected >= profile.holdout_first:
                raise ValueError('quarantined draw prohibited in development base')
            if len(row) != len(header_for(game_id)):
                raise ValueError('incorrect column count')
            number = _int(row[0], profile.first_draw, profile.holdout_first - 1, 'draw')
            if number != expected:
                raise ValueError('missing, duplicate or misordered draw')
            try:
                observed = date.fromisoformat(row[1])
            except ValueError as exc:
                raise ValueError('unparseable date') from exc
            if observed.isoformat() != row[1]:
                raise ValueError('noncanonical date')
            if observed != profile.derived_date(number):
                warnings.append(number)
            high = 35 if game_id == 'POWERBALL' else 47
            main = [_int(v, 1, high, 'main') for v in row[2:9]]
            if len(set(main)) != 7:
                raise ValueError('duplicate main number')
            if game_id == 'POWERBALL':
                secondary = _int(row[9], 1, 20, 'Powerball')
            else:
                secondary = [_int(v, 1, 47, 'supplementary') for v in row[9:12]]
                if len(set(main + secondary)) != 10:
                    raise ValueError('duplicate or overlapping supplementaries')
            rows.append((number, row[1], main, secondary))
    if len(rows) != profile.holdout_first - profile.first_draw:
        raise ValueError('development base not consecutive/comprehensive to holdout boundary')
    return DevelopmentDrawTable(game_id, source, rows, warnings)
