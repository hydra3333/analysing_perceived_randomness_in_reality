"""Owner-operated Lotterywest JSON API client for pre-holdout DEV_BUILD only.

NO background execution or browser impersonation. Results are returned only
in memory for full pre-publication auditing. The client cannot request dates
beyond 2026-08-07 and refuses misdirected redirects, unapproved robots, and
responses with unverified pagination. Never use it for HOLDOUT_FETCH/UPDATE.
"""
from __future__ import annotations

from datetime import date, timedelta
import hashlib
import time
from urllib.parse import urlencode, urlsplit
from urllib.request import Request, build_opener, HTTPRedirectHandler

from _common.game_profiles_v1 import get_profile
from _common.lotterywest_results_v1 import LOTTERYWEST_GAME_CODES, DEV_TO_DATE
from _common.multigame_source_policy_v1 import policy_for_offline_robots, PolicyDecision

ORIGIN = 'https://www.lotterywest.wa.gov.au'
ROBOTS = ORIGIN+'/robots.txt'
API = ORIGIN+'/api/games/draws/search'
USER_AGENT = 'analysing_perceived_randomness_in_reality/0.10 (+https://github.com/hydra3333/analysing_perceived_randomness_in_reality)'
PAUSE_DEFAULT_SECONDS = 2.0
PAUSE_MIN_SECONDS = 1.0
MAX_RESPONSE_BYTES = 4_000_000


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, *args, **kwargs):
        return None


def _get(url: str, *, user_agent: str = USER_AGENT) -> bytes:
    parsed = urlsplit(url)
    if (parsed.scheme != 'https' or parsed.netloc != 'www.lotterywest.wa.gov.au' or
            parsed.username is not None or parsed.password is not None or parsed.fragment or
            parsed.path not in ('/robots.txt','/api/games/draws/search')):
        raise ValueError('unapproved Lotterywest endpoint')
    with build_opener(NoRedirect()).open(Request(url, headers={'User-Agent':user_agent}), timeout=20) as response:
        raw = response.read(MAX_RESPONSE_BYTES+1)
        if len(raw)>MAX_RESPONSE_BYTES or response.status != 200 or response.url != url:
            raise ValueError('unsafe response size/status/origin')
    return raw


def effective_pause(requested: float, decision: PolicyDecision) -> float:
    if (type(requested) not in (int,float) or not 1.0 <= requested <= 60.0 or
            decision.request_allowed is not True):
        raise ValueError('rate limit or policy refusal')
    rate = (decision.request_rate[1]/decision.request_rate[0]
            if decision.request_rate is not None and decision.request_rate[0] > 0 else 0.0)
    return max(float(requested), PAUSE_MIN_SECONDS, decision.crawl_delay or 0.0, rate)


def years_for(game_id: str):
    profile = get_profile(game_id)
    d = profile.first_date - timedelta(days=1)
    while d <= DEV_TO_DATE:
        stop = min(date(d.year,12,31),DEV_TO_DATE)
        yield d,stop
        d = stop+timedelta(days=1)


def api_url(game_id: str, start: date, end: date, page: int) -> str:
    get_profile(game_id)
    if (type(start) is not date or type(end) is not date or start.year != end.year or
            start > end or end > DEV_TO_DATE or page < 1 or page > 1000):
        raise ValueError('DEV_BUILD request outside approved date/page window')
    params = {'from_date':start.isoformat(),'to_date':end.isoformat(),
              'game_id':LOTTERYWEST_GAME_CODES[game_id],'page':page,'draw_num':''}
    return API+'?'+urlencode(params)


def fetch_dev_pages(game_id: str, *, pause_seconds: float = PAUSE_DEFAULT_SECONDS,
                    fetch=_get, sleep=time.sleep) -> tuple[list[tuple[bytes,dict]],dict]:
    """Caller is responsible for never invoking except after owner's gate.

    Injection of fetch/sleep is for offline mock-only tests. No mode to read
    dates after 2026-08-07 exists in this client.
    """
    from _common.lotterywest_results_v1 import parse_api_page
    # Pause even for the initial robots request.
    if not 1.0 <= pause_seconds <= 60.0:
        raise ValueError('invalid requested API pause')
    sleep(pause_seconds)
    robots = fetch(ROBOTS)
    check_url=api_url(game_id,next(iter(years_for(game_id)))[0],
                      next(iter(years_for(game_id)))[1],1)
    policy = policy_for_offline_robots(source_id='LOTTERYWEST_JSON_API',
        page_url=check_url, robots_url=ROBOTS, robots_bytes=robots, user_agent=USER_AGENT)
    if not policy.request_allowed:
        raise ValueError('Lotterywest robots policy denied access')
    pause = effective_pause(pause_seconds,policy)
    downloaded=[]
    for start,end in years_for(game_id):
        page=1
        previous_total=None
        while True:
            url=api_url(game_id,start,end,page)
            sleep(pause)
            raw=fetch(url)
            # Validate envelope/pagination without relying on an order field:
            # both candidate fields exist, but no field is approved as drawn
            # until Powerball's 434/434 archived comparison chooses one.
            draws, meta=parse_api_page(raw,game_id,order_field='winning_numbers')
            if meta['page'] != page or (previous_total is not None and
                                        meta['total_pages'] != previous_total):
                raise ValueError('inconsistent Lotterywest pagination')
            previous_total=meta['total_pages']
            downloaded.append((raw, {'sha256':hashlib.sha256(raw).hexdigest(),
                        'source_id':'LOTTERYWEST_JSON_API','url':url,'page':page,
                        'start':start.isoformat(),'end':end.isoformat(),
                        'robots_sha256':policy.robots_sha256,'effective_pause_seconds':pause,
                        'lotterywest_game_code':LOTTERYWEST_GAME_CODES[game_id]}))
            if page==meta['total_pages']:
                break
            page+=1
            if page>1000:
                raise ValueError('excessive pagination')
    return downloaded, {'robots_sha256':policy.robots_sha256,'pause_seconds':pause,
                        'user_agent':USER_AGENT}
