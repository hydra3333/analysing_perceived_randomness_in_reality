"""Package-2 v0.10 candidate: offline assembly/atomic create-only dev snapshots.

This module performs NO network requests. Only structurally audited, strictly
pre-holdout draws can be published. All messages are value-free. A full source
response is held in memory until the audit succeeds; only then can raw response
bytes be written in a local git-ignored area. The caller must separately prove
which Lotterywest API field retains the observed drawn order.
"""
from __future__ import annotations

import csv
from datetime import datetime, timezone
import hashlib
from io import StringIO
import json
import os
from pathlib import Path
import re
import subprocess
import uuid
from typing import Sequence

from _common.game_profiles_v1 import get_profile
from _common.game_draws_reader_v1 import header_for, load_development_base
from _common.lotterywest_results_v1 import Draw, audit_complete_development, LOTTERYWEST_GAME_CODES

_HEX = re.compile(r'[0-9a-f]{64}\Z')
_REF = re.compile(r'[0-9a-f]{7,40}\Z')


def sha(raw: bytes) -> str:
    return hashlib.sha256(raw).hexdigest()


def _new(path: Path, raw: bytes) -> None:
    """Create-only, fsynced, no symlinks. No overwrite even on POSIX."""
    if path.parent.is_symlink() or not path.parent.is_dir() or os.path.lexists(path):
        raise ValueError('unsafe or already published destination: ' + path.name)
    temp = path.with_name(path.name + '.part-' + uuid.uuid4().hex)
    try:
        with temp.open('xb') as handle:
            handle.write(raw)
            handle.flush()
            os.fsync(handle.fileno())
        os.link(temp, path)
    finally:
        temp.unlink(missing_ok=True)


def _canonical(obj: dict) -> bytes:
    return (json.dumps(obj, sort_keys=True, ensure_ascii=True, allow_nan=False,
                       separators=(',', ':')) + '\n').encode('ascii')


def csv_bytes(game_id: str, draws: Sequence[Draw]) -> bytes:
    """Serialize EXACT audited objects, never reread a source after audit."""
    stream = StringIO(newline='')
    writer = csv.writer(stream, lineterminator='\n')
    writer.writerow(header_for(game_id))
    for item in draws:
        writer.writerow((item.number, item.date, *item.main, *item.secondary))
    return stream.getvalue().encode('ascii')


def audited_development_csv(game_id: str, draws: Sequence[Draw]) -> tuple[bytes, tuple[int, ...]]:
    profile = get_profile(game_id)
    if type(draws) not in (list, tuple):
        raise ValueError('untrusted development draw collection')
    sorted_draws = sorted(draws, key=lambda d: d.number)
    if len({d.number for d in sorted_draws}) != len(sorted_draws):
        raise ValueError('duplicate draw number')
    warnings = audit_complete_development(sorted_draws, game_id)
    if sorted_draws[-1].number != profile.holdout_first - 1:
        raise ValueError('development boundary not reached')
    return csv_bytes(game_id, sorted_draws), warnings


def _csv_legacy_prefix(raw: bytes, *, end: int) -> dict[int, dict]:
    """Only parse pre-holdout records. Never collect quarantine values."""
    text = raw.decode('utf-8-sig')
    reader = csv.DictReader(StringIO(text, newline=''))
    if not reader.fieldnames or 'Draw_Number' not in reader.fieldnames:
        raise ValueError('unrecognised archived Powerball CSV header')
    rows = {}
    for item in reader:
        number = int(item['Draw_Number'])
        if number > end:
            continue  # quarantined data MUST NOT be inspected
        if number in rows:
            raise ValueError('duplicate archived training draw')
        rows[number] = item
    return rows


def legacy_powerball_comparison(*, current: Sequence[Draw],
                                history_raw: bytes, drawn_raw: bytes,
                                start: int = 1144, end: int = 1577) -> dict:
    """Fail closed unless all 434 old training draws match both old CSVs.

    Reads only non-sealed draw fields; never displays the numbers. The old
    drawn-order file is only a comparison reference, not the new canonical base.
    """
    a = _csv_legacy_prefix(history_raw, end=end)
    b = _csv_legacy_prefix(drawn_raw, end=end)
    if set(a) != set(range(start, end+1)) or set(b) != set(range(start, end+1)):
        raise ValueError('archived Powerball development prefix incomplete')
    mapping = {d.number:d for d in current}
    if not set(range(start, end+1)) <= mapping.keys():
        raise ValueError('new Powerball development prefix incomplete')
    for n in range(start, end+1):
        row, ordered, candidate = a[n],b[n],mapping[n]
        def balls(r, prefix):
            return tuple(int(r[f'{prefix}{i}']) for i in range(1,8))
        # Compatibility header recognition is deliberately explicit.
        ordered_names = [('Drawn_',), ('Ball_',), ('Draw_Order_',)]
        drawn_value = None
        for (prefix,) in ordered_names:
            if all(f'{prefix}{i}' in ordered for i in range(1,8)):
                drawn_value = balls(ordered, prefix)
                break
        if drawn_value is None:
            raise ValueError('unrecognised archived drawn-order header')
        history_value = None
        for prefix in ('Ball_', 'Main_', 'Number_'):
            if all(f'{prefix}{i}' in row for i in range(1,8)):
                history_value = balls(row,prefix)
                break
        if history_value is None:
            raise ValueError('unrecognised archived history header')
        if (set(history_value) != set(candidate.main) or
                candidate.main != drawn_value or
                int(row['Powerball']) != candidate.secondary[0] or
                row['Date'] != candidate.date or ordered['Date'] != candidate.date):
            raise ValueError(f'Powerball archived comparison mismatch at draw {n} (values withheld)')
    return {'compared_draws': end - start + 1, 'agreement_count': end - start + 1,
            'compared_start':start, 'compared_end':end}


def git_reference_bytes(repo: Path, ref: str, relative: str) -> bytes:
    """A deliberate local git-history read, never network and never shell."""
    if not _REF.fullmatch(ref) or relative not in (
        'source_data/australian_powerball_history_20261021.csv',
        'source_data/australian_powerball_draw_order_20261021.csv'):
        raise ValueError('unapproved archived reference')
    complete = subprocess.run(['git', '-C', str(repo), 'show', f'{ref}:{relative}'],
                              capture_output=True, timeout=30, check=False)
    if complete.returncode or len(complete.stdout)>2_000_000:
        raise ValueError('archived Powerball reference unavailable')
    return complete.stdout


def provenance_record(*, game_id: str, mode: str, order_field: str,
                      snapshot_raw: bytes, warnings: tuple[int, ...],
                      response_meta: list[dict], started_utc: str,
                      finished_utc: str, comparison: dict | None = None) -> dict:
    profile = get_profile(game_id)
    if mode not in ('DEV_BUILD', 'OFFLINE_SAVED_PAGES'):
        raise ValueError('unsupported development publication mode')
    for item in response_meta:
        if type(item) is not dict or not re.fullmatch(r'[a-f0-9]{64}',str(item.get('sha256',''))):
            raise ValueError('invalid raw response provenance')
    return {'schema':'MULTIGAME_DEVELOPMENT_SNAPSHOT_PROVENANCE_V1',
            'mode':mode, 'game_id':game_id, 'profile_version':profile.version,
            'source':'LOTTERYWEST_JSON_API' if mode=='DEV_BUILD' else 'OWNER_SAVED_LOTTERYWEST_PAGES',
            'lotterywest_game_code':LOTTERYWEST_GAME_CODES[game_id],
            'order_field':order_field, 'raw_responses':response_meta,
            'snapshot_sha256':sha(snapshot_raw),
            'first_draw':profile.first_draw, 'last_draw':profile.holdout_first-1,
            'draw_count':profile.holdout_first-profile.first_draw,
            'date_warning_count':len(warnings),
            'started_utc':started_utc, 'finished_utc':finished_utc,
            'archived_powerball_comparison':comparison}


def publish_dev_snapshot(*, output_dir: Path, game_id: str, mode: str,
                         draws: Sequence[Draw], order_field: str,
                         response_meta: list[dict], started_utc: str,
                         comparison: dict | None = None,
                         stamp: str | None = None) -> tuple[Path, dict]:
    profile = get_profile(game_id)
    if not isinstance(output_dir, Path) or output_dir.is_symlink():
        raise ValueError('unsafe output directory')
    raw, warnings = audited_development_csv(game_id, draws)
    if game_id == 'POWERBALL' and (not comparison or comparison.get('agreement_count') != 434):
        raise ValueError('Powerball DEV_BUILD requires 434/434 archived comparison')
    # Build provenance from exactly the audited bytes, never reread.
    if stamp is None:
        stamp = datetime.now(timezone.utc).strftime('%Y%m%d')
    if not re.fullmatch(r'20[0-9]{6}',stamp):
        raise ValueError('invalid publication date')
    root = 'australian_powerball_drawn_' if game_id=='POWERBALL' else 'australian_ozlotto_drawn_'
    target = output_dir / (root+stamp+'.csv')
    provenance = target.with_suffix('.provenance.json')
    if os.path.lexists(target) or os.path.lexists(provenance):
        raise ValueError('snapshot collision; no overwrite')
    now = datetime.now(timezone.utc).isoformat()
    meta = provenance_record(game_id=game_id, mode=mode, order_field=order_field,
                              snapshot_raw=raw, warnings=warnings,
                              response_meta=response_meta, started_utc=started_utc,
                              finished_utc=now, comparison=comparison)
    _new(target, raw)
    _new(provenance, _canonical(meta))
    # No second-source read of the response occurs after audit. Verify the
    # exact published bytes through the same validated common-reader contract.
    return target, meta


def archive_dev_responses(*, raw_folder: Path, game_id: str, pages: Sequence[tuple[bytes,dict]]) -> list[Path]:
    """Only AFTER complete structural audit; local git-ignored raw evidence."""
    get_profile(game_id)
    if not raw_folder.is_dir() or raw_folder.is_symlink():
        raise ValueError('pre-existing local raw archive folder required')
    targets=[]
    for i,(raw,meta) in enumerate(pages,1):
        if type(raw) is not bytes or not isinstance(meta,dict) or sha(raw)!=meta.get('sha256'):
            raise ValueError('raw response and evidence digest disagree')
        target=raw_folder/(f'{game_id}_page_{i:03d}_{sha(raw)}.raw')
        if os.path.lexists(target):
            raise ValueError('immutable raw response collision')
        targets.append((target,raw))
    for target,raw in targets:
        _new(target,raw)
    return [target for target,_ in targets]
