"""Owner-operated historical-results tool. No mode runs implicitly.

The current reviewed candidate contains DEV_BUILD and OFFLINE_SAVED_PAGES;
HOLDOUT_FETCH and UPDATE are hard-disabled code stubs. Running the tool is
subject to Claude review and a separate owner authorisation. No values print.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
from pathlib import Path
import hashlib
import json
import sys

sys.path.insert(0,str(Path(__file__).resolve().parent/'methods'))
from _common.game_profiles_v1 import get_profile
from _common.lotterywest_results_v1 import parse_api_page, API_ORDER_FIELDS
from _common.lotterywest_saved_pages_v1 import parse_saved_page
from _common.multigame_results_build_v1 import (
    audited_development_csv, git_reference_bytes, legacy_powerball_comparison,
    publish_dev_snapshot, archive_dev_responses, sha)

ENABLE_HOLDOUT_FETCH = False
ENABLE_UPDATE = False
GIT_REFERENCE = '06f6e0f'


def _reference(repo: Path):
    base='source_data/'
    return (git_reference_bytes(repo,GIT_REFERENCE,base+'australian_powerball_history_20261021.csv'),
            git_reference_bytes(repo,GIT_REFERENCE,base+'australian_powerball_draw_order_20261021.csv'))


def choose_powerball_api_order(raw_pages: list[tuple[bytes,dict]], repo: Path):
    """Only one field whose 434/434 ORDER and set comparison passes is acceptable."""
    history, drawn = _reference(repo)
    matches=[]
    for field in sorted(API_ORDER_FIELDS):
        try:
            draws=[]
            for raw,_ in raw_pages:
                page,_=parse_api_page(raw,'POWERBALL',order_field=field)
                draws.extend(page)
            comparison=legacy_powerball_comparison(current=draws,
                                                  history_raw=history, drawn_raw=drawn)
            matches.append((field,draws,comparison))
        except ValueError:
            continue
    if len(matches)!=1:
        raise ValueError('Powerball API drawn-order field not uniquely verified 434/434')
    return matches[0]


def main(argv=None):
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument('--game',choices=('POWERBALL','OZLOTTO'),required=True)
    p.add_argument('--mode',choices=('DEV_BUILD','OFFLINE_SAVED_PAGES','HOLDOUT_FETCH','UPDATE'),required=True)
    p.add_argument('--input',nargs='*',default=[],help='Owner-saved .mhtml (offline mode only)')
    args=p.parse_args(argv)
    args.input=[x for x in args.input if x]
    root=Path(__file__).resolve().parents[1]
    if args.mode in ('HOLDOUT_FETCH','UPDATE'):
        # No fallback, flag or argument can override these gates in v0.10.
        print('[RESULTS] DISABLED: later phase requires separate ratification',file=sys.stderr)
        return 3
    if args.mode=='DEV_BUILD' and args.input:
        p.error('DEV_BUILD does not accept saved-page inputs')
    if args.mode=='OFFLINE_SAVED_PAGES' and not args.input:
        p.error('OFFLINE_SAVED_PAGES requires --input')
    try:
        # Part E installation invariant: the prior active source files must
        # already have been withdrawn from the working tree by the owner.
        for name in ('australian_powerball_history_20261021.csv',
                     'australian_powerball_draw_order_20261021.csv'):
            if (root/'source_data'/name).exists() or (root/'source_data'/name).is_symlink():
                raise ValueError('historical source CSV still active in working tree')
        started=datetime.now(timezone.utc).isoformat()
        raw_pages=[]
        if args.mode=='DEV_BUILD':
            from _common.lotterywest_api_client_v1 import fetch_dev_pages
            raw_pages,_ = fetch_dev_pages(args.game)
            if args.game=='POWERBALL':
                order_field,draws,comparison=choose_powerball_api_order(raw_pages,root)
            else:
                # The previously completed Powerball DEV_BUILD establishes the
                # order field: do not infer from the Oz Lotto values alone.
                import glob
                proofs=sorted((root/'source_data').glob('australian_powerball_drawn_*.provenance.json'))
                if len(proofs)!=1:
                    raise ValueError('exactly one accepted Powerball order proof required before Oz Lotto')
                proof=json.loads(proofs[0].read_bytes())
                order_field=proof.get('order_field')
                if order_field not in API_ORDER_FIELDS or proof.get('archived_powerball_comparison',{}).get('agreement_count')!=434:
                    raise ValueError('Powerball drawn-order proof unavailable')
                draws=[];comparison=None
                for raw,_ in raw_pages:
                    chunk,_=parse_api_page(raw,args.game,order_field=order_field)
                    draws.extend(chunk)
        else:
            order_field='MHTML_DRAWN_ATTESTED'
            draws=[];comparison=None
            for value in args.input:
                path=Path(value).resolve()
                if path.suffix.lower() not in ('.mhtml','.mht') or not path.is_file() or path.is_symlink():
                    raise ValueError('invalid owner-saved .mhtml path')
                raw=path.read_bytes()
                if len(raw)>12_000_000:
                    raise ValueError('saved-page input too large')
                parsed=parse_saved_page(raw,args.game,drawn_selected=True)
                draws.extend(parsed)
                raw_pages.append((raw,{'sha256':sha(raw),'source_id':'OWNER_SAVED_MHTML',
                                       'local_filename':path.name,'size':len(raw)}))
            if args.game=='POWERBALL':
                history,old_drawn=_reference(root)
                comparison=legacy_powerball_comparison(current=draws,
                                    history_raw=history,drawn_raw=old_drawn)
        # Full structural audit BEFORE any output or raw archive creation.
        audited_development_csv(args.game,draws)
        # Local raw evidence is NEVER placed in the public repository; it
        # must be under the pre-existing git-ignored transitory_data tree.
        raw_root=root/'transitory_data'/'raw_lotterywest_responses'
        raw_root.mkdir(parents=True, exist_ok=True)
        # Fail closed rather than risk publicly adding raw source responses.
        local_ignore=raw_root/'.gitignore'
        if not local_ignore.exists():
            with local_ignore.open('x', encoding='ascii') as fh:
                fh.write('*\n')
        if local_ignore.is_symlink() or local_ignore.read_bytes()!=b'*\n':
            raise ValueError('raw response archive is not safely git-ignored')
        archive_dev_responses(raw_folder=raw_root,game_id=args.game,pages=raw_pages)
        destination, meta=publish_dev_snapshot(output_dir=root/'source_data',
                game_id=args.game, mode=args.mode, draws=draws,
                order_field=order_field, response_meta=[item[1] for item in raw_pages],
                started_utc=started, comparison=comparison)
        print(f'[RESULTS] PASS game={args.game} mode={args.mode} '
              f'range={meta["first_draw"]}..{meta["last_draw"]} '
              f'count={meta["draw_count"]} warnings={meta["date_warning_count"]} '
              f'file={destination.name} sha256={meta["snapshot_sha256"]}')
        return 0
    except (ValueError,OSError,UnicodeError) as ex:
        # Never report raw values from a scraper or file in any exception.
        print(f'[RESULTS] STOP {type(ex).__name__}; no accepted new dataset',file=sys.stderr)
        return 2

if __name__=='__main__':
    raise SystemExit(main())
