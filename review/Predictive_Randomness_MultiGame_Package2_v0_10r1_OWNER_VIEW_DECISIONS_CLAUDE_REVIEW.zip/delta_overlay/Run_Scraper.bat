@echo off
setlocal DisableDelayedExpansion
rem Package-2 v0.10 REVIEW CANDIDATE: owner-run ONLY AFTER ratification.
rem Explicit game and mode; future modes disabled in Python.
set "ROOT=%~dp0"
set "PY=%ROOT%.venv\Scripts\python.exe"
set "VENV_ACTIVATE=%ROOT%.venv\Scripts\activate.bat"
set "RC=2"
if not exist "%PY%" goto :venv_missing
if not exist "%VENV_ACTIVATE%" goto :venv_missing
if "%~2"=="" goto :usage
if /I "%~2"=="DEV_BUILD" goto :select_mode_dev
if /I "%~2"=="OFFLINE_SAVED_PAGES" goto :select_mode_offline
if /I "%~2"=="HOLDOUT_FETCH" goto :select_mode_disabled
if /I "%~2"=="UPDATE" goto :select_mode_disabled
goto :usage
:select_mode_dev
if not "%~3"=="" goto :usage
set "MODE=DEV_BUILD"
goto :game_arg
:select_mode_offline
if "%~3"=="" goto :usage
set "MODE=OFFLINE_SAVED_PAGES"
goto :game_arg
:select_mode_disabled
set "MODE=%~2"
goto :game_arg
:game_arg
if /I "%~1"=="POWERBALL" goto :powerball
if /I "%~1"=="OZLOTTO" goto :ozlotto
goto :usage
:powerball
set "GAME=POWERBALL"
goto :check_venv
:ozlotto
set "GAME=OZLOTTO"
:check_venv
for %%I in ("%ROOT%.venv\.") do set "EXPECTED_ENV=%%~fI"
if defined VIRTUAL_ENV goto :check_active
call "%VENV_ACTIVATE%"
if errorlevel 1 goto :activation_failed
if not defined VIRTUAL_ENV goto :activation_failed
goto :check_python
:check_active
for %%I in ("%VIRTUAL_ENV%\.") do set "ACTIVE_ENV=%%~fI"
if /I not "%ACTIVE_ENV%"=="%EXPECTED_ENV%" goto :wrong_venv
:check_python
"%PY%" -c "import sys,pathlib;sys.exit(0 if pathlib.Path(sys.prefix).resolve()==pathlib.Path(sys.argv[1]).resolve() else 12)" "%EXPECTED_ENV%"
if errorlevel 1 goto :prefix_failed
if /I "%MODE%"=="OFFLINE_SAVED_PAGES" goto :offline
"%PY%" -u "%ROOT%src\multigame_results_tool_v1.py" --game "%GAME%" --mode "%MODE%"
goto :return_code
:offline
rem Saved-page input paths are passed as literal file arguments; parsing is Python-owned.
"%PY%" -u "%ROOT%src\multigame_results_tool_v1.py" --game "%GAME%" --mode OFFLINE_SAVED_PAGES --input "%~3" "%~4" "%~5" "%~6" "%~7" "%~8" "%~9"
:return_code
set "RC=%ERRORLEVEL%"
goto :finish
:venv_missing
echo [SCRAPER] ERROR: project .venv missing. >&2
goto :finish
:wrong_venv
echo [SCRAPER] ERROR: another virtual environment is active. >&2
goto :finish
:activation_failed
echo [SCRAPER] ERROR: venv activation failed. >&2
goto :finish
:prefix_failed
echo [SCRAPER] ERROR: Python does not match the expected sys.prefix. >&2
goto :finish
:usage
echo Usage: Run_Scraper.bat POWERBALL^|OZLOTTO DEV_BUILD >&2
echo    or: Run_Scraper.bat POWERBALL^|OZLOTTO OFFLINE_SAVED_PAGES file1.mhtml [file2...] >&2
:finish
endlocal & exit /b %RC%
