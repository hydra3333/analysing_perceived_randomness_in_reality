# Previously accepted Powerball CSV structure — HEADER-ONLY inspection

The archived repository ZIP `analysing_perceived_randomness_in_reality-main(5).zip` contains:
- `source_data/australian_powerball_history_20261021.csv`: `Draw_Number,Date,Ball_1,Ball_2,Ball_3,Ball_4,Ball_5,Ball_6,Ball_7,Powerball`.
- `source_data/australian_powerball_draw_order_20261021.csv`: `Draw_Number,Date,Drawn_1,Drawn_2,Drawn_3,Drawn_4,Drawn_5,Drawn_6,Drawn_7,Powerball,Official_Source_URL`.

Header and field count inspected only. **No archived ball values and no quarantine values were read for this evidence file**; 434/434 value comparison is reserved for authorised DEV_BUILD and restricted to draws 1144–1577. Earlier established provenance (per project): `powerball.net` sorted history; Lotterywest drawn-order lookup. Verify exact recovery against the owner's installed Git history before deletion from the working tree.
