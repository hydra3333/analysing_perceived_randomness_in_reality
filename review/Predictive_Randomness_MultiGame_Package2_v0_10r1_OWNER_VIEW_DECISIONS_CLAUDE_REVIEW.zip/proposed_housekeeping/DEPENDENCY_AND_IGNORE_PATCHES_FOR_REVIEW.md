# Package 2 v0.10 repository housekeeping proposals (not automatically installed)

**Status: DRAFT / owner review required.** The mounted development archive is older than Git HEAD `06f6e0f`, so do not blindly overwrite an unknown HEAD version of `.gitignore`, `requirements.txt` or `install_upgrade_dependencies_into_venv.bat`.

1. Verify that `requirements.txt` contains NumPy; if absent add an appropriately Python-3.14-compatible NumPy requirement (Windows acceptance evidence previously used NumPy 2.5.3). NumPy is required by the new common reader. Ensure the installer and requirements agree.
2. `install_upgrade_dependencies_into_venv.bat` in the available archived source already lists `numpy` among `DIRECT_PACKAGES`; preserve its venv checks and existing behaviour. Verify against the current HEAD before any change.
3. Add `transitory_data/raw_lotterywest_responses/` to `.gitignore`, and optionally `transitory_data/lotterywest_saved_pages/`; the source API responses and owner-saved `.mhtml` are local-only raw evidence, not public repository artifacts. Existing `transitory_data/poc_runs/` and dependency exclusions must remain.
4. The two historical Powerball CSVs are removed **from the working tree by the owner at the approved installation stage**, not by this review delta. They remain recoverable from Git history. This delta contains no delete operation touching actual source CSVs.

Do not install or commit these proposals until reconciled with the current HEAD.
