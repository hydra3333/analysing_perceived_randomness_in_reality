# P1/P2 unresolved-orphan interlock v0.5 — Claude review candidate

**Date:** 23 October 2026  
**Authority:** Ratified Software Architecture v0.4 §5C and owner-ratified strict no-status/no-kill rule.  
**Baseline:** Reviewed coordinator v0.3, SHA-256 `a2402175eaf22bf9d0293b49a6d1c91b48fe20d26866cf5d096dcfae6a95a58b`.  
**Supersedes rejected v0.4 candidate:** SHA-256 `b3a15a15aff3859090538ee950cff40ce189e0dbd1a540ed0f3ef234c225d1c7`.  
**Candidate v0.5 SHA-256:** `a05a32d7127a2730f5f108d3751222d910b55c56410e75a7052ddbb436736bf1`.  
**Status:** **NOT APPROVED. NO DESTRUCTIVE TESTS. DO NOT CHANGE OWNER SWITCH.**

## Scope and delta

- **B1 critical defect corrected.** The first time the coordinator detects that its launched wrapper has exited, it checks retained ancestry-member process objects with `_member_alive`. If **any** member is still alive **or cannot be verified gone**, the run becomes `ORPHAN_SUSPECTED`, scheduling stops, and the coordinator writes the persistent unresolved-orphan marker. This applies even when the wrapper exits with a nonzero code without calling `stop()` (e.g. wrapper killed externally). No PID from a status file becomes a kill target.
- **Status validation failure:** A `status_and_result()` finding of `Probe PID not confirmed gone` also causes `ORPHAN_SUSPECTED` and a marker, even outside the normal stop path; the PID is evidence-only.
- **B1 synthetic coverage:** New `tests/p1p2_orphan_interlock_v0_5.py` tests exited wrapper + live member; exited wrapper + identity-unknown member; confirmed-departed member; live root not spuriously marked; marker no-clobber; and marker-write failure. Tests use fakes, never real PIDs or termination calls.
- **Operator notice:** Highly visible `[SAFETY STOP]` banner when marker is generated **and** when subsequent launch is blocked; includes group, worker, root PID + creation time where available, exact marker path, and actionable instructions. Never kill solely from PID; if any identity alive/uncertain, leave marker and escalate; after verifying all gone, archive original marker bytes, SHA-256, and logs before manually clearing.
- **O1 addressed:** If marker persistence raises an OSError (except handled FileExistsError), print `CRITICAL ... DO NOT RUN AGAIN`, preserve coordinator failure, and write a `marker_write_failed` boolean into the final manifest. Disk failure cannot guarantee durable interlock on future starts; this residual limitation is explicit.
- **O2:** The marker already contains root PID, creation time, members and observed liveness when a worker is supplied. The prominent warning prints group/worker/root identities for immediate diagnosis.
- **O3:** The prior automated decoy utility pins the reviewed v0.3 hash; it must not be run unmodified against v0.5. A separate update/review will be required before that utility is used again.
- **O4/O5 deferred:** Manual individual wrapper warning and production marker path design are not part of this engineering POC patch.

## Unchanged and prohibited

- `ENABLE_PROCESS_TERMINATION = False`; no CLI override, no automatic marker acknowledgement or kill.
- Owner-ratified **no-status/no-kill** remains binding.
- `terminate_owned_tree()` implementation is **AST-identical** between reviewed v0.3, rejected v0.4 and candidate v0.5. No kill-path edits in v0.5.
- Same Option F per-experiment `Run_Experiment.bat` launch, one-to-six worker cap, no new dependencies, no scientific method implementation.
- Source files in repo are unchanged: this is a proposed installation package only.

## Package file inventory

| Path | Action | SHA-256 |
|---|---|---|
| `src/Powerball_Experiment_Coordinator.py` | replacement | `a05a32d7127a2730f5f108d3751222d910b55c56410e75a7052ddbb436736bf1` |
| `tests/p1p2_orphan_interlock_v0_4.py` | new | `16fadeb75756ff856d49f848450d71d55cf75c7f0f2ed3070b920dc696104895` |
| `tests/p1p2_orphan_interlock_v0_5.py` | new | `efecf6efecd4bd13a22b5af0512f459aca2676f38e04cc6976d1c06405927934` |

## Evidence — performed here, non-destructive only

On a disposable snapshot of the previously supplied repository, all six Python test files passed:
`p0_static_checks.py`, `p1p2_static_checks.py`, `p1p2_non_destructive_safety_checks.py`, `p1p2_safety_regression_v0_3.py`, `p1p2_orphan_interlock_v0_4.py`, and `p1p2_orphan_interlock_v0_5.py`.

**NOT TESTED:** real Windows marker creation/restart refusal; external wrapper termination; forced process termination; repeated Ctrl+C; data loss or crashes under filesystem write errors; production acceptance. Synthetic code coverage is not a substitute for Windows observations.

## DECIDED / RECOMMENDED / OPEN

**DECIDED by owner:** Strict no-status/no-kill; owner approves manual interlock clearance *after inspecting PID and creation time, verifying every affected process exited, and archiving the original marker bytes + SHA-256 and logs*. If anything alive/uncertain, do not manually kill the PID and escalate. No CLI bypass.

**DECIDED by ChatGPT within ratified policy (subject to Claude review):** Mark a suspected orphan on wrapper exit if any captured member survives/is unverified; treat unmatched live status PID as evidence only; stop further scheduling; write a prominent warning; report marker persistence errors in manifest.

**RECOMMENDED:** Claude review the v0.5 B1 fix and check acceptance against Architecture §5C.2 *before installing and exercising on Windows*. If approved, run static/synthetic tests first, then only non-destructive Windows checks. Consider automated decoy hash pin update as a future separate test-tool housekeeping change.

**OPEN:** Real termination controlled test procedure, test-copy switch change and verified revert, the mandatory before/after chcp check, direct Python coordinator launch negative test, and archival evidence under `results/architecture_poc/<date>_<test>/`. No automatic stage/Option F acceptance.

## Caution for operators

**Do not extract this candidate over the working repository until Claude has approved the source.** It replaces only `src/Powerball_Experiment_Coordinator.py` and adds two synthetic test files. Validate existing coordinator SHA-256 against the v0.3 baseline before replacing and validate v0.5 SHA-256 afterwards. Do not run a timeout, Ctrl+C, or destructive test at this checkpoint.
