# Independent Claude review request — P1/P2 orphan interlock v0.5

**Do not authorise destructive testing.** Review the enclosed source and `v0_4_to_v0_5.diff` against your rejected-v0.4 B1 finding and the ratified architecture. `v0_3_to_v0_5.diff` is included for complete reference from the reviewed baseline, whose SHA-256 is `a2402175eaf22bf9d0293b49a6d1c91b48fe20d26866cf5d096dcfae6a95a58b`.

Please specifically verify:
1. B1: process owner wrapper exits without `stop()` while retained child is live/unknown, including nonzero wrapper exit; marker publication, new-launch refusal, no kill and halt of scheduling.
2. `status_and_result()` non-gone PID detection outside stop() and no status-PID kill path.
3. Prominent actionable warning at both event and next launch, with strict manual identity inspection/archival instructions, never blind manual PID termination.
4. Marker write failures handled without losing the manifest and flagged `marker_write_failed`.
5. Tests are fake-only; exact diff against v0.3, no change to `terminate_owned_tree` or disabled global switch; local six-suite evidence.
6. Anything remaining before first safe *non-destructive* Windows install/test, and any blockers for the eventual destructive readiness gate.

Clearly separate BLOCKER, optional improvements and owner decisions. The test package is NOT to be installed/run on the user's Windows system until reviewed.
