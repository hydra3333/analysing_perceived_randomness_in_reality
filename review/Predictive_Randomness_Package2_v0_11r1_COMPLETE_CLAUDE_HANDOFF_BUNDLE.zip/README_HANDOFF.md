# Package 2 v0.11-r1: COMPLETE HANDOFF BUNDLE for fresh Claude reviewer

This *outer* ZIP bundles existing unmodified files for convenience. It is NOT a new
software overlay, an installation approval, or scientific-run authorisation.

PROJECT: hydra3333/analysing_perceived_randomness_in_reality
OWNER-VERIFIED GIT BASELINE: 618fe48c48ada46bcf60c80bbd291acc216d7e3b

CONTENTS
- analysing_perceived_randomness_in_reality-main(6).zip:
  Owner-supplied source/document snapshot, included for offline review convenience.
  Git metadata is not included. Verify source identities and baseline as needed.
- Predictive_Randomness_MultiGame_Package2_v0_11_CLAUDE_REVIEW_ONLY.zip:
  Original full v0.11 candidate (26-file repo_overlay), SHA-256
  0e00e231c46dafd01df52fb6f50db6ceaf399ea27be40efb318529101611d74c
- Predictive_Randomness_MultiGame_Package2_v0_11r1_FOCUSED_CLAUDE_REVIEW.zip:
  Small two-file overlay delta AGAINST the original v0.11 (not standalone), SHA-256
  7bddda746f56668fbc60af9826cee83c7fd95031dfd3c9b4b474641cc2734635
- Claude_Review_Package2_v0_11_v1.md:
  Prior independent review reporting one B1 blocker and one C1 correction.
- PASTE_TO_NEW_CLAUDE_CHAT.txt:
  Short handoff prompt.

FOCUSED REVIEW STEPS
1. Read the original Claude review and both ZIPs' README files.
2. Reconstruct a SCRATCH tree using baseline 618fe48 (from independently verified
   Git or supplied owner snapshot) plus the v0.11 repo_overlay. Do not edit the
   owner's working checkout.
3. Apply only the two replacement files from the v0.11-r1 repo_overlay, or
   independently verify/apply its included patch. Do NOT apply both mechanisms.
4. Verify manifest hashes and independently assess B1 and C1. In particular:
   - All method-facing DrawView fields, bytes, digests invariant under suffix
     changes (each view kind, both games, date optionality); whole-master hashes
     remain ONLY on orchestration side.
   - Assert the RATIFIED R2 §5.5/TIE v0.2 synthetic E_1 vectors alongside
     separately labeled standalone-runner golden tests.
   - Ensure all other v0.11 files unchanged; coordinator safety gates False and
     scientific result allowlist empty.
5. Return a focused BLOCKER/CORRECTION/OPTIONAL verdict for owner ratification.

NO real-data experiment, Windows/lifecycle/destructive runs, master update,
holdout access, Mode H, FINAL, process termination, switch activation,
scientific allowlist additions, ranking code, or E_2-readiness fields.

This bundle was created solely to repair broken cross-chat download links.
