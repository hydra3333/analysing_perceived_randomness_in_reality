# Multi-game Package 1 v0.2 — ratification candidates, NOT INSTALLED

Reviewed baseline: Claude independently checked repository HEAD `1c7cfced` on 24 October 2026. This ZIP applies **only the six corrections C1–C6** in Claude's Package 1 review, including its minor request to remove unearned `signed` wording. No independent second Claude round is required for these six narrow changes; return for review if anything else changes.

## What changed from v0.1

- **C1** Register v0.2 is explicitly the FIRST proposed committed register; correct the committed Architecture v0.5 SHA-256 to `9889617f...5502`, not the uncommitted heading-correction hash `2d57f59a...acd`; R3 v0.2 ratification date = 22 October 2026. Architecture source diff is now against the *actual* v0.5 committed bytes, reconstructed by reversing exactly the previously proposed §5C heading correction, with SHA-256 cross-checked against Claude.
- **C2** Structural acceptance and holdout sealing depend on data shape/range, era, consecutive unique draws, separate winning/raw files and hashes. Derived-date mismatches are recorded and stop only date-dependent E_14/E_54; they do not prevent structural acceptance/sealing by themselves.
- **C3** Historical development targets permanently remain **below** the game's first holdout number: Powerball `<=1577`, Oz `<=holdout_first-1`. Later targets require prospective FINAL or an explicitly approved separate protocol.
- **C4** New view-schema identity domains apply to **every new view** for either game, including future Powerball methods, not only Oz. The legacy Powerball E1_REAL_U_TRAINING_VIEW_V1 remains byte-identical.
- **C5** The new P3 task spec explicitly requires compatible BEGIN/FINISH/RESULT/DIGEST console messages (or an independently reviewed coordinator validator change) **before any coordinated method launch**; current E_001 does not satisfy coordinator v0.6's console validation as-is.
- **C6** Proposal includes an upfront historical-state note for its inherited stale R2/R3/predictor descriptions; Architecture no longer says `signed` for the unsigned holdout audit.

## Authority and installation

Everything in `repo_overlay/` remains a **REVIEW_CANDIDATE**. **Do not extract into the working repo until owner ratification and a separate final-install package.** Ratify in sequence: Proposal v0.4; ERR-R2-05/R2 erratum v0.3 and R3 v0.3; Architecture v0.6 and the new P3 task spec; supporting TIE contract note and register. Each old ratified file stays unchanged; history is not overwritten.

No implementation, scraping, Oz Lotto science, Powerball scoring, coordinator termination, orphan clearance, FINAL forecast or holdout access is authorised. The developer pause is still in effect.

See `diffs_vs_committed/` for exact LF-normalised source comparisons, `diffs_vs_v0_1/` for the review changes and `SHA256_MANIFEST.txt` for integrity.
