Previously checked owner ratified install: 20c883a990deb78def411b2ed3c6e7206b5964d3ca3ab9192d823a8d059bd06b
Correction scope: R3 single authority line; register R3 SHA-256, ERR-R2-06 wording and dates; README clarification; evidence regenerated.
Modified governing docs only: ['INSTALL_OVERLAY/doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_4.md', 'INSTALL_OVERLAY/doc/RATIFICATION_REGISTER_v0_3.md']
All other installed governing documents byte-identical.
