# Package 2 v0.11-r1 — owner overlay installation handback

**Prepared 27 October 2026, ChatGPT primary coding chat.**  
**Status:** reviewed code accepted by owner; installation is **not** performed by ChatGPT. Owner stages, commits and pushes. No Windows/lifecycle/scientific run is authorised by these steps.

## 1. What this ZIP is

- `repo_overlay/` contains **27** repository-relative files: **exactly 26 Claude-reviewed Package 2 v0.11-r1 source/test files** (parent v0.11 with the two r1 replacements) plus **one new non-normative acceptance/deferred-work record** at `doc/HANDOVER/Package2_v0_11r1_Acceptance_Deferred_Work_v0_1.md`.
- `SHA256_MANIFEST.json` records each installed file's raw SHA-256, including the two original committed-file identities that will be overwritten.
- `VERIFY_PACKAGE2_INSTALL.py` is a **read-only**, standard-library verifier that does not import project code, execute tests, read scientific outcomes, or alter Git.
- `GIT_STAGE_EXACT_FILES_ONLY.cmd` is an **optional, owner-invoked** script that stages only the listed 27 paths. It does not commit, push, delete or run tests.
- `evidence/` contains Claude's review, its exact reviewed 26-file inventory, and the 21 names retired **from never-installed review candidates**.
- `handoffs/ChatGPT_Coder_ADD_2_Package2_v0_11r1_v0_1.md` is a separate **DRAFT** future role-transition knowledge-transfer item. It is **NOT in `repo_overlay/` and must not be silently installed or treated as owner-ratified H-1/H-2/H-3**.
- `messages/` contains two paste-ready status blurbs for the new Claude chat and the separate ChatGPT reviewer chat. They are **not repo files**.

The original source ZIPs are not required for this install because the 26 source bytes have already been reconstructed and checked against Claude's independent inventory. This package does not include, replace, copy, edit or read any source master, ledger, INIT record or ratified governing-document edition.

## 2. Before copying anything (owner Windows CMD)

**Extract this installation ZIP into a temporary location OUTSIDE the repository** (example `E:\TEMP\P2_v011r1_install`). Do **not** extract the entire installation ZIP into the repository. In the repository root, check:

```bat
git rev-parse HEAD
git status --short --branch
python "E:\TEMP\P2_v011r1_install\VERIFY_PACKAGE2_INSTALL.py" --repo "." --phase pre
```

The verifier requires (a) a clean working tree/index, (b) current HEAD descended from reviewed commit `618fe48c48ada46bcf60c80bbd291acc216d7e3b`, (c) unchanged baseline hashes for `requirements.txt` and `src/Powerball_Experiment_Coordinator.py`, (d) every expected new path absent, and (e) old uninstalled candidate paths absent. It deliberately stops rather than overwrite unexpected content. A more recent documentation-only HEAD is fine **if** it passes those checks; do not reset a newer owner's commit merely to obtain 618fe48.

**If preflight fails, STOP and bring back the precise output.** Do not remove or reset anything to force it to pass.

## 3. Copy the familiar overlay

In Windows File Explorer open the extracted `repo_overlay` **folder**, select **its contents** (`requirements.txt`, `src`, `tests`, `doc`), and copy/extract them onto your existing repository ROOT. Accept ordinary replacement prompts for the two expected committed files only. Do not copy the enclosing `repo_overlay` folder as a new directory, and do not copy `handoffs`, `messages`, `evidence`, verifier, or ZIP root into the repository.

**No `git rm` is expected.** The 21 candidate-retirement paths were already absent from the verified baseline. Their list is in `evidence/RETIRED_CANDIDATE_ONLY_NOT_PRESENT_AT_BASE.txt`. If any unexpectedly exist in the current working checkout, the preflight is designed to stop; that requires manual reconciliation and is NOT permission to delete them.

## 4. Verify, stage and commit (owner only)

```bat
python "E:\TEMP\P2_v011r1_install\VERIFY_PACKAGE2_INSTALL.py" --repo "." --phase post
git status --short
git diff --check
```

**Expected:** 27/27 overlay file SHA-256 hashes PASS; 2 modified committed paths, 25 newly added paths (24 source/test + 1 factual status record), no deleted paths. For the **exact reviewed file list**, run the optional `GIT_STAGE_EXACT_FILES_ONLY.cmd` from the repository root via `call "E:\TEMP\P2_v011r1_install\GIT_STAGE_EXACT_FILES_ONLY.cmd"`. Alternatively, `git add --` precisely the paths listed in `evidence/INSTALL_27_FILE_LIST.txt`.

Before committing, inspect:

```bat
git diff --cached --check
git diff --cached --stat
git diff --cached --name-status
```

Only after the owner is satisfied, the owner may create a normal commit with their chosen message (e.g., `Accept Package 2 v0.11-r1 reviewed offline implementation`). This package does **not** create a Git commit or push. Preserve its SHA-256 and actual commit ID in the handback. Then run:

```bat
python "E:\TEMP\P2_v011r1_install\VERIFY_PACKAGE2_INSTALL.py" --repo "." --phase committed
git rev-parse HEAD
git status --short --branch
```

The `committed` phase checks both working file SHA-256 **and Git HEAD blob bytes** for all 27 expected files, plus the clean tree and baseline ancestry. Send the actual post-commit SHA/HEAD and output to Claude for independent installation verification. A SHA-256 match of the package itself is **not** a substitute for verifying the committed Git tree.

## 5. Deferred work, transition and safety

The factual repository note preserves **P2-R1-O1** (intermediate N + equal-length rewritten suffix T-05 fixture) and **P2-R1-O3** (automatic 11-function v0.6 protected AST baseline fixture) as **deferred/approved for later scheduling**. Prefer one separately approved offline test-hardening package after installation and before the next consequential view/reader extension. Neither is implemented here, a blocker, or an unapproved additional E_2 code gate. The previously identified `source_data` path containment / NTFS hard-link / full lifecycle-module-review options remain open.

**No automatic AI role change.** The ratified role plan requires ADD-2, earlier Claude D-1, reviewed owner-ratified H-1/H-2/H-3, installed atomically at an explicitly owner-designated effective commit/milestone. Recommendation: designate a **later transition commit**, after Package 2 installation proof and before E_2-readiness coding, rather than allowing the Package 2 acceptance commit to imply a change prematurely.

**All operational gates stay CLOSED.** All three switches False, scientific allowlist empty. This ZIP does not authorise or conduct process termination, Windows/lifecycle tests, scientific runs, network acquisition, master updates, holdout access, Mode H, FINAL, ranking implementation or E_2-readiness fields. Fresh marker state must be checked by the owner before any separately authorised future launch.
