@echo off
setlocal
rem OPTIONAL owner-run staging only. No commit/push/deletions, no project code execution.
git add -- ^
  "doc\HANDOVER\Package2_v0_11r1_Acceptance_Deferred_Work_v0_1.md" ^
  "requirements.txt" ^
  "src\Powerball_Experiment_Coordinator.py" ^
  "src\coordinator_private\__init__.py" ^
  "src\coordinator_private\multigame_coordinator_exit_receipt_v2.py" ^
  "src\coordinator_private\multigame_launch_spec_v1.py" ^
  "src\coordinator_private\multigame_windows_lifecycle_v1.py" ^
  "src\methods\POC_MultiGame_Synthetic_Worker.py" ^
  "src\methods\_common\e1_common_reader_bridge_v1.py" ^
  "src\methods\_common\game_draws_reader_v1.py" ^
  "src\methods\_common\game_profiles_v1.py" ^
  "src\methods\_common\multigame_ancestry_release_v1.py" ^
  "src\methods\_common\multigame_console_protocol_v1.py" ^
  "src\methods\_common\multigame_coordinated_manifest_v1.py" ^
  "src\methods\_common\multigame_e1_v1.py" ^
  "src\methods\_common\multigame_method_registry_v1.py" ^
  "src\methods\_common\multigame_result_registry_v1.py" ^
  "src\methods\_common\multigame_standalone_contract_v1.py" ^
  "src\methods\_common\multigame_synthetic_scorer_v1.py" ^
  "src\methods\_common\multigame_worker_launch_handshake_v1.py" ^
  "tests\test_multigame_console_and_synthetic_scorer_v0_4.py" ^
  "tests\test_multigame_exit_receipt_v0_8.py" ^
  "tests\test_multigame_launch_and_manifest_v0_8.py" ^
  "tests\test_multigame_science_allowlist_v0_8.py" ^
  "tests\test_multigame_v011_reader_contracts.py" ^
  "tests\test_multigame_v011_static_and_timing.py" ^
  "tests\test_multigame_windows_lifecycle_review_v0_9.py"
if errorlevel 1 (
  echo Git staging failed.
  exit /b 1
)
git diff --cached --check
if errorlevel 1 exit /b 1
git diff --cached --name-status
echo Staging completed. Review the staged changes BEFORE committing.
endlocal
