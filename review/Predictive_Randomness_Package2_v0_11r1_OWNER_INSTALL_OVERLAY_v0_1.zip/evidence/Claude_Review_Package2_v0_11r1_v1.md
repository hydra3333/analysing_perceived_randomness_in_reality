# Claude review of Package 2 v0.11-r1, v1

**Work-item card**

| Field | Value |
|---|---|
| Item | Package 2 v0.11-r1: closure of B1 and C1 from `Claude_Review_Package2_v0_11_v1.md` |
| Lead (author) chat | ChatGPT coding chat |
| Reviewer chat | Claude (new chat; independent reviewer under the current roles, agreed position v0.1r1 section 9 item 1, Option A) |
| Base commit | `618fe48c48ada46bcf60c80bbd291acc216d7e3b` (repository at `4a45b70` adds only documents and review files) |
| Inputs | r1 ZIP `7bddda746f56668fbc60af9826cee83c7fd95031dfd3c9b4b474641cc2734635` (also committed in `review/`); parent v0.11 ZIP `0e00e231c46dafd01df52fb6f50db6ceaf399ea27be40efb318529101611d74c`; handoff bundle `b7bda4e3107cdf3286baa378e5cf2ad804d7e2e285939e4bdf80ba2ae494341a` |
| Scope | Two replacement files against v0.11: `src/methods/_common/game_draws_reader_v1.py`, `tests/test_multigame_v011_reader_contracts.py` |
| Risk tier | HIGH (reader, view and digest code; test goldens) |
| Owner gate | Code acceptance and installation (commit) are owner decisions; no Windows, lifecycle, destructive or real-science run is authorised |
| Evidence state | REVIEWED (not ACCEPTED, not COMMITTED) |

**Date:** 27 October 2026 (Adelaide).
**Holdout statement:** no quarantined row was read, decoded or printed. The real development masters used stop at Powerball 1576 and Oz Lotto 1693. The only real-data computation was the existing forecast-only E_1 1577 view digest (rows 1144-1576), within the current contract. No draw values appear here.

## 1. Verdict

**PASS: 0 BLOCKER, 0 CORRECTION, 3 OPTIONAL.** B1 and C1 are closed. Nothing else changed. I recommend the owner accept v0.11 + r1 as the Package 2 v0.11 code.

## 2. What I verified independently

| Check | Result |
|---|---|
| Handoff bundle, r1 ZIP, parent v0.11 ZIP hashes | match the values above |
| v0.11 `SHA256_MANIFEST.json` (26 overlay files) | 26/26 match |
| r1 `SHA256_MANIFEST_V011R1.json` (7 payload files) | 7/7 match; both "v011_sha256" values equal the parent files |
| Scratch tree | `git archive 618fe48` + v0.11 `repo_overlay/` + the two r1 files; the 21 retired paths are absent at `618fe48` |
| r1 patch route | `evidence/V011_TO_V011R1_EXACT.diff` applied with `patch -p1` to a fresh parent overlay reproduces both r1 files byte for byte; the two routes agree |
| Files changed v0.11 -> r1 | exactly the two declared files (`diff -rq` over the whole tree) |
| Offline suite, my run (command from the r1 README) | v0.11 tree: 56 tests OK, 1 skip; r1 tree: **58 tests OK, 1 skip**. The skip is the inherited baseline-path AST test, covered by kit script 05 below |
| Coordinator | unchanged from v0.11 (`bc8380b5...b822`); the exact v0.6->v0.11 diff applied to committed v0.6 (`2e23d550...`) rebuilds it byte for byte |
| Protected functions (kit script 05) | **11/11 AST-identical** to committed v0.6; changed unprotected functions are the same five as v0.11 (`arguments`, `capture_owned_tree`, `coordinator_main`, `drain`, `read_lines`; added `receive_messages`), all reviewed in v0.11 |
| Switches | `ENABLE_PROCESS_TERMINATION`, `ENABLE_SCIENTIFIC_COORDINATION`, `ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE` all `False` |
| Scientific allowlist | `_COORDINATED_SCIENCE_ALLOWLIST = MappingProxyType({})` |
| Ratified R2 5.5 / TIE v0.2 goldens (kit script 06, committed v0.3 module) | `df21871f...`, `7ce5ab1b...`, `7b43d659...` reproduced |
| Real E_1 forecast-only view golden through the r1 reader | `d47fbbd6...4339` reproduced; the view holds 433 rows ending at 1576 |

Environment: Linux sandbox, Python 3.13.17, NumPy 2.5.3, psutil 7.2.2 (the owner's Windows environment is Python 3.14.8 / NumPy 2.5.4, owner-reported).

## 3. B1 - closed

**Code (read line by line).** In `load_pinned_draw_view` the whole-master SHA-256 is still computed and checked against the pinned ledger and INIT record (orchestration-side integrity, correct). The method-facing object no longer receives it: `order_evidence` is now `{'record': '<GAME>_results_master_init_verification.json', 'status': 'OPERATOR_DRAWN_ORDER_ASSUMED_OWNER_DECISION'}` for the two ordered kinds and `None` for `UNORDERED_SET`. Both values are constants per game. Every `DrawView` slot (`__slots__`, frozen by `__setattr__`) is either a constant, an identity from the manifest (game, method, variant, target, kind), or a byte-owned read-only array built only from rows below N. `e1_view_digest` binds only the record name, as in v0.11, so no digest changes. `master_sha256` appears in the reader only as a run-manifest key; the only other source using that name is the owner tool `results_master_v0_1.py`. The E_1 bridge consumes `DrawView` only.

**Coder's test (read).** `test_t05_complete_drawview_is_suffix_independent_for_every_kind` covers both games at the last development target (1576, 1693), all three view kinds, with and without dates. It changes the target row and the later rows, re-pins master, ledger and INIT record, and compares every slot by an exhaustive `__slots__` walk (array dtype, shape and bytes; mappings; scalars), `e1_view_digest()` and `simple_rows()`. It scans every slot for the master, ledger and INIT-file hashes, and checks `DrawView` source and slots statically. The old order-evidence test now asserts exactly the two fields.

**The test has teeth (mutation check).** Putting `'master_sha256': sha` back into `order_evidence` makes 5 assertions fail in the T-05 and dates tests. A hash-free leak (`len(raw)`, the whole-file size) also fails all 8 ordered-kind T-05 subtests.

**My independent probe (designed from R2 T-05, not from the coder's test).** `t05_real_prefix_probe.py` (attached, `525c1c07...e08c`) uses the **real development masters** at four targets per game (Powerball 1146, 1360, 1575, 1576; Oz Lotto 1476, 1583, 1692, 1693), all three kinds, with and without dates. For each, it rewrites every row with draw number >= N, both as valid-looking rows and as undecodable bytes, re-pins the ledger and INIT record, reloads, and requires every slot, array byte, `simple_rows()` and `e1_view_digest()` to be identical. It also scans every slot recursively for any orchestration hash. **Result: 96/96 comparisons identical, no hash found.** Run against the mutant tree, it stops at once ("order_evidence carries an orchestration hash").

## 4. C1 - closed

`test_ratified_r2_5_5_synthetic_identity_goldens` asserts all three ratified vectors (`df21871f...` training view, `7ce5ab1b...` MAIN label-3 tie, `7b43d659...` canonical forecast) from `tests/p3_e1_synthetic_v0_3.json` at target 1152, using the committed v0.3 module. It also checks that the fixture's stored values equal the literals, and checks TOP and WORST for both channels. The standalone-runner pair (`3851fa46...` / `8a7f917a...`) is kept as a separately labelled test, and the closure note now distinguishes the two sets. Kit script 06 reproduces the ratified three independently.

## 5. OPTIONAL

1. **T-05 coverage in the project suite.** The coder's test covers the last target only, with synthetic stand-ins whose two suffix variants differ in length. Consider adding an intermediate N and an equal-length suffix variant, so a length-dependent leak is also caught at the same size. My probe already covers both with real masters, so this is not needed for acceptance.
2. **Installation artifact.** r1 is a delta against v0.11. For the owner's install commit, use the parent v0.11 `repo_overlay/` (26 files) with the two r1 files replacing their v0.11 versions. I can list the 26 expected file hashes for checking after the commit. Under the agreed position section 7, a `git diff --binary` patch against `618fe48` is the proposed default transport; either route installs the same bytes.
3. **The inherited AST skip.** The baseline-path AST test still skips because the committed v0.6 coordinator is not supplied to it. It could locate v0.6 from Git or a packaged copy. Kit script 05 covers the same check meanwhile.

Carried forward from v0.11, not part of r1 and correctly left unimplemented: O1 (resolved path under `source_data`), O2 (`st_nlink` on NTFS, Windows TO-TEST), O3 (a full review of `multigame_windows_lifecycle_v1.py` before any Windows lifecycle gate).

## 6. Not tested (by me or by the coder)

- Any Windows behaviour: wrappers, venv, NTFS hard links and symlinks (`O_NOFOLLOW` does not exist on Windows, so the symlink refusal there relies on `is_symlink()`; see O1/O2), console and Ctrl+C, P1/P2 and the coordinator under real processes. The v0.11 `WINDOWS_TESTS_NOT_EXECUTED.md` still applies.
- The Windows synthetic-lifecycle module (gated False, never executed).
- Python 3.14 specifically (I ran 3.13.17).
- No real scientific run, scoring, holdout access, network or dependency change.

## 7. Second look

The agreed position (section 2.2) requires the independent review to be by the other model. Here the author is ChatGPT and the reviewer is Claude, so that is met. A further look by the ChatGPT reviewer chat would be same-model as the author and would not add independence. My review includes independent reproduction (R-2) and an independently designed T-05 oracle on real data (R-4). **I do not recommend a second look before acceptance.**

## 8. Next owner decisions

1. Accept v0.11 + r1 as the Package 2 v0.11 code (recommended).
2. Install it: commit the v0.11 overlay with the two r1 replacements (OPTIONAL 2). This is the acceptance commit; I then verify every file hash against Git.
3. Separately and later: whether and when to authorise owner-run Windows non-destructive tests. Nothing here decides that.

*End of document.*
