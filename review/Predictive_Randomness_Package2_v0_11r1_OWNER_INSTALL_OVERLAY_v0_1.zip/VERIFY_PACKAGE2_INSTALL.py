#!/usr/bin/env python3
"""Read-only Package 2 v0.11-r1 owner installation verifier. Does not import project code."""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path
import subprocess
import sys

HERE = Path(__file__).resolve().parent
META = json.loads((HERE / 'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
BASE = META['baseline_commit']


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def git(repo: Path, *args: str, checked: bool=True) -> subprocess.CompletedProcess:
    r = subprocess.run(['git', '-C', str(repo), *args], stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if checked and r.returncode != 0:
        raise RuntimeError(f'git {" ".join(args)} failed (rc={r.returncode}): {r.stderr.decode(errors="replace")[:400]}')
    return r


def check(condition: bool, message: str):
    if not condition:
        raise RuntimeError('FAIL: ' + message)


def main():
    parser = argparse.ArgumentParser(description='Read-only Package 2 v0.11-r1 manifest/source checker')
    parser.add_argument('--repo', type=Path, required=True, help='Existing owner Git repository root')
    parser.add_argument('--phase', required=True, choices=['pre', 'post', 'committed'])
    a = parser.parse_args()
    repo = a.repo.resolve()
    check((repo/'.git').exists(), 'Not a Git checkout: '+str(repo))
    current = git(repo, 'rev-parse','HEAD').stdout.decode().strip()
    check(git(repo, 'merge-base','--is-ancestor',BASE,'HEAD',checked=False).returncode==0,
          f'Current HEAD {current} is NOT descended from reviewed baseline {BASE}; STOP')
    print('Current HEAD:',current, '(reviewed baseline ancestor verified)')
    if a.phase in ('pre','committed'):
        status=git(repo,'status','--porcelain').stdout.decode(errors='replace')
        check(not status.strip(),'Git tree/index NOT clean: '+status[:500])
    entries=META['overlay_files']
    if a.phase=='pre':
        for e in entries:
            p=e['path']; f=repo/p
            check(not f.is_symlink(),f'Unexpected symlink at {p}')
            if p in META['existing_at_base_sha256']:
                check(f.is_file(),f'Expected committed file missing: {p}')
                check(sha(f.read_bytes())==META['existing_at_base_sha256'][p],
                      f'Unexpected existing bytes for {p}; STOP, do not overwrite')
            else:
                check(not f.exists(),f'New overlay path already exists: {p}; STOP')
        for p in META['obsolete_review_candidate_only_paths']:
            check(not (repo/p).exists(),f'Old uninstalled review-candidate path unexpectedly exists: {p}; STOP, do not auto-delete')
        check(not (repo/'src/GAIS/GAIS_results_fetcher_comparer.py').exists(), 'Prohibited GAIS script unexpectedly present; STOP')
        print('PRE-INSTALL PASS: original overwritten file identities, 25 absent additions, retired candidates absent; no files changed.')
        return
    for e in entries:
        p=e['path']; f=repo/p
        check(f.is_file() and not f.is_symlink(),f'Installed file missing/symlink: {p}')
        check(sha(f.read_bytes())==e['sha256'],f'Wrong installed file bytes: {p}')
        if a.phase=='committed':
            blob=git(repo,'show',f'HEAD:{p}').stdout
            check(sha(blob)==e['sha256'],f'Wrong Git HEAD blob bytes: {p}')
    for p in META['obsolete_review_candidate_only_paths']:
        check(not (repo/p).exists(),f'Retired candidate path unexpectedly present: {p}; STOP')
    print(f'{a.phase.upper()} PASS: {len(entries)} exact reviewed/accepted file SHA-256 identities verified.' +
          (' Git HEAD blob identities verified too.' if a.phase=='committed' else ''))
    print('No project code imported, no experiments run, no files modified.')

if __name__=='__main__':
    try: main()
    except Exception as exc:
        print('VERIFICATION STOP:',exc,file=sys.stderr)
        sys.exit(2)
