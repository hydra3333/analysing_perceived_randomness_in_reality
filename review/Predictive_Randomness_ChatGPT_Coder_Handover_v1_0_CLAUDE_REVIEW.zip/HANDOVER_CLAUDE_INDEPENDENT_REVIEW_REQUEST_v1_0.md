# Claude — single full independent review of ChatGPT Coder Handover v1.0

**Status: REVIEW REQUEST ONLY. No source modification, scientific run, data acquisition or process termination is authorised.**

## The task

The owner chose ChatGPT as primary coder and Claude as independent reviewer, unchanged. Bulk Package 2 v0.11 coding moves into a **fresh ChatGPT chat** once the ratified consolidated documentation is installed/pushed and this coder handover is reviewed, corrected if necessary, owner-accepted and committed.

Please read **the entire attached handover** without relying only on its table of contents or this request. Compare bidirectionally with **your updated reviewer handover v9** and the actual Git HEAD. Its stated eight ratified source hashes are from the independently approved installation ZIP; if actual Git HEAD and/or your v9 are not yet available, flag this as an external verification gap, **not evidence that they match**.

## Required review dimensions

1. **Knowledge completeness.** All relevant owner-decided and ratified policy, scientific philosophy, E_1–E_62 permanent registry, original E_1–E_6, source provenance, current data and master identity, prior work and outstanding work. Catch any lost material from prior handover v0.6r1, owner decisions P1–P4, CLAUDE v3 direction, and your own v9.
2. **Authority / precedence.** Ratified 26 Oct documents as one current edition each, not layered 0A/0B; R1/TIE unchanged; old R2 erratum historical; R3-PROPOSED ratified as written, OPEN still OPEN; exact status of code/checkpoints and owner permissions. One sentence must never create a new right to run.
3. **Scientific integrity.** August 1 cutoff PB 1577 / Oz 1694, fixed first-ten holdouts, approved E_1 forecast-only exception without any outcome read, exact synthetic+real hashes and predictions, master ledger+SHA, date-anomaly isolation, assumed operator published order, full-width `int64`/`float64` internal+view arrays, opt-in date digest, no base/suffix leakage, data kind/result allowlist and freeze-before-score.
4. **Process safety.** Full Architecture §5C identity matching and no-status/no-kill, global interlock, marker-path entries and publication failure, clearance only after verifying exits, Popen/psutil captured ancestry, status PID block-only, failed/orphan-group firewall, three False switches, eleven protected coordinator AST functions, human-speed constants and Windows/W-suite authorisation limits.
5. **Implementation continuity.** Actual committed coordinator v0.6, owner/Claude-side master tools and accepted INIT, uninstalled v0.10-r1 review candidate and exact C1–C6 corrections, retirement list, package2 v0.11 work order, baseline verification, source provenance and source SHA. Clear separation of reported vs independently executed evidence.

**Additional focused challenge:** is the purported *latest installed/committed Git HEAD* backed by a concrete reference? The handover intentionally says it is **not yet provided**; please independently verify when the owner supplies it. Is every rule that lacked an A/I/C/D/T/W identifier (for example schema-binding, date anomaly, per-game status) transferred? Does this handover inadvertently authorise an OPEN first Oz method, Mode H, FINAL or source update? Has a reviewer-decided recommendation been mislabelled as owner-ratified?

## Expected output

- Decision **BLOCKER / CORRECTION / OPTIONAL**, with exact handover section and replacement where possible.
- One two-way table: **present only in ChatGPT handover**, **present only in Claude v9**, **potentially conflicting**.
- Explicit `VERIFIED`, `OWNER-REPORTED` or `UNVERIFIED` identity and runtime claims.
- One reviewer acceptance conclusion **only after** the latest Git baseline and applicable source evidence are confirmed. This is a handover review, not a scientific-code acceptance or Windows-run gate.
- Any requested revision should preserve the complete handover and be submitted to the owner for final acceptance. There is **one planned comprehensive Claude handover review**, with any corrections verified; do not silently restart design or code.

## Exact source documents to compare

See the candidate handover §2 and `SOURCE_BASIS_AND_VERIFICATION.json` in this archive. The ratified installation ZIP SHA is `178208c6fef7fcb5685cc1572d64f809dae34a6936d6f61ab721ab17623ec2d3`; Claude previously passed its final r1 mechanical recheck. The current source is the **installed Git tree once independently confirmed**, not a copied candidate archive.

**Nothing here authorises coding in this old chat or executing tests with real data.**
