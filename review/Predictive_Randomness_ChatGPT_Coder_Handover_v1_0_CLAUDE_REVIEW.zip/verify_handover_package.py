#!/usr/bin/env python3
"""Offline package-internal check. Does NOT verify current Git or run experiments."""
from pathlib import Path
import hashlib, json, sys

def check():
    here = Path(__file__).resolve().parent
    m = json.loads((here / 'SOURCE_BASIS_AND_VERIFICATION.json').read_text(encoding='utf-8'))
    expected = {
        'Predictive_Randomness_ChatGPT_Coder_Handover_v1_0_CLAUDE_REVIEW_CANDIDATE.md': m['handover_sha256'],
        'HANDOVER_CLAUDE_INDEPENDENT_REVIEW_REQUEST_v1_0.md': m['review_request_sha256'],
    }
    for n, v in expected.items():
        p=here/n
        if hashlib.sha256(p.read_bytes()).hexdigest()!=v:
            raise AssertionError('mismatched handover file: '+n)
    s=(here/'Predictive_Randomness_ChatGPT_Coder_Handover_v1_0_CLAUDE_REVIEW_CANDIDATE.md').read_text(encoding='utf-8')
    for n,v in m['source_document_hashes_from_ratified_install_zip'].items():
        if n not in s or v not in s:
            raise AssertionError('Missing accepted-doc identity in handover: '+n)
    for text in ('OWNER TO SUPPLY','UNRESOLVED_ORPHAN.json','ENABLE_PROCESS_TERMINATION = False',
                 'ENABLE_SCIENTIFIC_COORDINATION = False','ENABLE_SYNTHETIC_WINDOWS_LIFECYCLE = False',
                 'PAIRED_DIAGNOSTIC','OPERATOR_DRAWN_ORDER_ASSUMED_OWNER_DECISION',
                 'df21871f8067e5405b4fdb1eec50c65dddbaa35958872bad3230d3c10a791fd4',
                 'd47fbbd6e60e6abc429fb74f47d8bbeafc6560152c2ecddb3b75d79932df4339',
                 '7f1130872b3afaa222ff4e8c2396cd2c2872583544dfa6b31cc5a07cd067164e'):
        if text not in s: raise AssertionError('Missing keyword: '+text)
    print('PASS: handover and reviewer request hashes, 8 ratified identities, critical invariant mentions')
    print('NOT VERIFIED: latest Git HEAD, owner Windows files or runtime marker, Claude v9, scientific semantics')
if __name__ == '__main__':
    try: check()
    except Exception as e: print('FAIL:',e, file=sys.stderr); sys.exit(1)
