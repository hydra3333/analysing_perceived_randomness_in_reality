# Claude focused review request — Coder Handover v1.0r1

**Status:** REVIEW CANDIDATE, NOT YET OWNER-ACCEPTED OR COMMITTED. This is **one focused spot-check**, not a repeat full review. Full review of v1.0 returned **ACCEPT AFTER CORRECTIONS, no BLOCKER** (Claude, 26 October 2026).

**Baseline:** Claude independently verified clean `main` at `2db25547bd3479abcfa05638fafcfbf09492d4f0`, including all eight ratified governing docs, R1/TIE, owner tools, master/ledger identities, coordinator v0.6, candidate ZIP, and E_1 goldens.

**Owner's new decision received during this revision:** The owner has **deleted** `src/GAIS/GAIS_results_fetcher_comparer.py` from the working tree. It will disappear from the tracked current tree at the **upcoming handover snapshot commit**. This is no longer an OPEN disposition. At HEAD `2db2554` the script still existed; until the next Git commit is inspected, the deletion is **owner-reported local action, not independently verified repository state**. Do not run/import/adapt/use that unreviewed Selenium script; `oz.lotterywest.com` must not be contacted, and The Lott must not be automated.

## Inspect corrections C1–C8

| ID | Check |
|---|---|
| C1 | All obsolete 'not yet installed/no post-install HEAD' claims corrected; exact HEAD and distinct later snapshot-commit gate in header, §§1–2, §7, §11 and Appendix D. |
| C2 | Explicit unreviewed GAIS provenance and prohibition; owner-decided deletion, with future commit verification, not an unresolved owner question; domain restrictions maintained. |
| C3 | Owner-decided 24 Oct timing authority, capture throttle equals poll interval; name the 0.12/0.05 literals, list any intentionally retained; 3-second protected termination waits untouched. |
| C4 | Prediction-time TIE_SHA256_V1 versus post-draw mid-rank; WORST inverse rule; R2 benchmark, R3 evaluation and per-game registry status vocabularies separately listed. |
| C5 | Other lottery eras DECIDED excluded by Proposal §3.1; O2 fixtures are owner-supplied **current-era, pre-boundary** Lotterywest excerpts. |
| C6 | Claude handovers v2–v8 historical, v9 next current. |
| C7 | Verified E_1 modules/tests, orphan safety utilities, historic checker versions, no committed Run_Scraper.bat, master headers and source_data .gitattributes; safe owner-tool provenance. |
| C8 | O1 closed by retirement of old results builder (reapply if surviving old-file comparator); O3 requirements.txt historical, authoritative installer default unchanged. |

## Additional useful optional items incorporated

Eleven protected AST function names; T-05 future-perturbation invariant; `game_id` regex and legacy compatibility; frozen profile Python module; owner-reported dependency version baseline; exposure record item 5; both historical R2 errata filenames; create-only Windows `os.rename` for frozen results (not master atomic update); E_2–E_6 sequencing clearly **planning only**.

## Independent acceptance questions

1. Are there any inaccurate/contradictory remaining mentions of a missing Git HEAD, v9 already committed, GAIS still an active project source, or stale v1.0 status?
2. Did any change inadvertently weaken the current R2/R3 scientific rules, §5C coordinator safety, or no-run authorisation?
3. Is owner-directed GAIS deletion represented precisely as a pending Git change, to be confirmed with the accepted handover/v9 snapshot commit?
4. Is there any substantive discrepancy in the diff not traceable to C1–C8, useful optional clarifications, or the owner's GAIS decision?

Classify any findings **BLOCKER / CORRECTION / OPTIONAL**. If clean, declare this v1.0r1 handover ready for **owner acceptance**; Claude then prepares reviewer handover v9; owner makes one snapshot commit with both handovers and deletion of GAIS `.py`; Claude verifies snapshot SHA/hashes. **Do not claim the new commit exists before it is verified.** No Package 2 coding, data acquisition, scientific run, Windows lifecycle test, holdout access, Mode H, FINAL, termination enablement or master update is authorised by the handover.
