#!/usr/bin/env python3
"""Offline manifest and minimal transfer-contract verifier; does not run project code."""
import hashlib,json, pathlib, sys
here=pathlib.Path(__file__).resolve().parent
manifest=json.loads((here/'SHA256_MANIFEST.json').read_text(encoding='utf-8'))
for filename, want in manifest['files'].items():
    candidate=here/filename
    if not candidate.is_file(): raise SystemExit(f'MISSING: {filename}')
    have=hashlib.sha256(candidate.read_bytes()).hexdigest()
    if have != want: raise SystemExit(f'HASH FAIL: {filename} {have}')
hand=here/manifest['handover_filename']
s=hand.read_text(encoding='utf-8')
for marker in manifest['markers']:
    if marker not in s: raise SystemExit(f'HANDOVER CONTRACT MARKER MISSING: {marker}')
for bad in manifest['must_not_contain']:
    if bad in s: raise SystemExit(f'STALE TEXT FOUND: {bad}')
print(f'PASS: {len(manifest["files"])} file hashes, {len(manifest["markers"])} contract markers, {len(manifest["must_not_contain"])} stale-text prohibitions')
