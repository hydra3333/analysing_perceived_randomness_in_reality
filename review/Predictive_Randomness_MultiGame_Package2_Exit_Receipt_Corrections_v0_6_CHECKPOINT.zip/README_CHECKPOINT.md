# Multi-Game Package 2 — Exit Receipt v0.6 Correction Checkpoint

**STATUS: INCREMENTAL ENGINEERING CHECKPOINT, NOT INSTALLED, NOT REVIEWED, NOT APPROVED FOR SCIENTIFIC COORDINATION.**

This checkpoint addresses Claude's light-review C1, C2 and optional cleanup for v0.5. It *supersedes the v0.5 candidate versions* of the coordinator, receipt module and exit-receipt tests. It DOES NOT supersede the v0.1/v0.3/v0.4 checkpoint contributions. For the final independent review, produce ONE consolidated overlay against a verified current repository HEAD, not a chain of patches.

## Critical C1: one-read binding

The coordinator-only receipt issuer reads `canonical_result.json` **once**, obtains its bytes, calls `verify_success_records()` for BEGIN, RESULT, DIGEST, FINISH against those exact bytes, and computes the bound SHA-256 from the same byte buffer. There is no caller-provided `console_result_digest_match=True` shortcut. Synthetic tests mutate the result and worker hashes after console publication; issuance fails with no receipt. Another test instruments `Path.read_bytes` and confirms one read by the issuer.

## Critical C2: actual observation timestamp

Worker now captures `exit_observed_utc` immediately when the supervising coordinator sees `Popen.poll()` report exit. A prospective receipt uses that stored timestamp; it does not substitute `ISO()` at later issuance. The timestamp is the coordinator's first exit **observation**, not the OS-reported true exit instant.

## Optional cleanups

The receipt issuer/consumer moved into `src/coordinator_private/multigame_coordinator_exit_receipt_v2.py`, with `__init__.py`. The retired v0.5-only candidate module `src/methods/_common/multigame_coordinator_exit_receipt_v1.py` is NOT part of this or the eventual overlay. `final['workers'] = reports` no-op removed. Receipt schema is `MULTIGAME_COORDINATOR_EXIT_RECEIPT_V2_REVIEW`, superseding the never-issued v1 review schema.

## Safety / baselines

Exact original POC coordinator v0.6 SHA-256 `2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b`, byte-extracted from the user's source ZIP. Exact diff against v0.6 included. `terminate_owned_tree`, `check_exited_worker_for_orphan`, `record_unresolved_orphan`, `capture_owned_tree`, `register_root`, `status_and_result` function bodies compared **identical**. `ENABLE_PROCESS_TERMINATION = False` and `ENABLE_SCIENTIFIC_COORDINATION = False` are unchanged. The scientific receipt branch is unreachable via the current POC launcher: no E-method worker or receipt is launched/issued by this code. Never flip switches or run a destructive test without independently reviewed owner authorisation.

## Offline verification

- 66/66 multi-game tests PASS, including 16 synthetic receipt tests, strict console and scorer tests and the frozen Powerball draw-1577 regression.
- 13/13 legacy E_1 tests PASS.
- Linux/Python offline environment; NO live scraping, no Popen lifecycle exercises, no process termination, no Oz holdout reads, no scientific scoring.

## Scope of remaining Package 2 work

1. Game-qualified E-method launcher, run-folder/run-ID handshake and per-game target gate — **Package 2 code deliverable, NOT implemented here**; it must preserve v0.6 ownership safety and require independent review.
2. Coordinated worker `manifest.json` schema and trusted producer — **Package 2 code deliverable, NOT implemented here**; do not treat the existing standalone synthetic manifest as satisfying it.
3. Actual Windows Popen lifecycle/orphan/console/receipt/collision synthetic integration — **Package 2 Windows acceptance gate**, to be performed on owner's Windows system after code review, BEFORE coordinated method execution is enabled. Linux source/unit tests are insufficient.
4. Live Oz Lotto scraping and holdout selection — **Package 3 separate owner-controlled authorisation**. Scraper launcher remains disabled.
5. Prospective FINAL/real scoring and any change to process termination — **separately gated later work**, not authorised here.

Do not install this checkpoint as a release or treat it as an approved coordinator. It is review material only. The complete Package 2 code review must include a **single consolidated overlay, one hash manifest, full test transcript, and final diff vs the v0.6 baseline**.
