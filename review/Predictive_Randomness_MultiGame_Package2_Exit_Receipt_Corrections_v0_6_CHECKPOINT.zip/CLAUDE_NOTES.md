# Claude's v0.5 findings — disposition in v0.6 correction checkpoint

- C1: RESOLVED IN CANDIDATE. The same canonical-result read is used for the strict console verification and hashed receipt binding. Includes mutation and one-read tests.
- C2: RESOLVED IN CANDIDATE. Exit observation UTC captured when supervising Popen first seen exited; passed unchanged to dormant issuer.
- OPT: COMPLETE. Relocated to coordinator-private namespace; removed no-op workers assignment.
- Independently reviewed? **NO**. Await complete Package 2 consolidated review, and Windows gates. No switches enabled.

Potential further design issue to assess in consolidated review: after a consumer passes all gates, the caller must obtain the result only from the successful verifier return value; it must not re-open an unvalidated path as a separate read. The receipt is a defense against accidental self-certification and late writes, not against a malicious local user.
