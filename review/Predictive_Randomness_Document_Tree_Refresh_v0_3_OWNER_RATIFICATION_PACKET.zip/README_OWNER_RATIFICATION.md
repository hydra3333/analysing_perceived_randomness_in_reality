# Documentation Refresh v0.3 — Owner Ratification Packet (NOT YET RATIFIED)

Claude independently spot-checked documentation refresh v0.3 against its own v0.2 copy. Its finding: **PASS, no blockers or corrections**, with three explicitly optional housekeeping suggestions.

This packet preserves the eight reviewed candidate document bodies, subject **only** to the following optional changes:

1. Ratification Register: describe the numerical document as a **Technical Reference (non-normative)**.
2. Ratification Register: record ChatGPT continuation handovers v0.6 and v0.6r1 as historical, with repository path/hash to be checked at installation.
3. Proposal v0.5: shorten redundant opening wording of its observation-period line; the accepted master-version evidence and Git reference later in the same line are retained verbatim.

The optional changes appear in `review_diffs/`. All other candidate document bytes are identical to the independently spot-checked v0.3 documents. **The documents are not ratified by creation of this packet.**

## Ratification request, in order

1. Proposal v0.5.
2. R2 Erratum Record v0.4 (ERR-R2-06) and R3 v0.4.
3. Architecture v0.7 and Multi-Game P3 Task Specification v0.2.
4. Holdout Exposure Record v0.1 and Numerical Integrity and Retraining Technical Reference v0.1 (non-normative).
5. Ratification Register v0.3.

## After the owner's explicit approval

ChatGPT will generate the **final ratified installation ZIP**, removing candidate suffixes and updating current authority/status/register entries and actual final file hashes. Claude will then perform the agreed mechanical comparison with the v0.3 candidates (allowing only ratification/status metadata, register hashes and the optional edits documented here). Only after its check should the owner install, commit and push. Then obtain the actual Git HEAD, and produce the definitive self-contained coder handover for a single Claude independent review. Only then start a fresh ChatGPT coding conversation.

**Not authorised:** code execution, reader scientific use, source update, holdout access, Mode H, FINAL, synthetic Windows lifecycle, process termination or changing safety switches. Package 2 v0.11 remains a separate code task.
