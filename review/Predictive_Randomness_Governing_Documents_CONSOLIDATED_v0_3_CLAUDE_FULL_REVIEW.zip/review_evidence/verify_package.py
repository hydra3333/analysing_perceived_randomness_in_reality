#!/usr/bin/env python3
"""Independent offline verification, no network or execution of experimental code."""
from pathlib import Path
import hashlib,json,re,sys
ROOT=Path(__file__).resolve().parent.parent
E=ROOT/'review_evidence';D=ROOT/'review_overlay'/'doc'
for x in json.loads((E/'SHA256_MANIFEST.json').read_text())['files']:
 f=ROOT/x['path']; assert f.is_file(),x['path']
 assert hashlib.sha256(f.read_bytes()).hexdigest()==x['sha256'],x['path']
blocks=json.loads((E/'VERBATIM_BLOCK_SHA256.json').read_text())
for b in blocks:
 data=(E/'verbatim_source'/b['block']).read_bytes()
 assert hashlib.sha256(data).hexdigest()==b['source_sha256'],b['block']
 assert data in (D/b['candidate']).read_bytes(),b['block']
for inv in json.loads((E/'REQUIRED_ID_INVENTORY.json').read_text()):
 assert not inv['missing'] and not inv['unexpected'],inv
scan=json.loads((E/'STALE_PHRASE_SCAN.json').read_text())
print('PASS: manifest, 7 protected blocks, required ID inventory')
print('Human semantic/stale review remains required; scanner flagged',len(scan['unexplained']),'lines')
if scan['unexplained']:sys.exit(2)
