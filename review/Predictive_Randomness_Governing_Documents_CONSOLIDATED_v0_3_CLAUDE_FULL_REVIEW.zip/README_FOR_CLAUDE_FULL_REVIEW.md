# Consolidated governing documents v0.3 — full independent Claude review ONLY

**Status:** NOT RATIFIED. **No code execution or scientific/Windows run is authorised.**

## Why v0.3 is different

Claude's v0.2 full review (25 October 2026) identified three BLOCKERS caused by excessive condensation. This edition uses the **full original ratified Proposal, R2 and Architecture documents**, retains their numbered requirement and test catalogues, and edits currently stale items in place. The documents are intentionally longer and more conservative. R3 was already accepted as materially sound; P3 is retained and its seven `M-INV` invariants restored.

## Source and evidence

- Original ratified files are in the owner's repository. Our reference is the local Package 1 ratified source ZIP; Claude should compare independently with HEAD `ce462be` or newer, verifying source hash identity.
- `review_overlay/doc/`: eight candidate Markdown documents, no installation files.
- `review_evidence/REQUIRED_ID_INVENTORY.json`: strict original versus new ID sets.
- `review_evidence/REQUIREMENT_DISPOSITION_MATRIX.csv`: source requirement IDs AND old section headings with actual source and destination line numbers, content snippets and dispositions. The section-heading rows with `HISTORICAL_OR_SUPERSEDED__CLAUDE_REVIEW_REQUIRED` explicitly require Claude's semantic confirmation.
- `review_evidence/VERBATIM_BLOCK_SHA256.json` and seven `verbatim_source/*.bin`: frozen scientific/maths/safety sections; `verify_package.py` checks bytes.
- `review_evidence/*.unified.diff`: ratified predecessor vs v0.3 and v0.2 candidate vs v0.3. **Some historical lines revealing quarantined draw values are deliberately redacted in the old-to-new diff**, with their hashes recorded. These diff hunks are for review, not byte-exact patch application; use the original source from Git for a full comparison under existing holdout exposure controls.
- `review_evidence/STALE_PHRASE_SCAN.json`: candidate phrase hits, with explicit dispositions; do not substitute the scan for full reading.
- `review_evidence/SHA256_MANIFEST.json`: package content hashes; `verify_package.py` verifies package contents offline.

## Claude review priorities

1. Full-read each governing doc; audit all 37 Proposal A decisions and D1–D5, all 17 R2 I, 24 R2-C (including C07A/C11A), 28 R2-D, 39 R2 T, 25 W, 26 architecture A, 34 architecture O, and 7 P3 M-INV. **A matching ID is necessary but insufficient**; check substantive content.
2. Confirm the approved errata ERR-R2-01..06 by source decision, and every normative/OPEN distinction. ERR-R2-02 remains PROVISIONAL.
3. Test the seven byte-identical source blocks, and all surrounding semantic dependencies including protected Architecture §5C and 5B/14 references.
4. Check no operative old 444-draw master, stale date/snapshot, 12-worker test, old Oz holdout seal, source scraper/API, or earlier `requirements.txt` authority.
5. Check results-master version/ledger identities, N−1 first-field rule, no readout of quarantined values, revised B1/B10, E_1 synthetic/real/TOP/WORST goldens, int64/float64, upgrade stop, fresh training, test/firewall/Windows acceptance gates, process identity/interlock/kill limits.
6. Classify results BLOCKER/CORRECTION/OPTIONAL with exact candidate section/line, and critically review any matrix entry marked REVIEW_REQUIRED or stale-scan line not clean.

## Package state

Docs remain **NOT RATIFIED**; no installation/commit or Git push is implied. After successful full Claude review and owner ratification, build a separately labelled installation ZIP, verify it before owner commit/push, and only then prepare the comprehensive new-ChatGPT coder handover for Claude's *separate* independent review. Package 2 v0.11 code remains PAUSED.
