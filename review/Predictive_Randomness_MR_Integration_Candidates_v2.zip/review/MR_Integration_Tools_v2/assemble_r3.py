"""Assemble R3 v0.5 = R3 v0.4 (ratified, unchanged except listed edits) + section 17.
Every replacement must match exactly once. New text is plain ASCII.
Usage: python -I assemble_r3.py R3_v0_4.md s17_x.md out.md"""
import sys

r3 = open(sys.argv[1], encoding="utf-8").read()
s17 = open(sys.argv[2], encoding="utf-8").read()

def rep(text, old, new, label):
    c = text.count(old)
    if c != 1:
        sys.exit(f"{label}: expected 1 match, found {c}: {old[:80]!r}")
    return text.replace(old, new)

# ---------------- section 17: intro, pointers, stage 0, search log, stub 17.15
INTRO = """## 17. Method ranking measures (league tables) [MR-RATIFIED]

This section carries the owner-ratified **Method Ranking Measures Proposal v0.5** (`doc/Predictive_Randomness_Method_Ranking_Measures_Proposal_v0_5.md`, SHA-256 `c6ca2cb2174ee2963a6fe33347820c80b92e6dd1eda518a1f0c8e3254d67ab19`, ratified 26 October 2026 at commit `ac01678`). It is the governing text on its subject. The proposal file is kept unchanged as history.

- **Numbering:** 17.x here is section x of the proposal (for example 17.5A is proposal 5A, 17.3.7A is proposal 3.7A). Parts with a home elsewhere leave a short pointer:
  - proposal 3.2 (numbering conventions) -> R2 section 3.6;
  - proposal 7.1-7.4 (in-sample mode, procedure, capability, firewall) -> R2 section 8.4; proposal 7.5 stays here as 17.7.5;
  - proposal 8 (supplementary-number rule) -> R2 section 2.5;
  - proposal 12 (execution model) -> Architecture sections 5A.4 and 12.5; the evaluator rules stay here in 17.12;
  - proposal 13 stage-1 contract fields and the acceptance list before E_2 -> R2 section 5.6.
- Proposal section 15 (the integration plan) is carried out by this edition set and is not repeated. Proposal 17.2-17.4 (traceability to the review rounds) stay only in the proposal file.
- **Authority:** this section grants no run, coding, data-access or holdout authority. It changes nothing in Package 2 v0.11, and P3 v0.2 is unchanged.
- **Status:** provisions in this section are owner-ratified as written. Items marked OPEN or DEFERRED in 17.16 remain undecided.
- **Holdout discipline:** this section contains no winning, Powerball or supplementary number of any draw. All figures are fair-draw reference calculations.

**ID prefixes:**

| Prefix | Meaning |
|---|---|
| `MR` | measures |
| `MRD` | owner decisions |
| `RK` | ranking-use rules |
| `PO` | pattern-origin categories |
| `MRT` | tests |
| `MRO` | open items |
| `PD1..PD9` | Powerball prize divisions |
| `OD1..OD7` | Oz Lotto prize divisions |
| `N1` | fair-draw null simulator |

None collides with existing IDs: A-, D-, I-, R2-C, R2-D, T-, W-, O-, M-INV-, ERR-.

"""
s17 = INTRO + s17

s17 = rep(s17, "@@POINTER-3.2@@",
    "The numbering conventions (proposal 3.2; MRD-11) are project-wide and live in R2 section 3.6. They apply unchanged to everything in this section.", "p3.2")
s17 = rep(s17, "@@POINTER-7@@",
    "The in-sample diagnostic mode (proposal 7.1-7.4: purpose, procedure, capability, firewall and labelling) is an execution contract and lives in R2 section 8.4 (8.4.1-8.4.4). Its side-by-side display (proposal 7.5) is a reporting rule and stays here as 17.7.5.", "p7")
s17 = rep(s17, "@@POINTER-8@@",
    "The evaluator-only supplementary-number rule (proposal section 8; MRD-03) lives in R2 section 2.5. Oz Lotto division classification (17.4.1, 17.4.3) reads a target draw's supplementaries only under that rule.", "p8")
s17 = rep(s17, "@@POINTER-12@@",
    "The report tool, the in-sample run mode, N1 as an evaluator component (Architecture section 12.5) and the wrapper `Run_Method_Rankings.bat` (Architecture section 5A.4) carry proposal section 12. The evaluator rules stay here:", "p12")
s17 = rep(s17, "- Dependency rules are unchanged: no upgrade between freeze and score, or within Mode H.\n### 17.13",
    "- Dependency rules are unchanged: no upgrade between freeze and score, or within Mode H.\n\n### 17.13", "blank13")
s17 = rep(s17, "ratified by the owner first (fields 1-7 below). |",
    "ratified by the owner first (fields 1-7, R2 section 5.6). |", "stage1")
s17 = rep(s17, "@@POINTER-13@@",
    "The stage-1 contract fields (proposal section 13, fields 1-7) and the acceptance conditions before E_2 live in R2 section 5.6. Architecture section 20A points to them.", "p13")
s17 = rep(s17,
    "| 0 | Now | Focused check of this proposal (v0.4 reviewed by ChatGPT; v0.5 applies its findings); owner ratification; integration into the governing documents (section 15). No code. Package 2 v0.11 proceeds unchanged in parallel. |",
    "| 0 | Completed | The proposal was reviewed (v0.4 by ChatGPT; v0.5 applied its findings) and ratified by the owner on 26 October 2026; integration into the governing documents is in progress (R3 v0.5, R2 v0.5, Architecture v0.8, Proposal v0.6, register v0.4). No code. Package 2 v0.11 proceeds unchanged in parallel. |",
    "stage0")
s17 = rep(s17,
    "- **Search log:** `results/method_rankings/SEARCH_LOG.csv`, programme-wide, append-only and committed. One row per report run:",
    "- **Search log:** the single programme-wide search record defined in R3 section 7.4 (`results/audit/SEARCH_LOG.csv`), append-only and committed. Each report run appends exactly one row with `row_type` = `RANKING_REPORT`:",
    "searchlog")
s17 = rep(s17, "- `.csv`: one row per (track, sub-measure);",
    "- `.csv`: one row per (analysis_unit, unit_id, sub-measure), keyed as in 17.3.4A;", "O-02")
s17 = rep(s17, "### 17.16 Open items",
    "### 17.15 Integration into the governing documents\n\nNot carried. Proposal section 15 is carried out by this edition set (see the pointers at the start of section 17); the proposal file keeps it as history.\n\n### 17.16 Open items", "stub15")
s17 = rep(s17, "### 17.18 Claude's analysis, implications and design matters",
    "### 17.18 Claude's analysis, implications and design matters (informative)\n\nInformative notes carried from the proposal. They explain the measures and give fair-draw context; the rules are in 17.0-17.16.", "s18")
s17 = s17.rstrip("\n") + "\n"

# ---------------- edits to the ratified R3 v0.4 text
r3 = rep(r3, "**Version:** 0.4 CONSOLIDATED, OWNER-RATIFIED 26 October 2026  \n",
    "**Version:** 0.5 RATIFICATION CANDIDATE (26 October 2026): R3 v0.4 plus section 17, which carries the owner-ratified Method Ranking Measures Proposal v0.5. Predecessor: R3 v0.4 CONSOLIDATED, OWNER-RATIFIED 26 October 2026.  \n", "hdr-version")
r3 = rep(r3, "**Date:** 26 October 2026 (consolidated v0.4 ratification; v0.3 ratified 24 October)  \n",
    "**Date:** 26 October 2026 (v0.5 candidate; v0.4 ratified 26 October; v0.3 ratified 24 October)  \n", "hdr-date")
r3 = rep(r3, "**Status:** OWNER-RATIFIED; ratification itself grants no Mode H/FINAL authority.\n",
    "**Status:** RATIFICATION CANDIDATE, awaiting owner ratification. Until then R3 v0.4 governs, except that the owner-ratified Method Ranking Measures Proposal v0.5 already governs its own subject. Ratification itself grants no Mode H/FINAL authority.\n", "hdr-status")
r3 = rep(r3, "`doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_4.md`  \n",
    "`doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md`  \n", "hdr-path")
r3 = rep(r3, "This paragraph is not an independent new policy.\n",
    "This paragraph is not an independent new policy.\n\nEdition 0.5 adds section 17, which carries the owner-ratified Method Ranking Measures Proposal v0.5 (26 October 2026), and the pointer edits it needs (0.1, 0.2, 5.6, 7.4, 11.5, 11.7, 12.6, 13 and R3-D21). Sections 0-16 otherwise keep the ratified v0.4 text.\n", "edition")
r3 = rep(r3, "| **This R3 v0.4** | Current scoring, freeze/evidence contract | OWNER-RATIFIED 26 Oct 2026; no Mode H/FINAL authority |\n",
    "| **This R3 v0.5** | Current scoring, freeze/evidence contract; method ranking measures (section 17) | RATIFICATION CANDIDATE; v0.4 OWNER-RATIFIED 26 Oct 2026; no Mode H/FINAL authority |\n"
    "| Method Ranking Measures Proposal v0.5 | Method ranking measures (league tables) | OWNER-RATIFIED 26 Oct 2026; carried in section 17 and in R2 / Architecture / Proposal as pointed to there; the file is kept unchanged as history |\n", "0.1-row")
r3 = rep(r3, "Later approved owner decisions supersede earlier conflicting text. With the owner\u2019s ratification of this edition (26 October 2026), provisions labelled [R3-PROPOSED] are ratified as written; items labelled OPEN, and decision-register entries still marked OPEN, remain undecided.",
    "Later approved owner decisions supersede earlier conflicting text. With the owner's ratification of R3 v0.4 (26 October 2026), provisions labelled [R3-PROPOSED] were ratified as written, and they remain ratified in this edition; items labelled OPEN, and decision-register entries still marked OPEN, remain undecided. Section 17 carries the owner-ratified Method Ranking Measures Proposal v0.5 (26 October 2026) as written.", "0.1-ratwording")
r3 = rep(r3, "- **[OPTIONAL]**: Candidate advanced analysis; should not block initial core reporting.\n",
    "- **[OPTIONAL]**: Candidate advanced analysis; should not block initial core reporting.\n- **[MR-RATIFIED]**: Owner-ratified on 26 October 2026 in the Method Ranking Measures Proposal v0.5 and carried in section 17 as written.\n", "0.2-tag")
r3 = rep(r3, "Detailed numerical presentation and precision policy can be finalised during implementation design or in a controlled R3 revision before live launch.\n",
    "Detailed numerical presentation and precision policy can be finalised during implementation design or in a controlled R3 revision before live launch.\n\nSeparately, the ranking measures MR6 and MR14 (17.6) use only typed probability outputs declared under R2 section 5.6. They are reporting measures and do not settle this optional-score decision, which remains OPEN.\n", "5.6")
r3 = rep(r3, "This is **not** a prescription to eliminate statistically weak, unusual or correlated methods.\n",
    "This is **not** a prescription to eliminate statistically weak, unusual or correlated methods.\n\n"
    "**One search record (single definition).** The search record named above (`search_history` / `method_selection_log`), the `SearchAndSelectionLedger` of 11.5 item 7 and the method-ranking search log of 17.5B are one mechanism, not several: a single programme-wide, append-only, committed file, `results/audit/SEARCH_LOG.csv`, with a typed `row_type` column. Every row carries its UTC time, game and row type, and rows are never edited or deleted. Each method-ranking report run appends exactly one row with `row_type` = `RANKING_REPORT`, holding the fields listed in 17.5B. Trial configurations, candidate combinations, selections and adaptation-policy changes append rows of their own types, defined when the tools that write them are specified. There is no second search log.\n", "7.4")
r3 = rep(r3, "7. `SearchAndSelectionLedger`: prospective hypothesis/track selections, all tested variants and ensembles, prior-score-based adaptation policy and changes over time.\n",
    "7. `SearchAndSelectionLedger`: prospective hypothesis/track selections, all tested variants and ensembles, prior-score-based adaptation policy and changes over time. This is the single search record of 7.4 (`results/audit/SEARCH_LOG.csv`), which also holds the method-ranking report rows of 17.5B.\n", "11.5")
r3 = rep(r3, "    benchmarks/                  # Timing/resource only; no merit scores\n    audit/                       # Search register, manifests, publication references\n",
    "    benchmarks/                  # Timing/resource only; no merit scores\n    method_rankings/             # Per-game ranking reports, create-only (17.10.1)\n    audit/                       # Search register (SEARCH_LOG.csv, 7.4), manifests, publication references\n", "11.7")
r3 = rep(r3, "- `mode`: `HISTORICAL_EVALUATION`, `FINAL_NEXT_DRAW`, `SYNTHETIC_NULL`, `SYNTHETIC_PLANTED`, `BENCHMARK`.\n",
    "- `mode`: `HISTORICAL_EVALUATION`, `FINAL_NEXT_DRAW`, `SYNTHETIC_NULL`, `SYNTHETIC_PLANTED`, `BENCHMARK`, and `IN_SAMPLE_DIAGNOSTIC` (R2 section 8.4; a labelled diagnostic, never a scientific result).\n", "12.6")
r3 = rep(r3, "Test identifiers are deliberately `R3-Txx`, distinct from R2 `T-xx`.\n",
    "Test identifiers are deliberately `R3-Txx`, distinct from R2 `T-xx`. The method-ranking tests MRT-01..MRT-25 are in 17.14; that prefix is distinct from both.\n", "13")
r3 = rep(r3, "| R3-D21 | Algorithmic ranking of a single project \u201cbest\u201d method | **OPEN**; do not create automatic champion until metrics and selection procedure are predeclared |\n",
    "| R3-D21 | Algorithmic ranking of a single project \u201cbest\u201d method | **PARTLY DECIDED** (MRD-01, MRD-05, RK-1..RK-6, R3 17): per-measure league tables, as reports only. A single combined best-method score or automatic champion remains **OPEN**. |\n", "R3-D21")
r3 = rep(r3, "\n\n## Appendix S \u2014 Superseded evaluation examples (historical only)\n",
    "\n\n---\n\n" + s17 + "\n## Appendix S \u2014 Superseded evaluation examples (historical only)\n", "insert17")

open(sys.argv[3], "w", encoding="utf-8", newline="\n").write(r3)
print("ok", len(r3.split("\n")), "lines")
