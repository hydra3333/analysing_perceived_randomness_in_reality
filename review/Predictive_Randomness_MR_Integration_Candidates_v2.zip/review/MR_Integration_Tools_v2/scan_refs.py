"""Scan every inserted or moved line of each candidate for references and directional pointers.
Each hit is classified:
  OK-QUALIFIED  explicit document + section that resolves (R2/R3/Architecture/Proposal section x)
  OK-17         R3 17.x reference that resolves to an R3 heading or numbered label
  OK-LOCAL      bare "section x" / "(x)" that resolves inside the same document AND is
                listed in LOCAL_OK as intended (same-document reference)
  REVIEW        anything else: bare/proposal-relative numbers, unresolved targets, and every
                directional word (below/above/following/earlier/later/this proposal ...)
Usage: python -I scan_refs.py BASE_DIR DRAFT_DIR [--all]"""
import re, sys, os, difflib
B, D = sys.argv[1], sys.argv[2]
PAIRS = {"R3": ("Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_4.md", "Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md"),
         "R2": ("Predictive_Randomness_Experimental_Method_Specifications_R2_v0_4.md", "Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md"),
         "Architecture": ("Predictive_Randomness_Software_Architecture_Discussion_v0_7.md", "Predictive_Randomness_Software_Architecture_Discussion_v0_8.md"),
         "Proposal": ("Predictive_Randomness_Research_Project_Proposal_v0_5.md", "Predictive_Randomness_Research_Project_Proposal_v0_6.md"),
         "Register": ("RATIFICATION_REGISTER_v0_3.md", "RATIFICATION_REGISTER_v0_4.md")}
T = {k: open(os.path.join(D, v[1]), encoding="utf-8").read() for k, v in PAIRS.items()}
def anchors(t):
    a = set()
    for l in t.split("\n"):
        m = re.match(r"^#{2,4} (?:\S+ )?(\d+[A-Z]?(?:\.\d+[A-Z]?)*)\.? ", l) or re.match(r"^#{2,4} (\d+[A-Z]?(?:\.\d+[A-Z]?)*)\.? ", l) \
            or re.match(r"^\*\*(\d+(?:\.\d+[A-Z]?)+)\.? ", l)
        if m: a.add(m.group(1))
        m = re.match(r"^#{2,4} (E_\d+) ", l)
        if m: a.add(m.group(1))
    return a
A = {k: anchors(t) for k, t in T.items()}
NUM = r"\d+[A-Z]?(?:\.\d+[A-Z]?)*"
qual = re.compile(r"\b(R3|R2|Architecture|Proposal)(?: sections?)? (" + NUM + r")((?:(?:, | and |-| or )" + NUM + r")*)")
bare_sec = re.compile(r"\b[Ss]ections? (" + NUM + r")((?:(?:, | and |-)" + NUM + r")*)")
paren = re.compile(r"\((" + NUM + r")\)")
r17 = re.compile(r"(?<![\w.])(17\.\d+[A-Z]?(?:\.\d+[A-Z]?)*)")
direc = re.compile(r"\b(below|above|following|earlier|later section|this proposal|this document|this version|herein)\b", re.I)
rows = []
for k, (bf, df) in PAIRS.items():
    bl = open(os.path.join(B, bf), encoding="utf-8").read().split("\n"); dl = T[k].split("\n")
    sm = difflib.SequenceMatcher(None, bl, dl, autojunk=False)
    new = [(j + 1, dl[j]) for o, i1, i2, j1, j2 in sm.get_opcodes() if o in ("insert", "replace") for j in range(j1, j2)]
    for n, s in new:
        if not s.strip() or re.match(r"^\|[-| ]+\|$", s): continue
        spans = []
        for m in qual.finditer(s):
            doc = m.group(1); nums = [m.group(2)] + re.findall(NUM, m.group(3) or "")
            for x in nums:
                okk = (doc == "R3" and x == "17") or x in A.get(doc, set())
                rows.append((k, n, m.group(0), "OK-QUALIFIED" if okk else "REVIEW: unresolved", s)); spans.append(m.span())
        insp = lambda p: any(a <= p < b for a, b in spans)
        for m in r17.finditer(s):
            if insp(m.start()) or re.fullmatch(r"17\.\d{3}", m.group(1)): continue
            x = m.group(1).rstrip(".")
            if k == "R3":
                rows.append((k, n, x, "OK-17" if x in A["R3"] else "REVIEW: unresolved 17.x", s))
            else:
                rows.append((k, n, x, "REVIEW: 17.x outside R3 without 'R3'", s))
            spans.append(m.span())
        for m in bare_sec.finditer(s):
            if insp(m.start()): continue
            nums = [m.group(1)] + re.findall(NUM, m.group(2) or "")
            for x in nums:
                rows.append((k, n, m.group(0), ("LOCAL resolves" if x in A[k] else "REVIEW: bare, no local target"), s))
        for m in paren.finditer(s):
            if insp(m.start()) or re.fullmatch(r"\d+", m.group(1)): continue
            x = m.group(1)
            if k == "R3" and x.startswith("17"): continue
            rows.append((k, n, m.group(0), ("LOCAL resolves" if x in A[k] else "REVIEW: bare number, no local target"), s))
        for m in direc.finditer(s):
            rows.append((k, n, m.group(0), "REVIEW: directional", s))
show_all = "--all" in sys.argv
cnt = {}
for k, n, ref, cls, s in rows:
    cnt[cls.split(":")[0]] = cnt.get(cls.split(":")[0], 0) + 1
    if show_all or not cls.startswith("OK"):
        print(f"{k:12} {n:5}  {ref!r:32} {cls:38} | {s[:150]}")
print("SUMMARY", cnt)
