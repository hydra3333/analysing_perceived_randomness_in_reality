"""Apply the hand-decided cross-reference rewrites to the raw section 17.
Each edit: (line number in s17_raw.md, old substring, new substring); the old
substring must occur exactly once on that line. Usage: python -I xref_s17.py in out"""
import sys

E = [
 (29, "(section 9)", "(17.9)"),
 (39, "(section 8)", "(R2 section 2.5)"),
 (41, "(section 9)", "(17.9)"),
 (42, "(section 5)", "(17.5)"),
 (44, "in this version", "in proposal v0.5, carried in this section"),
 (47, "(section 3.2)", "(R2 section 3.6)"),
 (53, "(section 5A)", "(17.5A)"),
 (54, "section 5A)", "17.5A)"),
 (54, "(section 5B)", "(17.5B)"),
 (58, "(section 7.5)", "(17.7.5)"),
 (59, "(section 3.5A)", "(17.3.5A)"),
 (110, "(3.9)", "(17.3.9)"),
 (111, "section 7.", "R2 section 8.4 (with 17.7.5 for the side-by-side display)."),
 (121, "(section 18.3)", "(R3 section 17.18.3)"),
 (126, "in 7.4", "in R2 section 8.4.4"),
 (146, "(section 5B)", "(17.5B)"),
 (199, "(5A)", "(17.5A)"),
 (216, "see 3.4", "see 17.3.4"),
 (228, "see 3.4", "see 17.3.4"),
 (319, "(5A)", "(17.5A)"),
 (321, "(3.7A)", "(17.3.7A)"),
 (323, "(section 7)", "(R2 section 8.4)"),
 (329, "of 3.7A", "of 17.3.7A"),
 (329, "(5B)", "(17.5B)"),
 (353, "(3.7A)", "(17.3.7A)"),
 (362, "(section 7)", "(R2 section 8.4)"),
 (379, "(3.4A)", "(17.3.4A)"),
 (394, "(5.2)", "(17.5.2)"),
 (406, "(section 17)", "(17.17)"),
 (406, "listed in 3.4A", "listed in 17.3.4A"),
 (433, "(3.8)", "(17.3.8)"),
 (445, "(section 9)", "(17.9)"),
 (446, "(3.8)", "(17.3.8)"),
 (455, "Then section 5.", "Then 17.5."),
 (478, "(section 13, field 3)", "(R2 section 5.6, field 3)"),
 (507, "(4.4)", "(17.4.4)"),
 (537, "from 4.4", "from 17.4.4"),
 (659, "from section 4)", "from 17.4)"),
 (690, "(3.4A)", "(17.3.4A)"),
 (720, "in 18.3", "in 17.18.3"),
 (736, "(5.3)", "(17.5.3)"),
 (751, "from 3.5A", "from 17.3.5A"),
 (756, "from 3.5A", "from 17.3.5A"),
 (758, "(7.5)", "(17.7.5)"),
 (762, "(section 13)", "(R2 sections 5.6 and 6.2)"),
 (788, "under section 8.", "under R2 section 2.5."),
 (796, "(with section 8)", "(with R2 section 2.5)"),
 (797, "(7.5)", "(17.7.5)"),
 (806, "in section 4.", "in 17.4."),
 (808, "section 5's table", "17.5's table"),
 (814, "(10.4)", "(17.10.4)"),
 (818, "of 3.5A", "of 17.3.5A"),
 (828, "the section 6 reference table", "the MR16 reference table (17.6)"),
 (829, "(3.4A)", "(17.3.4A)"),
 (852, "| 3.6 (S", "| 17.3.6 (S"),
 (853, "Section 7 (IS)", "R2 section 8.4 (IS) and 17.7.5"),
 (854, "| 3.6;", "| 17.3.6;"),
 (855, "| 7.2-7.3 |", "| R2 sections 8.4.2-8.4.3 |"),
 (856, "| 7.3 `IS", "| R2 section 8.4.3 `IS"),
 (857, "| 4.1 |", "| 17.4.1 |"),
 (859, "| 4.2-4.3 (", "| 17.4.2-17.4.3 ("),
 (858, "| Sections 6 and 10 |", "| R3 sections 17.6 and 17.10 |"),
 (865, "Section 10", "17.10"),
 (867, "Section 12", "17.12; Architecture section 12.5"),
 (868, "Sections 12, 13, 15, 18", "17.12, 17.13, 17.18; Architecture sections 5A.4 and 12.5; R2 section 5.6"),
 (899, "(7.5)", "(17.7.5)"),
]

L = open(sys.argv[1], encoding="utf-8").read().split("\n")
for n, old, new in E:
    s = L[n - 1]
    c = s.count(old)
    if c != 1:
        sys.exit(f"line {n}: {old!r} occurs {c} times: {s[:120]}")
    L[n - 1] = s.replace(old, new)
open(sys.argv[2], "w", encoding="utf-8", newline="\n").write("\n".join(L))
print(len(E), "edits applied")
