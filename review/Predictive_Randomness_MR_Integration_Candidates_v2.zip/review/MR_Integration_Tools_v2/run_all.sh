#!/bin/sh
# Rebuild all candidates from the ratified bases and run every check.
# Usage (from the folder holding base/, draft/, tools/): sh tools/run_all.sh > draft/check_output.txt 2>&1
set -e
B=base; D=draft; P="python3 -I"
MR=$B/Predictive_Randomness_Method_Ranking_Measures_Proposal_v0_5.md
$P tools/build_s17.py $MR $D/s17_raw.md
$P tools/xref_s17.py $D/s17_raw.md $D/s17_x.md
$P tools/assemble_r3.py $B/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_4.md $D/s17_x.md $D/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md
$P tools/assemble_r2.py $B/Predictive_Randomness_Experimental_Method_Specifications_R2_v0_4.md $MR $D/Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md
$P tools/assemble_arch.py $B/Predictive_Randomness_Software_Architecture_Discussion_v0_7.md $MR $D/Predictive_Randomness_Software_Architecture_Discussion_v0_8.md
$P tools/assemble_prop.py $B/Predictive_Randomness_Research_Project_Proposal_v0_5.md $D/Predictive_Randomness_Research_Project_Proposal_v0_6.md
$P tools/assemble_reg.py $B/RATIFICATION_REGISTER_v0_3.md $D $D/RATIFICATION_REGISTER_v0_4.md
set +e
echo "### R3 v0.5"; $P tools/check_doc.py $B/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_4.md $D/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md '0.4@@^### 0\.4 @@^(---|## |### )' '2.4@@^### 2\.4 @@^(## |### )' '3@@^## 3\. @@^## '
echo "### R2 v0.5"; $P tools/check_doc.py $B/Predictive_Randomness_Experimental_Method_Specifications_R2_v0_4.md $D/Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md '7 method inventory@@^## 7\. @@^## 8\. ' '4.1@@^### 4\.1 @@^### 4\.2 '
echo "### Architecture v0.8"; $P tools/check_doc.py $B/Predictive_Randomness_Software_Architecture_Discussion_v0_7.md $D/Predictive_Randomness_Software_Architecture_Discussion_v0_8.md '5C@@^## 5C\. @@^## 6\. '
echo "### Proposal v0.6"; $P tools/check_doc.py $B/Predictive_Randomness_Research_Project_Proposal_v0_5.md $D/Predictive_Randomness_Research_Project_Proposal_v0_6.md 'E_1-E_6@@^### E_1 @@^### 7\.1 '
echo "### Register v0.4"; $P tools/check_doc.py $B/RATIFICATION_REGISTER_v0_3.md $D/RATIFICATION_REGISTER_v0_4.md
echo "### cross-document"; $P tools/cross_checks.py $D
echo "### proposal line accounting"; $P tools/account_mr.py $MR $D/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md $D/s17_raw.md $D/s17_x.md $D/Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md $D/Predictive_Randomness_Software_Architecture_Discussion_v0_8.md
echo "### reference scan of every inserted or moved line (non-OK hits only)"; $P tools/scan_refs.py $B $D
echo "### candidate hashes"; sha256sum $D/Predictive_Randomness_*_v0_[5-8].md $D/RATIFICATION_REGISTER_v0_4.md
