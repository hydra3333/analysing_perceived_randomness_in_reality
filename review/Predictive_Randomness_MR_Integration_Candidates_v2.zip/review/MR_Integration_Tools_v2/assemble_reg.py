"""Assemble RATIFICATION_REGISTER v0.4 (candidate) from ratified v0.3 and the four draft editions.
Hashes are computed from the draft files (UTF-8, LF), so rerun after every revision.
v2: B-01 (one unambiguous current set; historical inventory labelled) and C-03 (installation
checklist), wording as suggested by the ChatGPT reviewer and agreed by the owner.
Usage: python -I assemble_reg.py REG_v0_3.md DRAFT_DIR out.md"""
import sys, hashlib, os
reg = open(sys.argv[1], encoding="utf-8").read(); D = sys.argv[2]
def h(name): return hashlib.sha256(open(os.path.join(D, name), "rb").read()).hexdigest()
def rep(text, old, new, label):
    c = text.count(old)
    if c != 1: sys.exit(f"{label}: expected 1 match, found {c}: {old[:80]!r}")
    return text.replace(old, new)
def rep_line(text, prefix, new, label):
    lines = text.split("\n"); hits = [i for i, l in enumerate(lines) if l.startswith(prefix)]
    if len(hits) != 1: sys.exit(f"{label}: expected 1 line starting {prefix[:60]!r}, found {len(hits)}")
    lines[hits[0]] = new
    return "\n".join(lines)
R3, R2 = "Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md", "Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md"
AR, PR = "Predictive_Randomness_Software_Architecture_Discussion_v0_8.md", "Predictive_Randomness_Research_Project_Proposal_v0_6.md"

new_section = f"""## Method ranking measures and integration editions (26 October 2026)

Two documents were owner-ratified on 26 October 2026 at commit `ac01678`. Their authoring-time headers ("RATIFICATION CANDIDATE" / "CANDIDATE ... awaits owner ratification") are historical; the ratification recorded here determines their status, and the files are never edited to change those headers.

| Document (path under `doc/`) | Authority and status | Git-content SHA-256 (UTF-8/LF) |
|---|---|---|
| `Predictive_Randomness_Method_Ranking_Measures_Proposal_v0_5.md` | OWNER-RATIFIED 26 Oct 2026. Its content is integrated into the four editions below; once they are ratified, the file is integrated history, kept unchanged. Versions v0.2-v0.4 are historical drafts. | `c6ca2cb2174ee2963a6fe33347820c80b92e6dd1eda518a1f0c8e3254d67ab19` |
| `HOLDOUT_EXPOSURE_RECORD_v0_2.md` | OWNER-RATIFIED 26 Oct 2026; factual, value-free record (6 items); supersedes v0.1 | `aec833fe031b6d1d73e6acbb81757b50b193425a6899c84d438431d9df4433e2` |
| `RATIFICATION_REGISTER_v0_3.md` | OWNER-RATIFIED 26 Oct 2026; superseded by this register when it is ratified | `99e75fbe1bc5cea34a7d2b1c456633815b88e340c4a05aab5fb671d624c7ec37` |

**Integration editions (RATIFICATION CANDIDATES, awaiting owner ratification).** Each is its ratified predecessor edited in place; every ratified ID and rule is kept, and the protected blocks are byte-identical.

| Candidate edition (path under `doc/`) | Ratified predecessor | Status and Git-content SHA-256 (LF) |
|---|---|---|
| `{R3}` | R3 v0.4 | RATIFICATION CANDIDATE; adds R3 section 17 (method ranking measures); `{h(R3)}` |
| `{R2}` | R2 v0.4 | RATIFICATION CANDIDATE; adds R2 sections 2.5 (supplementary rule), 3.6 (numbering), 5.6 (stage-1 contract fields) and 8.4 (in-sample mode); `{h(R2)}` |
| `{AR}` | Architecture v0.7 | RATIFICATION CANDIDATE; adds Architecture sections 5A.4 (ranking tool launcher) and 12.5 (report tool, in-sample runs, N1); protected 5C unchanged; `{h(AR)}` |
| `{PR}` | Proposal v0.5 | RATIFICATION CANDIDATE; adds Proposal section 2.7 (charter); supplementary sentence in Proposal sections 0 and 3.1; `{h(PR)}` |

**On owner ratification:** the installation step changes the **five edition/status headers, including this register**, and all affected candidate-status and present-authority rows to OWNER-RATIFIED; it marks the pre-integration inventory explicitly historical, updates the R3 section 17.13 stage-0 integration status, recomputes the **four governed-document Git-content hashes** in this register and places this register's own SHA-256 in the external installation manifest. Claude verifies the resulting installed files against the committed Git HEAD. Historical hashes and decisions remain preserved. Neither ratification nor documentation authorises runs, Mode H/FINAL, holdout access, process termination or Package 2 scientific use. Unchanged by this integration: R1 v0.4, TIE_SHA256_V1 v0.2, P3 v0.2, the Windows POC Task Specification v0.2, the numerical reference v0.1, the E_1 legacy schema and goldens, the masters, the owner tools, the coordinator and Package 2 v0.11.

**Continuity documents (commit `618fe48`, verified by Claude):** the current handovers are `HANDOVER/Claude_Reviewer_Handover_Predictive_Randomness_v10.md` and `HANDOVER/Predictive_Randomness_ChatGPT_Coder_Handover_v1_1r1.md`. Reviewer handovers v2-v9, coder handovers v1.0r1 and v1.1, and the ChatGPT handbacks are in `HANDOVER/superseded/`; the interim note is in `HANDOVER/`. They are continuity records, not normative.

"""

# header and basis
reg = rep(reg, "**Register version:** v0.3 OWNER-RATIFIED 26 October 2026, consolidated governing-document register; v0.2 OWNER-RATIFIED 24 October 2026.",
    "**Register version:** v0.4 RATIFICATION CANDIDATE (26 October 2026), adding the method-ranking integration; v0.3 OWNER-RATIFIED 26 October 2026; v0.2 OWNER-RATIFIED 24 October 2026.", "hdr")
reg = rep(reg, "The new consolidated governing editions below were owner-ratified 26 October 2026; only explicit OPEN/PROVISIONAL/RECOMMENDED subitems remain undecided.  \n",
    "The new consolidated governing editions below were owner-ratified 26 October 2026; only explicit OPEN/PROVISIONAL/RECOMMENDED subitems remain undecided. The v0.4 entries were cross-checked by Claude against GitHub HEAD `618fe48` (26 October 2026).  \n", "basis")

# B-01, lines 64-65 (reviewer wording)
reg = rep_line(reg, "- The **current** governing set is consolidated Proposal v0.5,",
    "- **Until the integration editions listed in the preceding table are owner-ratified**, the predecessor set identified below remains operative on its unaffected subjects, and the independently owner-ratified Method Ranking Measures Proposal v0.5 already governs its adopted subjects. **Upon owner ratification**, the operative editions are Proposal v0.6, R1 v0.4, R2 v0.5, R3 v0.5, Architecture v0.8, the Windows POC Task Specification v0.2, P3 v0.2, TIE_SHA256_V1 v0.2, and exposure record v0.2.\n"
    "- **Pre-integration predecessor set (ratified before this integration):** Proposal v0.5, R1 v0.4, R2 v0.4, R3 v0.4, Architecture v0.7, the Windows POC Task Specification v0.2, P3 v0.2 and TIE_SHA256_V1 v0.2. Their historical approvals and hashes remain valid; their operative status is superseded only on adoption of the corresponding later edition. Earlier editions and ChatGPT handovers remain historical sources, not replacement current specifications.", "B01-64-65")

# B-01, heading 78 + introductory portion of line 80 (reviewer wording), facts of line 80 kept in past tense
reg = rep_line(reg, "## Consolidated governing editions ",
    "## Pre-integration consolidation - historical ratification inventory (26 October 2026)\n\n"
    "This section preserves the prior consolidation's ratified identities, rules, decisions and Git-content hashes without deletion. The entries document the governing set **at the time of the v0.3 register's ratification**; they do not designate a second current set after the method-ranking integration is ratified. Present authority and supersession are stated in \"Method ranking measures and integration editions\" and \"Interpretation and verification\" above.", "B01-78")
reg = rep(reg, "Following the owner's decision to consolidate, the documents below are current **self-contained governing versions**, rather than layered amendments 0A/0B or a separate operative R2 erratum:",
    "Following the owner's decision to consolidate, the documents below became the **self-contained governing versions** on 26 October 2026, rather than layered amendments 0A/0B or a separate operative R2 erratum:", "B01-80")
reg = rep(reg, "| Current edition (path under `doc/`) | Historical governing predecessor |",
    "| Pre-integration ratified edition (path under `doc/`) | Historical governing predecessor |", "B01-82")
reg = rep(reg, "| OWNER-RATIFIED, factual record 26 Oct 2026; `a98064494444831b703587c48523dfb5e4b3c8aa66a3d00729ffcaa9d563c33b` |",
    "| OWNER-RATIFIED, factual record 26 Oct 2026; superseded by v0.2 (26 Oct 2026); `a98064494444831b703587c48523dfb5e4b3c8aa66a3d00729ffcaa9d563c33b` |", "B01-89")
reg = rep(reg, " The authoritative operative requirements are in consolidated R2 v0.4, R3 v0.4 and Architecture v0.7; their ratification alone does not authorise a run.",
    " These requirements were ratified in consolidated R2 v0.4, R3 v0.4 and Architecture v0.7; after the separately ratified method-ranking integration, their continuing operative editions are R2 v0.5, R3 v0.5 and Architecture v0.8, as amended only by the already owner-ratified MR proposal. Ratification of either set grants no run authority.", "B01-93")

# B-01, forward-looking lines recast as past/historical (facts kept; completions verified at 2db2554 / 6726963 / 618fe48)
reg = rep(reg, "**Historical handovers:** ChatGPT handbacks v0.6 and v0.6r1 were reported committed and are historical, not the accepted replacement new-coder handover. Exact HEAD bytes must be independently checked at final installation. A definitive handover will be prepared and independently reviewed only after these consolidated governing documents are ratified, installed and pushed.",
    "**Historical handovers (as at the v0.3 consolidation):** ChatGPT handbacks v0.6 and v0.6r1 were reported committed and were historical, not the accepted replacement new-coder handover. Exact HEAD bytes were to be checked independently at final installation. A definitive handover was to be prepared and independently reviewed only after those consolidated governing documents were ratified, installed and pushed; that was done (coder handover v1.0r1 at commit `6726963`, succeeded by v1.1r1 at `618fe48`).", "B01-95")
reg = rep(reg, "**Post-ratification / commit verification:** The seven installed document SHA-256 values above are computed from this ratified installation package. Confirm the actual Git HEAD and byte-identical committed files after owner commit/push. The register intentionally omits its own SHA-256 to avoid self-reference; use the enclosing installation manifest. Preserve historical editions, R1 v0.4 and TIE note v0.2 unchanged.",
    "**Post-ratification / commit verification (as at the v0.3 consolidation):** The seven installed document SHA-256 values above were computed from that ratified installation package; the committed files were confirmed byte-identical at Git HEAD `2db2554`. Register v0.3 omitted its own SHA-256 to avoid self-reference (it is now recorded in the method-ranking section above). Historical editions, R1 v0.4 and TIE note v0.2 were preserved unchanged.", "B01-97")
reg = rep(reg, "| Historical/previous continuity snapshots, not normative and due to be superseded after ratification |",
    "| Historical/previous continuity snapshots, not normative; since superseded (see Continuity documents above) |", "B01-109")
reg = rep(reg, "| Historical prior-state snapshots; Claude plans current v9 after owner commit |",
    "| Historical prior-state snapshots; succeeded by v9 and then v10 (see Continuity documents above) |", "B01-110")
reg = rep(reg, "Installation is pending Claude's final mechanical comparison and the owner's commit/push. The seven file hashes above identify the ratified-install package bytes; verify against the future Git HEAD.",
    "Installation was then pending Claude's final mechanical comparison and the owner's commit/push; both were completed (installed at `2db2554`). The seven file hashes above identify the ratified-install package bytes.", "B01-114")
reg = rep(reg, "Prior ChatGPT handovers v0.6/v0.6r1 are historical; definitive coder handover is pending Git HEAD verification and Claude independent handover review.",
    "Prior ChatGPT handovers v0.6/v0.6r1 are historical; the definitive coder handover was then pending Git HEAD verification and Claude's independent handover review, both since completed (v1.0r1 at `6726963`; v1.1r1 at `618fe48`).", "B01-116")

reg = rep(reg, "\n## Interpretation and verification\n", "\n" + new_section + "## Interpretation and verification\n", "insert")
open(sys.argv[3], "w", encoding="utf-8", newline="\n").write(reg)
print("ok")
