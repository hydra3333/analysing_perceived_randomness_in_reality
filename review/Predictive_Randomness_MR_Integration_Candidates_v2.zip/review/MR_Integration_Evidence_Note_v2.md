# Method ranking integration - evidence note for the candidate editions

**Note version:** v2, 26 October 2026 (Adelaide); supersedes v1 (package v1 `86f40744c679005eef8b55e9ad78f1606d3d5f862368213f69e46c790893355c`). Author: Claude (drafter for this task; ChatGPT reviews; the project owner ratifies).
**Repository baseline:** `hydra3333/analysing_perceived_randomness_in_reality` at HEAD `618fe48c48ada46bcf60c80bbd291acc216d7e3b`, verified by Claude (clean clone; the uploaded ZIP is byte-identical to that tree; all eleven section-4 hashes of reviewer handover v10 match).
**Status:** the five editions are RATIFICATION CANDIDATES. Nothing here grants any run, coding, data-access, holdout or termination authority.
**Holdout discipline:** no winning, Powerball or supplementary number of any draw appears in the candidates or in this note.

## 0. Changes from v1

Source: `Independent_ChatGPT_Review_MR_Integration_Candidates_v1.md` (SHA-256 `28c73726945d3f13d2ba4fd3ea2bf86b2f89a72c4f26499a07f0971131564e34`): 1 BLOCKER, 3 CORRECTIONS, 2 OPTIONAL. Every cited line was confirmed by Claude. Owner decisions, 26 October 2026: agree all; apply O-01; O-02 approved as an owner-approved change to ratified text; scan all moved text for proposal-relative references.

| Item | Change in v2 | Where |
|---|---|---|
| B-01 | One unambiguous current set. The two "Interpretation" bullets use the reviewer's wording (until ratification / upon ratification; pre-integration predecessor set). The old "Consolidated governing editions" section is relabelled "Pre-integration consolidation - historical ratification inventory", with the reviewer's introductory paragraph; its "are current" sentence becomes "became ... on 26 October 2026"; its table column "Current edition" becomes "Pre-integration ratified edition"; the exposure v0.1 row is marked "superseded by v0.2"; the "authoritative operative requirements" sentence uses the reviewer's wording. Every row and all 25 historical hashes are kept. | Register v0.4 |
| B-01 (recast) | Forward-looking lines recast in past tense, keeping their facts, with completions stated only where verified by Claude: handovers v1.0r1 at `6726963` and v1.1r1 at `618fe48`; installation byte-identical at `2db2554` (all seven hashes rechecked there). Two rows of the v0.3 dispositions table that also looked forward ("due to be superseded", "Claude plans current v9") are recast the same way; this extends B-01 in its own spirit and is flagged for the focused check. | Register v0.4 (old lines 95, 97, 109-110, 114, 116) |
| C-01 | R2 3.6 scored-opportunity row: "(3.8)" becomes "(R3 section 17.3.8)". | R2 v0.5 3.6 |
| C-02 | R3 17.17 "Step 3, rankings per game": "Sections 6 and 10" becomes "R3 sections 17.6 and 17.10". | R3 v0.5 17.17 |
| C-03 | Register "On owner ratification" paragraph replaced by the reviewer's text (five headers including the register; present-authority rows; pre-integration inventory historical; R3 17.13 stage 0; four hashes recomputed; register SHA in the external manifest), followed by the existing "Unchanged by this integration" list. Section 8 of this note uses the reviewer's sentence. | Register v0.4; note section 8 |
| O-01 | 17.5B: "Each report run appends exactly one row with `row_type` = `RANKING_REPORT`:"; R3 7.4 uses the same wording. | R3 v0.5 7.4, 17.5B |
| O-02 | **Owner-approved change to ratified text** (not an integration edit): 17.10.1 ".csv: one row per (track, sub-measure)" becomes "`.csv`: one row per (analysis_unit, unit_id, sub-measure), keyed as in 17.3.4A". This is the only change to ratified rule wording beyond integration edits. | R3 v0.5 17.10.1 |
| Register rows | The candidate-table rows now name sections with their document ("adds R3 section 17", "R2 sections 2.5 ...", "Architecture sections 5A.4 ...", "Proposal section 2.7 ..."), found by the reference scan. | Register v0.4 |

The only change to any verbatim printed string is still the owner-approved "(R3 section 17.18.3)" in 17.3.5A.

## 1. What is delivered

| Candidate (repository path) | Ratified base (Git blob SHA-256, LF) | Candidate SHA-256 (UTF-8, LF) |
|---|---|---|
| `doc/Predictive_Randomness_Evaluation_and_Reporting_Specifications_R3_v0_5.md` | R3 v0.4 `78e2818ab71f6fce68cf1b39b24f5d0f2ad5563f7143b4358a3bcf5b6d49c752` | `e80356aadb72f52c6e695bb30960d32923ae1c9820bc759df1d6675567353c2e` |
| `doc/Predictive_Randomness_Experimental_Method_Specifications_R2_v0_5.md` | R2 v0.4 `1a1853570197a4a62a7d5695417848aac2de65b5fc83c25a931d936c84e05ef4` | `62d1c9c99e7dd33fe5c2496615229d5a67e09d3c6f6b68ada2146b60999e53da` |
| `doc/Predictive_Randomness_Software_Architecture_Discussion_v0_8.md` | Architecture v0.7 `6c7ba2bc1da0d7b1f81e6e2e62e7c1e69448122bdf149399ae560f0c361b7218` | `d27115e095e309fc1e6d68099ee397432f561a7cb51eee722522a85493203875` |
| `doc/Predictive_Randomness_Research_Project_Proposal_v0_6.md` | Proposal v0.5 `834c0a8e738979ae5bed3527fd946d4f9b0f6a4d77dcbf6d087f1437db731d58` | `ee552a5b530b38604e7b8b8129e5c1ba9485cbe423658e4f5d73bbd9d8b52349` |
| `doc/RATIFICATION_REGISTER_v0_4.md` | Register v0.3 `99e75fbe1bc5cea34a7d2b1c456633815b88e340c4a05aab5fb671d624c7ec37` | `0ba1ae26521ace6a51d7a545576aecbe2b7e3e3f75cc1114480f56d8bd07af2f` |

Source of the integrated content: ratified `doc/Predictive_Randomness_Method_Ranking_Measures_Proposal_v0_5.md` (`c6ca2cb2174ee2963a6fe33347820c80b92e6dd1eda518a1f0c8e3254d67ab19`), unchanged, headers included.

Architecture v0.8 and Proposal v0.6 are byte-identical to package v1; R3, R2 and the register changed (section 0).

Also in the package: `review/MR_Integration_Tools_v2/` (the scripts that built and checked the candidates; `run_all.sh` runs everything) and `review/MR_Integration_Check_Output_v2.txt` (their full output).

**Encoding (owner decision Q3):** the candidates keep the ratified texts' UTF-8 with LF, exactly as stored in Git, so protected blocks stay byte-identical. Every character Claude inserted is plain ASCII, checked at character level. This note, the tools and the check output are ASCII with CRLF.

## 2. Owner decisions applied (26 October 2026)

| Item | Decision | Where applied |
|---|---|---|
| Q1 | Every rule and ratified ID gets exactly one home. R3 section 17 is the default home: proposal 0-2 (MRD-01..24), 3.1, 3.3, 7.5, 11, 13, 14 (MRT-01..25), 16 (MRO-01..11), 17.1, and 18 as informative 17.18. Traceability 17.2-17.4 stays only in the unchanged proposal file. | R3 section 17; mapping in section 3 below |
| Q1 (verbatim string) | In the MRD-24 word-for-word in-sample text, "(section 18.3)" becomes "(R3 section 17.18.3)". **This is the only change to any verbatim printed string.** | R3 17.3.5A |
| Q2 | R3-D21 becomes "PARTLY DECIDED (MRD-01, MRD-05, RK-1..RK-6, R3 17): per-measure league tables, as reports only. A single combined best-method score or automatic champion remains OPEN." R3 11.1 unchanged. | R3 section 14 |
| Q3 | UTF-8 with LF as in Git; additions plain ASCII; this note ASCII/CRLF. | all |
| Finding 1 | Apply MRD-03 consistently: R2 I-01; Architecture section 1 item 2; the four identical "Current development data" paragraphs; R2 2.1. | see section 4 |
| Addition 1 | One search log, not two. | R3 7.4 (single definition), 11.5 item 7, 11.7, 17.5B |
| Addition 2 | Proposal v0.5 file unchanged; register v0.4 records it as integrated history once the editions are ratified. | Register v0.4 new section |
| Addition 3 | Stage 0 "Now" restated as completed (ratified 26 Oct; integration in progress). | R3 17.13 |

## 3. Where each part of the ratified proposal went

R3 17.x is proposal section x throughout (17.5A = proposal 5A).

| Proposal section | Home | Notes |
|---|---|---|
| Header, ID-prefix table, holdout line, change logs | R3 17 intro carries the ID-prefix table, the no-authority statement and the holdout line | Change logs (v0.2-v0.4) are history; not carried |
| 0, 1, 2 (MRD-01..24) | R3 17.0, 17.1, 17.2 | |
| 3.1, 3.3-3.9 (incl. 3.4A, 3.5A, 3.7A) | R3 17.3.x | |
| 3.2 numbering conventions | R2 3.6 | R3 17.3.2 is a pointer |
| 4, 5, 5A, 5B, 6 (MR0-MR16) | R3 17.4, 17.5, 17.5A, 17.5B, 17.6 | |
| 7.1-7.4 in-sample mode | R2 8.4 (8.4.1-8.4.4) | R3 17.7 is a pointer |
| 7.5 side-by-side display | R3 17.7.5 | |
| 8 supplementary rule | R2 2.5 | R3 17.8 is a pointer |
| 9 (RK-1..RK-6), 10, 11 | R3 17.9, 17.10, 17.11 | |
| 12 execution model | Architecture 12.5 (report tool, in-sample runs, N1) and 5A.4 (wrapper); evaluator and dependency bullets stay in R3 17.12 | |
| 13 phasing table | R3 17.13 | stage 0 and stage 1 rows edited (section 5) |
| 13 stage-1 fields 1-7 and acceptance before E_2 | R2 5.6 | Architecture 20A and R3 17.13 point to it |
| 14 tests MRT-01..25 | R3 17.14 | table order kept as ratified |
| 15 integration plan | Not carried (executed by this set) | R3 17.15 is a one-line stub so the numbering stays complete |
| 16 open items MRO-01..11 | R3 17.16 | |
| 17.1 traceability to the owner's starter text | R3 17.17 | references rewritten to new homes |
| 17.2-17.4 traceability to review rounds | Not carried | stays in the proposal file |
| 18 analysis (18.1-18.9) | R3 17.18, headed "(informative)" | one-line note added under the heading |

**Line accounting (mechanical, `account_mr.py`):** of the proposal's 958 non-blank lines (separator lines excluded), 636 appear verbatim in R3 v0.5; 127 appear with only the renumbered heading or a rewritten cross-reference; 57 appear verbatim in R2 v0.5 (54) or Architecture v0.8 (3); 117 are history not carried (header and change logs, section 15, 17.2-17.4, end marker). The remaining 21 are deliberate edits: 14 relocated lines with renumbered headings or references (13 in R2, including C-01; 1 in Architecture), and 7 intended edits (the search-log line, stage 0 and stage 1 rows, three headings, and O-02). None is unaccounted.

**Cross-references:** 66 hand-decided rewrites inside section 17 (65 in v1, plus C-02) (each listed in `xref_s17.py`, one per line, exact-once); every reference to a new home (R3 17.x, R2 2.5/3.6/5.6/8.4.x, Architecture 5A.4/12.5/20A) resolves to an existing heading or numbered label (`cross_checks.py`).

## 4. Edits to ratified text, by document

Every other line of each ratified base is unchanged (mechanical diff, `check_doc.py`).

**R3 v0.5** (11 base lines changed; everything else is new section 17):
- Header: version, date, status, path. Edition-history paragraph: one new paragraph naming the 0.5 changes.
- 0.1: "This R3" row updated; one row added for the proposal. The ratification sentence is rephrased so that it **keeps** the [R3-PROPOSED] provisions ratified (they were ratified with v0.4 and remain ratified) and adds that section 17 carries the ratified proposal as written. Lesson from the v0.4 install (R3 line 37) applied.
- 0.2: new tag [MR-RATIFIED].
- 5.6: one paragraph: MR6/MR14 use typed probability outputs but do not settle this optional-score decision, which stays OPEN.
- 7.4: new paragraph "One search record (single definition)" (owner addition 1).
- 11.5 item 7: the ledger is that single record. 11.7: tree lines for `method_rankings/` and `audit/` (SEARCH_LOG.csv).
- 12.6: `mode` list adds `IN_SAMPLE_DIAGNOSTIC`.
- 13: one sentence: MRT-01..25 are in 17.14, distinct from R3-Txx and R2 T-xx.
- 14: R3-D21 status (owner decision Q2); its question column keeps its ratified text.
- Section 17 (new text) also carries the v2 items O-01 (17.5B) and O-02 (17.10.1) and C-02 (17.17).
- Protected 0.4, 2.4 and 3: byte-identical (hashes in section 6).

**R2 v0.5** (7 base lines changed):
- Header lines and section 0 note naming the 0.5 changes.
- I-01: "supplementary numbers excluded from views and scoring" becomes "excluded from every method view, fit, seed, digest and forecast; the evaluator alone may read a target draw's supplementaries to classify prize divisions (section 2.5)".
- Section 2 "Current development data" paragraph: the shared replacement sentence (below).
- 2.1: "structural checks only" qualified as "for every method-facing reader and view; their only other use is the evaluator-only division scoring of section 2.5".
- 2.4: one sentence naming the separate `IN_SAMPLE_DIAGNOSTIC` namespace.
- New 2.5 (proposal 8), 3.6 (proposal 3.2), 5.6 (proposal 13 fields), 8.4 (proposal 7.1-7.4), each with a one-line provenance sentence.
- Pointer lines: 4.2 (per-channel probability kinds), 6.2 (registry texts), 8.1 (new mode row), 13.2 (R3 17 settles part of the list for ranking reports only).
- Protected section 7 and 4.1: byte-identical.

**Architecture v0.8** (6 base lines changed):
- Header lines; section 0 note; shared replacement sentence in the section 0 data paragraph; 0.2 rows for this edition and the proposal.
- Section 1 item 2: "no earlier formats or Oz supplemental science" becomes "no earlier formats; Oz supplementaries are never method inputs and are read only by the evaluator for prize-division scoring (R2 section 2.5)".
- 5A heading: "Three operator-maintained ..." becomes "Operator-maintained ..." (5A.4 makes "Three" wrong).
- New 5A.4 (`Run_Method_Rankings.bat`), new 12.5 (report tool, in-sample runs, N1), 7.1 illustrative `--mode` list adds `in-sample-diagnostic`, 20A pointer paragraph.
- Protected 5C: byte-identical.

**Proposal v0.6** (6 base lines changed):
- Title line and edition status; section 0 note.
- Shared replacement sentence in sections 0 and 3.1 (the same paragraph appears twice).
- New charter section 2.7 (rankings are reports; in-sample diagnostics labelled; mark, never suppress; statistics an instrument, not a gate; explanation-text rule), each point citing its MRD/RK/PO IDs.
- Pointers: 10.1 (league tables are in R3 17; principles in 2.7) and 18 item 8.
- Protected E_1-E_6: byte-identical.

**Register v0.4** (14 base lines changed, all listed in section 0 under B-01 and C-03, plus the version line, the basis line and the interpretation bullet): version line, basis (cross-checked at `618fe48`), the "current governing set" bullet (until and after ratification). New section listing the ratified proposal v0.5 and exposure record v0.2 (with the historical-header note), register v0.3 with its hash, the four candidates with hashes, the on-ratification procedure, and the current continuity documents at `618fe48`. All 25 hashes of v0.3 are kept.

**The shared replacement sentence** (identical in all four copies of the paragraph; one text, checked):
- Old: "Three supplementary Oz Lotto labels are provenance only and never become scientific inputs."
- New: "Three supplementary Oz Lotto labels are never method inputs; the evaluator alone may read a target draw's supplementaries, after the target is opened and its forecast frozen, solely to classify prize divisions (R2 section 2.5)."

## 5. Points for ChatGPT's review (decided by Claude while drafting)

Each is a consequential-but-mechanical integration choice. The owner may overrule any of them.

1. **Single search-log location.** To make one mechanism (owner addition 1), the file is `results/audit/SEARCH_LOG.csv` (R3 11.7 already designates `audit/` for the search register), with a `row_type` column; each ranking report run writes exactly one row with `row_type` = `RANKING_REPORT` (O-01). The ChatGPT reviewer found this consistent across 7.4, 11.5, 11.7 and 17.5B. The proposal had `results/method_rankings/SEARCH_LOG.csv`. Other row types are defined when their tools are specified. Please check that R3 7.4, 11.5, 11.7 and 17.5B now give one consistent definition.
2. **Charter note placed as Proposal 2.7, not 10.8** (as first proposed): Proposal 10.1 says nothing in section 10 sets a leaderboard policy, so a ranking charter note inside section 10 would contradict it. 2.7 sits with the philosophy sections; 10.1 gains a pointer.
3. **Stage rows in R3 17.13:** stage 0 restated as completed (owner wording); stage 1 "(fields 1-7 below)" becomes "(fields 1-7, R2 section 5.6)", since the fields moved.
4. **R2 2.5 wording:** the proposal's "**Current ratified text:**" becomes "**Earlier ratified text (replaced by this rule on 26 October 2026):**", and "outside this proposal" becomes "outside this rule".
5. **MRD-08:** "formulas as corrected in this version" becomes "formulas as corrected in proposal v0.5, carried in this section".
6. **Headings:** proposal 17/17.1 headings become "17.17 Traceability to the owner's starter text"; 18 becomes "17.18 ... (informative)" with one explanatory line; 17.15 is a one-line stub.
7. **Name of the in-sample mode:** `IN_SAMPLE_DIAGNOSTIC` (the proposal's product label) is used for the R2 8.1 mode row, the R2 2.4 namespace and the R3 12.6 mode list; the command-line spelling stays `in-sample-diagnostic` (proposal 12).
8. **Search-log line in 17.5B:** rewritten to point to R3 7.4 (item 1).
9. **Version mentions not updated** elsewhere (for example R3 header lines naming Proposal v0.5 / R2 v0.4, Architecture section 0's list of editions), under the "that version or later" convention; only self-references, status rows and hierarchy rows for the edited documents changed.
10. **Not edited:** P3 v0.2, R1 v0.4, TIE v0.2, the Windows POC Task Specification v0.2, the numerical reference v0.1, the exposure record v0.2, the ratified proposal v0.5, and all code and data.

Questions the review should answer:
- Is any ratified rule without an ID lost or weakened? (Mechanical check: every base line is kept except those listed in section 4, and every proposal line is accounted for in section 3.)
- Does any ratification wording de-ratify anything (R3 0.1; the "until then ... governs" status lines)?
- Does any new pointer sentence add a rule that is not in the ratified texts?
- Are the "one home" choices sound, in particular 7.5 in R3 and 12 split between Architecture and R3 17.12?
- Does anything make a number less honest, or act as a veto on an idea, method or measure (handover v10 section 2A, test 6)?

## 6. Mechanical check results (all PASS)

| Check | Result |
|---|---|
| LF only, single final newline, valid UTF-8 | PASS, all five candidates |
| Protected R3 0.4 | byte-identical, 1517 chars, sha256 prefix `5308df97989437b9` |
| Protected R3 2.4 | byte-identical, 3661 chars, `5d3ff750e7504d10` |
| Protected R3 section 3 | byte-identical, 6210 chars, `9b0bc4884ffb147e` |
| Protected R2 section 7 (method inventory) | byte-identical, 43987 chars, `bfce3c4d0da8ef96` |
| Protected R2 4.1 | byte-identical, 874 chars, `c3c2594288635f56` |
| Protected Architecture 5C | byte-identical, 9911 chars, `540cf6bca0e8e62b` |
| Protected Proposal E_1-E_6 | byte-identical, 7064 chars, `805f7418e8e5cdc8` |
| Inserted characters plain ASCII | PASS, all five (character-level against the edited base line) |
| Base IDs kept | R3 87/87, R2 180/180, Architecture 59/59, Proposal 53/53, Register 5/5 |
| Proposal IDs in the edition set | 118/118 (incl. MRD-01..24, MRT-01..25, MRO-01..11, RK-1..6, PO-1..4, MR0-MR16, PD1-9, OD1-7, N1; T-05 now in R2 5.6) |
| Shared data paragraph | 4 copies, 1 text |
| Stale supplementary wording | none left unqualified in any candidate |
| Cross-references to new homes | all resolve |
| Owner name | absent from all outputs |

Hashes of protected blocks are SHA-256 of the block text (UTF-8) as extracted by `check_doc.py`; they are the same in base and candidate.

## 6A. Reference scan of all inserted and moved text (owner request after review v1)

Both review defects (C-01, C-02) were relics of the proposal's own section numbers that happened to resolve to unrelated local sections. `scan_refs.py` therefore lists every reference in every inserted or moved line of all five candidates (diffed against the ratified bases), not only references to new homes, and classifies it:

| Class | Count | Judgement |
|---|---|---|
| Qualified reference (R2/R3/Architecture/Proposal section x) that resolves | 90 | resolves to the intended home |
| R3 17.x reference that resolves | 127 | resolves |
| Bare "section x" / "(x)" that resolves locally | 36 | each read: all are same-document references (R2 2.5, 5.6, 8.4; R3 17; Architecture 0, 1, 5C; Proposal 0, 2.7, 3.1) or carry an explicit "proposal section" / "Proposal v0.5 section" prefix. None is a relic. |
| REVIEW: directional words and bare numbers | 42 | each read: all are local and descriptive ("algorithm below", "the quantity below", "tails below 1e-300", "earlier draws", "the preceding table", "Continuity documents above", "(0.0475)" a value); none points across a move |
| Unresolved | 0 | |

A separate sweep of bare decimal tokens in R2 2.5 / 3.6 / 5.6 / 8.4, Architecture 5A.4 / 12.5 / 20A and Proposal 2.7 found only C-01 (now fixed); R3 section 17 had been swept the same way in v1. After v2: "(3.8)" in R2 and "Sections 6 and 10" in R3 occur 0 times. The full lists are in the check output and reproducible with `scan_refs.py --all`.

## 7. How to reproduce

From a folder holding `base/` (the six ratified blobs from `git show 618fe48:doc/<file>`), `draft/` (empty) and `tools/` (the packaged scripts), run `sh tools/run_all.sh > draft/check_output.txt`. It runs, with Python 3 `-I`:
1. `build_s17.py`, then `xref_s17.py` (builds section 17).
2. `assemble_r3.py`, `assemble_r2.py`, `assemble_arch.py`, `assemble_prop.py`, then `assemble_reg.py` (register last; it hashes the drafts).
3. `check_doc.py` per document with the protected-block patterns, then `cross_checks.py`, `account_mr.py` and `scan_refs.py`.

Every replacement in the assemble scripts must match exactly once, or the script stops.

## 8. After review

ChatGPT's focused check of v2 -> the owner ratifies -> install package -> Claude verifies the installed files against Git HEAD. Candidate-status changes must cover the four governing editions **and register v0.4 itself**, with consistent hierarchy/present-authority rows, the completed stage-0 line, and historical labelling of the predecessor inventory. Regenerate all resulting file hashes and the external manifest identity before the project owner's ratification and post-commit verification. Cosmetic, not worth a revision: reviewer handover v10 still gives pre-move paths for the interim note (its section 4) and for v9 / coder v1.0r1 (its section 7); their hashes are correct.

*End of note.*
