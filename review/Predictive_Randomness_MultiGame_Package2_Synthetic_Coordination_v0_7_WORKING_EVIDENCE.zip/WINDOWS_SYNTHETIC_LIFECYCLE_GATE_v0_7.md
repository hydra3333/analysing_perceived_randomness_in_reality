# Package 2 — Windows coordinator lifecycle acceptance gate (draft)

**Status: NOT RUN; NOT AUTHORISED FOR SCIENTIFIC COORDINATION.**

This is a proposed *future test plan*, not a runnable coordinator command. It must be independently reviewed and explicitly authorised after the remaining scientific synthetic-launch integration is complete. The authorisation to write code is not permission to run the Windows process-supervision test or to change either safety switch.

## Before execution

- Confirm current Git HEAD, coordinator source SHA-256, fresh Windows .venv, psutil, Windows `cmd.exe` root, and known exact test source identities.
- Confirm the persistent global `UNRESOLVED_ORPHAN.json` is absent, including symlink/ambiguous cases. **Never delete or clear an unresolved marker automatically.** If one exists, STOP and use separately ratified manual inspection/archival process.
- Review the final coordinator diff against v0.6 SHA-256 `2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b`. Independently review all revised launch, status, manifest and receipt code.
- `ENABLE_PROCESS_TERMINATION = False` remains mandatory. No `taskkill` fallback or PID-only signals. Keep `ENABLE_SCIENTIFIC_COORDINATION = False` until a distinct owner-authorised test mechanism is reviewed.
- Ensure synthetic tests cannot open `source_data/`, real results, Powerball holdout or Oz Lotto data.

## Cases requiring Windows evidence

1. `Popen` root identity: capture `cmd.exe` PID and creation time from handle, then record verified descendant `python.exe` PID, creation time and process ancestry **while alive**. Deliberately short-lived worker must fail closed if ancestry was never captured.
2. Status STARTED and immutable run identity: group ID, worker sequence, run ID, game, target and method must match coordinator's launch request. Wrong variant, target or group must fail even if files otherwise look correct.
3. Console BEGIN/RESULT/DIGEST/FINISH: exact canonical byte agreement; reordered, duplicated, missing or altered markers fail. Confirm reader pipe EOF and all readers are done before group publication.
4. Genuine wrapper exit: receipt only if the coordinator observed `Popen.poll()` exit with code 0 and recorded that UTC at first observation; verify no known or uncertain descendants remain; root and status process identities match verified ancestry.
5. Group PASS manifest and coordinator-only receipt: create-only under group `receipts/`, missing/colliding/symlinked receipt FAIL. Method cannot create receipt or assert group exit. Consumer checks marker/group/status/manifest/hashes before opening and returns exactly one verified object, never reopens path.
6. Failure/timeout/exception, abrupt exit or status-less worker: no receipt, no consumable result. If root or status process is alive/unknown, persistent unresolved-orphan marker and no later launch. Human inspection/archival for recovery; no automated kill or cleanup.
7. Non-scientific plumbing probe: confirm it is refused by scientific consumption even if all synthetic receipt fields match.
8. Single-barrel `OZLOTTO` synthetic fixture and `POWERBALL` frozen golden regressions remain separate, with two different games sharing a draw number. Real Oz Lotto holdout unsealed and inaccessible.

## Acceptance evidence required

Full Windows version/environment transcript, code+fixture hashes, dry-run command lines, root/descendant identity and creation-time logs, group PASS/FAIL files, receipt hashes and consumption denials, normal and adverse cases, and a statement that no termination signals or live scraping occurred. Any orphan case triggers a safety STOP, not an automatic retry.

**Unresolved:** a coordinator-reviewed synthetic E-method launch path and deterministic live-process ancestry handshake remain to be implemented; the current isolated launcher only constructs arguments. This plan is NOT executable acceptance evidence.
