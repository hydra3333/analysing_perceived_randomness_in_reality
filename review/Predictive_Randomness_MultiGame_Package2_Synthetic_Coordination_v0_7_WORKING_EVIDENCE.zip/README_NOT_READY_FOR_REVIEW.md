# Package 2 — synthetic coordinator-plumbing working evidence v0.7

**NOT CODE-COMPLETE. NOT INSTALLED. NOT AN EXECUTABLE COORDINATED METHOD RELEASE. NOT THE CONSOLIDATED CLAUDE REVIEW OVERLAY.**

This is a bounded intermediate engineering snapshot based on the retained Package-2 working copy. Only the files shown under `repo_overlay/` are new/modified in this increment. Retain Foundation v0.1, Source v0.3, Console/Scoring v0.4, Receipt-Corrections v0.6 for reconstruction. The final package must be generated afresh against a verified GitHub HEAD, with one single manifest, full tests and coordinator diff against exact v0.6 SHA-256 `2e23d55049afa8cf336a14e60d7ee52f3ea5043fda442da4d6837f81f79c762b`.

## Implemented in this increment

1. Coordinator-private **pure** game-qualified synthetic launch specification, validated against frozen profiles, registry, development bounds and safe ASCII arguments; **does not execute processes**.
2. Separate method-side handshake validator; methods never import coordinator-private issuance code.
3. Self-reporting **synthetic plumbing-only** method with durable STARTED/SUCCESS status, immutable canonical result and worker manifest, and exact BEGIN/RESULT/DIGEST/FINISH console publication. It is not a scientific forecast, has no dataset reader and emits no scoreable predictions.
4. Worker manifest explicitly says `worker_exit_certified: false` and `coordinator_receipt_required: true`. It cannot attest wrapper exit or group PASS.
5. Receipt consumer refuses a synthetic plumbing record even if receipt and artifact hashes agree, so tests cannot masquerade as science.
6. 11 new offline tests (79/79 multi-game total, 13/13 original E_1). No actual Windows Popen, live website, holdout, scoring or process-kill tests were run.

## PENDING — DO NOT CLAIM COMPLETION

- Actual game-qualified coordinator Popen dispatch, owned run-root/ID handshake, and worker ancestry capture with short-lived Windows process timing. **Not yet integrated** into the executable coordinator; existing `--poc` parser is unchanged.
- Windows coordinator lifecycle/orphan/collision/receipt acceptance under independently reviewed owner gate. See `WINDOWS_SYNTHETIC_LIFECYCLE_GATE_v0_7.md` (plan, not executable evidence).
- Consolidation of all checkpoints, exact Powerball regression/full test transcript and final Claude review against current live HEAD.
- Live scraping (Package 3) and Oz Lotto science remain separately gated.

**Safety:** `ENABLE_PROCESS_TERMINATION = False` and `ENABLE_SCIENTIFIC_COORDINATION = False`; POC coordinator itself is UNCHANGED in this v0.7 overlay, and six safety function bodies were rechecked identical against its v0.6 baseline. Never flip a switch to run these tests; no manual or automated orphan bypass.
