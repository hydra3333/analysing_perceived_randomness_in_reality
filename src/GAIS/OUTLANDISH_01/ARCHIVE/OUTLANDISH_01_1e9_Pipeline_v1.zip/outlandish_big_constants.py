#!/usr/bin/env python3
"""OUTLANDISH_01 -- create/verify numeric-byte pi and phi digit streams.

Standalone; no lottery data, no network, no project modules.  The optional
'generate' subcommand explicitly launches the owner's local y-cruncher.
Conversion input must be PLAIN ASCII decimal digits, optional decimal point
immediately after first integer digit, optional whitespace; no headers.
Output byte i is numeric decimal digit 0..9, INCLUDING the integer digit.
"""
from __future__ import annotations

import argparse
import hashlib
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile
import time

CHUNK = 4 * 1024 * 1024
WHITESPACE = b' \t\r\n'
TABLE = bytes((v - 48) if 48 <= v <= 57 else 255 for v in range(256))
PREFIXES = {
    'pi': b'31415926535897932384626433832795',
    'phi': b'16180339887498948482045868343656',
}
FILE_STEMS = {'pi': 'digits_pi_', 'phi': 'digits_golden_ratio_'}


def display_cmd(args: list[str]) -> str:
    return subprocess.list2cmdline(args) if os.name == 'nt' else shlex.join(args)


def get_exe(explicit: str | None) -> Path:
    if explicit:
        p = Path(explicit)
    else:
        matches = sorted(Path.cwd().glob('y-cruncher*/y-cruncher.exe'))
        if len(matches) != 1:
            raise ValueError('expected one y-cruncher*/y-cruncher.exe beneath current folder; use --exe')
        p = matches[0]
    if not p.is_file():
        raise FileNotFoundError(f'y-cruncher executable not found: {p}')
    return p.resolve()


def ycmd(exe: Path, const: str, digits: int, output: Path) -> list[str]:
    # y-cruncher -dec requests FRACTIONAL digits.  We need N decimal digits
    # INCLUDING the integer digit.  MUST BE VALIDATED by owner's 1e6 local smoke test.
    return [str(exe), 'custom', 'pi' if const == 'pi' else 'goldenratio',
            f'-dec:{digits-1}', '-hex:0', '-o', str(output), '-od:1',
            '-compress:0', '-verify:1', '-TD:1', '-PF:none']


def output_dir(root: Path, const: str, digits: int) -> Path:
    return (root / f'{const}_{digits}_digits').resolve()


def generate(args) -> None:
    exe = get_exe(args.exe)
    root = args.output_root.resolve()
    constants = ('pi', 'phi') if args.constant == 'both' else (args.constant,)
    for const in constants:
        out = output_dir(root, const, args.digits)
        cmd = ycmd(exe, const, args.digits, out)
        print(f'[{const}] TARGET: {args.digits:,} digits INCLUDING leading integer digit.', flush=True)
        print(f'[{const}] y-cruncher DECIMAL PLACES: {args.digits - 1:,}', flush=True)
        print(f'[{const}] OUTPUT FOLDER: {out}', flush=True)
        print(f'[{const}] COMMAND: {display_cmd(cmd)}', flush=True)
        if args.run:
            # Prevent accidentally adding more y-cruncher files to existing output.
            if out.exists():
                raise FileExistsError(f'will not generate into existing directory: {out}')
            if root.exists() and root.is_symlink():
                raise ValueError('refusing symlinked output root')
            if shutil.disk_usage(root if root.exists() else root.parent).free < args.digits * 2:
                print('WARNING: less than 2x target bytes free; input text + binary conversion need workspace.', flush=True)
            out.mkdir(parents=True, exist_ok=False)
            print(f'[{const}] Running local y-cruncher (single-thread command options).', flush=True)
            t0 = time.perf_counter()
            completed = subprocess.run(cmd, check=False)
            print(f'[{const}] y-cruncher exit code: {completed.returncode}, elapsed: {time.perf_counter()-t0:.1f}s', flush=True)
            if completed.returncode:
                raise RuntimeError(f'y-cruncher failed; inspect its own output in {out}')
            print(f'[{const}] Check output file names and text format using inspect before converting.', flush=True)


def inspect_folder(folder: Path):
    if not folder.is_dir():
        raise FileNotFoundError(folder)
    items = sorted(x for x in folder.rglob('*') if x.is_file())
    print(f'{len(items)} files under {folder}')
    for f in items:
        rel = f.relative_to(folder)
        print(f'{rel}: {f.stat().st_size:,} bytes')
        if f.suffix.lower() == '.txt':
            with f.open('rb') as h:
                b = h.read(90)
            print('  first 90 bytes:', repr(b))
    print('Only explicitly selected, PLAIN DIGIT text input files should be passed to convert.')


def validate_reference(ref: Path | None, target_digits: int):
    if ref is None:
        return None, 0
    if not ref.is_file() or ref.is_symlink():
        raise ValueError(f'reference is not an ordinary file: {ref}')
    n = min(ref.stat().st_size, target_digits)
    if not n or n > 4_000_000:
        raise ValueError('reference must have between 1 and 4,000,000 bytes (e.g. prior million-digit file)')
    expected = ref.read_bytes()[:n]
    if any(x > 9 for x in expected):
        raise ValueError('reference is not a numeric-decimal-digit .bin file')
    return expected, n


def check_filenames(ins: list[Path], destination: Path) -> None:
    if not ins:
        raise ValueError('provide at least one --input in explicit digit order')
    if len({x.resolve() for x in ins}) != len(ins):
        raise ValueError('duplicated input file')
    if destination.exists() or destination.is_symlink():
        raise FileExistsError(f'output already exists, refusing overwrite: {destination}')
    for f in ins:
        if not f.is_file() or f.is_symlink():
            raise ValueError(f'input is missing or a symlink: {f}')
        if f.resolve() == destination.resolve():
            raise ValueError('source and destination must differ')


def convert(args):
    ins: list[Path] = args.input
    out: Path = args.output
    check_filenames(ins, out)
    expected, ref_len = validate_reference(args.reference, args.digits)
    out.parent.mkdir(parents=True, exist_ok=True)
    free = shutil.disk_usage(out.parent).free
    if free < args.digits:
        raise ValueError(f'Insufficient free space for numeric binary: need {args.digits:,} bytes, have {free:,}')
    target_prefix = bytes(c-48 for c in PREFIXES[args.constant])
    digits_seen = 0
    periods = 0
    digest = hashlib.sha256()
    t0 = time.perf_counter()
    next_report = t0 + args.progress_seconds
    tmp = None
    try:
        with tempfile.NamedTemporaryFile(mode='wb', dir=out.parent, prefix='.outlandish_build_',
                                          suffix='.tmp', delete=False) as dest:
            tmp = Path(dest.name)
            for item in ins:
                print(f'INPUT {item} ({item.stat().st_size:,} bytes)', flush=True)
                with item.open('rb') as src:
                    while raw := src.read(CHUNK):
                        if b'.' in raw:
                            count = raw.count(b'.')
                            if count != 1 or periods:
                                raise ValueError('unexpected/multiple decimal points')
                            # Count digits in this chunk BEFORE the decimal point.
                            before = raw[:raw.index(b'.')].translate(None, WHITESPACE)
                            if digits_seen + len(before) != 1:
                                raise ValueError('decimal point must immediately follow the integer digit')
                            periods += 1
                        numeric = raw.translate(None, WHITESPACE + b'.').translate(TABLE)
                        if b'\xff' in numeric:
                            raise ValueError(f'non-digit/header/metadata in {item}; inspect its first bytes')
                        if digits_seen < len(target_prefix):
                            count = min(len(numeric), len(target_prefix)-digits_seen)
                            if numeric[:count] != target_prefix[digits_seen:digits_seen+count]:
                                raise ValueError(f'{args.constant} 32-digit prefix mismatch')
                        if expected is not None and digits_seen < ref_len:
                            count = min(len(numeric), ref_len-digits_seen)
                            if numeric[:count] != expected[digits_seen:digits_seen+count]:
                                # Identify location without publishing unnecessary data.
                                raise ValueError(f'new constant digits differ from prior reference at block containing offset {digits_seen}')
                        digits_seen += len(numeric)
                        if digits_seen > args.digits:
                            raise ValueError(f'input has more than expected {args.digits:,} digits; check -dec count')
                        dest.write(numeric)
                        digest.update(numeric)
                        now = time.perf_counter()
                        if now >= next_report:
                            elapsed = max(now-t0, 1e-9)
                            print(f'CONVERT {digits_seen:,}/{args.digits:,} digits ({digits_seen/args.digits:.1%}); '
                                  f'{digits_seen/elapsed/1e6:.1f} MB/s', flush=True)
                            next_report = now + args.progress_seconds
            if digits_seen != args.digits:
                raise ValueError(f'input digit count {digits_seen:,}, expected {args.digits:,}')
        os.replace(tmp, out)
        tmp = None
    finally:
        if tmp is not None and tmp.exists():
            tmp.unlink()
    print(f'CONVERSION PASS: {args.constant} {digits_seen:,} numeric digit bytes ({time.perf_counter()-t0:.1f}s)')
    print(f'OUTPUT {out}; SHA-256 {digest.hexdigest()}')
    if expected is not None:
        print(f'PREVIOUS {ref_len:,}-digit reference prefix MATCHES: {args.reference}')


def verify(args):
    inp: Path = args.input_file
    if not inp.is_file() or inp.is_symlink():
        raise ValueError('input binary must be a regular file, not a symlink')
    if inp.stat().st_size != args.digits:
        raise ValueError(f'file size {inp.stat().st_size:,} bytes, expected {args.digits:,}')
    expected, reflen = validate_reference(args.reference, args.digits)
    known = bytes(c-48 for c in PREFIXES[args.constant])
    n = 0
    sha = hashlib.sha256()
    start = time.perf_counter()
    next_report = start+args.progress_seconds
    with inp.open('rb') as src:
        while chunk := src.read(CHUNK):
            if n < len(known):
                count = min(len(chunk), len(known)-n)
                if chunk[:count] != known[n:n+count]:
                    raise ValueError('known 32-digit constant prefix mismatch')
            if expected is not None and n < reflen:
                count = min(len(chunk), reflen-n)
                if chunk[:count] != expected[n:n+count]:
                    raise ValueError(f'first {reflen:,} digits do not match reference')
            if max(chunk, default=0) > 9:
                raise ValueError(f'invalid binary numeric digit in chunk beginning at {n:,}')
            sha.update(chunk)
            n += len(chunk)
            now = time.perf_counter()
            if now >= next_report:
                print(f'VERIFY {n:,}/{args.digits:,} ({n/args.digits:.1%})', flush=True)
                next_report = now + args.progress_seconds
    if n != args.digits:
        raise ValueError('file changed during verification')
    print(f'VERIFY PASS {args.constant} {n:,} digits; SHA-256 {sha.hexdigest()}; elapsed {time.perf_counter()-start:.1f}s')
    if expected is not None:
        print(f'PREVIOUS {reflen:,}-digit reference prefix MATCHES: {args.reference}')


def self_test():
    with tempfile.TemporaryDirectory() as folder:
        p = Path(folder)
        for const in ('pi', 'phi'):
            prefix = PREFIXES[const]
            n = len(prefix)
            expected = bytes(x-48 for x in prefix)
            (p/'reference.bin').write_bytes(expected)
            (p/'head.txt').write_bytes(prefix[:1] + b'. ' + prefix[1:11] + b'\n')
            (p/'tail.txt').write_bytes(prefix[11:])
            opts = argparse.Namespace(input=[p/'head.txt', p/'tail.txt'], output=p/f'{const}.bin',
                                      reference=p/'reference.bin', constant=const, digits=n,
                                      progress_seconds=999)
            convert(opts)
            verify(argparse.Namespace(input_file=opts.output, reference=opts.reference,
                                      constant=const, digits=n, progress_seconds=999))
            assert opts.output.read_bytes() == expected
            opts2 = argparse.Namespace(input=[p/'head.txt', p/'tail.txt'], output=p/f'{const}_error.bin',
                                       reference=opts.reference, constant=const, digits=n-1,
                                       progress_seconds=999)
            try:
                convert(opts2)
            except ValueError as exc:
                assert 'more than expected' in str(exc)
            else:
                raise AssertionError('extra digit should refuse')
            assert not opts2.output.exists()
            (p/'head_bad.txt').write_bytes(b'HEADER' + prefix[:1]+b'.'+prefix[1:11])
            opts3 = argparse.Namespace(input=[p/'head_bad.txt', p/'tail.txt'], output=p/f'{const}_bad.bin',
                                       reference=opts.reference, constant=const, digits=n,
                                       progress_seconds=999)
            try:
                convert(opts3)
            except ValueError:
                pass
            else:
                raise AssertionError('metadata should refuse')
            assert not opts3.output.exists()
    print('SELF-TEST PASS: pi/phi, split text, decimal point, reference prefix, extra digits, metadata refusal')


def main():
    p = argparse.ArgumentParser(description=__doc__)
    sub = p.add_subparsers(dest='command', required=True)
    g = sub.add_parser('generate', help='print or explicitly run local y-cruncher command')
    g.add_argument('--digits', type=int, required=True, help='total digit count including leading integer digit')
    g.add_argument('--constant', choices=('pi', 'phi', 'both'), default='both')
    g.add_argument('--output-root', type=Path, default=Path('ycruncher_digits'))
    g.add_argument('--exe', help='path to local y-cruncher.exe; auto-detect if absent')
    g.add_argument('--run', action='store_true', help='actually execute y-cruncher (otherwise dry run)')
    i = sub.add_parser('inspect', help='list generated files, show first 90 bytes of .txt files')
    i.add_argument('--folder', type=Path, required=True)
    c = sub.add_parser('convert', help='text digit files in stated order to numeric-byte stream')
    c.add_argument('--constant', choices=('pi', 'phi'), required=True)
    c.add_argument('--digits', type=int, required=True)
    c.add_argument('--input', nargs='+', type=Path, required=True, help='one or more plain digit text files in exact order')
    c.add_argument('--output', type=Path, required=True)
    c.add_argument('--reference', type=Path, help='prior trusted 1e6 .bin file; prefix must match')
    c.add_argument('--progress-seconds', type=float, default=5)
    v = sub.add_parser('verify', help='check numeric-byte file length, values and previous prefix')
    v.add_argument('--constant', choices=('pi', 'phi'), required=True)
    v.add_argument('--digits', type=int, required=True)
    v.add_argument('--input-file', type=Path, required=True)
    v.add_argument('--reference', type=Path)
    v.add_argument('--progress-seconds', type=float, default=5)
    sub.add_parser('self-test', help='invented text conversion and negative-case tests')
    a = p.parse_args()
    if a.command in {'generate', 'convert', 'verify'} and a.digits < 33:
        p.error('--digits must be >= 33')
    if a.command in {'convert', 'verify'} and a.progress_seconds <= 0:
        p.error('--progress-seconds must be positive')
    if a.command == 'generate':
        generate(a)
    elif a.command == 'inspect':
        inspect_folder(a.folder)
    elif a.command == 'convert':
        convert(a)
    elif a.command == 'verify':
        verify(a)
    else:
        self_test()


if __name__ == '__main__':
    try:
        main()
    except (ValueError, FileNotFoundError, OSError, RuntimeError) as exc:
        print(f'ERROR: {exc}', file=sys.stderr)
        raise SystemExit(2)
